#!/usr/bin/env python3
"""VGHL Meta-Analysis: When does geometry help?

Runs VGHL + baselines on a large diverse set of datasets, computes
meta-features for each, and correlates with VGHL lift to identify
what predicts when geometric structure aids computation.

New datasets added (beyond existing 20):
  - Large embedding: CIFAR-100 ResNet-18, SVHN ResNet-18, STL-10 ResNet-18
  - Large tabular: shuttle, magic, texture, phoneme, vehicle, connect-4
  - Small complex: ecoli, yeast, glass, dermatology, vowel, balance_scale
  - High-dim: isolet (617d), mfeat-fourier, mfeat-karhunen, madelon
  - Text: 20newsgroups with sentence-transformer embeddings

Meta-features computed per dataset:
  1. ridge_acc        - linear separability (raw features + ridge)
  2. knn_acc          - kNN accuracy (nonlinear signal available)
  3. knn_ridge_gap    - kNN - ridge: how much nonlinear structure exists
  4. intrinsic_dim    - MLE intrinsic dimensionality
  5. n_samples        - dataset size
  6. n_features       - feature dimensionality
  7. n_classes         - number of classes
  8. d_over_n         - feature-to-sample ratio
  9. silhouette       - cluster separability (sampled)
  10. label_purity    - kNN label homogeneity

Usage:
    python -u scripts/meta_analysis.py                    # all datasets
    python -u scripts/meta_analysis.py --only existing    # just the 20 we already have
    python -u scripts/meta_analysis.py --only new         # just newly added
    python -u scripts/meta_analysis.py --only large_embed # just large embedding datasets
"""
import os, sys, argparse, csv, time, warnings
import numpy as np
import torch
from pathlib import Path
from dataclasses import dataclass

warnings.filterwarnings("ignore", category=FutureWarning)
warnings.filterwarnings("ignore", category=UserWarning)

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from vghl.models.graph_builder import build_base_graph, GraphBuilderConfig
from vghl.models.propagation import propagate, PropagationConfig
from vghl.models.probe import ridge_eval, embed_queries_via_knn


def _save_csv(rows, path):
    if not rows: return
    path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    keys = list(rows[0].keys())
    extra = sorted({k for r in rows for k in r.keys()} - set(keys))
    keys.extend(extra)
    tmp = str(path) + f".tmp.{os.getpid()}"
    with open(tmp, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=keys); w.writeheader()
        for r in rows: w.writerow({k: r.get(k, "") for k in keys})
        f.flush(); os.fsync(f.fileno())
    os.replace(tmp, str(path))
    print(f"  Saved: {path}")


# ══════════════════════════════════════════════════════════════════════
# DATASET LOADING
# ══════════════════════════════════════════════════════════════════════

def load_from_vghl_loader(ds_name, seed, n_train=5000, n_val=500, n_test=2000):
    """Load via the existing VGHL data loader."""
    from vghl.utils.config import ExperimentConfig
    from vghl.data.loaders import build_datasets
    cfg = ExperimentConfig()
    cfg.data.dataset = ds_name
    cfg.data.n_train = n_train
    cfg.data.n_val = n_val
    cfg.data.n_test = n_test
    cfg.seed = seed
    tr, va, te, meta = build_datasets(cfg)
    return tr.X, tr.y, te.X, te.y, meta


def load_openml_direct(openml_id, seed, n_train=5000, n_test=2000, name=None):
    """Load dataset directly from OpenML by ID."""
    from sklearn.datasets import fetch_openml
    from sklearn.preprocessing import StandardScaler, LabelEncoder
    try:
        data = fetch_openml(data_id=openml_id, as_frame=False, parser="liac-arff")
    except Exception:
        data = fetch_openml(data_id=openml_id, as_frame=False, parser="auto")
    X, y = data.data, data.target
    if y.dtype.kind in ('U', 'S', 'O'):
        y = LabelEncoder().fit_transform(y)
    X = X.astype(np.float64)
    mask = np.isfinite(X).all(axis=1)
    X, y = X[mask], y[mask]
    if np.isnan(X).any():
        from sklearn.impute import SimpleImputer
        X = SimpleImputer(strategy="median").fit_transform(X)
    X = StandardScaler().fit_transform(X).astype(np.float32)
    y = y.astype(np.int64)
    rng = np.random.RandomState(seed)
    perm = rng.permutation(len(X))
    X, y = X[perm], y[perm]
    n_tr = min(n_train, int(len(X) * 0.7))
    n_te = min(n_test, len(X) - n_tr)
    X_tr, y_tr = X[:n_tr], y[:n_tr]
    X_te, y_te = X[n_tr:n_tr + n_te], y[n_tr:n_tr + n_te]
    nc = len(np.unique(np.concatenate([y_tr, y_te])))
    meta = {"n_classes": nc, "input_dim": X_tr.shape[1], "dataset": name or str(openml_id)}
    return (torch.tensor(X_tr), torch.tensor(y_tr, dtype=torch.long),
            torch.tensor(X_te), torch.tensor(y_te, dtype=torch.long), meta)


def load_frozen_embed(dataset_name, extractor, seed, n_train=5000, n_test=2000):
    """Load image dataset with frozen ResNet-18 embeddings."""
    from torchvision import datasets, transforms, models
    root = os.path.expanduser("~/.cache/vghl_data")
    cache_path = os.path.join(root, f"{dataset_name}_{extractor}_cache.pt")

    if os.path.exists(cache_path):
        cached = torch.load(cache_path, weights_only=True)
        X_tr, y_tr, X_te, y_te = cached["X_tr"], cached["y_tr"], cached["X_te"], cached["y_te"]
    else:
        os.makedirs(root, exist_ok=True)
        transform = transforms.Compose([
            transforms.Resize(224),
            transforms.ToTensor(),
            transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225]),
        ])

        if dataset_name == "cifar100":
            ds_train = datasets.CIFAR100(root, train=True, download=True, transform=transform)
            ds_test = datasets.CIFAR100(root, train=False, download=True, transform=transform)
        elif dataset_name == "svhn":
            ds_train = datasets.SVHN(root, split="train", download=True, transform=transform)
            ds_test = datasets.SVHN(root, split="test", download=True, transform=transform)
        elif dataset_name == "stl10":
            ds_train = datasets.STL10(root, split="train", download=True, transform=transform)
            ds_test = datasets.STL10(root, split="test", download=True, transform=transform)
        else:
            raise ValueError(f"Unknown dataset: {dataset_name}")

        # Extract features
        model = models.resnet18(weights=models.ResNet18_Weights.DEFAULT)
        model = torch.nn.Sequential(*list(model.children())[:-1])  # remove FC
        model.eval()
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        model = model.to(device)

        def extract(ds, batch_size=256):
            loader = torch.utils.data.DataLoader(ds, batch_size=batch_size, shuffle=False, num_workers=2)
            feats, labels = [], []
            with torch.no_grad():
                for batch in loader:
                    if isinstance(batch, (list, tuple)):
                        x, y = batch[0], batch[1]
                    else:
                        x, y = batch
                    x = x.to(device)
                    f = model(x).squeeze(-1).squeeze(-1).cpu()
                    feats.append(f)
                    labels.append(y if isinstance(y, torch.Tensor) else torch.tensor(y))
            return torch.cat(feats), torch.cat(labels).long()

        print(f"    Extracting {dataset_name} features with ResNet-18...", flush=True)
        X_tr, y_tr = extract(ds_train)
        X_te, y_te = extract(ds_test)
        torch.save({"X_tr": X_tr, "y_tr": y_tr, "X_te": X_te, "y_te": y_te}, cache_path)
        print(f"    Cached to {cache_path}")

    # Subsample
    rng = np.random.RandomState(seed)
    perm_tr = rng.permutation(len(X_tr))
    perm_te = rng.permutation(len(X_te))
    n_tr = min(n_train, len(X_tr))
    n_te = min(n_test, len(X_te))
    X_tr, y_tr = X_tr[perm_tr[:n_tr]], y_tr[perm_tr[:n_tr]]
    X_te, y_te = X_te[perm_te[:n_te]], y_te[perm_te[:n_te]]
    nc = max(int(y_tr.max()) + 1, int(y_te.max()) + 1)
    meta = {"n_classes": nc, "input_dim": X_tr.shape[1], "dataset": f"{dataset_name}_resnet18"}
    return X_tr, y_tr, X_te, y_te, meta


def load_newsgroups_sbert(seed, n_train=5000, n_test=2000):
    """20 Newsgroups with sentence-transformer embeddings (384d)."""
    root = os.path.expanduser("~/.cache/vghl_data")
    cache_path = os.path.join(root, "newsgroups_sbert_cache.pt")

    if os.path.exists(cache_path):
        cached = torch.load(cache_path, weights_only=True)
        X_tr, y_tr, X_te, y_te = cached["X_tr"], cached["y_tr"], cached["X_te"], cached["y_te"]
    else:
        os.makedirs(root, exist_ok=True)
        from sklearn.datasets import fetch_20newsgroups
        try:
            from sentence_transformers import SentenceTransformer
            train = fetch_20newsgroups(subset='train')
            test = fetch_20newsgroups(subset='test')
            model = SentenceTransformer('all-MiniLM-L6-v2')
            print("    Encoding newsgroups with sentence-transformers...", flush=True)
            X_tr = torch.tensor(model.encode(train.data, show_progress_bar=True, batch_size=256),
                                dtype=torch.float32)
            X_te = torch.tensor(model.encode(test.data, show_progress_bar=True, batch_size=256),
                                dtype=torch.float32)
            y_tr = torch.tensor(train.target, dtype=torch.long)
            y_te = torch.tensor(test.target, dtype=torch.long)
            torch.save({"X_tr": X_tr, "y_tr": y_tr, "X_te": X_te, "y_te": y_te}, cache_path)
        except ImportError:
            print("    sentence-transformers not installed, skipping newsgroups_sbert")
            return None

    rng = np.random.RandomState(seed)
    n_tr = min(n_train, len(X_tr))
    n_te = min(n_test, len(X_te))
    perm = rng.permutation(len(X_tr))
    X_tr, y_tr = X_tr[perm[:n_tr]], y_tr[perm[:n_tr]]
    perm2 = rng.permutation(len(X_te))
    X_te, y_te = X_te[perm2[:n_te]], y_te[perm2[:n_te]]
    nc = max(int(y_tr.max()) + 1, int(y_te.max()) + 1)
    meta = {"n_classes": nc, "input_dim": X_tr.shape[1], "dataset": "newsgroups_sbert"}
    return X_tr, y_tr, X_te, y_te, meta


# ══════════════════════════════════════════════════════════════════════
# DATASET REGISTRY
# ══════════════════════════════════════════════════════════════════════

# (name, loader_type, loader_args, default_k)
EXISTING_DATASETS = [
    ("iris", "vghl", {}, 8),
    ("wine", "vghl", {}, 12),
    ("breast_cancer", "vghl", {}, 16),
    ("digits", "vghl", {}, 16),
    ("diabetes", "vghl", {}, 12),
    ("california_housing", "vghl", {"n_train": 5000, "n_test": 1000}, 16),
    ("segment", "vghl", {}, 16),
    ("waveform", "vghl", {"n_train": 3000, "n_test": 500}, 16),
    ("satellite", "vghl", {"n_train": 3000, "n_test": 500}, 16),
    ("pendigits", "vghl", {"n_train": 5000, "n_test": 1000}, 16),
    ("optdigits", "vghl", {"n_train": 3000, "n_test": 500}, 16),
    ("letter", "vghl", {"n_train": 5000, "n_test": 1000}, 16),
    ("covertype", "vghl", {"n_train": 5000, "n_test": 1000}, 16),
    ("adult", "vghl", {"n_train": 5000, "n_test": 1000}, 16),
    ("mnist_embed", "vghl", {"n_train": 5000, "n_test": 1000}, 16),
    ("fmnist_embed", "vghl", {"n_train": 5000, "n_test": 1000}, 16),
    ("cifar10_pca", "vghl", {"n_train": 5000, "n_test": 1000}, 16),
    ("cifar10_resnet18", "vghl", {"n_train": 5000, "n_test": 1000}, 16),
    ("newsgroups_embed", "vghl", {"n_train": 3000, "n_test": 500}, 16),
    ("cora", "vghl", {}, 16),
]

NEW_OPENML_DATASETS = [
    # (name, openml_id, n_train, n_test, k, description)
    ("shuttle", 40685, 5000, 2000, 16, "9d, 7-class, 58000 samples"),
    ("magic", 1120, 5000, 2000, 16, "10d, 2-class, 19020 - gamma ray"),
    ("texture", 40499, 3000, 1000, 16, "40d, 11-class, 5500 - Brodatz textures"),
    ("phoneme", 1489, 3000, 1000, 16, "5d, 2-class, 5404 - speech"),
    ("vehicle", 54, 0, 0, 12, "18d, 4-class, 846 - vehicle silhouettes"),
    ("ecoli", 39, 0, 0, 8, "7d, 8-class, 336 - protein localization"),
    ("yeast", 181, 0, 0, 8, "8d, 10-class, 1484 - protein localization"),
    ("glass", 41, 0, 0, 8, "9d, 6-class, 214 - glass identification"),
    ("vowel", 307, 0, 0, 12, "10d, 11-class, 990 - vowel recognition"),
    ("balance_scale", 11, 0, 0, 8, "4d, 3-class, 625"),
    ("isolet", 300, 3000, 1000, 16, "617d, 26-class, 7797 - spoken letters"),
    ("mfeat_fourier", 14, 0, 0, 16, "76d, 10-class, 2000 - digit features"),
    ("mfeat_karhunen", 16, 0, 0, 16, "64d, 10-class, 2000 - digit features"),
    ("madelon", 1485, 0, 0, 16, "500d, 2-class, 2600 - artificial"),
    ("connect_4", 40668, 5000, 2000, 16, "42d, 3-class, 67557"),
    ("har", 1478, 3000, 1000, 16, "561d, 6-class, 10299 - human activity"),
    ("steel_plates", 1504, 0, 0, 16, "27d, 7-class, 1941"),
    ("wall_robot", 1497, 3000, 1000, 16, "24d, 4-class, 5456 - robot navigation"),
    ("gas_drift", 1476, 5000, 2000, 16, "128d, 6-class, 13910 - gas sensor"),
]

LARGE_EMBED_DATASETS = [
    # (name, extractor, n_train, n_test, k)
    ("cifar100", "resnet18", 5000, 2000, 16),
    ("svhn", "resnet18", 5000, 2000, 16),
    ("stl10", "resnet18", 4000, 1000, 16),
]


# ══════════════════════════════════════════════════════════════════════
# META-FEATURE COMPUTATION
# ══════════════════════════════════════════════════════════════════════

def compute_meta_features(X_tr, y_tr, k=16):
    """Compute dataset meta-features that might predict VGHL effectiveness."""
    N, d = X_tr.shape
    nc = int(y_tr.max()) + 1
    X_np = X_tr.numpy() if isinstance(X_tr, torch.Tensor) else X_tr

    result = {
        "n_samples": N,
        "n_features": d,
        "n_classes": nc,
        "d_over_n": d / N,
        "log_n": np.log10(max(N, 1)),
    }

    # 1. Intrinsic dimensionality (MLE estimator)
    try:
        from sklearn.neighbors import NearestNeighbors
        k_id = min(20, N - 1)
        nn = NearestNeighbors(n_neighbors=k_id, algorithm='brute', n_jobs=-1)
        nn.fit(X_np[:min(N, 5000)])  # subsample for speed
        dists, _ = nn.kneighbors()
        dists = dists[:, 1:]  # remove self
        dists = np.maximum(dists, 1e-10)
        # Levina-Bickel MLE
        log_ratios = np.log(dists[:, -1:] / dists[:, :-1])
        id_est = (k_id - 2) / log_ratios.sum(axis=1)
        result["intrinsic_dim"] = float(np.median(id_est))
        result["id_over_d"] = result["intrinsic_dim"] / max(d, 1)
    except Exception:
        result["intrinsic_dim"] = float('nan')
        result["id_over_d"] = float('nan')

    # 2. Silhouette score (sampled)
    try:
        from sklearn.metrics import silhouette_score
        n_samp = min(5000, N)
        idx = np.random.RandomState(0).choice(N, n_samp, replace=False) if N > n_samp else np.arange(N)
        result["silhouette"] = float(silhouette_score(X_np[idx], y_tr.numpy()[idx],
                                                       sample_size=min(2000, n_samp)))
    except Exception:
        result["silhouette"] = float('nan')

    # 3. kNN label purity
    try:
        from sklearn.neighbors import NearestNeighbors
        k_lp = min(k, N - 1)
        nn = NearestNeighbors(n_neighbors=k_lp + 1, algorithm='brute', n_jobs=-1)
        nn.fit(X_np)
        _, indices = nn.kneighbors()
        y_np = y_tr.numpy()
        # Fraction of neighbors with same label (excluding self)
        neighbor_labels = y_np[indices[:, 1:]]
        purity = (neighbor_labels == y_np[:, None]).mean()
        result["label_purity"] = float(purity)
    except Exception:
        result["label_purity"] = float('nan')

    # 4. Between/within class variance ratio (Fisher criterion)
    try:
        global_mean = X_np.mean(axis=0)
        sw = 0.0  # within-class scatter (trace)
        sb = 0.0  # between-class scatter (trace)
        for c in range(nc):
            mask = y_tr.numpy() == c
            if mask.sum() < 2: continue
            X_c = X_np[mask]
            mu_c = X_c.mean(axis=0)
            sw += ((X_c - mu_c) ** 2).sum()
            sb += mask.sum() * ((mu_c - global_mean) ** 2).sum()
        result["fisher_ratio"] = float(sb / max(sw, 1e-10))
    except Exception:
        result["fisher_ratio"] = float('nan')

    # 5. Class balance (entropy of class distribution)
    try:
        counts = np.bincount(y_tr.numpy(), minlength=nc).astype(float)
        probs = counts / counts.sum()
        probs = probs[probs > 0]
        result["class_entropy"] = float(-np.sum(probs * np.log2(probs)) / np.log2(max(nc, 2)))
    except Exception:
        result["class_entropy"] = float('nan')

    return result


# ══════════════════════════════════════════════════════════════════════
# EVALUATION
# ══════════════════════════════════════════════════════════════════════

def evaluate_dataset(X_tr, y_tr, X_te, y_te, k=16, name="unknown"):
    """Run full evaluation suite on one dataset. Returns dict of results."""
    N, d = X_tr.shape
    nc = max(int(y_tr.max()) + 1, int(y_te.max()) + 1)
    k_eff = min(k, N - 1)

    results = {"dataset": name, "N": N, "d": d, "C": nc}

    # 1. Ridge on raw features (linear separability)
    try:
        results["ridge_acc"] = ridge_eval(X_tr, y_tr, X_te, y_te, n_classes=nc)
    except Exception as e:
        results["ridge_acc"] = -1.0
        print(f"    ridge failed: {e}")

    # 2. kNN baseline
    try:
        from sklearn.neighbors import KNeighborsClassifier
        knn_clf = KNeighborsClassifier(n_neighbors=k_eff, n_jobs=-1)
        knn_clf.fit(X_tr.numpy(), y_tr.numpy())
        results["knn_acc"] = float(knn_clf.score(X_te.numpy(), y_te.numpy()))
    except Exception as e:
        results["knn_acc"] = -1.0
        print(f"    knn failed: {e}")

    # 3. VGHL: standard pipeline (random_walk, T=5)
    try:
        gc = GraphBuilderConfig(type="knn", k=k_eff)
        pc = PropagationConfig(type="random_walk", steps=5)
        g = build_base_graph(X_tr, gc)
        h = propagate(X_tr, g["edge_index"], g["edge_weight"], N, pc)
        h_te = embed_queries_via_knn(h, X_tr, X_te, k=k_eff)
        results["vghl_rw_T5"] = ridge_eval(h, y_tr, h_te, y_te, n_classes=nc)
    except Exception as e:
        results["vghl_rw_T5"] = -1.0
        print(f"    vghl_rw_T5 failed: {e}")

    # 4. VGHL: T=1 (minimal smoothing)
    try:
        pc1 = PropagationConfig(type="random_walk", steps=1)
        h1 = propagate(X_tr, g["edge_index"], g["edge_weight"], N, pc1)
        h_te1 = embed_queries_via_knn(h1, X_tr, X_te, k=k_eff)
        results["vghl_rw_T1"] = ridge_eval(h1, y_tr, h_te1, y_te, n_classes=nc)
    except Exception:
        results["vghl_rw_T1"] = -1.0

    # 5. VGHL: PPR (α=0.85, preserves most raw signal)
    try:
        pc_ppr = PropagationConfig(type="ppr", steps=5, alpha=0.85)
        h_ppr = propagate(X_tr, g["edge_index"], g["edge_weight"], N, pc_ppr)
        h_te_ppr = embed_queries_via_knn(h_ppr, X_tr, X_te, k=k_eff)
        results["vghl_ppr85"] = ridge_eval(h_ppr, y_tr, h_te_ppr, y_te, n_classes=nc)
    except Exception:
        results["vghl_ppr85"] = -1.0

    # 6. VGHL: concat [raw || propagated]
    try:
        H_cat = torch.cat([X_tr, h], dim=1)
        H_te_cat = torch.cat([X_te, h_te], dim=1)
        results["vghl_concat_T5"] = ridge_eval(H_cat, y_tr, H_te_cat, y_te, n_classes=nc)
    except Exception:
        results["vghl_concat_T5"] = -1.0

    # 7. Random edges (chance-level control)
    try:
        E = g["edge_index"].shape[1]
        rng = np.random.RandomState(42)
        rs = torch.tensor(rng.randint(0, N, E), dtype=torch.long)
        rd = torch.tensor(rng.randint(0, N, E), dtype=torch.long)
        valid = rs != rd
        ei_r = torch.stack([rs[valid], rd[valid]])
        ew_r = torch.ones(ei_r.shape[1])
        h_r = propagate(X_tr, ei_r, ew_r, N, pc)
        h_te_r = embed_queries_via_knn(h_r, X_tr, X_te, k=k_eff)
        results["random_edges"] = ridge_eval(h_r, y_tr, h_te_r, y_te, n_classes=nc)
    except Exception:
        results["random_edges"] = -1.0

    # 8. Label propagation (pure geometry, no ridge)
    try:
        Y = torch.zeros(N, nc, dtype=torch.float32)
        Y.scatter_(1, y_tr.unsqueeze(1).long(), 1.0)
        pc_lp = PropagationConfig(type="random_walk", steps=5)
        Y_prop = propagate(Y, g["edge_index"], g["edge_weight"], N, pc_lp)
        Y_te_lp = embed_queries_via_knn(Y_prop, X_tr, X_te, k=k_eff)
        results["label_prop_T5"] = float((Y_te_lp.argmax(dim=1) == y_te).float().mean())
    except Exception:
        results["label_prop_T5"] = -1.0

    # Derived
    results["best_vghl"] = max(results.get("vghl_rw_T5", 0),
                                results.get("vghl_rw_T1", 0),
                                results.get("vghl_ppr85", 0),
                                results.get("vghl_concat_T5", 0))
    results["vghl_lift_vs_ridge"] = results["best_vghl"] - results.get("ridge_acc", 0)
    results["vghl_lift_vs_knn"] = results["best_vghl"] - results.get("knn_acc", 0)
    results["geometry_collapse"] = results["best_vghl"] - results.get("random_edges", 0)
    results["knn_ridge_gap"] = results.get("knn_acc", 0) - results.get("ridge_acc", 0)

    return results


# ══════════════════════════════════════════════════════════════════════
# MAIN RUNNER
# ══════════════════════════════════════════════════════════════════════

def run_meta_analysis(dataset_group, seeds, out_dir):
    print(f"\n{'='*70}")
    print(f"META-ANALYSIS: {dataset_group}")
    print(f"{'='*70}")

    all_rows = []

    def process_dataset(name, X_tr, y_tr, X_te, y_te, k, seed):
        N, d = X_tr.shape
        nc = max(int(y_tr.max()) + 1, int(y_te.max()) + 1)
        print(f"\n  {name} (N={N}, d={d}, C={nc}, seed={seed})...")

        # Meta-features
        meta = compute_meta_features(X_tr, y_tr, k=k)

        # Evaluation
        results = evaluate_dataset(X_tr, y_tr, X_te, y_te, k=k, name=name)
        results["seed"] = seed
        results.update(meta)

        print(f"    ridge={results['ridge_acc']:.4f} knn={results['knn_acc']:.4f} "
              f"vghl_best={results['best_vghl']:.4f} "
              f"lift={results['vghl_lift_vs_ridge']:+.4f} "
              f"collapse={results['geometry_collapse']:+.4f}")
        return results

    for seed in seeds:
        # Existing datasets
        if dataset_group in ("all", "existing"):
            for ds_name, loader_type, loader_args, k in EXISTING_DATASETS:
                try:
                    X_tr, y_tr, X_te, y_te, meta = load_from_vghl_loader(
                        ds_name, seed, **loader_args)
                    all_rows.append(process_dataset(ds_name, X_tr, y_tr, X_te, y_te, k, seed))
                except Exception as e:
                    print(f"  SKIP {ds_name}: {e}")

        # New OpenML datasets
        if dataset_group in ("all", "new", "new_openml"):
            for ds_name, openml_id, n_tr, n_te, k, desc in NEW_OPENML_DATASETS:
                try:
                    n_tr_eff = n_tr if n_tr > 0 else 0
                    n_te_eff = n_te if n_te > 0 else 0
                    X_tr, y_tr, X_te, y_te, meta = load_openml_direct(
                        openml_id, seed, n_train=max(n_tr_eff, 500), n_test=max(n_te_eff, 200),
                        name=ds_name)
                    all_rows.append(process_dataset(ds_name, X_tr, y_tr, X_te, y_te, k, seed))
                except Exception as e:
                    print(f"  SKIP {ds_name}: {e}")

        # Large embedding datasets
        if dataset_group in ("all", "new", "large_embed"):
            for ds_name, extractor, n_tr, n_te, k in LARGE_EMBED_DATASETS:
                try:
                    X_tr, y_tr, X_te, y_te, meta = load_frozen_embed(
                        ds_name, extractor, seed, n_train=n_tr, n_test=n_te)
                    all_rows.append(process_dataset(
                        f"{ds_name}_resnet18", X_tr, y_tr, X_te, y_te, k, seed))
                except Exception as e:
                    print(f"  SKIP {ds_name}: {e}")

        # Sentence-transformer newsgroups
        if dataset_group in ("all", "new", "text"):
            try:
                result = load_newsgroups_sbert(seed)
                if result is not None:
                    X_tr, y_tr, X_te, y_te, meta = result
                    all_rows.append(process_dataset(
                        "newsgroups_sbert", X_tr, y_tr, X_te, y_te, 16, seed))
            except Exception as e:
                print(f"  SKIP newsgroups_sbert: {e}")

    _save_csv(all_rows, out_dir / "meta_analysis.csv")

    # Print correlation analysis
    if len(all_rows) > 5:
        print(f"\n{'='*70}")
        print("CORRELATION ANALYSIS: What predicts VGHL lift?")
        print(f"{'='*70}")
        from scipy.stats import spearmanr

        # Average across seeds
        from collections import defaultdict
        by_ds = defaultdict(list)
        for r in all_rows:
            by_ds[r["dataset"]].append(r)

        meta_keys = ["ridge_acc", "knn_acc", "knn_ridge_gap", "intrinsic_dim",
                      "id_over_d", "n_samples", "n_features", "d_over_n",
                      "silhouette", "label_purity", "fisher_ratio", "class_entropy",
                      "n_classes"]
        target = "vghl_lift_vs_ridge"

        lifts = []
        feature_vals = {k: [] for k in meta_keys}
        ds_names = []
        for ds, runs in by_ds.items():
            lift = np.mean([r[target] for r in runs if r[target] is not None])
            lifts.append(lift)
            ds_names.append(ds)
            for mk in meta_keys:
                vals = [r.get(mk, float('nan')) for r in runs]
                feature_vals[mk].append(np.nanmean(vals))

        lifts = np.array(lifts)
        print(f"\n{'Meta-feature':<20} {'ρ':>7} {'p':>10} {'interpretation'}")
        print("-" * 65)
        for mk in meta_keys:
            vals = np.array(feature_vals[mk])
            mask = np.isfinite(vals) & np.isfinite(lifts)
            if mask.sum() < 5: continue
            rho, pval = spearmanr(vals[mask], lifts[mask])
            interp = ""
            if abs(rho) > 0.3 and pval < 0.1:
                if rho > 0:
                    interp = "↑ helps geometry"
                else:
                    interp = "↓ hurts geometry"
            print(f"{mk:<20} {rho:>+7.3f} {pval:>10.4f} {interp}")

        # Top/bottom datasets
        order = np.argsort(lifts)
        print(f"\n  TOP 5 (geometry helps most):")
        for i in order[-5:][::-1]:
            print(f"    {ds_names[i]:<25} lift={lifts[i]:+.4f}")
        print(f"\n  BOTTOM 5 (geometry hurts most):")
        for i in order[:5]:
            print(f"    {ds_names[i]:<25} lift={lifts[i]:+.4f}")

    return all_rows


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--seeds", type=str, default="0,1,2")
    p.add_argument("--out", type=str, default="outputs/meta_analysis")
    p.add_argument("--only", type=str, default="all",
                   help="all | existing | new | new_openml | large_embed | text")
    args = p.parse_args()
    seeds = [int(s) for s in args.seeds.split(",")]
    out = Path(args.out)

    print("=" * 70)
    print(f"VGHL META-ANALYSIS: When does geometry help?")
    print(f"  Group: {args.only}")
    print(f"  Seeds: {seeds}")
    print("=" * 70)

    run_meta_analysis(args.only, seeds, out)


if __name__ == "__main__":
    main()
