#!/usr/bin/env python3
"""Transfer experiment: geometry of dataset A used to learn dataset B.

Build graph on dataset A train points only. Freeze it. For dataset B,
connect each B point to its kNN in A, embed B by aggregating diffused
A embeddings, train linear readout on B train, evaluate on B test.

Conditions:
  1. transfer_real: A's real geometry graph
  2. transfer_rewired: degree-preserving rewired A graph (geometry destroyed)
  3. direct_B: standard pipeline with the graph built on B (reference)
  4. transfer_random_attach: real A graph but random B→A connections

If transfer_real >> transfer_rewired, the geometry encodes reusable
computational structure independent of the specific dataset.

Usage:
    python scripts/transfer.py
    python scripts/transfer.py --pairs "sk_moons:sk_circles,breast_cancer:wine"
    python scripts/transfer.py --seeds 0,1,2,3,4 --k_base 16
"""
import argparse
import sys
import os

os.environ["OMP_NUM_THREADS"] = os.environ.get("OMP_NUM_THREADS", "1")
os.environ["MKL_NUM_THREADS"] = os.environ.get("MKL_NUM_THREADS", "1")
os.environ["OPENBLAS_NUM_THREADS"] = os.environ.get("OPENBLAS_NUM_THREADS", "1")
os.environ["NUMEXPR_NUM_THREADS"] = os.environ.get("NUMEXPR_NUM_THREADS", "1")
os.environ["VECLIB_MAXIMUM_THREADS"] = os.environ.get("VECLIB_MAXIMUM_THREADS", "1")

import csv
import time
import statistics as stats_mod
import numpy as np
import torch
from pathlib import Path
from collections import defaultdict

torch.set_num_threads(1)

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from vghl.data.loaders import build_datasets, PointDataset
from vghl.utils.config import ExperimentConfig
from vghl.models.graph_builder import build_base_graph, GraphBuilderConfig
from vghl.models.propagation import propagate, PropagationConfig
from vghl.models.knn_backend import KNNIndex
from vghl.models.probe import ridge_eval

DATASET_DEFAULTS = {
    # sklearn tabular
    "iris":              {"n_train": 0, "n_val": 0, "n_test": 0},
    "wine":              {"n_train": 0, "n_val": 0, "n_test": 0},
    "breast_cancer":     {"n_train": 0, "n_val": 0, "n_test": 0},
    "digits":            {"n_train": 0, "n_val": 0, "n_test": 0},
    "diabetes":          {"n_train": 0, "n_val": 0, "n_test": 0},
    "california_housing":{"n_train": 5000, "n_val": 1000, "n_test": 1000},
    # OpenML tabular
    "segment":           {"n_train": 0, "n_val": 0, "n_test": 0},
    "waveform":          {"n_train": 3000, "n_val": 500, "n_test": 500},
    "satellite":         {"n_train": 3000, "n_val": 500, "n_test": 500},
    "pendigits":         {"n_train": 5000, "n_val": 1000, "n_test": 1000},
    "optdigits":         {"n_train": 3000, "n_val": 500, "n_test": 500},
    "letter":            {"n_train": 5000, "n_val": 1000, "n_test": 1000},
    "covertype":         {"n_train": 5000, "n_val": 1000, "n_test": 1000},
    "adult":             {"n_train": 5000, "n_val": 1000, "n_test": 1000},
    # Embeddings
    "mnist_embed":       {"n_train": 5000, "n_val": 1000, "n_test": 1000},
    "fmnist_embed":      {"n_train": 5000, "n_val": 1000, "n_test": 1000},
    "cifar10_pca":       {"n_train": 5000, "n_val": 1000, "n_test": 1000},
    "newsgroups_embed":  {"n_train": 3000, "n_val": 500, "n_test": 500},
    "cifar10_resnet18":  {"n_train": 5000, "n_val": 1000, "n_test": 1000},
    "cora":              {"n_train": 0, "n_val": 0, "n_test": 0},
}


def load_dataset(name, seed, n_train=0, n_val=0, n_test=0):
    """Load dataset splits. Returns X_tr, y_tr, X_val, y_val, X_te, y_te, meta."""
    cfg = ExperimentConfig()
    cfg.data.dataset = name
    cfg.data.n_train = n_train
    cfg.data.n_val = n_val
    cfg.data.n_test = n_test
    cfg.seed = seed
    train_ds, val_ds, test_ds, meta = build_datasets(cfg)
    return train_ds.X, train_ds.y, val_ds.X, val_ds.y, test_ds.X, test_ds.y, meta


def embed_B_via_A(H_A, X_A, X_B, k_attach, random_attach=False, seed=0):
    """Embed dataset B points by aggregating diffused A embeddings.

    For each B point, find k nearest A points and mean-aggregate their
    propagated embeddings. If random_attach, use random A indices instead.

    Args:
        H_A: (N_A, d_out) propagated embeddings of A
        X_A: (N_A, d_in) raw features of A
        X_B: (N_B, d_in) raw features of B
        k_attach: number of A neighbors per B point
        random_attach: if True, randomize attachment (control)
        seed: for random attachment

    Returns:
        H_B: (N_B, d_out) embedded B features
    """
    N_A = X_A.shape[0]
    N_B = X_B.shape[0]
    k_actual = min(k_attach, N_A)

    if random_attach:
        rng = np.random.RandomState(seed)
        indices = np.stack([rng.choice(N_A, k_actual, replace=False)
                            for _ in range(N_B)])
    else:
        # kNN from B to A
        index = KNNIndex(X_A)
        indices, _ = index.query(X_B, k_actual)

    # Mean aggregation of A embeddings
    idx_t = torch.tensor(indices, dtype=torch.long)  # (N_B, k)
    neighbor_embeds = H_A[idx_t]  # (N_B, k, d_out)
    H_B = neighbor_embeds.mean(dim=1)  # (N_B, d_out)
    return H_B


def run_transfer_condition(X_A_tr, X_B_tr, y_B_tr, X_B_val, y_B_val,
                           X_B_te, y_B_te, n_classes,
                           graph_cfg, prop_cfg, k_attach, condition, seed):
    """Run one transfer condition and return metrics.

    Conditions:
      transfer_real: real geometry graph on A, kNN attach B→A
      transfer_rewired: degree-preserving rewired graph on A
      transfer_random_attach: real graph on A, random attach B→A
      direct_B: normal pipeline on B (no transfer)
    """
    t0 = time.time()

    if condition == "direct_B":
        # Upper bound: build graph directly on B train
        N_B = X_B_tr.shape[0]
        graph = build_base_graph(X_B_tr, graph_cfg)
        H_B_tr = propagate(X_B_tr, graph["edge_index"], graph["edge_weight"],
                           N_B, prop_cfg)
        # Val/test: embed via kNN to B train
        H_B_val = embed_B_via_A(H_B_tr, X_B_tr, X_B_val, k_attach)
        H_B_te = embed_B_via_A(H_B_tr, X_B_tr, X_B_te, k_attach)
        n_edges = graph["edge_index"].shape[1]
    else:
        # Build graph on A
        if condition == "transfer_rewired":
            cfg_ctrl = GraphBuilderConfig(
                type=graph_cfg.type, k=graph_cfg.k,
                weight_mode=graph_cfg.weight_mode,
                sigma=graph_cfg.sigma,
                control="degree_preserving_rewire",
            )
            graph = build_base_graph(X_A_tr, cfg_ctrl)
        else:
            graph = build_base_graph(X_A_tr, graph_cfg)

        N_A = X_A_tr.shape[0]
        # Propagate on A
        H_A = propagate(X_A_tr, graph["edge_index"], graph["edge_weight"],
                        N_A, prop_cfg)

        random_attach = (condition == "transfer_random_attach")
        # Embed B splits via A
        H_B_tr = embed_B_via_A(H_A, X_A_tr, X_B_tr, k_attach,
                               random_attach=random_attach, seed=seed)
        H_B_val = embed_B_via_A(H_A, X_A_tr, X_B_val, k_attach,
                                random_attach=random_attach, seed=seed + 1000)
        H_B_te = embed_B_via_A(H_A, X_A_tr, X_B_te, k_attach,
                               random_attach=random_attach, seed=seed + 2000)
        n_edges = graph["edge_index"].shape[1]

    elapsed = time.time() - t0

    # Ridge evaluation
    val_acc = ridge_eval(H_B_tr, y_B_tr, H_B_val, y_B_val, n_classes)
    test_acc = ridge_eval(H_B_tr, y_B_tr, H_B_te, y_B_te, n_classes)

    return {
        "val_accuracy": val_acc,
        "test_accuracy": test_acc,
        "n_edges": n_edges,
        "elapsed_s": elapsed,
    }


def main():
    p = argparse.ArgumentParser(description="Transfer experiment: Geometry(A) → Learn(B)")
    p.add_argument("--pairs", type=str,
                   default="sk_moons:sk_circles,breast_cancer:wine,digits:breast_cancer",
                   help="Comma-separated A:B pairs")
    p.add_argument("--seeds", type=str, default="0,1,2,3,4")
    p.add_argument("--k_base", type=int, default=16, help="Graph k for A")
    p.add_argument("--k_attach", type=int, default=8, help="kNN from B to A")
    p.add_argument("--operator", type=str, default="random_walk")
    p.add_argument("--prop_steps", type=int, default=5)
    p.add_argument("--out", type=str, default="outputs/transfer")
    p.add_argument("--plot_only", action="store_true")

    args = p.parse_args()
    pairs = [(p.split(":")[0].strip(), p.split(":")[1].strip())
             for p in args.pairs.split(",")]
    seeds = [int(s) for s in args.seeds.split(",")]
    out_dir = Path(args.out)
    out_dir.mkdir(parents=True, exist_ok=True)

    conditions = ["transfer_real", "transfer_rewired",
                  "transfer_random_attach", "direct_B"]

    print("=" * 70)
    print("TRANSFER EXPERIMENT")
    print(f"  Pairs:      {pairs}")
    print(f"  Seeds:      {seeds}")
    print(f"  k_base:     {args.k_base}")
    print(f"  k_attach:   {args.k_attach}")
    print(f"  Conditions: {conditions}")
    print("=" * 70)

    if args.plot_only:
        rows = _load_csv(out_dir / "transfer_results.csv")
    else:
        rows = []
        graph_cfg = GraphBuilderConfig(type="knn", k=args.k_base)
        prop_cfg = PropagationConfig(type=args.operator, steps=args.prop_steps)

        total = len(pairs) * len(seeds) * len(conditions)
        done = 0

        for ds_A, ds_B in pairs:
            dd_A = DATASET_DEFAULTS.get(ds_A, {})
            dd_B = DATASET_DEFAULTS.get(ds_B, {})

            for seed in seeds:
                # Load both datasets
                X_A_tr, y_A_tr, X_A_val, y_A_val, _, _, meta_A = load_dataset(
                    ds_A, seed, dd_A.get("n_train", 0),
                    dd_A.get("n_val", 0), dd_A.get("n_test", 0),
                )
                X_B_tr, y_B_tr, X_B_val, y_B_val, X_B_te, y_B_te, meta_B = load_dataset(
                    ds_B, seed, dd_B.get("n_train", 0),
                    dd_B.get("n_val", 0), dd_B.get("n_test", 0),
                )
                n_classes_B = meta_B.get("n_classes",
                                         int(y_B_tr.max()) + 1)

                # Dimensionality check - A and B must have same feature dim
                d_A = X_A_tr.shape[1]
                d_B = X_B_tr.shape[1]
                if d_A != d_B:
                    # Project each dataset independently to d_common dims
                    # Independent PCA is correct for transfer: we transfer
                    # graph structure, not feature semantics
                    from sklearn.decomposition import PCA
                    from sklearn.preprocessing import StandardScaler
                    d_common = min(d_A, d_B)

                    # Project A independently
                    scaler_A = StandardScaler()
                    pca_A = PCA(n_components=d_common, random_state=seed)
                    X_A_tr = torch.tensor(
                        pca_A.fit_transform(
                            scaler_A.fit_transform(X_A_tr.detach().cpu().numpy())
                        ), dtype=torch.float32)

                    # Project B independently (each split uses B's scaler+PCA)
                    scaler_B = StandardScaler()
                    pca_B = PCA(n_components=d_common, random_state=seed)
                    X_B_np = scaler_B.fit_transform(X_B_tr.detach().cpu().numpy())
                    X_B_tr = torch.tensor(
                        pca_B.fit_transform(X_B_np), dtype=torch.float32)
                    X_B_val = torch.tensor(
                        pca_B.transform(
                            scaler_B.transform(X_B_val.detach().cpu().numpy())
                        ), dtype=torch.float32)
                    X_B_te = torch.tensor(
                        pca_B.transform(
                            scaler_B.transform(X_B_te.detach().cpu().numpy())
                        ), dtype=torch.float32)

                    print(f"    PCA: d_A={d_A} d_B={d_B} → d_common={d_common} "
                          f"(independent PCA per dataset)")

                for condition in conditions:
                    done += 1
                    tag = f"{ds_A}→{ds_B}_{condition}_s{seed}"
                    print(f"[{done}/{total}] {tag}", end=" ... ", flush=True)

                    t0 = time.time()
                    res = run_transfer_condition(
                        X_A_tr, X_B_tr, y_B_tr, X_B_val, y_B_val,
                        X_B_te, y_B_te, n_classes_B,
                        graph_cfg, prop_cfg, args.k_attach, condition, seed,
                    )
                    elapsed = time.time() - t0

                    row = {
                        "dataset_A": ds_A, "dataset_B": ds_B,
                        "condition": condition, "seed": seed,
                        "k_base": args.k_base, "k_attach": args.k_attach,
                        "val_accuracy": res["val_accuracy"],
                        "test_accuracy": res["test_accuracy"],
                        "n_edges": res["n_edges"],
                    }
                    rows.append(row)
                    print(f"test={res['test_accuracy']:.4f} [{elapsed:.1f}s]")

        # Save
        if rows:
            csv_path = out_dir / "transfer_results.csv"
            with open(csv_path, "w", newline="") as f:
                writer = csv.DictWriter(f, fieldnames=rows[0].keys())
                writer.writeheader()
                writer.writerows(rows)
            print(f"\nResults: {csv_path}")

    # Summary
    _print_summary(rows, out_dir)
    _generate_figure(rows, out_dir)
    _write_latex(rows, out_dir)


def _load_csv(path):
    """Load CSV rows."""
    if not path.exists():
        return []
    with open(path) as f:
        rows = []
        for r in csv.DictReader(f):
            for k in ["seed", "k_base", "k_attach", "n_edges"]:
                if r.get(k):
                    try:
                        r[k] = int(r[k])
                    except ValueError:
                        pass
            for k in ["val_accuracy", "test_accuracy"]:
                if r.get(k):
                    try:
                        r[k] = float(r[k])
                    except ValueError:
                        pass
            rows.append(r)
        return rows


def _print_summary(rows, out_dir):
    """Print and save summary table."""
    if not rows:
        return

    groups = defaultdict(list)
    for r in rows:
        key = (r["dataset_A"], r["dataset_B"], r["condition"])
        groups[key].append(float(r["test_accuracy"]))

    print("\n" + "=" * 80)
    print("TRANSFER SUMMARY: Test Accuracy (mean ± std)")
    print("=" * 80)
    print(f"{'A→B':<30} {'Condition':<26} {'Test Acc':>15} {'n':>3}")
    print("-" * 80)

    summary = []
    for (ds_A, ds_B, cond), accs in sorted(groups.items()):
        mean = stats_mod.mean(accs)
        std = stats_mod.stdev(accs) if len(accs) > 1 else 0.0
        acc_str = f"{mean:.3f} ± {std:.3f}"
        print(f"{ds_A}→{ds_B:<24} {cond:<26} {acc_str:>15} {len(accs):>3}")
        summary.append({
            "dataset_A": ds_A, "dataset_B": ds_B, "condition": cond,
            "mean_acc": mean, "std_acc": std, "n": len(accs),
            "acc_str": acc_str,
        })

    if summary:
        spath = out_dir / "transfer_summary.csv"
        with open(spath, "w", newline="") as f:
            w = csv.DictWriter(f, fieldnames=summary[0].keys())
            w.writeheader()
            w.writerows(summary)


def _generate_figure(rows, out_dir):
    """Generate transfer bar chart."""
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except ImportError:
        print("matplotlib not installed, skipping figure")
        return

    groups = defaultdict(list)
    for r in rows:
        key = (r["dataset_A"], r["dataset_B"], r["condition"])
        groups[key].append(float(r["test_accuracy"]))

    pair_keys = sorted(set((r["dataset_A"], r["dataset_B"]) for r in rows))
    conditions = ["transfer_real", "transfer_rewired", "transfer_random_attach", "direct_B"]
    COLORS = {
        "transfer_real": "#2563eb",
        "transfer_rewired": "#dc2626",
        "transfer_random_attach": "#f59e0b",
        "direct_B": "#6b7280",
    }
    LABELS = {
        "transfer_real": "Transfer (real geom.)",
        "transfer_rewired": "Transfer (rewired)",
        "transfer_random_attach": "Transfer (random attach)",
        "direct_B": "Direct B (upper bound)",
    }

    n_pairs = len(pair_keys)
    fig, ax = plt.subplots(figsize=(3.5 * n_pairs, 4))
    x = np.arange(n_pairs)
    bar_w = 0.2

    for j, cond in enumerate(conditions):
        means, stds = [], []
        for ds_A, ds_B in pair_keys:
            accs = groups.get((ds_A, ds_B, cond), [])
            if accs:
                means.append(stats_mod.mean(accs))
                stds.append(stats_mod.stdev(accs) if len(accs) > 1 else 0)
            else:
                means.append(0)
                stds.append(0)
        ax.bar(x + j * bar_w, means, bar_w, yerr=stds,
               label=LABELS[cond], color=COLORS[cond],
               capsize=3, alpha=0.85)

    pair_labels = [f"{a}→{b}" for a, b in pair_keys]
    ax.set_xticks(x + 1.5 * bar_w)
    ax.set_xticklabels(pair_labels, fontsize=9, rotation=15, ha="right")
    ax.set_ylabel("Test accuracy", fontsize=11)
    ax.legend(fontsize=8, frameon=True, loc="lower right")
    ax.grid(True, axis="y", alpha=0.2)
    ax.set_title("Transfer: Geometry(A) → Learn(B)", fontsize=13, fontweight="bold")
    plt.tight_layout()

    for ext in ["pdf", "png"]:
        fig.savefig(out_dir / f"transfer_plot.{ext}", dpi=300, bbox_inches="tight")
    print(f"Transfer figure: {out_dir / 'transfer_plot.pdf'}")
    plt.close(fig)


def _write_latex(rows, out_dir):
    """Write LaTeX table."""
    if not rows:
        return
    groups = defaultdict(list)
    for r in rows:
        key = (r["dataset_A"], r["dataset_B"], r["condition"])
        groups[key].append(float(r["test_accuracy"]))

    pair_keys = sorted(set((r["dataset_A"], r["dataset_B"]) for r in rows))

    lines = [
        r"\begin{table}[t]",
        r"\centering",
        r"\caption{Transfer experiment: geometry from dataset A used to classify dataset B. "
        r"Real geometry transfers significantly better than controls.}",
        r"\label{tab:transfer}",
        r"\begin{tabular}{llcccc}",
        r"\toprule",
        r"A & B & Transfer (real) & Transfer (rewired) & Random attach & Direct B \\",
        r"\midrule",
    ]

    for ds_A, ds_B in pair_keys:
        parts = [ds_A.replace("_", r"\_"), ds_B.replace("_", r"\_")]
        for cond in ["transfer_real", "transfer_rewired",
                     "transfer_random_attach", "direct_B"]:
            accs = groups.get((ds_A, ds_B, cond), [])
            if accs:
                m = stats_mod.mean(accs)
                s = stats_mod.stdev(accs) if len(accs) > 1 else 0
                parts.append(f"{m:.3f}$\\pm${s:.3f}")
            else:
                parts.append("-")
        lines.append("  " + " & ".join(parts) + r" \\")

    lines.extend([r"\bottomrule", r"\end{tabular}", r"\end{table}"])

    tex_path = out_dir / "transfer_table.tex"
    with open(tex_path, "w") as f:
        f.write("\n".join(lines))
    print(f"LaTeX table: {tex_path}")


if __name__ == "__main__":
    main()
