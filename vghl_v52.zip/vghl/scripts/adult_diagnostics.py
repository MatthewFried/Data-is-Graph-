#!/usr/bin/env python3
"""Training-only provenance for kNN purity and the kNN-minus-ridge gap.

Definitions on the artifact's training split:
  purity(k): mean same-label fraction among each point's k nearest training
             neighbors, excluding itself.
  gap(k):    stratified-CV accuracy of kNN(k) minus the exact closed-form
             one-hot ridge probe used elsewhere in the artifact.

The data arrays come from run_real_experiments.load_dataset, so this reproduces
the artifact's existing preprocessing and split protocol. It does not use
validation/test labels or intervention outcomes.
"""
import argparse
import os
import sys
from pathlib import Path

os.environ.setdefault("OMP_NUM_THREADS", "4")

import numpy as np
import torch

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))
sys.path.insert(0, os.path.dirname(__file__))

from run_real_experiments import DATASETS, _save_csv, get_k, load_dataset  # noqa: E402


def purity(x, y, k):
    from sklearn.neighbors import NearestNeighbors

    if k < 1 or k >= len(x):
        raise ValueError(f"purity requires 1 <= k < n; got k={k}, n={len(x)}")
    nn = NearestNeighbors(n_neighbors=k + 1).fit(x)
    _, idx = nn.kneighbors(x)
    neigh = y[idx[:, 1:]]
    return float((neigh == y[:, None]).mean())


def _ridge_predict(x_train, y_train, x_eval, n_classes, alpha=1e-2):
    """Exact no-intercept one-hot ridge probe, primal/dual as appropriate."""
    xt = torch.as_tensor(x_train, dtype=torch.float64)
    yt = torch.as_tensor(y_train, dtype=torch.long)
    xe = torch.as_tensor(x_eval, dtype=torch.float64)
    targets = torch.nn.functional.one_hot(yt, n_classes).double()
    n, d = xt.shape
    if n <= d:
        gram = xt @ xt.T
        gram.diagonal().add_(alpha)
        try:
            coeff = torch.linalg.solve(gram, targets)
        except RuntimeError:
            coeff = torch.linalg.lstsq(gram, targets).solution
        weights = xt.T @ coeff
    else:
        gram = xt.T @ xt
        gram.diagonal().add_(alpha)
        rhs = xt.T @ targets
        try:
            weights = torch.linalg.solve(gram, rhs)
        except RuntimeError:
            weights = torch.linalg.lstsq(gram, rhs).solution
    return (xe @ weights).argmax(1).cpu().numpy()


def cv_gap(x, y, k, seed, folds=5):
    from sklearn.model_selection import StratifiedKFold
    from sklearn.neighbors import KNeighborsClassifier

    classes, counts = np.unique(y, return_counts=True)
    if counts.min() < folds:
        raise ValueError(
            f"smallest class has {counts.min()} examples, fewer than {folds} folds"
        )
    cv = StratifiedKFold(folds, shuffle=True, random_state=seed)
    knn_scores, ridge_scores = [], []
    n_classes = int(classes.max()) + 1
    for train_idx, eval_idx in cv.split(x, y):
        k_fold = min(k, len(train_idx))
        knn = KNeighborsClassifier(n_neighbors=k_fold).fit(x[train_idx], y[train_idx])
        knn_pred = knn.predict(x[eval_idx])
        ridge_pred = _ridge_predict(
            x[train_idx], y[train_idx], x[eval_idx], n_classes=n_classes
        )
        knn_scores.append(float((knn_pred == y[eval_idx]).mean()))
        ridge_scores.append(float((ridge_pred == y[eval_idx]).mean()))
    knn_mean = float(np.mean(knn_scores))
    ridge_mean = float(np.mean(ridge_scores))
    return knn_mean - ridge_mean, knn_mean, ridge_mean


def _parse_list(value):
    return [x.strip() for x in value.split(",") if x.strip()]


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--datasets", default="adult",
                   help="comma-separated names, or all for the full artifact registry")
    p.add_argument("--seeds", default="0,1,2,3,4")
    p.add_argument("--folds", type=int, default=5)
    p.add_argument("--out", default="outputs")
    a = p.parse_args()

    datasets = list(DATASETS) if a.datasets.strip().lower() == "all" else _parse_list(a.datasets)
    unknown = sorted(set(datasets) - set(DATASETS))
    if unknown:
        p.error(f"unknown datasets: {unknown}")
    seeds = [int(s) for s in _parse_list(a.seeds)]
    if a.folds < 2:
        p.error("--folds must be at least 2")

    rows = []
    out_path = Path(a.out) / "adult_diagnostics.csv"
    for ds in datasets:
        for seed in seeds:
            x, y, _, _, _, _, _ = load_dataset(ds, seed)
            x = np.asarray(x, dtype=np.float64)
            y = np.asarray(y, dtype=np.int64)
            kd = min(get_k(ds), len(x) - 1)
            ks = sorted({min(10, len(x) - 1), kd})
            values = {
                "dataset": ds,
                "seed": seed,
                "n_train": len(x),
                "d": x.shape[1],
                "n_classes": int(np.unique(y).size),
                "majority_prior": float(np.bincount(y).max() / len(y)),
                "k_default": kd,
                "cv_folds": a.folds,
                "ridge_definition": "closed_form_onehot_no_intercept_l2_1e-2",
            }
            for k in ks:
                values[f"purity_k{k}"] = purity(x, y, k)
                gap, knn_acc, ridge_acc = cv_gap(x, y, k, seed, folds=a.folds)
                values[f"gap_k{k}"] = gap
                values[f"knn_cv_k{k}"] = knn_acc
                values[f"ridge_cv_k{k}"] = ridge_acc
            rows.append(values)
            _save_csv(rows, out_path)
            print(
                f"  {ds} s{seed}: "
                + " ".join(
                    f"{key}={value:.3f}"
                    for key, value in values.items()
                    if isinstance(value, float)
                ),
                flush=True,
            )

    adult = [row for row in rows if row["dataset"] == "adult"]
    if adult:
        float_keys = [k for k, v in adult[0].items() if isinstance(v, float)]
        print(
            "\nADULT (mean over seeds): "
            + " ".join(
                f"{key}={np.mean([row[key] for row in adult]):.3f}"
                for key in float_keys
            )
        )


if __name__ == "__main__":
    main()
