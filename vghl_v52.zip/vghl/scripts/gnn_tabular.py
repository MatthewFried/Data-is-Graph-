#!/usr/bin/env python3
"""Learned operators (GCN, GAT, MLP) on feature-induced kNN graphs.

Same feature-induced construction as the main pipeline (kNN, k=16,
symmetrized, self-loops stripped) on the public datasets of the main
experiments, with learned operators under three connectivity conditions
(given kNN | random edges | degree-preserving rewire), the fixed
random-walk operator with ridge readout under the same three conditions,
the raw-feature oracle envelope (ridge / logistic regression / RF) and a
raw-feature MLP.

Protocol: data come from run_real_experiments.load_dataset. The graph is
built transductively over the training rows plus the held-out rows, as is
standard for GNN evaluation. The held-out evaluation set is the loader's
validation split (disjoint from training); GNN model selection uses the
last 20% of the training rows. Features are L2-normalized per row.

Usage:
  python -u scripts/gnn_tabular.py
  python -u scripts/gnn_tabular.py --datasets digits,breast_cancer --seeds 0 \
      --models mlp,gcn --skip-rf
"""
import os
import sys

os.environ.setdefault("OMP_NUM_THREADS", "4")

import argparse
from collections import defaultdict
from pathlib import Path

import numpy as np
import torch

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))
sys.path.insert(0, os.path.dirname(__file__))

from run_real_experiments import (  # noqa: E402
    load_dataset, _save_csv, _degree_preserving_rewire,
)
from gnn_native import train_eval  # noqa: E402
from native_graph import make_random_edges  # noqa: E402
from regime_b import propagate, ridge_acc  # noqa: E402

DEFAULT = "digits,optdigits,pendigits,satellite,segment,letter,mnist_embed,breast_cancer"


def build_knn(X, k=16):
    from sklearn.neighbors import NearestNeighbors
    nn = NearestNeighbors(n_neighbors=k + 1).fit(X)
    _, idx = nn.kneighbors(X)
    src = np.repeat(np.arange(X.shape[0]), k)
    dst = idx[:, 1:].reshape(-1)
    ei = np.stack([np.concatenate([src, dst]), np.concatenate([dst, src])])
    ei = np.unique(ei.T, axis=0).T
    ei = ei[:, ei[0] != ei[1]]
    return torch.tensor(ei, dtype=torch.long)


def get_split(ds, seed):
    """Stack training and held-out rows; return X, y and train/val/test masks.

    load_dataset returns (X_tr, y_tr, X_val, y_val, X_te, y_te, meta); the
    held-out set used here is (X_val, y_val).
    """
    out = load_dataset(ds, seed)
    Xtr, ytr = np.asarray(out[0]), np.asarray(out[1])
    Xho, yho = np.asarray(out[2]), np.asarray(out[3])
    assert Xtr.ndim == 2 and Xho.ndim == 2 and len(Xtr) == len(ytr) \
        and len(Xho) == len(yho) and Xtr.shape[1] == Xho.shape[1], \
        f"{ds}: unexpected loader layout {[np.shape(o) for o in out[:4]]}"
    X = np.vstack([Xtr, Xho]).astype(np.float32)
    y = np.concatenate([ytr, yho]).astype(np.int64)
    ntr = len(ytr)
    trm = torch.zeros(len(y), dtype=torch.bool)
    trm[:ntr] = True
    tem = ~trm
    nval = max(1, ntr // 5)
    vam = torch.zeros(len(y), dtype=torch.bool)
    vam[ntr - nval:ntr] = True
    trm = trm & ~vam
    return torch.tensor(X), torch.tensor(y), trm, vam, tem


def raw_envelope(X, y, trm, tem, nc, seed, skip_rf):
    accs = {"ridge": ridge_acc(X, y, trm, tem, nc)}
    Xtr, ytr = X[trm].numpy(), y[trm].numpy()
    Xte, yte = X[tem].numpy(), y[tem].numpy()
    from sklearn.linear_model import LogisticRegression
    accs["logreg"] = float((LogisticRegression(max_iter=2000)
                            .fit(Xtr, ytr).predict(Xte) == yte).mean())
    if not skip_rf:
        from sklearn.ensemble import RandomForestClassifier
        accs["rf"] = float((RandomForestClassifier(200, random_state=seed, n_jobs=-1)
                            .fit(Xtr, ytr).predict(Xte) == yte).mean())
    return max(accs.values()), accs


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--datasets", default=DEFAULT)
    ap.add_argument("--seeds", default="0,1,2")
    ap.add_argument("--models", default="mlp,gcn,gat")
    ap.add_argument("--device", default="cpu", help="cpu | cuda | auto")
    ap.add_argument("--skip-rf", action="store_true")
    ap.add_argument("--out", default="outputs")
    a = ap.parse_args()
    rows = []
    for ds in a.datasets.split(","):
        for seed in [int(s) for s in a.seeds.split(",")]:
            torch.manual_seed(seed)
            np.random.seed(seed)
            X, y, trm, vam, tem = get_split(ds, seed)
            X = X / X.norm(dim=1, keepdim=True).clamp(min=1e-8)
            N, nc = X.shape[0], int(y.max()) + 1
            ei = build_knn(X.numpy(), k=min(16, N - 2))
            E = ei.shape[1]
            E_und = int((ei[0] < ei[1]).sum())
            rw, diag = _degree_preserving_rewire(ei, N, 2 * E_und, seed)
            r = {"dataset": ds, "seed": seed, "N": N, "E": E,
                 "rewire_overlap": float(diag["orig_edge_overlap"])}
            conds = {"given": ei,
                     "random_edges": make_random_edges(N, E, seed)[0],
                     "degree_rewire": rw}
            for cname, e in conds.items():
                r[f"fixed_{cname}"] = ridge_acc(propagate(X, e, N), y, trm, tem, nc)
            r["best_raw"], per = raw_envelope(X, y, trm, tem, nc, seed, a.skip_rf)
            for k, v in per.items():
                r[f"raw_{k}"] = v
            for m in a.models.split(","):
                if m == "mlp":
                    r["mlp_raw"] = train_eval("mlp", X, y, conds["given"],
                                              trm, vam, tem, nc, seed,
                                              device=a.device)
                else:
                    for cname, e in conds.items():
                        r[f"{m}_{cname}"] = train_eval(m, X, y, e, trm, vam,
                                                       tem, nc, seed,
                                                       device=a.device)
            rows.append(r)
            print(f"  {ds} s{seed}: " + " ".join(
                f"{k}={v:.3f}" for k, v in r.items() if isinstance(v, float)),
                flush=True)
        _save_csv(rows, Path(a.out) / "gnn_tabular.csv")
    by = defaultdict(list)
    for r in rows:
        by[r["dataset"]].append(r)
    cols = sorted({k for r in rows for k in r if isinstance(r[k], float)})
    print("\n" + f"{'dataset':<15}" + " ".join(f"{c[:13]:>14}" for c in cols))
    for ds, rs in by.items():
        print(f"{ds:<15}" + " ".join(
            f"{np.mean([r[c] for r in rs if c in r]):>14.3f}" if any(c in r for r in rs)
            else f"{'---':>14}" for c in cols))


if __name__ == "__main__":
    main()
