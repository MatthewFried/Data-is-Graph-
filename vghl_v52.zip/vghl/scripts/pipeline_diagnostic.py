#!/usr/bin/env python3
"""VGHL Pipeline Diagnostic: Identify and fix bottlenecks.

For every dataset, tests each pipeline component independently:

Experiment 1 - PCA PRE-PROJECTION:
  Build kNN graph on PCA-reduced features instead of raw.
  Tests: does reducing d improve graph quality for high-d datasets?
  Dims: adaptive based on dataset (skip if d <= 50)

Experiment 2 - READOUT VARIANTS:
  After propagation, compare readout heads:
  a) Ridge (current default)
  b) kNN on propagated features (no learned head)
  c) Small MLP (1-hidden-layer, 128 units)
  d) SVM (RBF kernel, for small-moderate N)
  Tests: is the ridge readout the bottleneck?

Experiment 3 - GRAPH QUALITY AUDIT:
  For each dataset, measure:
  a) kNN label purity (what % of neighbors share label)
  b) Label purity after PCA
  c) Graph connectivity (largest component fraction)
  Tests: is the graph itself the problem?

Experiment 4 - TEST EMBEDDING VARIANTS:
  Compare test-time strategies:
  a) kNN embed test into propagated space (current)
  b) Raw test features + ridge on propagated train
  c) kNN on propagated train, predict test by kNN lookup
  Tests: is the inductive kNN embedding the bottleneck?

Experiment 5 - BEST COMBO:
  For each dataset, pick best PCA dim + best readout + best propagation
  from above sweeps and report the "oracle best" pipeline.

Usage:
    python -u scripts/pipeline_diagnostic.py
    python -u scripts/pipeline_diagnostic.py --only pca
    python -u scripts/pipeline_diagnostic.py --only readout
    python -u scripts/pipeline_diagnostic.py --only graph_quality
    python -u scripts/pipeline_diagnostic.py --only test_embed
"""
import os, sys, argparse, csv, time, warnings
import numpy as np
import torch
from pathlib import Path

warnings.filterwarnings("ignore", category=FutureWarning)
warnings.filterwarnings("ignore", category=UserWarning)

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from vghl.models.graph_builder import build_base_graph, GraphBuilderConfig
from vghl.models.propagation import propagate, PropagationConfig
from vghl.models.probe import ridge_eval, embed_queries_via_knn, fit_ridge_classifier, predict_logits, accuracy


def _save_csv(rows, path):
    if not rows: return
    path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    keys = list(rows[0].keys())
    extra = sorted({k for r in rows for k in r.keys()} - set(keys))
    keys.extend(extra)
    tmp = str(path) + f".tmp.{os.getpid()}"
    with open(tmp, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=keys); w.writeheader()
        for r in rows: w.writerow({k: r.get(k, "") for k in keys})
        f.flush(); os.fsync(f.fileno())
    os.replace(tmp, str(path))
    print(f"  Saved: {path}")


# ══════════════════════════════════════════════════════════════════════
# DATASET LOADING (reuse from meta_analysis.py)
# ══════════════════════════════════════════════════════════════════════

def load_dataset(ds_name, seed, n_train=5000, n_val=500, n_test=2000):
    """Unified loader - tries VGHL loader first, then OpenML direct."""
    try:
        from vghl.utils.config import ExperimentConfig
        from vghl.data.loaders import build_datasets
        cfg = ExperimentConfig()
        cfg.data.dataset = ds_name
        cfg.data.n_train = n_train
        cfg.data.n_val = n_val
        cfg.data.n_test = n_test
        cfg.seed = seed
        tr, va, te, meta = build_datasets(cfg)
        return tr.X, tr.y, te.X, te.y, meta
    except Exception:
        # Try frozen embed cache
        root = os.path.expanduser("~/.cache/vghl_data")
        cache = os.path.join(root, f"{ds_name}_cache.pt")
        if os.path.exists(cache):
            c = torch.load(cache, weights_only=True)
            X_tr, y_tr, X_te, y_te = c["X_tr"], c["y_tr"], c["X_te"], c["y_te"]
            rng = np.random.RandomState(seed)
            perm = rng.permutation(len(X_tr))
            n_tr = min(n_train, len(X_tr))
            n_te = min(n_test, len(X_te))
            X_tr, y_tr = X_tr[perm[:n_tr]], y_tr[perm[:n_tr]]
            nc = max(int(y_tr.max()) + 1, int(y_te.max()) + 1)
            return X_tr, y_tr, X_te[:n_te], y_te[:n_te], {"n_classes": nc, "input_dim": X_tr.shape[1]}
        raise


# All datasets to test (name, n_train, n_test, k)
ALL_DATASETS = [
    # Existing
    ("iris", 0, 0, 8), ("wine", 0, 0, 12), ("breast_cancer", 0, 0, 16),
    ("digits", 0, 0, 16), ("diabetes", 0, 0, 12),
    ("california_housing", 5000, 1000, 16), ("segment", 0, 0, 16),
    ("waveform", 3000, 500, 16), ("satellite", 3000, 500, 16),
    ("pendigits", 5000, 1000, 16), ("optdigits", 3000, 500, 16),
    ("letter", 5000, 1000, 16), ("covertype", 5000, 1000, 16),
    ("adult", 5000, 1000, 16), ("mnist_embed", 5000, 1000, 16),
    ("fmnist_embed", 5000, 1000, 16), ("cifar10_pca", 5000, 1000, 16),
    ("cifar10_resnet18", 5000, 1000, 16), ("newsgroups_embed", 3000, 500, 16),
    ("cora", 0, 0, 16),
    # New OpenML (using VGHL loader which auto-falls back to OpenML)
    ("shuttle", 5000, 2000, 16), ("magic", 5000, 2000, 16),
    ("texture", 3000, 1000, 16), ("phoneme", 3000, 1000, 16),
    ("vehicle", 0, 0, 12), ("ecoli", 0, 0, 8), ("yeast", 0, 0, 8),
    ("glass", 0, 0, 8), ("vowel", 0, 0, 12),
    ("isolet", 3000, 1000, 16), ("mfeat_fourier", 0, 0, 16),
    ("mfeat_karhunen", 0, 0, 16), ("madelon", 0, 0, 16),
    ("har", 3000, 1000, 16), ("wall_robot", 3000, 1000, 16),
    ("gas_drift", 5000, 2000, 16),
    # Large embed (from cache)
    ("cifar100_resnet18", 5000, 2000, 16),
    ("svhn_resnet18", 5000, 2000, 16),
    ("stl10_resnet18", 4000, 1000, 16),
]


def apply_pca(X_tr, X_te, n_components, seed=0):
    """Apply PCA, returns reduced features."""
    from sklearn.decomposition import PCA
    from sklearn.preprocessing import StandardScaler
    scaler = StandardScaler()
    X_tr_s = scaler.fit_transform(X_tr.numpy())
    X_te_s = scaler.transform(X_te.numpy())
    pca = PCA(n_components=min(n_components, X_tr_s.shape[1], X_tr_s.shape[0]),
              random_state=seed)
    X_tr_d = torch.tensor(pca.fit_transform(X_tr_s), dtype=torch.float32)
    X_te_d = torch.tensor(pca.transform(X_te_s), dtype=torch.float32)
    var_exp = pca.explained_variance_ratio_.sum()
    return X_tr_d, X_te_d, var_exp


def vghl_pipeline(X_tr, y_tr, X_te, y_te, k, T=5, prop_type="random_walk"):
    """Standard VGHL: build graph, propagate, kNN embed test, ridge."""
    N = len(X_tr)
    nc = max(int(y_tr.max()) + 1, int(y_te.max()) + 1)
    k_eff = min(k, N - 1)
    gc = GraphBuilderConfig(type="knn", k=k_eff)
    pc = PropagationConfig(type=prop_type, steps=T)
    g = build_base_graph(X_tr, gc)
    h_tr = propagate(X_tr, g["edge_index"], g["edge_weight"], N, pc)
    h_te = embed_queries_via_knn(h_tr, X_tr, X_te, k=k_eff)
    return h_tr, h_te, g, nc, k_eff


# ══════════════════════════════════════════════════════════════════════
# EXPERIMENT 1: PCA PRE-PROJECTION
# ══════════════════════════════════════════════════════════════════════
def run_pca_diagnostic(datasets, seeds, out_dir):
    print("\n" + "=" * 70)
    print("EXPERIMENT 1: PCA Pre-Projection")
    print("=" * 70)
    rows = []

    for ds_name, n_tr, n_te, k in datasets:
        for seed in seeds:
            try:
                X_tr, y_tr, X_te, y_te, meta = load_dataset(ds_name, seed, n_tr, 500, n_te)
            except Exception as e:
                print(f"  SKIP {ds_name}: {e}"); continue

            N, d = X_tr.shape
            nc = max(int(y_tr.max()) + 1, int(y_te.max()) + 1)
            k_eff = min(k, N - 1)

            # Baselines on raw features
            ridge_raw = ridge_eval(X_tr, y_tr, X_te, y_te, n_classes=nc)
            try:
                h_tr, h_te, g, _, _ = vghl_pipeline(X_tr, y_tr, X_te, y_te, k)
                vghl_raw = ridge_eval(h_tr, y_tr, h_te, y_te, n_classes=nc)
            except Exception:
                vghl_raw = -1.0

            rows.append({"dataset": ds_name, "seed": seed, "pca_dim": d,
                          "var_explained": 1.0, "ridge": ridge_raw, "vghl": vghl_raw,
                          "lift": vghl_raw - ridge_raw, "is_pca": False})

            # PCA dims to test (adaptive)
            if d > 50:
                pca_dims = [dim for dim in [16, 32, 50, 64, 128, 256] if dim < d]
            elif d > 16:
                pca_dims = [dim for dim in [8, 16, 32] if dim < d]
            else:
                pca_dims = []  # skip PCA for very low-d

            for pca_d in pca_dims:
                try:
                    X_tr_p, X_te_p, var_exp = apply_pca(X_tr, X_te, pca_d, seed)
                    ridge_pca = ridge_eval(X_tr_p, y_tr, X_te_p, y_te, n_classes=nc)
                    h_tr_p, h_te_p, _, _, _ = vghl_pipeline(X_tr_p, y_tr, X_te_p, y_te, k)
                    vghl_pca = ridge_eval(h_tr_p, y_tr, h_te_p, y_te, n_classes=nc)
                except Exception:
                    ridge_pca = vghl_pca = -1.0
                    var_exp = 0

                rows.append({"dataset": ds_name, "seed": seed, "pca_dim": pca_d,
                              "var_explained": round(var_exp, 4),
                              "ridge": ridge_pca, "vghl": vghl_pca,
                              "lift": vghl_pca - ridge_pca, "is_pca": True})

            # Print summary
            best_pca_lift = max((r["lift"] for r in rows
                                 if r["dataset"] == ds_name and r["seed"] == seed
                                 and r["is_pca"]), default=float('-inf'))
            raw_lift = vghl_raw - ridge_raw
            improved = "✓" if best_pca_lift > raw_lift + 0.005 else ""
            print(f"  {ds_name:<25} d={d:>4} raw_lift={raw_lift:+.4f} "
                  f"best_pca_lift={best_pca_lift:+.4f} {improved}", flush=True)

    _save_csv(rows, out_dir / "pca_diagnostic.csv")
    return rows


# ══════════════════════════════════════════════════════════════════════
# EXPERIMENT 2: READOUT VARIANTS
# ══════════════════════════════════════════════════════════════════════
def run_readout_diagnostic(datasets, seeds, out_dir):
    print("\n" + "=" * 70)
    print("EXPERIMENT 2: Readout Variants (Ridge vs kNN vs MLP vs SVM)")
    print("=" * 70)
    rows = []

    for ds_name, n_tr, n_te, k in datasets:
        for seed in seeds:
            try:
                X_tr, y_tr, X_te, y_te, meta = load_dataset(ds_name, seed, n_tr, 500, n_te)
            except Exception as e:
                print(f"  SKIP {ds_name}: {e}"); continue

            N, d = X_tr.shape
            nc = max(int(y_tr.max()) + 1, int(y_te.max()) + 1)
            k_eff = min(k, N - 1)

            # Get propagated features
            try:
                h_tr, h_te, g, _, _ = vghl_pipeline(X_tr, y_tr, X_te, y_te, k)
            except Exception:
                print(f"  SKIP {ds_name} s{seed}: pipeline failed"); continue

            base = {"dataset": ds_name, "seed": seed, "N": N, "d": d, "C": nc}

            # --- Readouts on RAW features ---
            # Ridge on raw
            ridge_raw = ridge_eval(X_tr, y_tr, X_te, y_te, n_classes=nc)
            rows.append({**base, "features": "raw", "readout": "ridge", "acc": ridge_raw})

            # kNN on raw
            from sklearn.neighbors import KNeighborsClassifier
            knn_clf = KNeighborsClassifier(n_neighbors=k_eff, n_jobs=-1)
            knn_clf.fit(X_tr.numpy(), y_tr.numpy())
            knn_raw = float(knn_clf.score(X_te.numpy(), y_te.numpy()))
            rows.append({**base, "features": "raw", "readout": "knn", "acc": knn_raw})

            # MLP on raw
            try:
                from sklearn.neural_network import MLPClassifier
                mlp = MLPClassifier(hidden_layer_sizes=(128,), max_iter=500,
                                     random_state=seed, early_stopping=True,
                                     validation_fraction=0.1)
                mlp.fit(X_tr.numpy(), y_tr.numpy())
                mlp_raw = float(mlp.score(X_te.numpy(), y_te.numpy()))
            except Exception:
                mlp_raw = -1.0
            rows.append({**base, "features": "raw", "readout": "mlp", "acc": mlp_raw})

            # SVM on raw (skip if N > 10k for speed)
            if N <= 10000:
                try:
                    from sklearn.svm import SVC
                    svm = SVC(kernel='rbf', random_state=seed, max_iter=5000)
                    svm.fit(X_tr.numpy(), y_tr.numpy())
                    svm_raw = float(svm.score(X_te.numpy(), y_te.numpy()))
                except Exception:
                    svm_raw = -1.0
                rows.append({**base, "features": "raw", "readout": "svm", "acc": svm_raw})

            # --- Readouts on PROPAGATED features ---
            # Ridge on propagated (standard VGHL)
            ridge_prop = ridge_eval(h_tr, y_tr, h_te, y_te, n_classes=nc)
            rows.append({**base, "features": "propagated", "readout": "ridge", "acc": ridge_prop})

            # kNN on propagated features
            knn_prop_clf = KNeighborsClassifier(n_neighbors=k_eff, n_jobs=-1)
            knn_prop_clf.fit(h_tr.numpy(), y_tr.numpy())
            knn_prop = float(knn_prop_clf.score(h_te.numpy(), y_te.numpy()))
            rows.append({**base, "features": "propagated", "readout": "knn", "acc": knn_prop})

            # MLP on propagated
            try:
                mlp2 = MLPClassifier(hidden_layer_sizes=(128,), max_iter=500,
                                      random_state=seed, early_stopping=True,
                                      validation_fraction=0.1)
                mlp2.fit(h_tr.numpy(), y_tr.numpy())
                mlp_prop = float(mlp2.score(h_te.numpy(), y_te.numpy()))
            except Exception:
                mlp_prop = -1.0
            rows.append({**base, "features": "propagated", "readout": "mlp", "acc": mlp_prop})

            # SVM on propagated (skip if N > 10k)
            if N <= 10000:
                try:
                    svm2 = SVC(kernel='rbf', random_state=seed, max_iter=5000)
                    svm2.fit(h_tr.numpy(), y_tr.numpy())
                    svm_prop = float(svm2.score(h_te.numpy(), y_te.numpy()))
                except Exception:
                    svm_prop = -1.0
                rows.append({**base, "features": "propagated", "readout": "svm", "acc": svm_prop})

            # --- Readouts on CONCAT [raw || propagated] ---
            H_cat_tr = torch.cat([X_tr, h_tr], dim=1)
            H_cat_te = torch.cat([X_te, h_te], dim=1)

            ridge_cat = ridge_eval(H_cat_tr, y_tr, H_cat_te, y_te, n_classes=nc)
            rows.append({**base, "features": "concat", "readout": "ridge", "acc": ridge_cat})

            try:
                mlp3 = MLPClassifier(hidden_layer_sizes=(128,), max_iter=500,
                                      random_state=seed, early_stopping=True,
                                      validation_fraction=0.1)
                mlp3.fit(H_cat_tr.numpy(), y_tr.numpy())
                mlp_cat = float(mlp3.score(H_cat_te.numpy(), y_te.numpy()))
            except Exception:
                mlp_cat = -1.0
            rows.append({**base, "features": "concat", "readout": "mlp", "acc": mlp_cat})

            # Summary
            best_raw = max(ridge_raw, knn_raw, mlp_raw)
            best_prop = max(ridge_prop, knn_prop, mlp_prop)
            best_overall = max(best_raw, best_prop, ridge_cat, mlp_cat)
            print(f"  {ds_name:<25} raw_best={best_raw:.4f} prop_best={best_prop:.4f} "
                  f"cat_best={max(ridge_cat, mlp_cat):.4f} overall={best_overall:.4f}", flush=True)

    _save_csv(rows, out_dir / "readout_diagnostic.csv")
    return rows


# ══════════════════════════════════════════════════════════════════════
# EXPERIMENT 3: GRAPH QUALITY AUDIT
# ══════════════════════════════════════════════════════════════════════
def run_graph_quality(datasets, seeds, out_dir):
    print("\n" + "=" * 70)
    print("EXPERIMENT 3: Graph Quality Audit")
    print("=" * 70)
    rows = []

    for ds_name, n_tr, n_te, k in datasets:
        for seed in seeds:
            try:
                X_tr, y_tr, X_te, y_te, meta = load_dataset(ds_name, seed, n_tr, 500, n_te)
            except Exception as e:
                print(f"  SKIP {ds_name}: {e}"); continue

            N, d = X_tr.shape
            nc = max(int(y_tr.max()) + 1, int(y_te.max()) + 1)
            k_eff = min(k, N - 1)

            gc = GraphBuilderConfig(type="knn", k=k_eff)
            g = build_base_graph(X_tr, gc)
            ei = g["edge_index"]

            # Label purity on raw graph
            y_np = y_tr.numpy()
            src_labels = y_np[ei[0].numpy()]
            dst_labels = y_np[ei[1].numpy()]
            purity_raw = float((src_labels == dst_labels).mean())

            # Label purity after PCA (if d > 50)
            purity_pca = purity_raw
            pca_dim_used = d
            if d > 50:
                try:
                    X_tr_p, _, _ = apply_pca(X_tr, X_te, 50, seed)
                    gc_p = GraphBuilderConfig(type="knn", k=k_eff)
                    g_p = build_base_graph(X_tr_p, gc_p)
                    ei_p = g_p["edge_index"]
                    src_p = y_np[ei_p[0].numpy()]
                    dst_p = y_np[ei_p[1].numpy()]
                    purity_pca = float((src_p == dst_p).mean())
                    pca_dim_used = 50
                except Exception:
                    pass

            # Degree stats
            degree = torch.zeros(N)
            degree.scatter_add_(0, ei[0], torch.ones(ei.shape[1]))
            deg_mean = degree.mean().item()
            deg_std = degree.std().item()

            # Cross-class edge fraction
            cross_class_frac = 1.0 - purity_raw

            # Distance statistics: are kNN distances concentrated?
            ew = g["edge_weight"]
            dist_mean = ew.mean().item() if ew.numel() > 0 else 0
            dist_std = ew.std().item() if ew.numel() > 0 else 0
            dist_cv = dist_std / max(dist_mean, 1e-10)  # coefficient of variation

            rows.append({
                "dataset": ds_name, "seed": seed, "N": N, "d": d, "C": nc,
                "k": k_eff,
                "label_purity_raw": round(purity_raw, 4),
                "label_purity_pca50": round(purity_pca, 4),
                "purity_improvement": round(purity_pca - purity_raw, 4),
                "cross_class_frac": round(cross_class_frac, 4),
                "deg_mean": round(deg_mean, 2),
                "deg_std": round(deg_std, 2),
                "dist_mean": round(dist_mean, 4),
                "dist_cv": round(dist_cv, 4),
            })

            print(f"  {ds_name:<25} d={d:>4} purity={purity_raw:.3f} "
                  f"pca50_purity={purity_pca:.3f} "
                  f"dist_cv={dist_cv:.3f}", flush=True)

    _save_csv(rows, out_dir / "graph_quality.csv")
    return rows


# ══════════════════════════════════════════════════════════════════════
# EXPERIMENT 4: TEST EMBEDDING VARIANTS
# ══════════════════════════════════════════════════════════════════════
def run_test_embed_diagnostic(datasets, seeds, out_dir):
    print("\n" + "=" * 70)
    print("EXPERIMENT 4: Test Embedding Variants")
    print("=" * 70)
    rows = []

    for ds_name, n_tr, n_te, k in datasets:
        for seed in seeds:
            try:
                X_tr, y_tr, X_te, y_te, meta = load_dataset(ds_name, seed, n_tr, 500, n_te)
            except Exception as e:
                print(f"  SKIP {ds_name}: {e}"); continue

            N, d = X_tr.shape
            nc = max(int(y_tr.max()) + 1, int(y_te.max()) + 1)
            k_eff = min(k, N - 1)
            gc = GraphBuilderConfig(type="knn", k=k_eff)
            pc = PropagationConfig(type="random_walk", steps=5)

            base = {"dataset": ds_name, "seed": seed, "N": N, "d": d}

            # No graph baseline
            ridge_raw = ridge_eval(X_tr, y_tr, X_te, y_te, n_classes=nc)
            rows.append({**base, "method": "no_graph_ridge", "acc": ridge_raw})

            try:
                g = build_base_graph(X_tr, gc)
                h_tr = propagate(X_tr, g["edge_index"], g["edge_weight"], N, pc)
            except Exception:
                print(f"  SKIP {ds_name} s{seed}: build failed"); continue

            # A: Standard kNN embed + ridge (current pipeline)
            h_te_knn = embed_queries_via_knn(h_tr, X_tr, X_te, k=k_eff)
            acc_a = ridge_eval(h_tr, y_tr, h_te_knn, y_te, n_classes=nc)
            rows.append({**base, "method": "knn_embed_ridge", "acc": acc_a})

            # B: Raw test + ridge on propagated train
            acc_b = ridge_eval(h_tr, y_tr, X_te, y_te, n_classes=nc)
            rows.append({**base, "method": "raw_test_ridge", "acc": acc_b})

            # C: kNN lookup on propagated features (no ridge)
            from sklearn.neighbors import KNeighborsClassifier
            knn_clf = KNeighborsClassifier(n_neighbors=k_eff, n_jobs=-1)
            knn_clf.fit(h_tr.numpy(), y_tr.numpy())
            # Test embedding via kNN then classify via kNN
            acc_c = float(knn_clf.score(h_te_knn.numpy(), y_te.numpy()))
            rows.append({**base, "method": "knn_embed_knn_readout", "acc": acc_c})

            # D: kNN lookup on raw test in propagated train space
            # (find k nearest propagated train points to raw test point)
            knn_raw_to_prop = KNeighborsClassifier(n_neighbors=k_eff, n_jobs=-1)
            knn_raw_to_prop.fit(X_tr.numpy(), y_tr.numpy())
            acc_d_raw_knn = float(knn_raw_to_prop.score(X_te.numpy(), y_te.numpy()))
            rows.append({**base, "method": "raw_knn_baseline", "acc": acc_d_raw_knn})

            # E: Concat [raw || propagated] train, [raw || knn_embed] test, ridge
            H_cat_tr = torch.cat([X_tr, h_tr], dim=1)
            H_cat_te = torch.cat([X_te, h_te_knn], dim=1)
            acc_e = ridge_eval(H_cat_tr, y_tr, H_cat_te, y_te, n_classes=nc)
            rows.append({**base, "method": "concat_ridge", "acc": acc_e})

            # F: Concat [raw || propagated] train, raw test doubled [raw || raw], ridge
            H_cat_te_raw = torch.cat([X_te, X_te], dim=1)
            acc_f = ridge_eval(H_cat_tr, y_tr, H_cat_te_raw, y_te, n_classes=nc)
            rows.append({**base, "method": "concat_raw_test_ridge", "acc": acc_f})

            best = max(acc_a, acc_b, acc_c, acc_e, acc_f)
            print(f"  {ds_name:<25} ng={ridge_raw:.4f} std={acc_a:.4f} "
                  f"raw_te={acc_b:.4f} knn_ro={acc_c:.4f} cat={acc_e:.4f} "
                  f"best={best:.4f}", flush=True)

    _save_csv(rows, out_dir / "test_embed_diagnostic.csv")
    return rows


# ══════════════════════════════════════════════════════════════════════
# EXPERIMENT 5: BEST COMBO (PCA + readout + propagation)
# ══════════════════════════════════════════════════════════════════════
def run_best_combo(datasets, seeds, out_dir):
    print("\n" + "=" * 70)
    print("EXPERIMENT 5: Best Combo (PCA + readout + propagation)")
    print("=" * 70)
    rows = []

    pca_dims = [None, 32, 50, 64]  # None = no PCA
    prop_types = [("random_walk", 1), ("random_walk", 5), ("ppr", 5)]
    readouts = ["ridge", "knn", "mlp"]

    for ds_name, n_tr, n_te, k in datasets:
        for seed in seeds:
            try:
                X_tr, y_tr, X_te, y_te, meta = load_dataset(ds_name, seed, n_tr, 500, n_te)
            except Exception as e:
                print(f"  SKIP {ds_name}: {e}"); continue

            N, d = X_tr.shape
            nc = max(int(y_tr.max()) + 1, int(y_te.max()) + 1)
            k_eff = min(k, N - 1)

            # No-graph baselines
            ridge_raw = ridge_eval(X_tr, y_tr, X_te, y_te, n_classes=nc)
            from sklearn.neighbors import KNeighborsClassifier
            knn_raw = float(KNeighborsClassifier(n_neighbors=k_eff, n_jobs=-1).fit(
                X_tr.numpy(), y_tr.numpy()).score(X_te.numpy(), y_te.numpy()))

            rows.append({"dataset": ds_name, "seed": seed, "pca": "none",
                          "prop": "none", "readout": "ridge", "acc": ridge_raw,
                          "N": N, "d": d})
            rows.append({"dataset": ds_name, "seed": seed, "pca": "none",
                          "prop": "none", "readout": "knn", "acc": knn_raw,
                          "N": N, "d": d})

            best_acc = max(ridge_raw, knn_raw)
            best_config = "no_graph"

            for pca_d in pca_dims:
                if pca_d is not None and pca_d >= d:
                    continue
                if pca_d is not None:
                    try:
                        X_tr_p, X_te_p, _ = apply_pca(X_tr, X_te, pca_d, seed)
                    except Exception:
                        continue
                else:
                    X_tr_p, X_te_p = X_tr, X_te

                pca_label = f"pca{pca_d}" if pca_d else "raw"
                k_p = min(k, len(X_tr_p) - 1)

                for prop_name, T in prop_types:
                    try:
                        gc = GraphBuilderConfig(type="knn", k=k_p)
                        if prop_name == "ppr":
                            pc = PropagationConfig(type="ppr", steps=T, alpha=0.85)
                        else:
                            pc = PropagationConfig(type=prop_name, steps=T)
                        g = build_base_graph(X_tr_p, gc)
                        h_tr = propagate(X_tr_p, g["edge_index"], g["edge_weight"],
                                         len(X_tr_p), pc)
                        h_te = embed_queries_via_knn(h_tr, X_tr_p, X_te_p, k=k_p)
                    except Exception:
                        continue

                    prop_label = f"{prop_name}_T{T}"

                    for readout in readouts:
                        try:
                            if readout == "ridge":
                                acc = ridge_eval(h_tr, y_tr, h_te, y_te, n_classes=nc)
                            elif readout == "knn":
                                clf = KNeighborsClassifier(n_neighbors=k_p, n_jobs=-1)
                                clf.fit(h_tr.numpy(), y_tr.numpy())
                                acc = float(clf.score(h_te.numpy(), y_te.numpy()))
                            elif readout == "mlp":
                                from sklearn.neural_network import MLPClassifier
                                mlp = MLPClassifier(hidden_layer_sizes=(128,),
                                                     max_iter=500, random_state=seed,
                                                     early_stopping=True,
                                                     validation_fraction=0.1)
                                mlp.fit(h_tr.numpy(), y_tr.numpy())
                                acc = float(mlp.score(h_te.numpy(), y_te.numpy()))
                            else:
                                continue
                        except Exception:
                            acc = -1.0

                        rows.append({
                            "dataset": ds_name, "seed": seed,
                            "pca": pca_label, "prop": prop_label,
                            "readout": readout, "acc": acc,
                            "N": N, "d": d,
                        })

                        if acc > best_acc:
                            best_acc = acc
                            best_config = f"{pca_label}/{prop_label}/{readout}"

            print(f"  {ds_name:<25} ridge={ridge_raw:.4f} knn={knn_raw:.4f} "
                  f"best={best_acc:.4f} [{best_config}]", flush=True)

    _save_csv(rows, out_dir / "best_combo.csv")
    return rows


# ══════════════════════════════════════════════════════════════════════
# MAIN
# ══════════════════════════════════════════════════════════════════════
def main():
    p = argparse.ArgumentParser()
    p.add_argument("--seeds", type=str, default="0,1")
    p.add_argument("--out", type=str, default="outputs/pipeline_diagnostic")
    p.add_argument("--only", type=str, default=None)
    args = p.parse_args()
    seeds = [int(s) for s in args.seeds.split(",")]
    out = Path(args.out)
    only = (args.only or "all").lower()

    print("=" * 70)
    print(f"PIPELINE DIAGNOSTIC ({len(ALL_DATASETS)} datasets, seeds={seeds})")
    print("=" * 70)

    if only in ("all", "pca"):          run_pca_diagnostic(ALL_DATASETS, seeds, out)
    if only in ("all", "readout"):      run_readout_diagnostic(ALL_DATASETS, seeds, out)
    if only in ("all", "graph_quality"):run_graph_quality(ALL_DATASETS, seeds, out)
    if only in ("all", "test_embed"):   run_test_embed_diagnostic(ALL_DATASETS, seeds, out)
    if only in ("all", "best_combo"):   run_best_combo(ALL_DATASETS, seeds, out)

    print(f"\n{'='*70}")
    print("ALL DIAGNOSTICS DONE")
    print(f"Results in {out}/")
    print(f"{'='*70}")


if __name__ == "__main__":
    main()
