#!/usr/bin/env python3
"""Regime-B extended roster on 11 supplied graphs.

Per dataset/seed this script reports:
  * training-induced and full edge homophily (with train-edge counts),
  * fixed random-walk propagation + the exact closed-form ridge probe,
  * an oracle raw-feature envelope (ridge/logistic/RF), and
  * optional MLP/GCN/GAT readouts on given, random, and rewired graphs.

The symmetric degree-preserving control uses successful double-edge swaps and
emits runtime diagnostics. The default requests 2*|E_und| successful swaps;
increase --rewire-mult only when a stronger mixing check is needed.

Usage:
  python -u scripts/regime_b.py
  python -u scripts/regime_b.py --skip-gnn
  python -u scripts/regime_b.py --datasets texas,actor \
      --seeds 0,1,2 --models mlp,gcn,gat --device auto
"""
import argparse
import os
import random
import sys
from collections import defaultdict
from pathlib import Path

os.environ.setdefault("OMP_NUM_THREADS", "4")

import numpy as np
import torch

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))
sys.path.insert(0, os.path.dirname(__file__))

from native_graph import row_normalize, symmetrize_dedup  # noqa: E402
from run_real_experiments import _degree_preserving_rewire, _save_csv  # noqa: E402

ROOT = os.path.expanduser("~/.cache/vghl_pyg")
TAU, RIDGE_LAM = 5, 1e-2
DATASETS = [
    "cora", "citeseer", "pubmed", "computers", "photo",
    "coauthor_cs", "coauthor_physics", "texas", "wisconsin",
    "cornell", "actor",
]


def _parse_csv_list(value):
    return [x.strip() for x in value.split(",") if x.strip()]


def load_graph(name, seed):
    """Return X, y, raw edge_index, and train/val/test masks."""
    from torch_geometric.datasets import Actor, Amazon, Coauthor, Planetoid, WebKB

    if name in ("cora", "citeseer", "pubmed"):
        d = Planetoid(ROOT, {"cora": "Cora", "citeseer": "CiteSeer", "pubmed": "PubMed"}[name])[0]
        trm, vam, tem = d.train_mask, d.val_mask, d.test_mask
    elif name in ("computers", "photo"):
        d = Amazon(ROOT, {"computers": "Computers", "photo": "Photo"}[name])[0]
        trm, vam, tem = shchur_split(d.y, seed)
    elif name in ("coauthor_cs", "coauthor_physics"):
        d = Coauthor(ROOT, {"coauthor_cs": "CS", "coauthor_physics": "Physics"}[name])[0]
        trm, vam, tem = shchur_split(d.y, seed)
    elif name in ("texas", "wisconsin", "cornell"):
        d = WebKB(ROOT, name.capitalize())[0]
        c = seed % d.train_mask.shape[1]
        trm, vam, tem = d.train_mask[:, c], d.val_mask[:, c], d.test_mask[:, c]
    elif name == "actor":
        d = Actor(os.path.join(ROOT, "Actor"))[0]
        c = seed % d.train_mask.shape[1]
        trm, vam, tem = d.train_mask[:, c], d.val_mask[:, c], d.test_mask[:, c]
    else:
        raise ValueError(f"unknown dataset {name!r}")

    trm, vam, tem = trm.bool(), vam.bool(), tem.bool()
    missing = _validate_masks(d.y, trm, vam, tem, name, seed)
    return d.x.float(), d.y.long(), d.edge_index.long(), trm, vam, tem, missing


def _validate_masks(y, trm, vam, tem, name, seed):
    """Hard-fail on structural defects; soft-report class coverage.

    WebKB geom-gcn splits legitimately miss tiny classes in some columns
    (e.g. texas col 0 has no class-1 training node). That is a property
    of the community-standard split, not a defect: the run proceeds and
    the missing classes are recorded in the output as
    train_missing_classes, so the readout's inability to predict them is
    visible in the record rather than silently absorbed."""
    n = len(y)
    if any(m.ndim != 1 or len(m) != n for m in (trm, vam, tem)):
        raise ValueError(f"{name} seed {seed}: malformed masks")
    if bool((trm & vam).any() or (trm & tem).any() or (vam & tem).any()):
        raise ValueError(f"{name} seed {seed}: split masks overlap")
    if min(int(trm.sum()), int(vam.sum()), int(tem.sum())) == 0:
        raise ValueError(f"{name} seed {seed}: empty train/val/test split")
    missing = sorted(set(range(int(y.max()) + 1)) - set(y[trm].tolist()))
    if missing:
        print(f"  NOTE {name} seed {seed}: training split misses classes "
              f"{missing} (geom-gcn standard split; run proceeds, recorded "
              f"as train_missing_classes)", flush=True)
    return missing


def shchur_split(y, seed, n_train=20, n_val=30):
    """20 train + 30 validation nodes per class, remainder test."""
    g = torch.Generator().manual_seed(seed)
    n = y.shape[0]
    trm = torch.zeros(n, dtype=torch.bool)
    vam = torch.zeros(n, dtype=torch.bool)
    for c in range(int(y.max()) + 1):
        idx = (y == c).nonzero(as_tuple=True)[0]
        if len(idx) <= n_train + n_val:
            raise ValueError(
                f"class {c} has {len(idx)} nodes; need more than {n_train + n_val} "
                "for a nonempty class-specific test remainder"
            )
        perm = idx[torch.randperm(len(idx), generator=g)]
        trm[perm[:n_train]] = True
        vam[perm[n_train:n_train + n_val]] = True
    return trm, vam, ~(trm | vam)


def make_random_edges_exact(n, e, seed):
    """I1 directed null with exactly e non-self edge instances.

    Parallel edges are allowed, matching the multigraph interpretation used by
    PyG and sparse propagation. Self-loops are resampled rather than dropped.
    """
    rng = np.random.RandomState(seed + 555)
    src = rng.randint(0, n, size=e, dtype=np.int64)
    dst = rng.randint(0, n, size=e, dtype=np.int64)
    bad = src == dst
    while bad.any():
        dst[bad] = rng.randint(0, n, size=int(bad.sum()), dtype=np.int64)
        bad = src == dst
    return torch.tensor(np.stack([src, dst]), dtype=torch.long)


def propagate(x, ei, n, tau=TAU):
    """H = (D^-1(A+I))^tau X using sparse matrix multiplication."""
    loops = torch.arange(n, dtype=ei.dtype, device=ei.device)
    src = torch.cat([ei[0], loops])
    dst = torch.cat([ei[1], loops])
    deg = torch.zeros(n, dtype=x.dtype, device=x.device).index_add_(
        0, src, torch.ones(src.shape[0], dtype=x.dtype, device=x.device)
    )
    if bool((deg <= 0).any()):
        raise RuntimeError("nonpositive propagation degree after self-loop insertion")
    weight = 1.0 / deg[src]
    p = torch.sparse_coo_tensor(torch.stack([src, dst]), weight, (n, n)).coalesce()
    h = x
    for _ in range(tau):
        h = torch.sparse.mm(p, h)
    return h


def _solve_ridge(xtr, ytr, n_classes, lam):
    """Exact ridge weights, using the cheaper primal or dual system."""
    x64 = xtr.double()
    y64 = torch.nn.functional.one_hot(ytr, n_classes).double()
    n, d = x64.shape
    if n <= d:
        gram = x64 @ x64.T
        gram.diagonal().add_(lam)
        try:
            alpha = torch.linalg.solve(gram, y64)
        except RuntimeError:
            alpha = torch.linalg.lstsq(gram, y64).solution
        w = x64.T @ alpha
    else:
        gram = x64.T @ x64
        gram.diagonal().add_(lam)
        rhs = x64.T @ y64
        try:
            w = torch.linalg.solve(gram, rhs)
        except RuntimeError:
            w = torch.linalg.lstsq(gram, rhs).solution
    return w.to(dtype=xtr.dtype)


def ridge_acc(h, y, trm, tem, nc, lam=RIDGE_LAM):
    w = _solve_ridge(h[trm], y[trm], nc, lam)
    pred = (h[tem] @ w).argmax(1)
    return (pred == y[tem]).float().mean().item()


def raw_envelope(x, y, trm, tem, nc, seed, skip_rf=False):
    """Test-set oracle envelope; conservative comparator, not model selection."""
    accs = {"ridge": ridge_acc(x, y, trm, tem, nc)}
    xtr, ytr = x[trm].cpu().numpy(), y[trm].cpu().numpy()
    xte, yte = x[tem].cpu().numpy(), y[tem].cpu().numpy()

    from sklearn.linear_model import LogisticRegression

    lr = LogisticRegression(max_iter=2000, random_state=seed).fit(xtr, ytr)
    accs["logreg"] = float((lr.predict(xte) == yte).mean())
    if not skip_rf and x.shape[0] * x.shape[1] <= 3e8:
        from sklearn.ensemble import RandomForestClassifier

        rf = RandomForestClassifier(
            n_estimators=200, random_state=seed, n_jobs=-1
        ).fit(xtr, ytr)
        accs["rf"] = float((rf.predict(xte) == yte).mean())
    return max(accs.values()), accs


def homophily(ei, y, mask=None):
    """Directed-edge label agreement and the number of evaluated edges."""
    s, t = ei[0], ei[1]
    keep = torch.ones(s.shape[0], dtype=torch.bool, device=s.device)
    if mask is not None:
        keep = mask[s] & mask[t]
    count = int(keep.sum())
    if count == 0:
        return float("nan"), 0
    value = float((y[s[keep]] == y[t[keep]]).float().mean())
    return value, count


def _resolved_device(value):
    if value == "auto":
        return "cuda" if torch.cuda.is_available() else "cpu"
    if value.startswith("cuda") and not torch.cuda.is_available():
        raise RuntimeError(f"requested {value}, but CUDA is unavailable")
    return value


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--datasets", default=",".join(DATASETS))
    p.add_argument("--seeds", default="0,1,2")
    p.add_argument("--models", default="mlp,gcn,gat")
    p.add_argument("--skip-rf", action="store_true")
    p.add_argument("--skip-gnn", action="store_true")
    p.add_argument("--rewire-mult", type=int, default=2,
                   help="successful swaps requested per undirected edge")
    p.add_argument("--homophily-threshold", type=float, default=0.5)
    p.add_argument("--device", default="auto")
    p.add_argument("--gnn-epochs", type=int, default=200)
    p.add_argument("--out", default="outputs")
    a = p.parse_args()

    datasets = _parse_csv_list(a.datasets)
    unknown = sorted(set(datasets) - set(DATASETS))
    if unknown:
        p.error(f"unknown datasets: {unknown}")
    seeds = [int(s) for s in _parse_csv_list(a.seeds)]
    models = [] if a.skip_gnn else _parse_csv_list(a.models)
    if not set(models) <= {"mlp", "gcn", "gat"}:
        p.error("--models may contain only mlp,gcn,gat")
    if a.rewire_mult < 1 or a.gnn_epochs < 1:
        p.error("--rewire-mult and --gnn-epochs must be positive")
    device = _resolved_device(a.device) if models else "cpu"
    print(f"learned-model device: {device}" if models else "learned models skipped")

    rows = []
    out_path = Path(a.out) / "regime_b.csv"

    for ds in datasets:
        for seed in seeds:
            torch.manual_seed(seed)
            np.random.seed(seed)
            random.seed(seed)

            x, y, ei_raw, trm, vam, tem, tr_missing = load_graph(ds, seed)
            x = row_normalize(x)
            n, nc = x.shape[0], int(y.max()) + 1
            ei = symmetrize_dedup(ei_raw)
            # Reduce to a simple graph: strip self-loops uniformly.
            # The operator P = D^-1(A+I) supplies every node's
            # self-connection itself, so raw loops (present in WebKB)
            # are redundant with +I and are not part of the
            # connectivity being intervened on.
            ei = ei[:, ei[0] != ei[1]]
            e = ei.shape[1]
            e_und = int((ei[0] < ei[1]).sum())

            htr, n_htr = homophily(ei, y, trm)
            hfull, n_hfull = homophily(ei, y)
            if np.isnan(htr):
                regime = "undetermined"
            else:
                regime = "collapse" if htr > a.homophily_threshold else "no_gain"

            random_ei = make_random_edges_exact(n, e, seed)
            rewired_ei, rw = _degree_preserving_rewire(
                ei, n, a.rewire_mult * e_und, seed
            )
            if not (rw["degree_vector_unchanged"] and rw["reciprocity"] == 1.0):
                raise RuntimeError(f"{ds} seed {seed}: invalid degree-preserving control: {rw}")

            r = {
                "dataset": ds,
                "seed": seed,

                "train_missing_classes": ";".join(map(str, tr_missing)) if tr_missing else "",
                "N": n,
                "E_sym": e,
                "regime_pred": regime,
                "homophily_train": htr,
                "homophily_train_edges": n_htr,
                "homophily_full": hfull,
                "homophily_full_edges": n_hfull,
                "random_edge_instances": int(random_ei.shape[1]),
                "random_unique_edges": int(torch.unique(random_ei[0] * n + random_ei[1]).numel()),
                "rewire_swaps_requested": rw["swaps_requested"],
                "rewire_swaps_done": rw["swaps_done"],
                "rewire_overlap": rw["orig_edge_overlap"],
                "rewire_under_mixed": rw["under_mixed"],
            }

            conds = {"given": ei, "random_edges": random_ei, "degree_rewire": rewired_ei}
            for cname, edge_index in conds.items():
                h = propagate(x, edge_index, n)
                r[f"fixed_{cname}"] = ridge_acc(h, y, trm, tem, nc)
                del h

            r["best_raw"], per = raw_envelope(x, y, trm, tem, nc, seed, a.skip_rf)
            r["best_raw_is_test_oracle"] = True
            for key, value in per.items():
                r[f"raw_{key}"] = value

            if models:
                from gnn_native import train_eval

                for model_name in models:
                    if model_name == "mlp":
                        r["mlp_raw"] = train_eval(
                            "mlp", x, y, ei, trm, vam, tem, nc, seed,
                            device=device, epochs=a.gnn_epochs,
                        )
                    else:
                        for cname, edge_index in conds.items():
                            # PyG aggregates source->target, whereas the fixed
                            # operator uses rows as receiving nodes (i pulls from
                            # its listed out-neighbors). Flip directed edges so
                            # both readouts evaluate the same adjacency action.
                            pyg_edge_index = edge_index.flip(0)
                            r[f"{model_name}_{cname}"] = train_eval(
                                model_name, x, y, pyg_edge_index, trm, vam, tem, nc, seed,
                                device=device, epochs=a.gnn_epochs,
                            )

            rows.append(r)
            _save_csv(rows, out_path)
            shown = " ".join(
                f"{k}={v:.3f}" for k, v in r.items()
                if isinstance(v, float) and k not in ("homophily_train", "homophily_full")
            )
            print(
                f"  {ds} s{seed} hom_tr={htr:.3f} (n_edges={n_htr}) "
                f"rw={rw['swaps_done']}/{rw['swaps_requested']} "
                f"overlap={rw['orig_edge_overlap']:.3f} {shown}",
                flush=True,
            )

    float_cols = sorted({k for r in rows for k, v in r.items() if isinstance(v, float)})
    by = defaultdict(list)
    for r in rows:
        by[r["dataset"]].append(r)
    print("\n" + f"{'dataset':<18}" + " ".join(f"{c[:14]:>15}" for c in float_cols))
    for ds, rs in by.items():
        values = []
        for c in float_cols:
            xs = [r[c] for r in rs if c in r and np.isfinite(r[c])]
            values.append(f"{np.mean(xs):.3f}" if xs else "---")
        print(f"{ds:<18}" + " ".join(f"{v:>15}" for v in values))

    print("\nInterpretation must use the computed diagnostic, its edge count, and")
    print("the rewiring overlap/mixing diagnostics; do not infer scope from the")
    print("dataset name alone. best_raw is a test-set oracle envelope.")


if __name__ == "__main__":
    main()
