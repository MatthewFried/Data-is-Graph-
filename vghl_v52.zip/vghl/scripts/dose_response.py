#!/usr/bin/env python3
"""Dose-response under partial destruction.

The substrate account predicts a monotone dose-response in the fraction p
of redirected edges. Non-monotone response or recovery at intermediate p
refutes it.

Protocol:
  - p=0 is the original graph, untouched: same edges, same weights.
  - Interventions are nested: one fixed random edge ordering and one fixed
    replacement destination per edge are drawn per (dataset, seed); dose p
    applies the first round(p*E) redirects of that fixed sequence, so the
    p=0.25 intervention is a superset of the p=0.1 intervention.
  - The dose interpolates between the paper's endpoints: hit edges receive
    the destroyed-edge convention (uniform random destination, weight 1.0,
    as in I1/I2); un-hit edges keep their original destination and kernel
    weight. p=0 is the original graph and p=1.0 is the random-destination
    condition.
    Decomposition modes: --mode topology (redirect only, kernel weights
    kept) and --mode weights (weight -> 1.0 only, destinations kept)
    separate the two channels of the intervention. In topology mode,
    datasets whose kernel weights are small relative to the self-loop
    (e.g. digits) show a flat curve: the operator goes inert rather than
    destructive. The monotonicity refuter applies to mode=both only, and
    only within the predicted-collapse regime: kNN purity > 0.6 AND
    kNN-ridge gap > 0 (both computed from the data before any
    intervention). Out-of-scope curves are reported descriptively.
  - Edge count is exactly constant (self-loop redirects are re-drawn,
    never dropped).
  - Trend statistics: per-(dataset, seed) Spearman rho of acc vs p, plus a
    sign test across runs.

Usage:
  python -u scripts/dose_response.py
  python -u scripts/dose_response.py --datasets digits,adult --seeds 0,1,2
"""
import os, sys
os.environ.setdefault("OMP_NUM_THREADS", "1")
os.environ.setdefault("MKL_NUM_THREADS", "1")

import argparse
import numpy as np
import torch
from pathlib import Path
from collections import defaultdict

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))
sys.path.insert(0, os.path.dirname(__file__))

from run_real_experiments import (  # noqa: E402
    DATASETS, load_dataset, get_k, _save_csv, eval_pipeline_edges,
)
from vghl.models.graph_builder import build_base_graph, GraphBuilderConfig  # noqa: E402
from vghl.models.propagation import PropagationConfig  # noqa: E402
from low_label import knn_purity  # noqa: E402

DEFAULT_DATASETS = ["digits", "optdigits", "pendigits", "satellite",
                    "segment", "iris", "adult", "covertype"]
FRACS = [0.0, 0.1, 0.25, 0.5, 0.75, 1.0]


def make_nested_redirector(ei, ew, N, seed, mode="both"):
    """Draw ONE fixed edge ordering, ONE replacement destination per edge.

    Returns dose(p) -> (ei_p, ew_p). Hit sets are NESTED across p (prefixes
    of one fixed ordering). p=0 returns the original (ei, ew) untouched.
    mode:
      both     -- hit edges: destination redirected AND weight -> 1.0
                  (destroyed-edge convention; default)
      topology -- destination redirected, original kernel weight kept
      weights  -- destination kept, weight -> 1.0
    Edge count is exactly constant; replacement destinations are re-drawn
    (vectorized rejection) until no self-loop remains, per fixed seed.
    """
    E = ei.shape[1]
    rng = np.random.RandomState(seed + 777)
    order = torch.tensor(rng.permutation(E), dtype=torch.long)
    src = ei[0]
    new_dst = torch.tensor(rng.randint(0, N, E), dtype=torch.long)
    bad = new_dst == src
    while bool(bad.any()):
        new_dst[bad] = torch.tensor(rng.randint(0, N, int(bad.sum())),
                                    dtype=torch.long)
        bad = new_dst == src
    w_destroyed = 1.0  # I1/I2 uniform-weight convention

    def dose(p):
        if p <= 0:
            return ei, ew
        m = int(round(E * p))
        hit_idx = order[:m]
        dst = ei[1].clone()
        ew_p = ew.clone()
        if mode in ("both", "topology"):
            dst[hit_idx] = new_dst[hit_idx]
        if mode in ("both", "weights"):
            ew_p[hit_idx] = w_destroyed
        return torch.stack([src, dst]), ew_p

    return dose


def run(datasets, seeds, tau, out_dir, mode="both"):
    out_dir = Path(out_dir)
    rows = []
    for ds in datasets:
        k = get_k(ds)
        for seed in seeds:
            try:
                X_tr, y_tr, _, _, X_te, y_te, _ = load_dataset(ds, seed)
            except Exception as e:
                print(f"  SKIP {ds} s{seed}: {e}", flush=True)
                continue
            N = len(X_tr)
            k_eff = min(k, N - 1)
            gc = GraphBuilderConfig(type="knn", k=k_eff)
            pc = PropagationConfig(type="random_walk", steps=tau)
            g = build_base_graph(X_tr, gc)
            ei0, ew0 = g["edge_index"], g["edge_weight"]
            purity = knn_purity(X_tr, y_tr, k_eff)
            # a priori chain diagnostic: kNN-vs-ridge gap on raw features
            from sklearn.neighbors import KNeighborsClassifier
            from vghl.models.probe import ridge_eval
            nc_ = max(int(y_tr.max()) + 1, int(y_te.max()) + 1)
            knn_clf = KNeighborsClassifier(n_neighbors=min(k_eff, N - 1))
            knn_clf.fit(X_tr.numpy(), y_tr.numpy())
            acc_knn = float((knn_clf.predict(X_te.numpy()) == y_te.numpy()).mean())
            acc_ridge = ridge_eval(X_tr, y_tr, X_te, y_te, n_classes=nc_)
            gap = acc_knn - acc_ridge
            dose = make_nested_redirector(ei0, ew0, N, seed, mode=mode)
            for frac in FRACS:
                ei_p, ew_p = dose(frac)
                acc, _ = eval_pipeline_edges(X_tr, y_tr, X_te, y_te,
                                             ei_p, ew_p, gc, pc)
                rows.append({"dataset": ds, "seed": seed, "mode": mode,
                             "purity": purity, "knn_ridge_gap": gap,
                             "rewire_frac": frac, "acc": acc})
        print(f"  {ds}: done", flush=True)

    # ── summary + paired trend statistics ──
    from scipy import stats as sst
    print(f"\n{'Dataset':<20} {'pur/gap':>10} "
          + " ".join(f"p={f:<5}" for f in FRACS) + "  mean_rho  in_scope")
    by = defaultdict(lambda: defaultdict(dict))
    pur, gaps = {}, {}
    for r in rows:
        by[r["dataset"]][r["seed"]][r["rewire_frac"]] = r["acc"]
        pur[r["dataset"]] = r["purity"]
        gaps[r["dataset"]] = r["knn_ridge_gap"]
    all_rhos = []
    for ds in datasets:
        if ds not in by:
            continue
        in_scope = pur[ds] > 0.6 and gaps[ds] > 0
        rhos = []
        for sd, curve in by[ds].items():
            xs = [f for f in FRACS if f in curve]
            ys = [curve[f] for f in xs]
            if len(xs) >= 3:
                if np.std(ys) == 0:
                    rhos.append(0.0)  # flat curve: no trend
                else:
                    rhos.append(sst.spearmanr(xs, ys).statistic)
        if in_scope:
            all_rhos.extend(rhos)
        means = [np.mean([by[ds][sd][f] for sd in by[ds] if f in by[ds][sd]])
                 for f in FRACS]
        mono = "yes" if (in_scope and all(r < 0 for r in rhos)) else                ("NO <-- inspect" if in_scope else "out of scope")
        print(f"{ds:<20} {pur[ds]:>4.2f}/{gaps[ds]:>+5.2f} "
              + " ".join(f"{m:.3f} " for m in means)
              + f" {np.mean(rhos):>+8.3f}  {mono}")
    n_neg = sum(1 for r in all_rhos if r < 0)
    if all_rhos:
        p_sign = sst.binomtest(n_neg, len(all_rhos), 0.5,
                               alternative="greater").pvalue
        print(f"\nTrend (in-scope datasets only): {n_neg}/{len(all_rhos)} "
              f"(dataset,seed) runs have negative Spearman rho; "
              f"sign test p={p_sign:.2e}")
    if mode == "both":
        print("Refuter (mode=both): any dataset with mean "
              "rho >= 0, or systematic recovery at intermediate p.")
    else:
        print(f"(mode={mode}: decomposition run; monotonicity refuter "
              "applies to mode=both only)")
    _save_csv(rows, out_dir / f"dose_response_{mode}.csv")
    return rows


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--datasets", type=str, default=None)
    p.add_argument("--seeds", type=str, default="0,1,2")
    p.add_argument("--tau", type=int, default=5)
    p.add_argument("--out", type=str, default="outputs")
    p.add_argument("--mode", type=str, default="both",
                   choices=["both", "topology", "weights"])
    a = p.parse_args()
    ds = a.datasets.split(",") if a.datasets else DEFAULT_DATASETS
    ds = [d for d in ds if d in DATASETS]
    run(ds, [int(s) for s in a.seeds.split(",")], a.tau, a.out, mode=a.mode)


if __name__ == "__main__":
    main()
