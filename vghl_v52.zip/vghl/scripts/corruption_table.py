#!/usr/bin/env python3
"""Corruption x detector table (mean AP lift) from the noise-suite CSV.

Usage:
  python -u scripts/run_real_experiments.py --only noise_suite
  python -u scripts/corruption_table.py \
      --csv outputs/real_experiments/noise_exp3_corruption_matrix.csv
"""
import argparse
import signal
import pandas as pd
if hasattr(signal, "SIGPIPE"):
    signal.signal(signal.SIGPIPE, signal.SIG_DFL)  # tolerate | head

ORDER = ["label_flip", "feature_and_label", "outlier_insert", "feature_perturb_only"]
LABEL = {"label_flip": r"\texttt{label\_flip}",
         "feature_and_label": r"\texttt{feat+label}",
         "outlier_insert": r"\texttt{outlier\_insert}",
         "feature_perturb_only": r"\texttt{feat\_only}"}
COLS = [("lift_disagreement", "Disagree"), ("lift_stability", "Stability"),
        ("lift_knn_dist", "kNN dist"), ("lift_lof", "LOF"),
        ("lift_centroid_dist", "Centroid"), ("lift_margin", "Margin")]


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--csv", default="outputs/real_experiments/noise_exp3_corruption_matrix.csv")
    a = p.parse_args()
    df = pd.read_csv(a.csv)
    g = df.groupby("noise_type")[[c for c, _ in COLS]].mean()

    print("Mean AP lift by corruption type and detector:\n")
    print(f"{'Corruption':<24}" + "".join(f"{n:>10}" for _, n in COLS))
    for nt in ORDER:
        row = g.loc[nt]
        print(f"{nt:<24}" + "".join(f"{row[c]:>+10.3f}" for c, _ in COLS))

    print("\nLaTeX body rows:")
    for nt in ORDER:
        row = g.loc[nt]
        best = row.idxmax()
        cells = []
        for c, _ in COLS:
            v = f"{row[c]:+.3f}"
            cells.append(rf"$\mathbf{{{v}}}$" if c == best else f"${v}$")
        print(f"{LABEL[nt]:<28} & " + " & ".join(cells) + r" \\")


if __name__ == "__main__":
    main()
