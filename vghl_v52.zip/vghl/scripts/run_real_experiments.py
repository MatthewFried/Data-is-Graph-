#!/usr/bin/env python3
"""Main experiment runner for the feature-induced (kNN) regime.

Pipeline: kNN graph phi(X) -> fixed random-walk propagation D^-1(A+I),
tau steps -> closed-form ridge readout. Each --only mode writes one CSV to
--out (default outputs/real_experiments):

  ablation        Full / No Prop / No Graph / tau=1 / Random Edges / Pruned
  rewiring        symmetric degree-preserving rewire control
  hp_transfer     three fixed (k, tau) configurations, no per-dataset tuning
  sensitivity     k x tau sweep
  noise_curve     accuracy under increasing label noise
  noise           noise identification (edge and node level)
  geometry        region selection (stable / boundary / random subsets)
  signal          intervention under label noise (raw, full, node prune,
                  random destination)
  reliability     accuracy by stability quintile
  representation  mean stability and accuracy across representations
  baselines       kNN / label propagation / spectral baselines
  scaling         accuracy vs N
  wallclock       runtime vs N
  noise_suite     corruption analysis (six experiments; not part of "all")

Usage:
    python -u scripts/run_real_experiments.py                    # all modes
    python -u scripts/run_real_experiments.py --only ablation --seeds 0,1,2,3,4
    python -u scripts/run_real_experiments.py --only noise_suite
    python -u scripts/run_real_experiments.py --quick
"""
import os, sys

# Thread control MUST be set before importing numpy/torch/sklearn
os.environ["OMP_NUM_THREADS"] = os.environ.get("OMP_NUM_THREADS", "1")
os.environ["MKL_NUM_THREADS"] = os.environ.get("MKL_NUM_THREADS", "1")
os.environ["OPENBLAS_NUM_THREADS"] = os.environ.get("OPENBLAS_NUM_THREADS", "1")
os.environ["NUMEXPR_NUM_THREADS"] = os.environ.get("NUMEXPR_NUM_THREADS", "1")
os.environ["VECLIB_MAXIMUM_THREADS"] = os.environ.get("VECLIB_MAXIMUM_THREADS", "1")

import argparse, csv, time, statistics as stats_mod
import numpy as np, torch
from pathlib import Path
from collections import defaultdict

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

# Now safe to set torch threads (after torch import)
torch.set_num_threads(1)
try:
    torch.set_num_interop_threads(1)
except RuntimeError:
    pass

from vghl.data.loaders import build_datasets, PointDataset
from vghl.utils.config import ExperimentConfig
from vghl.models.graph_builder import build_base_graph, GraphBuilderConfig
from vghl.models.propagation import propagate, PropagationConfig
from vghl.models.probe import ridge_eval, embed_queries_via_knn
from vghl.models.knn_backend import KNNIndex
from vghl.models.pruning import _build_neighbor_sets, _pairwise_jaccard

DATASETS = {
    # name:  (n_train, n_val, n_test, k, geometry_type, source)
    "iris":              (0, 0, 0, 8,  "low_dim_tabular",  "sklearn"),
    "wine":              (0, 0, 0, 12, "low_dim_tabular",  "sklearn"),
    "breast_cancer":     (0, 0, 0, 16, "low_dim_tabular",  "sklearn"),
    "digits":            (0, 0, 0, 16, "med_dim_tabular",  "sklearn"),
    "diabetes":          (0, 0, 0, 12, "low_dim_tabular",  "sklearn"),
    "california_housing":(5000, 1000, 1000, 16, "med_dim_tabular", "sklearn"),
    "segment":           (0, 0, 0, 16, "med_dim_tabular",  "OpenML"),
    "waveform":          (3000, 500, 500, 16, "high_dim_tabular", "OpenML"),
    "satellite":         (3000, 500, 500, 16, "high_dim_tabular", "OpenML"),
    "pendigits":         (5000, 1000, 1000, 16, "med_dim_tabular", "OpenML"),
    "optdigits":         (3000, 500, 500, 16, "med_dim_tabular",  "OpenML"),
    "letter":            (5000, 1000, 1000, 16, "med_dim_tabular", "OpenML"),
    "covertype":         (5000, 1000, 1000, 16, "high_dim_tabular","OpenML"),
    "adult":             (5000, 1000, 1000, 16, "med_dim_tabular", "OpenML"),
    "mnist_embed":       (5000, 1000, 1000, 16, "high_dim_embed",  "torchvision"),
    "fmnist_embed":      (5000, 1000, 1000, 16, "high_dim_embed",  "torchvision"),
    "cifar10_pca":       (5000, 1000, 1000, 16, "very_high_dim",   "torchvision"),
    "cifar10_resnet18":  (5000, 1000, 1000, 16, "pretrained_embed","torchvision"),
    "newsgroups_embed":  (3000, 500, 500, 16, "text_embed",        "sklearn"),
    "cora":              (0, 0, 0, 16, "graph_native",      "planetoid"),
}
QUICK_DATASETS = ["breast_cancer", "digits", "mnist_embed"]

def load_dataset(name, seed, n_train_override=None):
    n_train, n_val, n_test, _, _, _ = DATASETS[name]
    if n_train_override is not None:
        n_train = n_train_override
        n_val = max(n_train // 5, 50)
        n_test = max(n_train // 5, 50)
    cfg = ExperimentConfig()
    cfg.data.dataset = name
    cfg.data.n_train = n_train
    cfg.data.n_val = n_val
    cfg.data.n_test = n_test
    cfg.seed = seed
    tr, va, te, meta = build_datasets(cfg)
    return tr.X, tr.y, va.X, va.y, te.X, te.y, meta

def get_k(name): return DATASETS[name][3]
def get_geometry(name): return DATASETS[name][4]
def get_source(name): return DATASETS[name][5]

# ── Core utilities ─────────────────────────────────────────────────
def adaptive_sigma(X, graph_cfg):
    g = build_base_graph(X, graph_cfg)
    ei = g["edge_index"]
    return max(0.05 * (X[ei[0]] - X[ei[1]]).norm(dim=1).median().item(), 1e-6)

def compute_stability(X, graph_cfg, n_trials=5, seed=0):
    N, d = X.shape; device = X.device
    sigma = adaptive_sigma(X, graph_cfg)
    rng = np.random.RandomState(seed)
    boot_sets = []
    for _ in range(n_trials):
        noise = torch.tensor(rng.randn(N, d).astype(np.float32) * sigma, device=device, dtype=X.dtype)
        g = build_base_graph(X + noise, graph_cfg)
        boot_sets.append(_build_neighbor_sets(g["edge_index"], N, device))
    return _pairwise_jaccard(boot_sets, N, device), sigma

def compute_boundary(X, y, k_boundary=128):
    N = X.shape[0]; k_b = min(k_boundary, N - 1)
    index = KNNIndex(X.detach().cpu())
    ind, _ = index.query(X.detach().cpu(), k_b + 1)
    ind = ind[:, 1:]
    nl = y.detach().cpu()[torch.tensor(ind, dtype=torch.long)]
    return (nl != y.detach().cpu().unsqueeze(1)).float().mean(dim=1)

def eval_pipeline(X_tr, y_tr, X_val, y_val, graph_cfg, prop_cfg, k_embed=None):
    N = X_tr.shape[0]
    if N < 5: return 0.0, 0
    g = build_base_graph(X_tr, graph_cfg)
    h = propagate(X_tr, g["edge_index"], g["edge_weight"], N, prop_cfg)
    k_e = min(graph_cfg.k if k_embed is None else k_embed, N)
    h_val = embed_queries_via_knn(h, X_tr, X_val, k=k_e)
    nc = max(int(y_tr.max()) + 1, int(y_val.max()) + 1)
    return ridge_eval(h, y_tr, h_val, y_val, n_classes=nc), g["edge_index"].shape[1]

def eval_pipeline_edges(X_tr, y_tr, X_val, y_val, ei, ew, graph_cfg, prop_cfg):
    N = X_tr.shape[0]
    if N < 5: return 0.0, 0
    h = propagate(X_tr, ei, ew, N, prop_cfg)
    k_e = min(graph_cfg.k, N)
    h_val = embed_queries_via_knn(h, X_tr, X_val, k=k_e)
    nc = max(int(y_tr.max()) + 1, int(y_val.max()) + 1)
    return ridge_eval(h, y_tr, h_val, y_val, n_classes=nc), ei.shape[1]

# ── Noise injection ───────────────────────────────────────────────
def inject_label_noise(X, y, frac, seed):
    rng = np.random.RandomState(seed); n = len(y); n_flip = int(n * frac)
    flip_idx = rng.choice(n, n_flip, replace=False)
    nc = int(y.max()) + 1; y_n = y.clone()
    for i in flip_idx:
        o = y_n[i].item(); nv = rng.randint(0, nc - 1)
        if nv >= o: nv += 1
        y_n[i] = nv
    is_n = torch.zeros(n, dtype=torch.bool); is_n[flip_idx] = True
    return X.clone(), y_n, is_n

def inject_outlier_points(X, y, frac, seed):
    """Inject uniform random outlier points (formerly misnamed 'feature_noise').

    Appends nn = frac*N new points sampled uniformly from the expanded bounding
    box, with random labels. is_noise mask marks the injected points.
    NOTE: these are *outlier insertions*, not perturbations of existing points.
    """
    rng = np.random.RandomState(seed); n0 = len(X); nn = int(n0 * frac)
    Xnp = X.detach().cpu().numpy()
    lo = Xnp.min(0) - 0.1*(Xnp.max(0)-Xnp.min(0))
    hi = Xnp.max(0) + 0.1*(Xnp.max(0)-Xnp.min(0))
    Xn = rng.uniform(lo, hi, (nn, Xnp.shape[1])).astype(np.float32)
    nc = int(y.max()) + 1
    yn = torch.tensor(rng.randint(0, nc, nn), dtype=torch.long)
    Xa = torch.cat([X, torch.tensor(Xn)]); ya = torch.cat([y, yn])
    isn = torch.zeros(len(Xa), dtype=torch.bool); isn[n0:] = True
    p = torch.randperm(len(Xa), generator=torch.Generator().manual_seed(seed))
    return Xa[p], ya[p], isn[p]

# Keep old name as alias so other callers don't break
inject_feature_noise = inject_outlier_points


def inject_feature_and_label_noise(X, y, frac, seed, sigma_scale=0.3):
    """Perturb features AND flip labels of frac*N existing points (mixed corruption).

    This is the hardest detection case: perturbed points look like normal
    data in isolation but disrupt local relational structure. Both feature
    geometry AND label consistency are corrupted simultaneously.
    """
    rng = np.random.RandomState(seed)
    n = len(X); n_perturb = int(n * frac)
    perturb_idx = rng.choice(n, n_perturb, replace=False)
    Xnp = X.detach().cpu().numpy()
    sigma = sigma_scale * Xnp.std(axis=0).clip(min=1e-8)
    nc = int(y.max()) + 1
    X_new = X.clone(); y_new = y.clone()
    noise = rng.randn(n_perturb, Xnp.shape[1]).astype(np.float32) * sigma
    X_new[perturb_idx] = X[perturb_idx] + torch.tensor(noise)
    for i in perturb_idx:
        o = y_new[i].item(); nv = rng.randint(0, nc - 1)
        if nv >= o: nv += 1
        y_new[i] = nv
    is_n = torch.zeros(n, dtype=torch.bool); is_n[perturb_idx] = True
    return X_new, y_new, is_n

# Keep old name as alias
inject_gaussian_feature_noise = inject_feature_and_label_noise


def inject_feature_perturb_only(X, y, frac, seed, sigma_scale=0.3):
    """Perturb features of frac*N existing points WITHOUT changing labels.

    Pure feature noise: labels are correct, but feature positions are
    shifted. Tests whether stability detects geometric displacement alone,
    without the label signal that label_flip and inject_feature_and_label_noise
    both provide.
    """
    rng = np.random.RandomState(seed)
    n = len(X); n_perturb = int(n * frac)
    perturb_idx = rng.choice(n, n_perturb, replace=False)
    Xnp = X.detach().cpu().numpy()
    sigma = sigma_scale * Xnp.std(axis=0).clip(min=1e-8)
    X_new = X.clone()
    noise = rng.randn(n_perturb, Xnp.shape[1]).astype(np.float32) * sigma
    X_new[perturb_idx] = X[perturb_idx] + torch.tensor(noise)
    is_n = torch.zeros(n, dtype=torch.bool); is_n[perturb_idx] = True
    return X_new, y.clone(), is_n



def stability_node_prune(X, y, graph_cfg, n_remove, seed):
    stab, _ = compute_stability(X, graph_cfg, seed=seed)
    _, worst = torch.topk(stab, n_remove, largest=False)
    mask = torch.ones(len(X), dtype=torch.bool); mask[worst] = False
    return mask, stab

def random_node_prune(X, n_remove, seed):
    rng = np.random.RandomState(seed + 9999)
    idx = rng.choice(len(X), n_remove, replace=False)
    mask = torch.ones(len(X), dtype=torch.bool); mask[idx] = False
    return mask

def make_geometry_destroyed_graph(X, y, graph_cfg, seed):
    g = build_base_graph(X, graph_cfg)
    ei, ew = g["edge_index"], g["edge_weight"]
    E, N = ei.shape[1], X.shape[0]
    rng = np.random.RandomState(seed + 777)
    nd = torch.tensor(rng.randint(0, N, E), dtype=torch.long)
    m = nd != ei[0]
    return torch.stack([ei[0][m], nd[m]]), ew[m]

def _save_csv(rows, path):
    if not rows: return
    path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    keys = list(rows[0].keys())
    extra = sorted({k for r in rows for k in r.keys()} - set(keys))
    keys.extend(extra)
    tmp = str(path) + f".tmp.{os.getpid()}"
    with open(tmp, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=keys); w.writeheader()
        for r in rows: w.writerow({k: r.get(k, "") for k in keys})
        f.flush(); os.fsync(f.fileno())
    os.replace(tmp, str(path))
    print(f"  Saved: {path}")

# ══════════════════════════════════════════════════════════════════════
# BASELINES
# ══════════════════════════════════════════════════════════════════════
def run_baselines(datasets_to_run, seeds, out_dir):
    print("\n" + "=" * 70)
    print("BASELINE COMPARISON: kNN vs LabelProp vs Spectral vs VGHL")
    print("=" * 70)
    rows = []
    for ds_name in datasets_to_run:
        k = get_k(ds_name)
        graph_cfg = GraphBuilderConfig(type="knn", k=k)
        prop_cfg = PropagationConfig(type="random_walk", steps=5)
        for seed in seeds:
            try:
                X_tr, y_tr, X_val, y_val, X_te, y_te, meta = load_dataset(ds_name, seed)
            except Exception as e:
                print(f"  SKIP {ds_name} s{seed}: {e}", flush=True); continue
            N, d = len(X_tr), X_tr.shape[1]
            nc = max(int(y_tr.max())+1, int(y_val.max())+1)
            Xn, yn = X_tr.numpy(), y_tr.numpy()
            Xtn, ytn = X_te.numpy(), y_te.numpy()

            from sklearn.neighbors import KNeighborsClassifier
            knn = KNeighborsClassifier(n_neighbors=min(k, N-1), n_jobs=1)
            knn.fit(Xn, yn); acc_knn = float(knn.score(Xtn, ytn))

            try:
                from sklearn.semi_supervised import LabelPropagation
                lp = LabelPropagation(kernel='knn', n_neighbors=min(k, N-1), max_iter=200, n_jobs=1)
                lp.fit(Xn, yn); acc_lp = float(lp.score(Xtn, ytn))
            except: acc_lp = float('nan')

            try:
                from sklearn.manifold import SpectralEmbedding
                from sklearn.neighbors import NearestNeighbors
                nc2 = min(d, 20, N-2)
                se = SpectralEmbedding(n_components=nc2, n_neighbors=min(k, N-1), random_state=seed, n_jobs=1)
                Xse = se.fit_transform(Xn)
                nn = NearestNeighbors(n_neighbors=min(8, len(Xse)), algorithm='auto', n_jobs=1)
                nn.fit(Xn); dists, inds = nn.kneighbors(Xtn)
                wt = 1.0/(dists+1e-8); wt = wt/wt.sum(axis=1, keepdims=True)
                Xset = np.sum(Xse[inds]*wt[:,:,None], axis=1)
                acc_spec = ridge_eval(torch.tensor(Xse, dtype=torch.float32), y_tr,
                                       torch.tensor(Xset, dtype=torch.float32), y_te, nc)
            except: acc_spec = float('nan')

            acc_vghl, ne = eval_pipeline(X_tr, y_tr, X_te, y_te, graph_cfg, prop_cfg)
            rows.append({"dataset": ds_name, "source": get_source(ds_name), "seed": seed,
                          "N": N, "d": d, "n_classes": nc,
                          "acc_knn": acc_knn, "acc_label_prop": acc_lp,
                          "acc_spectral": acc_spec, "acc_vghl": acc_vghl})

    print(f"\n{'='*95}")
    print(f"{'Dataset':<20} {'Src':<8} {'N':>6} {'d':>3} {'C':>2} {'kNN':>7} {'LblPr':>7} {'Spec':>7} {'VGHL':>7} {'D(best)':>8}")
    print(f"{'='*95}")
    by_ds = defaultdict(list)
    for r in rows: by_ds[r["dataset"]].append(r)
    wins, total = 0, 0
    for ds in [d for d in DATASETS if d in by_ds]:
        rs = by_ds[ds]
        def m(f):
            v = [r[f] for r in rs if not (isinstance(r[f],float) and np.isnan(r[f]))]
            return np.mean(v) if v else float('nan')
        ak, al, asp, av = m("acc_knn"), m("acc_label_prop"), m("acc_spectral"), m("acc_vghl")
        bl = [v for v in [ak,al,asp] if not np.isnan(v)]
        bb = max(bl) if bl else 0; d_ = av - bb
        def fmt(v): return f"{v:>7.3f}" if not np.isnan(v) else f"{'N/A':>7}"
        total += 1
        if d_ >= -0.005: wins += 1
        print(f"{ds:<20} {rs[0]['source']:<8} {rs[0]['N']:>6} {rs[0]['d']:>3} {rs[0]['n_classes']:>2} "
              f"{fmt(ak)} {fmt(al)} {fmt(asp)} {fmt(av)} {d_:>+8.4f}")
    print(f"{'='*95}")
    print(f"VGHL >= best baseline on {wins}/{total} datasets")
    _save_csv(rows, out_dir / "baselines.csv")
    return rows

# ══════════════════════════════════════════════════════════════════════
# SCALING
# ══════════════════════════════════════════════════════════════════════
def run_scaling(datasets_to_run, seeds, out_dir, sizes=(100, 250, 500, 1000, 2000, 5000)):
    print("\n" + "=" * 70)
    print("SCALING: Accuracy vs Dataset Size")
    print("=" * 70)
    scalable = [d for d in datasets_to_run if DATASETS[d][0] >= 2000 or DATASETS[d][0] == 0]
    rows = []
    for ds_name in scalable:
        k = get_k(ds_name)
        for seed in seeds:
            for Ns in sizes:
                try:
                    X_tr, y_tr, _, _, X_te, y_te, _ = load_dataset(ds_name, seed, n_train_override=Ns)
                except: continue
                aN = len(X_tr)
                if aN < 20: continue
                gc = GraphBuilderConfig(type="knn", k=min(k, aN-1))
                pc = PropagationConfig(type="random_walk", steps=5)
                av, ne = eval_pipeline(X_tr, y_tr, X_te, y_te, gc, pc)
                from sklearn.neighbors import KNeighborsClassifier
                knn = KNeighborsClassifier(n_neighbors=min(k, aN-1), n_jobs=1)
                knn.fit(X_tr.numpy(), y_tr.numpy())
                ak = float(knn.score(X_te.numpy(), y_te.numpy()))
                rows.append({"dataset": ds_name, "seed": seed, "N_target": Ns,
                              "N_actual": aN, "acc_vghl": av, "acc_knn": ak, "delta": av-ak})
    print(f"\n{'='*75}")
    print(f"{'Dataset':<20} {'N':>6} {'VGHL':>7} {'kNN':>7} {'D':>7}")
    print(f"{'='*75}")
    by_key = defaultdict(list)
    for r in rows: by_key[(r["dataset"], r["N_target"])].append(r)
    for key in sorted(by_key.keys()):
        ds, Nt = key; rs = by_key[key]
        av = np.mean([r["acc_vghl"] for r in rs]); ak = np.mean([r["acc_knn"] for r in rs])
        print(f"{ds:<20} {Nt:>6} {av:>7.4f} {ak:>7.4f} {av-ak:>+7.4f}")
    _save_csv(rows, out_dir / "scaling.csv")
    return rows

# ══════════════════════════════════════════════════════════════════════
# NOISE CURVES
# ══════════════════════════════════════════════════════════════════════
def run_noise_curve(datasets_to_run, seeds, out_dir,
                    noise_fracs=(0.0, 0.02, 0.05, 0.10, 0.15, 0.20, 0.30)):
    print("\n" + "=" * 70)
    print("NOISE DEGRADATION CURVES")
    print("=" * 70)
    rows = []
    for ds_name in datasets_to_run:
        k = get_k(ds_name)
        gc = GraphBuilderConfig(type="knn", k=k)
        pc = PropagationConfig(type="random_walk", steps=5)
        for seed in seeds:
            try: X_tr, y_tr, _, _, X_te, y_te, _ = load_dataset(ds_name, seed)
            except Exception as e: print(f"  SKIP {ds_name} s{seed}: {e}"); continue
            N = len(X_tr)
            for nf in noise_fracs:
                if nf > 0: _, yn, _ = inject_label_noise(X_tr, y_tr, nf, seed)
                else: yn = y_tr
                av, _ = eval_pipeline(X_tr, yn, X_te, y_te, gc, pc)
                if nf > 0:
                    nr = min(max(int(N*nf*1.2),5), N-20)
                    sm, _ = stability_node_prune(X_tr, yn, gc, nr, seed)
                    ap, _ = eval_pipeline(X_tr[sm], yn[sm], X_te, y_te, gc, pc)
                else: ap = av
                from sklearn.neighbors import KNeighborsClassifier
                knn = KNeighborsClassifier(n_neighbors=min(k, N-1), n_jobs=1)
                knn.fit(X_tr.numpy(), yn.numpy())
                ak = float(knn.score(X_te.numpy(), y_te.numpy()))
                rows.append({"dataset": ds_name, "seed": seed, "noise_frac": nf,
                              "acc_vghl": av, "acc_vghl_pruned": ap, "acc_knn": ak})
    print(f"\n{'='*85}")
    print(f"{'Dataset':<20} {'NF':>5} {'VGHL':>7} {'VGHL+P':>7} {'kNN':>7} {'D(V-K)':>7} {'D(P-V)':>7}")
    print(f"{'='*85}")
    by_key = defaultdict(list)
    for r in rows: by_key[(r["dataset"], r["noise_frac"])].append(r)
    for key in sorted(by_key.keys()):
        ds, nf = key; rs = by_key[key]
        av = np.mean([r["acc_vghl"] for r in rs])
        ap = np.mean([r["acc_vghl_pruned"] for r in rs])
        ak = np.mean([r["acc_knn"] for r in rs])
        print(f"{ds:<20} {nf:>5.0%} {av:>7.4f} {ap:>7.4f} {ak:>7.4f} {av-ak:>+7.4f} {ap-av:>+7.4f}")
    _save_csv(rows, out_dir / "noise_curve.csv")
    return rows

# ══════════════════════════════════════════════════════════════════════
# CLAIM A: Noise Identification
# ══════════════════════════════════════════════════════════════════════
def _edge_level_noise_detection(X, y, isn, graph_cfg, seed, n_bootstrap=5):
    """Compute true edge-level noise detection metrics.

    Ground truth: edges (i,j) where AT LEAST ONE endpoint is a noise node.
    Evaluated on UNIQUE UNDIRECTED edges (canonicalized), not duplicated
    directed pairs, to avoid double-counting and prevalence distortion.

    Detector: bootstrap edge instability = 1 - mean_survival.

    Returns dict with:
      edge_ap       - Average Precision (sklearn, correct)
      edge_chance   - prevalence of corrupted unique edges
      edge_ap_lift  - edge_ap - edge_chance
      edge_prec_f1, edge_rec_f1, edge_f1  - max-F1 operating point
      n_corrupted_edges, n_edges  - counts on unique undirected edges
    """
    from sklearn.metrics import average_precision_score, precision_recall_curve
    N = len(X)
    g = build_base_graph(X, graph_cfg)
    ei = g["edge_index"]
    E = ei.shape[1]

    empty = {"edge_ap": 0., "edge_chance": 0., "edge_ap_lift": 0.,
             "edge_prec_f1": 0., "edge_rec_f1": 0., "edge_f1": 0.,
             "n_corrupted_edges": 0, "n_edges": 0}
    if E == 0:
        return empty

    # Canonicalize to unique undirected edges
    u = torch.minimum(ei[0], ei[1])
    v = torch.maximum(ei[0], ei[1])
    hash_all = u * N + v
    hash_unique, inv_map = hash_all.unique(return_inverse=True)
    hash_sorted, sort_idx = hash_unique.sort()
    n_unique = int(hash_unique.shape[0])

    # Ground truth on unique edges
    u_uniq = (hash_unique // N).long()
    v_uniq = (hash_unique %  N).long()
    is_corrupt_uniq = (isn[u_uniq] | isn[v_uniq]).cpu().numpy().astype(bool)
    n_corrupt = int(is_corrupt_uniq.sum())

    if n_corrupt == 0 or n_corrupt == n_unique:
        chance = float(n_corrupt / n_unique)
        return {**empty, "edge_ap": chance, "edge_chance": chance,
                "edge_ap_lift": 0., "n_corrupted_edges": n_corrupt,
                "n_edges": n_unique}

    # Bootstrap edge survival on unique edges
    device = X.device
    sigma = adaptive_sigma(X, graph_cfg)
    rng = np.random.RandomState(seed)
    survival_unique = torch.zeros(n_unique, device=device)

    for _ in range(n_bootstrap):
        noise = torch.tensor(
            rng.randn(N, X.shape[1]).astype(np.float32) * sigma,
            device=device, dtype=X.dtype)
        gp = build_base_graph(X + noise, graph_cfg)
        pu = torch.minimum(gp["edge_index"][0], gp["edge_index"][1])
        pv = torch.maximum(gp["edge_index"][0], gp["edge_index"][1])
        ph = (pu * N + pv).unique().sort()[0]
        if ph.numel() > 0:
            pos = torch.searchsorted(ph, hash_sorted).clamp(max=ph.shape[0] - 1)
            found = ph[pos] == hash_sorted
        else:
            found = torch.zeros(n_unique, dtype=torch.bool, device=device)
        sv = torch.zeros(n_unique, device=device)
        sv[sort_idx] = found.float()
        survival_unique += sv

    survival_unique /= n_bootstrap
    instability = (1.0 - survival_unique).cpu().numpy()

    # Metrics via sklearn (correct AP, no artificial endpoints)
    chance = float(is_corrupt_uniq.mean())
    ap = float(average_precision_score(is_corrupt_uniq, instability))
    precs_c, recs_c, _ = precision_recall_curve(is_corrupt_uniq, instability)
    f1s = 2 * precs_c * recs_c / np.maximum(precs_c + recs_c, 1e-8)
    best_idx = int(np.argmax(f1s))

    return {
        "edge_ap":           ap,
        "edge_chance":       chance,
        "edge_ap_lift":      ap - chance,
        "edge_prec_f1":      float(precs_c[best_idx]),
        "edge_rec_f1":       float(recs_c[best_idx]),
        "edge_f1":           float(f1s[best_idx]),
        "n_corrupted_edges": n_corrupt,
        "n_edges":           n_unique,
    }

def _node_level_detection_at_budgets(stab, isn, budget_mults, N):
    """Node detection precision/recall at multiple removal budgets.

    budget_mults: list of multipliers relative to the TRUE number of noise nodes.
      e.g. [0.5, 1.0, 1.5, 2.0] means remove 0.5*n_noise ... 2.0*n_noise nodes.
    This correctly handles outlier_insert (where Nn > N_clean) because budgets
    are tied to the actual noise count, not a fraction of total dataset size.
    """
    results = []
    n_noise = int(isn.sum())
    if n_noise == 0:
        for mult in budget_mults:
            results.append({"budget_mult": mult, "n_removed": 0,
                             "node_prec": 0., "node_rec": 0.})
        return results
    for mult in budget_mults:
        nr = min(max(int(round(mult * n_noise)), 1), N - 5)
        _, worst_idx = torch.topk(stab, nr, largest=False)
        removed = torch.zeros(N, dtype=torch.bool)
        removed[worst_idx] = True
        n_noise_removed = int((removed & isn).sum())
        prec = n_noise_removed / nr if nr > 0 else 0.
        rec  = n_noise_removed / n_noise
        results.append({"budget_mult": mult, "n_removed": nr,
                         "node_prec": prec, "node_rec": rec})
    return results


def run_claim_a(datasets_to_run, seeds, out_dir, noise_fracs=(0.05, 0.1, 0.2)):
    """Noise identification: edge-level vs node-level detection.

    Three noise types:
      - label_flip: flip labels of frac*N existing points (features unchanged)
      - outlier_insert: inject frac*N uniform random points (outlier insertion)
      - feature_and_label: perturb features of frac*N points + flip labels

    For each, we compute:
      NODE-LEVEL: stability-based node removal precision/recall at four budgets
        (0.5x, 1x, 1.5x, 2x the noise fraction). Recall is budget-dependent.
      EDGE-LEVEL: true edge corruption detection using bootstrap edge survival.
        Ground truth = any edge touching a noise node. Reports precision@F1,
        recall@F1, F1, precision@recall>=0.5, and AUPRC. Compared to chance
        (= fraction of edges that are corrupted).
    """
    print("\n" + "=" * 70)
    print("CLAIM A: Noise Identification (Honest Edition)")
    print("  Node-level: stability pruning precision at multiple budgets")
    print("  Edge-level: bootstrap edge instability vs ground truth corrupted edges")
    print("=" * 70)

    rows = []
    for ds_name in datasets_to_run:
        k = get_k(ds_name)
        gc = GraphBuilderConfig(type="knn", k=k)
        pc = PropagationConfig(type="random_walk", steps=5)
        geo = get_geometry(ds_name)
        for seed in seeds:
            try:
                X_tr, y_tr, X_val, y_val, _, _, _ = load_dataset(ds_name, seed)
            except Exception as e:
                print(f"  SKIP {ds_name} s{seed}: {e}"); continue
            N = len(X_tr)
            acc_clean, _ = eval_pipeline(X_tr, y_tr, X_val, y_val, gc, pc)

            for nt in ["label_flip", "outlier_insert", "feature_and_label", "feature_perturb_only"]:
                for nf in noise_fracs:
                    if nt == "label_flip":
                        Xn, yn, isn = inject_label_noise(X_tr, y_tr, nf, seed)
                    elif nt == "outlier_insert":
                        Xn, yn, isn = inject_outlier_points(X_tr, y_tr, nf, seed)
                    else:  # feature_and_label
                        Xn, yn, isn = inject_gaussian_feature_noise(X_tr, y_tr, nf, seed)

                    Nn = len(Xn)
                    nn = int(isn.sum())
                    if nn == 0:
                        continue

                    acc_noisy, _ = eval_pipeline(Xn, yn, X_val, y_val, gc, pc)

                    # ── Node-level detection at multiple budgets ──────────────
                    stab, _ = compute_stability(Xn, gc, seed=seed)
                    budgets_mults = [0.5, 1.0, 1.5, 2.0]
                    node_results = _node_level_detection_at_budgets(stab, isn, budgets_mults, Nn)

                    # Accuracy after stability pruning at 1x budget
                    nr_1x = node_results[1]["n_removed"]  # index 1 = 1.0x budget
                    sm_1x = torch.ones(Nn, dtype=torch.bool)
                    _, worst = torch.topk(stab, nr_1x, largest=False)
                    sm_1x[worst] = False
                    acc_stab, _ = eval_pipeline(Xn[sm_1x], yn[sm_1x], X_val, y_val, gc, pc)

                    # Random removal at same budget for comparison
                    rm_1x = random_node_prune(Xn, nr_1x, seed)
                    acc_rand, _ = eval_pipeline(Xn[rm_1x], yn[rm_1x], X_val, y_val, gc, pc)

                    # ── Edge-level detection ──────────────────────────────────
                    edge_metrics = _edge_level_noise_detection(Xn, yn, isn, gc, seed)

                    base_row = {
                        "dataset": ds_name, "geometry": geo, "seed": seed,
                        "noise_type": nt, "noise_frac": nf,
                        "N": Nn, "n_noise": nn,
                        "node_chance": float(nn / Nn),  # true node-level chance
                        "acc_clean": acc_clean,
                        "acc_noisy": acc_noisy,
                        "acc_stab_1x": acc_stab,
                        "acc_rand_1x": acc_rand,
                    }

                    # Node detection columns at each budget multiplier
                    for nr_res, mult in zip(node_results, budgets_mults):
                        tag = f"x{mult:.1f}".replace(".", "")
                        base_row[f"node_prec_{tag}"] = nr_res["node_prec"]
                        base_row[f"node_rec_{tag}"]  = nr_res["node_rec"]
                        base_row[f"node_nrem_{tag}"] = nr_res["n_removed"]

                    # Edge detection columns
                    base_row.update({
                        "edge_ap":           edge_metrics["edge_ap"],
                        "edge_chance":       edge_metrics["edge_chance"],
                        "edge_ap_lift":      edge_metrics["edge_ap_lift"],
                        "edge_prec_f1":      edge_metrics["edge_prec_f1"],
                        "edge_rec_f1":       edge_metrics["edge_rec_f1"],
                        "edge_f1":           edge_metrics["edge_f1"],
                        "n_corrupted_edges": edge_metrics["n_corrupted_edges"],
                        "n_edges":           edge_metrics["n_edges"],
                    })
                    rows.append(base_row)

    # ── Print summary ─────────────────────────────────────────────────
    print(f"\n{'='*110}")
    print("NODE-LEVEL DETECTION (precision at 1x and 1.5x removal budget)")
    print(f"{'Dataset':<16} {'Type':<14} {'NF':>4} {'P@1x':>6} {'R@1x':>6} "
          f"{'P@1.5x':>7} {'R@1.5x':>7} {'Acc+':>6} {'Chance':>7}")
    print(f"{'='*110}")
    by_key = defaultdict(list)
    for r in rows:
        by_key[(r["dataset"], r["noise_type"], r["noise_frac"])].append(r)

    def _mean(rs, f):
        vals = [r[f] for r in rs if f in r and r[f] is not None
                and not (isinstance(r[f], float) and np.isnan(r[f]))]
        return float(np.mean(vals)) if vals else float('nan')

    for key, rs in sorted(by_key.items()):
        ds, nt, nf = key
        p1x  = _mean(rs, 'node_prec_x10')
        r1x  = _mean(rs, 'node_rec_x10')
        p15x = _mean(rs, 'node_prec_x15')
        r15x = _mean(rs, 'node_rec_x15')
        acc_delta  = _mean(rs, 'acc_stab_1x') - _mean(rs, 'acc_noisy')
        node_chance = _mean(rs, 'node_chance')
        print(f"{ds:<16} {nt:<14} {nf:>4.0%} "
              f"{p1x:>6.3f} {r1x:>6.3f} "
              f"{p15x:>7.3f} {r15x:>7.3f} "
              f"{acc_delta:>+6.4f} "
              f"{node_chance:>7.3f}")

    print(f"\n{'='*110}")
    print("EDGE-LEVEL DETECTION (bootstrap instability, unique undirected edges, sklearn AP)")
    print(f"{'Dataset':<16} {'Type':<14} {'NF':>4} "
          f"{'AP':>7} {'Chance':>7} {'Lift':>7} "
          f"{'P@F1':>7} {'R@F1':>7} {'F1':>6}")
    print(f"{'='*110}")
    for key, rs in sorted(by_key.items()):
        ds, nt, nf = key
        ap     = _mean(rs, 'edge_ap')
        chance = _mean(rs, 'edge_chance')
        lift   = _mean(rs, 'edge_ap_lift')
        print(f"{ds:<16} {nt:<14} {nf:>4.0%} "
              f"{ap:>7.3f} {chance:>7.3f} {lift:>+7.3f} "
              f"{_mean(rs,'edge_prec_f1'):>7.3f} "
              f"{_mean(rs,'edge_rec_f1'):>7.3f} "
              f"{_mean(rs,'edge_f1'):>6.3f}")

    _save_csv(rows, out_dir / "claim_a_noise.csv")
    return rows

# ══════════════════════════════════════════════════════════════════════
# CLAIM B: Geometric Universality
# ══════════════════════════════════════════════════════════════════════
def run_claim_b(datasets_to_run, seeds, out_dir):
    print("\n" + "=" * 70); print("CLAIM B: Geometric Universality"); print("=" * 70)
    rows = []
    for ds_name in datasets_to_run:
        k = get_k(ds_name)
        gc = GraphBuilderConfig(type="knn", k=k)
        pc = PropagationConfig(type="random_walk", steps=5)
        geo = get_geometry(ds_name)
        for seed in seeds:
            try: X_tr, y_tr, X_val, y_val, _, _, _ = load_dataset(ds_name, seed)
            except Exception as e: print(f"  SKIP {ds_name} s{seed}: {e}"); continue
            N = len(X_tr)
            stab, _ = compute_stability(X_tr, gc, seed=seed)
            bnd = compute_boundary(X_tr, y_tr, k_boundary=max(k*8, 128))
            full_acc, _ = eval_pipeline(X_tr, y_tr, X_val, y_val, gc, pc)
            ns = max(N//5, 20)
            subs = {
                "top_stable": torch.argsort(stab, descending=True)[:ns],
                "bot_stable": torch.argsort(stab, descending=False)[:ns],
                "top_bound":  torch.argsort(bnd, descending=True)[:ns],
                "bot_bound":  torch.argsort(bnd, descending=False)[:ns],
                "random":     torch.randperm(N, generator=torch.Generator().manual_seed(seed))[:ns],
            }
            accs = {}
            for sn, idx in subs.items():
                a, _ = eval_pipeline(X_tr[idx], y_tr[idx], X_val, y_val, gc, pc)
                accs[sn] = a
            rho = float(np.corrcoef(stab.numpy(), bnd.numpy())[0, 1])
            rows.append({"dataset": ds_name, "geometry": geo, "seed": seed, "N": N,
                          "rho": rho, "acc_full": full_acc, **{f"acc_{k_}": v for k_, v in accs.items()}})
    print(f"\n{'='*100}")
    print(f"{'Dataset':<16} {'N':>5} {'rho':>6} {'Full':>6} {'TopS':>6} {'BotS':>6} {'TopB':>6} {'BotB':>6} {'Rand':>6}")
    print(f"{'='*100}")
    by_ds = defaultdict(list)
    for r in rows: by_ds[r["dataset"]].append(r)
    for ds in [d for d in DATASETS if d in by_ds]:
        rs = by_ds[ds]
        def m(f): return np.mean([r[f] for r in rs])
        print(f"{ds:<16} {rs[0]['N']:>5} {m('rho'):>+6.3f} {m('acc_full'):>6.3f} "
              f"{m('acc_top_stable'):>6.3f} {m('acc_bot_stable'):>6.3f} "
              f"{m('acc_top_bound'):>6.3f} {m('acc_bot_bound'):>6.3f} {m('acc_random'):>6.3f}")
    _save_csv(rows, out_dir / "claim_b_geometry.csv")
    return rows

# ══════════════════════════════════════════════════════════════════════
# CLAIM C: Structural Signal
# ══════════════════════════════════════════════════════════════════════
def run_claim_c(datasets_to_run, seeds, out_dir, noise_fracs=(0.0, 0.1)):
    print("\n" + "=" * 70); print("CLAIM C: Structural Signal"); print("=" * 70)
    rows = []
    for ds_name in datasets_to_run:
        k = get_k(ds_name); gc = GraphBuilderConfig(type="knn", k=k); geo = get_geometry(ds_name)
        for seed in seeds:
            try: X_tr, y_tr, X_val, y_val, _, _, _ = load_dataset(ds_name, seed)
            except Exception as e: print(f"  SKIP {ds_name} s{seed}: {e}"); continue
            N = len(X_tr)
            for nf in noise_fracs:
                if nf > 0: Xn, yn, _ = inject_label_noise(X_tr, y_tr, nf, seed)
                else: Xn, yn = X_tr, y_tr
                p0 = PropagationConfig(type="random_walk", steps=0)
                acc_raw, _ = eval_pipeline(Xn, yn, X_val, y_val, gc, p0)
                gd_ei, gd_ew = make_geometry_destroyed_graph(Xn, yn, gc, seed)
                for T in [1, 5]:
                    pT = PropagationConfig(type="random_walk", steps=T)
                    af, _ = eval_pipeline(Xn, yn, X_val, y_val, gc, pT)
                    nr = max(int(len(Xn)*0.15),5)
                    sm, _ = stability_node_prune(Xn, yn, gc, nr, seed)
                    an, _ = eval_pipeline(Xn[sm], yn[sm], X_val, y_val, gc, pT)
                    rm = random_node_prune(Xn, nr, seed)
                    ar, _ = eval_pipeline(Xn[rm], yn[rm], X_val, y_val, gc, pT)
                    ad, _ = eval_pipeline_edges(Xn, yn, X_val, y_val, gd_ei, gd_ew, gc, pT)
                    rows.append({"dataset": ds_name, "geometry": geo, "seed": seed,
                                  "noise_frac": nf, "T": T, "acc_raw": acc_raw, "acc_full": af,
                                  "acc_node": an, "acc_rand": ar, "acc_dest": ad,
                                  "d_nr": an-ar, "d_fd": af-ad})
    print(f"\n{'='*95}")
    print(f"{'Dataset':<16} {'NF':>4} {'T':>2} {'Raw':>6} {'Full':>6} {'Node':>6} {'Rand':>6} {'Dest':>6} {'D(n-r)':>7} {'D(f-d)':>7}")
    print(f"{'='*95}")
    by_key = defaultdict(list)
    for r in rows: by_key[(r["dataset"], r["noise_frac"], r["T"])].append(r)
    for key, rs in sorted(by_key.items()):
        ds, nf, T = key
        def m(f): return np.mean([r[f] for r in rs])
        print(f"{ds:<16} {nf:>4.0%} {T:>2} {m('acc_raw'):>6.3f} {m('acc_full'):>6.3f} "
              f"{m('acc_node'):>6.3f} {m('acc_rand'):>6.3f} {m('acc_dest'):>6.3f} "
              f"{m('d_nr'):>+7.4f} {m('d_fd'):>+7.4f}")
    _save_csv(rows, out_dir / "claim_c_signal.csv")
    return rows

# ══════════════════════════════════════════════════════════════════════
# CLAIM D: Stability Predicts Reliability
# ══════════════════════════════════════════════════════════════════════
def run_claim_d(datasets_to_run, seeds, out_dir):
    print("\n" + "=" * 70); print("CLAIM D: Stability Predicts Reliability"); print("=" * 70)
    rows = []; nq = 5
    for ds_name in datasets_to_run:
        k = get_k(ds_name); gc = GraphBuilderConfig(type="knn", k=k)
        pc = PropagationConfig(type="random_walk", steps=5)
        for seed in seeds:
            try: X_tr, y_tr, X_val, y_val, _, _, _ = load_dataset(ds_name, seed)
            except Exception as e: print(f"  SKIP {ds_name} s{seed}: {e}"); continue
            stab, _ = compute_stability(X_tr, gc, seed=seed)
            qe = np.linspace(0, 1, nq+1)
            for qi in range(nq):
                lo = np.percentile(stab.numpy(), qe[qi]*100)
                hi = np.percentile(stab.numpy(), qe[qi+1]*100)
                qm = (stab >= lo) if qi == nq-1 else (stab >= lo) & (stab < hi)
                nq_ = int(qm.sum())
                if nq_ < 5: continue
                aq, _ = eval_pipeline(X_tr[qm], y_tr[qm], X_val, y_val, gc, pc)
                rows.append({"dataset": ds_name, "seed": seed, "quantile": qi,
                              "n_nodes": nq_, "mean_stab": stab[qm].mean().item(), "acc": aq})
    print(f"\n{'='*80}")
    print(f"{'Dataset':<16} {'Q1':>8} {'Q2':>8} {'Q3':>8} {'Q4':>8} {'Q5':>8} {'D(5-1)':>9}")
    print(f"{'='*80}")
    by_ds = defaultdict(lambda: defaultdict(list))
    for r in rows: by_ds[r["dataset"]][r["quantile"]].append(r["acc"])
    for ds in sorted(by_ds.keys()):
        accs = [np.mean(by_ds[ds].get(qi, [0])) for qi in range(nq)]
        d = accs[-1]-accs[0] if len(accs)==nq else 0
        print(f"{ds:<16} " + " ".join(f"{a:>8.4f}" for a in accs) + f" {d:>+9.4f}")
    _save_csv(rows, out_dir / "claim_d_reliability.csv")
    return rows

# ══════════════════════════════════════════════════════════════════════
# CLAIM E: Representation Quality
# ══════════════════════════════════════════════════════════════════════
def run_claim_e(seeds, out_dir):
    print("\n" + "=" * 70); print("CLAIM E: Representation Quality"); print("=" * 70)
    rows = []
    reps = [
        ("mnist_raw784","mnist"), ("mnist_pca50","mnist_embed"),
        ("fmnist_raw784","fashion_mnist"), ("fmnist_pca50","fmnist_embed"),
        ("cifar10_pca50","cifar10_pca"), ("breast_cancer","breast_cancer"),
        ("wine","wine"), ("digits","digits"), ("iris","iris"),
        ("newsgroups","newsgroups_embed"),
    ]
    for rn, dn in reps:
        gc = GraphBuilderConfig(type="knn", k=16)
        pc = PropagationConfig(type="random_walk", steps=5)
        for seed in seeds:
            try:
                cfg = ExperimentConfig(); cfg.data.dataset = dn
                cfg.data.n_train = 3000; cfg.data.n_val = 500; cfg.data.n_test = 500; cfg.seed = seed
                tr, va, _, _ = build_datasets(cfg)
                X_tr, y_tr, X_val, y_val = tr.X, tr.y, va.X, va.y
            except Exception as e: print(f"  SKIP {rn} s{seed}: {e}"); continue
            stab, _ = compute_stability(X_tr, gc, seed=seed)
            acc, _ = eval_pipeline(X_tr, y_tr, X_val, y_val, gc, pc)
            rows.append({"rep": rn, "dataset": dn, "seed": seed, "dim": X_tr.shape[1],
                          "N": len(X_tr), "stability": stab.mean().item(), "acc": acc})
    print(f"\n{'='*65}")
    print(f"{'Representation':<18} {'Dim':>5} {'N':>5} {'Stability':>10} {'Acc':>7}")
    print(f"{'='*65}")
    by_rep = defaultdict(list)
    for r in rows: by_rep[r["rep"]].append(r)
    for rep in sorted(by_rep.keys()):
        rs = by_rep[rep]
        print(f"{rep:<18} {rs[0]['dim']:>5} {rs[0]['N']:>5} "
              f"{np.mean([r['stability'] for r in rs]):>10.4f} {np.mean([r['acc'] for r in rs]):>7.4f}")
    _save_csv(rows, out_dir / "claim_e_representation.csv")
    return rows

# ══════════════════════════════════════════════════════════════════════
# HYPERPARAMETER SENSITIVITY
# ══════════════════════════════════════════════════════════════════════
SENSITIVITY_DATASETS = ["breast_cancer", "digits", "waveform", "satellite", "mnist_embed", "newsgroups_embed"]

def run_sensitivity(datasets_to_run, seeds, out_dir):
    """Sweep k and T on representative datasets to show robustness."""
    print("\n" + "=" * 70)
    print("HYPERPARAMETER SENSITIVITY: k × T sweep")
    print("=" * 70)
    ds_list = [d for d in datasets_to_run if d in SENSITIVITY_DATASETS]
    if not ds_list:
        ds_list = datasets_to_run[:6]
    k_values = [8, 16, 32]
    T_values = [1, 3, 5, 10]
    rows = []
    for ds_name in ds_list:
        for seed in seeds:
            X_tr, y_tr, _, _, X_te, y_te, _ = load_dataset(ds_name, seed)
            N = len(X_tr)
            nc = max(int(y_tr.max()) + 1, int(y_te.max()) + 1)
            for k in k_values:
                k_eff = min(k, N - 1)
                gc = GraphBuilderConfig(type="knn", k=k_eff)
                for T in T_values:
                    pc = PropagationConfig(type="random_walk", steps=T)
                    acc, ne = eval_pipeline(X_tr, y_tr, X_te, y_te, gc, pc)
                    rows.append({
                        "dataset": ds_name, "seed": seed, "k": k, "T": T,
                        "N": N, "acc": acc, "n_edges": ne,
                    })
            print(f"  {ds_name} s{seed}: done ({len(k_values)*len(T_values)} combos)")

    # Print summary: mean acc per (dataset, k, T)
    print(f"\n{'Dataset':<20} {'k':>3} {'T':>3} {'acc':>8} {'±':>7}")
    print("-" * 45)
    by_key = defaultdict(list)
    for r in rows:
        by_key[(r["dataset"], r["k"], r["T"])].append(r["acc"])
    for (ds, k, T) in sorted(by_key.keys()):
        accs = by_key[(ds, k, T)]
        m = np.mean(accs)
        s = np.std(accs) if len(accs) > 1 else 0
        print(f"{ds:<20} {k:>3} {T:>3} {m:>8.4f} {s:>7.4f}")

    # Print robustness: range across k×T for each dataset
    print(f"\n{'Dataset':<20} {'min':>8} {'max':>8} {'range':>8}")
    print("-" * 48)
    by_ds = defaultdict(list)
    for r in rows:
        by_ds[r["dataset"]].append(r["acc"])
    for ds in sorted(by_ds.keys()):
        accs = by_ds[ds]
        print(f"{ds:<20} {min(accs):>8.4f} {max(accs):>8.4f} {max(accs)-min(accs):>8.4f}")

    _save_csv(rows, out_dir / "sensitivity.csv")
    return rows


# ══════════════════════════════════════════════════════════════════════
# ABLATION
# ══════════════════════════════════════════════════════════════════════
def run_ablation(datasets_to_run, seeds, out_dir):
    """Ablate components: no propagation, no pruning, no stability, random edges."""
    print("\n" + "=" * 70)
    print("ABLATION: Component-wise contribution")
    print("=" * 70)
    rows = []
    for ds_name in datasets_to_run:
        k = get_k(ds_name)
        for seed in seeds:
            X_tr, y_tr, _, _, X_te, y_te, _ = load_dataset(ds_name, seed)
            N = len(X_tr)
            nc = max(int(y_tr.max()) + 1, int(y_te.max()) + 1)
            k_eff = min(k, N - 1)
            gc = GraphBuilderConfig(type="knn", k=k_eff)
            pc = PropagationConfig(type="random_walk", steps=5)

            # (1) Full VGHL pipeline
            acc_full, _ = eval_pipeline(X_tr, y_tr, X_te, y_te, gc, pc)

            # (2) No propagation (raw features + ridge)
            h_val_raw = embed_queries_via_knn(X_tr, X_tr, X_te, k=k_eff)
            acc_no_prop = ridge_eval(X_tr, y_tr, h_val_raw, y_te, n_classes=nc)

            # (3) No graph (ridge on raw features directly, no kNN embed)
            acc_no_graph = ridge_eval(X_tr, y_tr, X_te, y_te, n_classes=nc)

            # (4) Propagation T=1 only (minimal smoothing)
            pc1 = PropagationConfig(type="random_walk", steps=1)
            acc_t1, _ = eval_pipeline(X_tr, y_tr, X_te, y_te, gc, pc1)

            # (5) Random edges (same degree, random connectivity)
            g = build_base_graph(X_tr, gc)
            ei_real = g["edge_index"]
            E = ei_real.shape[1]
            rng_ab = np.random.RandomState(seed + 555)
            rand_src = torch.tensor(rng_ab.randint(0, N, E), dtype=torch.long)
            rand_dst = torch.tensor(rng_ab.randint(0, N, E), dtype=torch.long)
            # Remove self-loops
            valid = rand_src != rand_dst
            ei_rand = torch.stack([rand_src[valid], rand_dst[valid]])
            ew_rand = torch.ones(ei_rand.shape[1])
            acc_rand_edges, _ = eval_pipeline_edges(
                X_tr, y_tr, X_te, y_te, ei_rand, ew_rand, gc, pc)

            # (6) Stability pruned (remove 10% least stable, then propagate)
            n_prune = max(int(N * 0.1), 1)
            mask, _ = stability_node_prune(X_tr, y_tr, gc, n_prune, seed)
            X_p, y_p = X_tr[mask], y_tr[mask]
            Np = len(X_p)
            if Np >= 10:
                gc_p = GraphBuilderConfig(type="knn", k=min(k, Np - 1))
                acc_pruned, _ = eval_pipeline(X_p, y_p, X_te, y_te, gc_p, pc)
            else:
                acc_pruned = 0.0

            rows.append({
                "dataset": ds_name, "seed": seed, "N": N,
                "full_vghl": acc_full,
                "no_propagation": acc_no_prop,
                "no_graph": acc_no_graph,
                "prop_T1": acc_t1,
                "random_edges": acc_rand_edges,
                "stability_pruned": acc_pruned,
            })
        print(f"  {ds_name}: done", flush=True)

    # Print ablation table
    print(f"\n{'Dataset':<20} {'full':>7} {'no_prp':>7} {'no_grp':>7} {'T=1':>7} {'rnd_e':>7} {'pruned':>7}")
    print("-" * 68)
    by_ds = defaultdict(list)
    for r in rows:
        by_ds[r["dataset"]].append(r)
    for ds in [d for d in DATASETS if d in by_ds]:
        rs = by_ds[ds]
        def m(f): return np.mean([r[f] for r in rs])
        print(f"{ds:<20} {m('full_vghl'):>7.3f} {m('no_propagation'):>7.3f} "
              f"{m('no_graph'):>7.3f} {m('prop_T1'):>7.3f} "
              f"{m('random_edges'):>7.3f} {m('stability_pruned'):>7.3f}")

    _save_csv(rows, out_dir / "ablation.csv")
    return rows


# ══════════════════════════════════════════════════════════════════════
# WALL-CLOCK SCALING
# ══════════════════════════════════════════════════════════════════════
def run_wallclock(datasets_to_run, seeds, out_dir,
                  sizes=(100, 250, 500, 1000, 2000, 5000)):
    """Measure wall-clock time for VGHL pipeline at different N."""
    print("\n" + "=" * 70)
    print("WALL-CLOCK SCALING: Runtime vs N")
    print("=" * 70)
    scalable = [d for d in datasets_to_run if DATASETS[d][0] >= 2000 or DATASETS[d][0] == 0]
    rows = []
    for ds_name in scalable:
        k = get_k(ds_name)
        for seed in seeds[:3]:  # 3 seeds for timing (less noise)
            for Ns in sizes:
                try:
                    X_tr, y_tr, _, _, X_te, y_te, _ = load_dataset(ds_name, seed, n_train_override=Ns)
                except:
                    continue
                aN = len(X_tr)
                if aN < 20:
                    continue
                k_eff = min(k, aN - 1)
                gc = GraphBuilderConfig(type="knn", k=k_eff)
                pc = PropagationConfig(type="random_walk", steps=5)

                # Time each phase
                t0 = time.time()
                g = build_base_graph(X_tr, gc)
                t_graph = time.time() - t0

                t0 = time.time()
                h = propagate(X_tr, g["edge_index"], g["edge_weight"], aN, pc)
                t_prop = time.time() - t0

                t0 = time.time()
                h_val = embed_queries_via_knn(h, X_tr, X_te, k=k_eff)
                t_embed = time.time() - t0

                t0 = time.time()
                nc = max(int(y_tr.max()) + 1, int(y_te.max()) + 1)
                acc = ridge_eval(h, y_tr, h_val, y_te, n_classes=nc)
                t_ridge = time.time() - t0

                t_total = t_graph + t_prop + t_embed + t_ridge

                rows.append({
                    "dataset": ds_name, "seed": seed, "N": aN,
                    "t_graph": round(t_graph, 4),
                    "t_propagation": round(t_prop, 4),
                    "t_embed": round(t_embed, 4),
                    "t_ridge": round(t_ridge, 4),
                    "t_total": round(t_total, 4),
                    "acc": acc,
                })
        print(f"  {ds_name}: done", flush=True)

    # Print timing table
    print(f"\n{'Dataset':<20} {'N':>6} {'graph':>7} {'prop':>7} {'embed':>7} {'ridge':>7} {'total':>7}")
    print("-" * 68)
    by_key = defaultdict(list)
    for r in rows:
        by_key[(r["dataset"], r["N"])].append(r)
    for (ds, n) in sorted(by_key.keys(), key=lambda x: (x[0], x[1])):
        rs = by_key[(ds, n)]
        def m(f): return np.mean([r[f] for r in rs])
        print(f"{ds:<20} {n:>6} {m('t_graph'):>7.3f} {m('t_propagation'):>7.3f} "
              f"{m('t_embed'):>7.3f} {m('t_ridge'):>7.3f} {m('t_total'):>7.3f}")

    _save_csv(rows, out_dir / "wallclock.csv")
    return rows


# ══════════════════════════════════════════════════════════════════════
# HYPERPARAMETER TRANSFER TEST
# ══════════════════════════════════════════════════════════════════════
def run_hp_transfer(datasets_to_run, seeds, out_dir):
    """Fix hyperparams from one dataset group, apply unchanged to all others.

    Picks k=16, T=5 (tabular defaults) and evaluates on ALL datasets
    without any per-dataset tuning. Shows method is not dataset-specific.
    """
    print("\n" + "=" * 70)
    print("HYPERPARAMETER TRANSFER: Fixed config across all datasets")
    print("=" * 70)
    # Source configs: tuned on tabular, embed, and graph-native subsets
    configs = {
        "tabular_defaults":  {"k": 16, "T": 5},
        "small_k":           {"k": 8,  "T": 3},
        "large_k":           {"k": 32, "T": 10},
    }
    rows = []
    for ds_name in datasets_to_run:
        for seed in seeds:
            X_tr, y_tr, _, _, X_te, y_te, _ = load_dataset(ds_name, seed)
            N = len(X_tr)
            for cfg_name, cfg in configs.items():
                k_eff = min(cfg["k"], N - 1)
                gc = GraphBuilderConfig(type="knn", k=k_eff)
                pc = PropagationConfig(type="random_walk", steps=cfg["T"])
                acc, ne = eval_pipeline(X_tr, y_tr, X_te, y_te, gc, pc)
                rows.append({
                    "dataset": ds_name, "seed": seed, "config": cfg_name,
                    "k": cfg["k"], "T": cfg["T"], "N": N, "acc": acc,
                })
        print(f"  {ds_name}: done", flush=True)

    # Print: for each dataset, show acc under each fixed config
    print(f"\n{'Dataset':<22} {'tabular_def':>12} {'small_k':>12} {'large_k':>12} {'range':>8}")
    print("-" * 70)
    by_ds = defaultdict(lambda: defaultdict(list))
    for r in rows:
        by_ds[r["dataset"]][r["config"]].append(r["acc"])
    for ds in [d for d in DATASETS if d in by_ds]:
        d = by_ds[ds]
        mt = np.mean(d.get("tabular_defaults", [0]))
        ms = np.mean(d.get("small_k", [0]))
        ml = np.mean(d.get("large_k", [0]))
        rng = max(mt, ms, ml) - min(mt, ms, ml)
        print(f"{ds:<22} {mt:>12.4f} {ms:>12.4f} {ml:>12.4f} {rng:>8.4f}")

    _save_csv(rows, out_dir / "hp_transfer.csv")
    return rows


# ══════════════════════════════════════════════════════════════════════
# DEGREE-PRESERVING REWIRING CONTROL
# ══════════════════════════════════════════════════════════════════════
def _degree_preserving_rewire(ei, N, n_swaps, seed):
    """Undirected degree-preserving double-edge swap.

    Swaps operate on canonical undirected edges (u<v) and both directions
    are re-emitted, so reciprocity = 1.0 and the undirected degree vector
    is exactly preserved. Returns (edge_index, diagnostics_dict); every run should
    print the diagnostics.
    """
    rng = np.random.RandomState(seed)
    src_t, dst_t = ei[0], ei[1]
    mask = src_t < dst_t
    u = src_t[mask].tolist()
    v = dst_t[mask].tolist()
    n_und = len(u)
    orig_set = set(zip(u, v))
    edge_set = set(orig_set)
    swaps_done = 0
    for _ in range(n_swaps * 5):
        if swaps_done >= n_swaps:
            break
        i, j = rng.randint(0, n_und, 2)
        if i == j:
            continue
        a, b = u[i], v[i]
        c, d = u[j], v[j]
        e1 = (min(a, d), max(a, d))
        e2 = (min(c, b), max(c, b))
        if e1[0] == e1[1] or e2[0] == e2[1]:
            continue
        if e1 in edge_set or e2 in edge_set:
            continue
        edge_set.discard((a, b)); edge_set.discard((c, d))
        edge_set.add(e1); edge_set.add(e2)
        u[i], v[i] = e1
        u[j], v[j] = e2
        swaps_done += 1

    u_t = torch.tensor(u, dtype=ei.dtype)
    v_t = torch.tensor(v, dtype=ei.dtype)
    new_ei = torch.cat([torch.stack([u_t, v_t]), torch.stack([v_t, u_t])], dim=1)

    # ── mandatory control diagnostics ──
    deg_before = torch.zeros(N, dtype=torch.long).scatter_add_(
        0, ei[0], torch.ones(ei.shape[1], dtype=torch.long))
    deg_after = torch.zeros(N, dtype=torch.long).scatter_add_(
        0, new_ei[0], torch.ones(new_ei.shape[1], dtype=torch.long))
    pairs_after = set(zip(new_ei[0].tolist(), new_ei[1].tolist()))
    recip = sum(1 for (a, b) in pairs_after if (b, a) in pairs_after) / max(len(pairs_after), 1)
    diag = {
        "swaps_requested": n_swaps, "swaps_done": swaps_done,
        "edge_count_unchanged": new_ei.shape[1] == ei.shape[1],
        "degree_vector_unchanged": bool((deg_before == deg_after).all()),
        "reciprocity": recip,
        "self_loops": int((new_ei[0] == new_ei[1]).sum()),
        "duplicate_undirected": len(edge_set) != n_und,
        "orig_edge_overlap": len(edge_set & orig_set) / max(n_und, 1),
        "under_mixed": swaps_done < 0.5 * n_swaps,
    }
    if diag["under_mixed"]:
        print(f"    WARNING: rewire under-mixed ({swaps_done}/{n_swaps} swaps "
              f"accepted, overlap {diag['orig_edge_overlap']:.2f}); this "
              f"control is close to a null intervention for this graph "
              f"(e.g. near-clique kNN structure from duplicate rows).",
              flush=True)
    return new_ei, diag


def run_rewiring_control(datasets_to_run, seeds, out_dir):
    """Degree-preserving rewiring: preserves degree but destroys geometry.

    Tests whether performance depends on specific geometry, not just
    degree distribution. Stronger control than random edges.
    """
    print("\n" + "=" * 70)
    print("REWIRING CONTROL: Degree-preserving vs random vs real geometry")
    print("=" * 70)
    rows = []
    for ds_name in datasets_to_run:
        k = get_k(ds_name)
        for seed in seeds:
            X_tr, y_tr, _, _, X_te, y_te, _ = load_dataset(ds_name, seed)
            N = len(X_tr)
            nc = max(int(y_tr.max()) + 1, int(y_te.max()) + 1)
            k_eff = min(k, N - 1)
            gc = GraphBuilderConfig(type="knn", k=k_eff)
            pc = PropagationConfig(type="random_walk", steps=5)

            # (1) Real geometry
            acc_real, _ = eval_pipeline(X_tr, y_tr, X_te, y_te, gc, pc)

            # (2) Degree-preserving rewiring (symmetric double-edge swaps, 2x|E_und|)
            g = build_base_graph(X_tr, gc)
            ei_real, ew_real = g["edge_index"], g["edge_weight"]
            E = ei_real.shape[1]
            E_und = int((ei_real[0] < ei_real[1]).sum())
            ei_rewired, rw_diag = _degree_preserving_rewire(ei_real, N, 2 * E_und, seed)
            if seed == seeds[0]:
                print(f"    rewire diag: {rw_diag}", flush=True)
            assert rw_diag["degree_vector_unchanged"] and rw_diag["reciprocity"] == 1.0 \
                and rw_diag["self_loops"] == 0, f"rewire control invalid: {rw_diag}"
            ew_rewired = torch.ones(ei_rewired.shape[1])
            acc_rewired, _ = eval_pipeline_edges(
                X_tr, y_tr, X_te, y_te, ei_rewired, ew_rewired, gc, pc)

            # (3) Random edges (same E, no degree preservation)
            rng_r = np.random.RandomState(seed + 555)
            rand_src = torch.tensor(rng_r.randint(0, N, E), dtype=torch.long)
            rand_dst = torch.tensor(rng_r.randint(0, N, E), dtype=torch.long)
            valid = rand_src != rand_dst
            ei_rand = torch.stack([rand_src[valid], rand_dst[valid]])
            ew_rand = torch.ones(ei_rand.shape[1])
            acc_rand, _ = eval_pipeline_edges(
                X_tr, y_tr, X_te, y_te, ei_rand, ew_rand, gc, pc)

            rows.append({
                "dataset": ds_name, "seed": seed, "N": N,
                "real_geometry": acc_real,
                "degree_preserving_rewire": acc_rewired,
                "random_edges": acc_rand,
                "drop_rewire": acc_real - acc_rewired,
                "drop_random": acc_real - acc_rand,
            })
        print(f"  {ds_name}: real={np.mean([r['real_geometry'] for r in rows if r['dataset']==ds_name]):.3f} "
              f"rewired={np.mean([r['degree_preserving_rewire'] for r in rows if r['dataset']==ds_name]):.3f} "
              f"random={np.mean([r['random_edges'] for r in rows if r['dataset']==ds_name]):.3f}", flush=True)

    _save_csv(rows, out_dir / "rewiring_control.csv")
    return rows








# ══════════════════════════════════════════════════════════════════════
# NOISE CLAIM STRENGTHENING SUITE
# Six experiments to establish the noise-is-relational claim properly.
# Run via: --only noise_suite
# ══════════════════════════════════════════════════════════════════════

def _compute_auprc(scores, gt):
    """Average Precision (area under PR curve) via sklearn.

    Uses sklearn.metrics.average_precision_score which correctly handles
    step-interpolation and does not add artificial (0,1)/(1,0) endpoints.
    Chance baseline = gt.mean().
    """
    from sklearn.metrics import average_precision_score
    n_pos = int(gt.sum())
    if n_pos == 0 or n_pos == len(gt):
        return float(n_pos / max(len(gt), 1))
    return float(average_precision_score(gt, scores))


def _node_scores_all_methods(X, y, graph_cfg, seed):
    """Return dict of node-level anomaly scores for all baseline methods.

    Keys:
      stability   - Jaccard stability (low = anomalous)  [RELATIONAL]
      disagreement- fraction of kNN neighbors with different label [RELATIONAL]
      knn_dist    - mean distance to k nearest neighbors [POINTWISE]
      lof         - Local Outlier Factor                 [POINTWISE]
      centroid_dist - distance to own-class centroid     [POINTWISE]
      margin      - 1 - max softmax prob from kNN vote   [POINTWISE]
    All scores are returned as numpy arrays, normalised so HIGH = more anomalous.
    """
    from sklearn.neighbors import LocalOutlierFactor
    N, d = X.shape
    k = graph_cfg.k
    Xnp = X.detach().cpu().numpy()
    ynp = y.detach().cpu().numpy()

    scores = {}

    # ── RELATIONAL: stability ─────────────────────────────────────────
    stab, _ = compute_stability(X, graph_cfg, seed=seed)
    scores["stability"] = 1.0 - stab.numpy()      # invert: high = unstable

    # ── RELATIONAL: label disagreement ───────────────────────────────
    g = build_base_graph(X, graph_cfg)
    ei = g["edge_index"]
    src, dst = ei[0].numpy(), ei[1].numpy()
    disagree = np.zeros(N)
    count    = np.zeros(N)
    for s, d_ in zip(src, dst):
        count[s] += 1
        if ynp[s] != ynp[d_]:
            disagree[s] += 1
    with np.errstate(divide='ignore', invalid='ignore'):
        scores["disagreement"] = np.where(count > 0, disagree / count, 0.)

    # ── POINTWISE: mean kNN distance ─────────────────────────────────
    index = KNNIndex(X.detach().cpu())
    _, dists = index.query(X.detach().cpu(), k + 1)
    scores["knn_dist"] = dists[:, 1:].mean(axis=1)  # exclude self

    # ── POINTWISE: LOF ────────────────────────────────────────────────
    k_lof = min(k, N - 1)
    lof = LocalOutlierFactor(n_neighbors=k_lof, novelty=False)
    lof_scores = -lof.fit_predict(Xnp)   # LOF: -1=outlier, 1=inlier → negate
    scores["lof"] = (-lof.negative_outlier_factor_).astype(np.float32)

    # ── POINTWISE: centroid distance ─────────────────────────────────
    nc = int(ynp.max()) + 1
    centroid_d = np.zeros(N)
    for c in range(nc):
        mask = ynp == c
        if mask.sum() > 0:
            cent = Xnp[mask].mean(axis=0)
            centroid_d[mask] = np.linalg.norm(Xnp[mask] - cent, axis=1)
    scores["centroid_dist"] = centroid_d

    # ── POINTWISE: kNN-vote margin ────────────────────────────────────
    ind, _ = index.query(X.detach().cpu(), k + 1)
    ind = ind[:, 1:]   # (N, k)
    margin = np.zeros(N)
    for i in range(N):
        nbr_labels = ynp[ind[i]]
        counts = np.bincount(nbr_labels, minlength=nc).astype(float)
        margin[i] = 1.0 - counts.max() / max(counts.sum(), 1)
    scores["margin"] = margin

    return scores


def _edge_scores_all_methods(X, y, graph_cfg, seed, n_bootstrap=5):
    """Per-edge anomaly scores for edge-level detection benchmark.

    Keys:
      stability_edge - bootstrap edge survival (low survival = anomalous)
      label_disagree - 1 if endpoints have different labels, else 0
      dist_zscore    - z-score of edge length (long edges = anomalous)
      node_stab_min  - min endpoint node stability (anomalous if either node unstable)
      node_stab_mean - mean endpoint node stability
    Returns: scores dict (high=anomalous), edge_index, is_corrupt_edge (gt)
    """
    N = len(X)
    g = build_base_graph(X, graph_cfg)
    ei = g["edge_index"]
    E = ei.shape[1]
    if E == 0:
        empty = np.zeros(0)
        return {k: empty for k in
                ["stability_edge","label_disagree","dist_zscore",
                 "node_stab_min","node_stab_mean"]}, ei, np.zeros(0, dtype=bool)

    device = X.device
    sigma = adaptive_sigma(X, graph_cfg)
    rng = np.random.RandomState(seed)

    # Bootstrap edge survival
    u_orig = torch.minimum(ei[0], ei[1])
    v_orig = torch.maximum(ei[0], ei[1])
    hash_orig = u_orig * N + v_orig
    hash_unique, inv_map = hash_orig.unique(return_inverse=True)
    hash_sorted, sort_idx = hash_unique.sort()
    n_unique = hash_unique.shape[0]
    survival = torch.zeros(n_unique, device=device)
    for _ in range(n_bootstrap):
        noise = torch.tensor(rng.randn(N, X.shape[1]).astype(np.float32) * sigma,
                             device=device, dtype=X.dtype)
        gp = build_base_graph(X + noise, graph_cfg)
        pu = torch.minimum(gp["edge_index"][0], gp["edge_index"][1])
        pv = torch.maximum(gp["edge_index"][0], gp["edge_index"][1])
        ph = (pu * N + pv).unique().sort()[0]
        if ph.numel() > 0:
            pos = torch.searchsorted(ph, hash_sorted).clamp(max=ph.shape[0]-1)
            found = (ph[pos] == hash_sorted)
        else:
            found = torch.zeros(n_unique, dtype=torch.bool, device=device)
        sv = torch.zeros(n_unique, device=device)
        sv[sort_idx] = found.float()
        survival += sv
    survival /= n_bootstrap
    edge_survival = survival[inv_map].cpu().numpy()

    # Label disagreement on edges
    ynp = y.cpu().numpy()
    label_disagree = (ynp[ei[0].numpy()] != ynp[ei[1].numpy()]).astype(np.float32)

    # Edge length z-score
    diffs = (X[ei[0]] - X[ei[1]]).norm(dim=1).cpu().numpy()
    mu, std = diffs.mean(), diffs.std() + 1e-8
    dist_zscore = (diffs - mu) / std

    # Node stability scores (both endpoints)
    stab, _ = compute_stability(X, graph_cfg, seed=seed)
    stab_np = stab.numpy()
    node_stab_min  = np.minimum(stab_np[ei[0].numpy()], stab_np[ei[1].numpy()])
    node_stab_mean = 0.5 * (stab_np[ei[0].numpy()] + stab_np[ei[1].numpy()])

    scores = {
        "stability_edge": 1.0 - edge_survival,      # high = unstable
        "label_disagree": label_disagree,
        "dist_zscore":    dist_zscore.clip(min=0),   # only long edges matter
        "node_stab_min":  1.0 - node_stab_min,       # high = at least one unstable
        "node_stab_mean": 1.0 - node_stab_mean,
    }
    return scores, ei, None   # gt set by caller


# ── Experiment 1: True edge-level benchmark ───────────────────────────
def run_noise_exp1_edge_benchmark(datasets, seeds, out_dir,
                                   noise_fracs=(0.05, 0.1, 0.2)):
    """Edge-level detection: bootstrap instability vs explicit corrupted-edge GT.

    Compares 5 edge scoring methods. GT = any edge touching an injected noise node.
    Reports AUPRC and lift over chance for each method × noise type × dataset.
    """
    print("\n" + "="*70)
    print("NOISE EXP1: True Edge-Level Detection Benchmark")
    print("="*70)
    rows = []
    for ds in datasets:
        k = get_k(ds); gc = GraphBuilderConfig(type="knn", k=k)
        for seed in seeds:
            try: X_tr, y_tr, X_val, y_val, _, _, _ = load_dataset(ds, seed)
            except Exception as e: print(f"  SKIP {ds} s{seed}: {e}"); continue
            for nt in ["label_flip", "feature_and_label", "outlier_insert", "feature_perturb_only"]:
                for nf in noise_fracs:
                    if nt == "label_flip":
                        Xn, yn, isn = inject_label_noise(X_tr, y_tr, nf, seed)
                    elif nt == "feature_and_label":
                        Xn, yn, isn = inject_feature_and_label_noise(X_tr, y_tr, nf, seed)
                    elif nt == "feature_perturb_only":
                        Xn, yn, isn = inject_feature_perturb_only(X_tr, y_tr, nf, seed)
                    else:
                        Xn, yn, isn = inject_outlier_points(X_tr, y_tr, nf, seed)

                    esc, ei, _ = _edge_scores_all_methods(Xn, yn, gc, seed)
                    if ei.shape[1] == 0: continue

                    # GT: edge touches a noise node
                    is_corrupt = (isn[ei[0]] | isn[ei[1]]).numpy()
                    chance = float(is_corrupt.mean())

                    row = {"dataset": ds, "noise_type": nt, "noise_frac": nf,
                           "seed": seed, "n_edges": ei.shape[1],
                           "n_corrupt_edges": int(is_corrupt.sum()),
                           "chance": chance}
                    for method, sc in esc.items():
                        if len(sc) == 0: continue
                        auprc = _compute_auprc(sc, is_corrupt.astype(bool))
                        row[f"auprc_{method}"] = auprc
                        row[f"lift_{method}"] = auprc - chance
                    rows.append(row)

    # Summary
    methods = ["stability_edge","label_disagree","dist_zscore",
               "node_stab_min","node_stab_mean"]
    by_key = defaultdict(list)
    for r in rows: by_key[(r["dataset"], r["noise_type"], r["noise_frac"])].append(r)
    print(f"\n{'Dataset':<16} {'Type':<14} {'NF':>4} {'Chance':>7}  "
          + "  ".join(f"{m[:10]:>10}" for m in methods))
    print("-"*100)
    for key, rs in sorted(by_key.items()):
        ds, nt, nf = key
        chance = np.mean([r["chance"] for r in rs])
        lifts = []
        for m in methods:
            vals = [r.get(f"lift_{m}", np.nan) for r in rs]
            lifts.append(np.nanmean(vals))
        print(f"{ds:<16} {nt:<14} {nf:>4.0%} {chance:>7.3f}  "
              + "  ".join(f"{l:>+10.3f}" for l in lifts))

    _save_csv(rows, out_dir / "noise_exp1_edge_benchmark.csv")
    return rows


# ── Experiment 2: Matched-budget node detection vs strong baselines ───
def run_noise_exp2_node_baselines(datasets, seeds, out_dir,
                                   noise_fracs=(0.05, 0.1, 0.2)):
    """Node detection AUPRC: stability vs all pointwise baselines.

    Uses ranking metric (AUPRC) not a fixed budget, removing the recall-inflation
    problem. Pointwise baselines: kNN_dist, LOF, centroid_dist, margin, disagreement.
    """
    print("\n" + "="*70)
    print("NOISE EXP2: Matched-Budget Node Detection vs Baselines (AUPRC)")
    print("="*70)
    rows = []
    methods = ["stability","disagreement","knn_dist","lof","centroid_dist","margin"]
    for ds in datasets:
        k = get_k(ds); gc = GraphBuilderConfig(type="knn", k=k)
        for seed in seeds:
            try: X_tr, y_tr, X_val, y_val, _, _, _ = load_dataset(ds, seed)
            except Exception as e: print(f"  SKIP {ds} s{seed}: {e}"); continue
            for nt in ["label_flip", "feature_and_label", "outlier_insert", "feature_perturb_only"]:
                for nf in noise_fracs:
                    if nt == "label_flip":
                        Xn, yn, isn = inject_label_noise(X_tr, y_tr, nf, seed)
                    elif nt == "feature_and_label":
                        Xn, yn, isn = inject_feature_and_label_noise(X_tr, y_tr, nf, seed)
                    elif nt == "feature_perturb_only":
                        Xn, yn, isn = inject_feature_perturb_only(X_tr, y_tr, nf, seed)
                    else:
                        Xn, yn, isn = inject_outlier_points(X_tr, y_tr, nf, seed)

                    node_sc = _node_scores_all_methods(Xn, yn, gc, seed)
                    gt = isn.numpy().astype(bool)
                    chance = float(gt.mean())

                    row = {"dataset": ds, "noise_type": nt, "noise_frac": nf,
                           "seed": seed, "N": len(Xn), "n_noise": int(isn.sum()),
                           "chance": chance}
                    for m in methods:
                        sc = node_sc.get(m, np.zeros(len(Xn)))
                        auprc = _compute_auprc(sc, gt)
                        row[f"auprc_{m}"] = auprc
                        row[f"lift_{m}"] = auprc - chance
                    rows.append(row)

    by_key = defaultdict(list)
    for r in rows: by_key[(r["dataset"], r["noise_type"], r["noise_frac"])].append(r)
    print(f"\n{'Dataset':<16} {'Type':<14} {'NF':>4} {'Chance':>7}  "
          + "  ".join(f"{m[:8]:>9}" for m in methods))
    print("-"*110)
    for key, rs in sorted(by_key.items()):
        ds, nt, nf = key
        chance = np.mean([r["chance"] for r in rs])
        lifts = [np.nanmean([r.get(f"lift_{m}", np.nan) for r in rs]) for m in methods]
        winner = methods[int(np.argmax(lifts))]
        line = f"{ds:<16} {nt:<14} {nf:>4.0%} {chance:>7.3f}  "
        for m, l in zip(methods, lifts):
            marker = "*" if m == winner else " "
            line += f"{l:>+8.3f}{marker} "
        print(line)

    _save_csv(rows, out_dir / "noise_exp2_node_baselines.csv")
    return rows


# ── Experiment 3: Corruption-type matrix ─────────────────────────────
def run_noise_exp3_corruption_matrix(datasets, seeds, out_dir):
    """Full corruption × detector matrix.

    4 corruption types × 6 detectors, showing where relational methods win.
    The hypothesis: label_flip and feature_and_label favor relational detectors;
    outlier_insert favors pointwise detectors (LOF, kNN_dist).
    """
    print("\n" + "="*70)
    print("NOISE EXP3: Corruption-Type × Detector Matrix")
    print("="*70)
    noise_types = ["label_flip", "feature_and_label", "outlier_insert", "feature_perturb_only"]
    node_methods = ["stability","disagreement","knn_dist","lof","centroid_dist","margin"]
    nf = 0.10   # fixed fraction for matrix clarity
    rows = []
    for ds in datasets:
        k = get_k(ds); gc = GraphBuilderConfig(type="knn", k=k)
        for seed in seeds:
            try: X_tr, y_tr, X_val, y_val, _, _, _ = load_dataset(ds, seed)
            except Exception as e: print(f"  SKIP {ds} s{seed}: {e}"); continue
            for nt in noise_types:
                if nt == "label_flip":
                    Xn, yn, isn = inject_label_noise(X_tr, y_tr, nf, seed)
                elif nt == "feature_and_label":
                    Xn, yn, isn = inject_feature_and_label_noise(X_tr, y_tr, nf, seed)
                elif nt == "feature_perturb_only":
                    Xn, yn, isn = inject_feature_perturb_only(X_tr, y_tr, nf, seed)
                else:
                    Xn, yn, isn = inject_outlier_points(X_tr, y_tr, nf, seed)

                node_sc = _node_scores_all_methods(Xn, yn, gc, seed)
                gt = isn.numpy().astype(bool)
                chance = float(gt.mean())
                row = {"dataset": ds, "noise_type": nt, "seed": seed, "chance": chance}
                for m in node_methods:
                    sc = node_sc.get(m, np.zeros(len(Xn)))
                    row[f"auprc_{m}"] = _compute_auprc(sc, gt)
                    row[f"lift_{m}"] = row[f"auprc_{m}"] - chance
                rows.append(row)

    # Print matrix: rows=corruption type, cols=method, cells=mean lift
    by_nt = defaultdict(list)
    for r in rows: by_nt[r["noise_type"]].append(r)
    header = f"{'Corruption':<18}  " + "  ".join(f"{m[:9]:>10}" for m in node_methods)
    print(f"\n{header}")
    print("-"*90)
    for nt in noise_types:
        rs = by_nt[nt]
        if not rs: continue
        lifts = [np.nanmean([r.get(f"lift_{m}", np.nan) for r in rs]) for m in node_methods]
        best = int(np.argmax(lifts))
        line = f"{nt:<18}  "
        for i, (m, l) in enumerate(zip(node_methods, lifts)):
            marker = "**" if i == best else "  "
            line += f"{l:>+8.3f}{marker}"
        print(line)
    print("\n** = best method for that corruption type")
    print("Hypothesis: stability/disagreement should win on label_flip/feature_and_label;")
    print("            LOF/knn_dist should win on outlier_insert")

    _save_csv(rows, out_dir / "noise_exp3_corruption_matrix.csv")
    return rows


# ── Experiment 4: Budget sweep (PR curve / AUROC) ────────────────────
def run_noise_exp4_budget_sweep(datasets, seeds, out_dir):
    """Sweep removal budget 0.1x to 3x noise fraction.

    Reports precision and recall at each budget, cleanly separating them.
    Also reports AUPRC for ranking (budget-independent).
    This directly addresses the 'recall is just budget' criticism.
    """
    print("\n" + "="*70)
    print("NOISE EXP4: Budget Sweep (Precision-Recall vs Removal Budget)")
    print("="*70)
    nf = 0.10
    budget_mults = [0.25, 0.5, 0.75, 1.0, 1.25, 1.5, 2.0, 2.5, 3.0]
    methods_to_sweep = ["stability", "disagreement", "knn_dist", "lof"]
    rows = []
    for ds in datasets:
        k = get_k(ds); gc = GraphBuilderConfig(type="knn", k=k)
        for seed in seeds:
            try: X_tr, y_tr, X_val, y_val, _, _, _ = load_dataset(ds, seed)
            except Exception as e: print(f"  SKIP {ds} s{seed}: {e}"); continue
            for nt in ["label_flip", "feature_and_label", "feature_perturb_only"]:
                if nt == "label_flip":
                    Xn, yn, isn = inject_label_noise(X_tr, y_tr, nf, seed)
                else:
                    Xn, yn, isn = inject_gaussian_feature_noise(X_tr, y_tr, nf, seed)

                Nn = len(Xn); nn = int(isn.sum())
                if nn == 0: continue
                gt = isn.numpy().astype(bool)
                chance = float(gt.mean())
                node_sc = _node_scores_all_methods(Xn, yn, gc, seed)

                for m in methods_to_sweep:
                    sc = node_sc.get(m, np.zeros(Nn))
                    auprc = _compute_auprc(sc, gt)
                    # Rank nodes by score descending
                    ranked = np.argsort(sc)[::-1]
                    for bm in budget_mults:
                        nr = min(max(int(Nn * nf * bm), 1), Nn - 2)
                        removed = ranked[:nr]
                        n_noise_removed = int(gt[removed].sum())
                        prec = n_noise_removed / nr
                        rec  = n_noise_removed / nn
                        rows.append({
                            "dataset": ds, "noise_type": nt, "seed": seed,
                            "method": m, "budget_mult": bm,
                            "n_removed": nr, "precision": prec, "recall": rec,
                            "auprc": auprc, "chance": chance,
                            "prec_lift": prec - chance,
                        })

    # Print PR at key budgets
    by_key = defaultdict(list)
    for r in rows: by_key[(r["noise_type"], r["method"])].append(r)
    for (nt, m), rs in sorted(by_key.items()):
        print(f"\n  {nt} | {m}")
        print(f"  {'Budget':>8}  {'Precision':>10}  {'Recall':>8}  {'PrecLift':>10}")
        for bm in budget_mults:
            sub = [r for r in rs if r["budget_mult"] == bm]
            if sub:
                mp = np.mean([r["precision"] for r in sub])
                mr = np.mean([r["recall"] for r in sub])
                ml = np.mean([r["prec_lift"] for r in sub])
                print(f"  {bm:>7.2f}x  {mp:>10.3f}  {mr:>8.3f}  {ml:>+10.3f}")

    _save_csv(rows, out_dir / "noise_exp4_budget_sweep.csv")
    return rows


# ── Experiment 5: Graph-construction sensitivity ──────────────────────
def run_noise_exp5_graph_sensitivity(datasets, seeds, out_dir):
    """Does stability signal persist across graph constructions?

    If noise detection is truly relational (not an artifact of kNN), stability
    should work across k=8, k=16, k=32, mutual_knn. A signal that depends
    entirely on one graph variant is fragile. Cross-construction consistency
    is strong evidence for the relational nature of the signal.
    """
    print("\n" + "="*70)
    print("NOISE EXP5: Graph-Construction Sensitivity")
    print("="*70)
    graph_variants = [
        ("knn_k8",    GraphBuilderConfig(type="knn",       k=8)),
        ("knn_k16",   GraphBuilderConfig(type="knn",       k=16)),
        ("knn_k32",   GraphBuilderConfig(type="knn",       k=32)),
        ("mutual_k16",GraphBuilderConfig(type="mutual_knn",k=16)),
    ]
    nf = 0.10
    rows = []
    for ds in datasets:
        for seed in seeds:
            try: X_tr, y_tr, X_val, y_val, _, _, _ = load_dataset(ds, seed)
            except Exception as e: print(f"  SKIP {ds} s{seed}: {e}"); continue
            for nt in ["label_flip", "feature_and_label", "feature_perturb_only"]:
                if nt == "label_flip":
                    Xn, yn, isn = inject_label_noise(X_tr, y_tr, nf, seed)
                else:
                    Xn, yn, isn = inject_gaussian_feature_noise(X_tr, y_tr, nf, seed)
                gt = isn.numpy().astype(bool)
                chance = float(gt.mean())
                row = {"dataset": ds, "noise_type": nt, "seed": seed, "chance": chance}
                for gname, gc in graph_variants:
                    try:
                        stab, _ = compute_stability(Xn, gc, seed=seed)
                        sc = 1.0 - stab.numpy()
                        auprc = _compute_auprc(sc, gt)
                        row[f"auprc_{gname}"] = auprc
                        row[f"lift_{gname}"]  = auprc - chance
                    except Exception as e:
                        row[f"auprc_{gname}"] = np.nan
                        row[f"lift_{gname}"]  = np.nan
                rows.append(row)

    gnames = [g[0] for g in graph_variants]
    by_key = defaultdict(list)
    for r in rows: by_key[(r["dataset"], r["noise_type"])].append(r)
    print(f"\n{'Dataset':<16} {'Type':<16}  "
          + "  ".join(f"{g:>12}" for g in gnames))
    print("-"*80)
    for key, rs in sorted(by_key.items()):
        ds, nt = key
        lifts = [np.nanmean([r.get(f"lift_{g}", np.nan) for r in rs]) for g in gnames]
        # Spearman correlation across graph variants (consistency metric)
        vals = [l for l in lifts if not np.isnan(l)]
        print(f"{ds:<16} {nt:<16}  "
              + "  ".join(f"{l:>+12.3f}" for l in lifts))
    print("\nConsistency: if all variants show positive lift, signal is robust to graph choice")

    _save_csv(rows, out_dir / "noise_exp5_graph_sensitivity.csv")
    return rows


# ── Experiment 6: Localization by graph position ──────────────────────
def run_noise_exp6_localization(datasets, seeds, out_dir):
    """Does stability catch noise better at different graph positions?

    Partition the dataset into four structural zones:
      boundary    - high label disagreement in neighborhood
      hub         - top-25% degree nodes
      interior    - low disagreement, moderate degree
      low_density - bottom-25% degree nodes (sparse regions)

    Inject noise uniformly but measure detection AUPRC separately per zone.
    Hypothesis: relational stability should be strongest at boundaries and hubs
    (where relational structure matters most), weaker in interiors.
    """
    print("\n" + "="*70)
    print("NOISE EXP6: Localization by Graph Position")
    print("="*70)
    nf = 0.10
    rows = []
    for ds in datasets:
        k = get_k(ds); gc = GraphBuilderConfig(type="knn", k=k)
        for seed in seeds:
            try: X_tr, y_tr, X_val, y_val, _, _, _ = load_dataset(ds, seed)
            except Exception as e: print(f"  SKIP {ds} s{seed}: {e}"); continue
            for nt in ["label_flip", "feature_and_label", "feature_perturb_only"]:
                if nt == "label_flip":
                    Xn, yn, isn = inject_label_noise(X_tr, y_tr, nf, seed)
                else:
                    Xn, yn, isn = inject_gaussian_feature_noise(X_tr, y_tr, nf, seed)

                N = len(Xn)
                g = build_base_graph(Xn, gc)
                ei = g["edge_index"]

                # Compute zone membership
                ynp = yn.numpy()
                # Degree
                degree = np.zeros(N)
                for s in ei[0].numpy(): degree[s] += 1
                # Label disagreement
                disagree = np.zeros(N); cnt = np.zeros(N)
                for s, d_ in zip(ei[0].numpy(), ei[1].numpy()):
                    cnt[s] += 1
                    if ynp[s] != ynp[d_]: disagree[s] += 1
                with np.errstate(divide='ignore', invalid='ignore'):
                    disagree_rate = np.where(cnt > 0, disagree / cnt, 0.)

                deg_hi = np.percentile(degree, 75)
                deg_lo = np.percentile(degree, 25)
                dis_hi = np.percentile(disagree_rate, 75)

                zones = {
                    "boundary":    (disagree_rate >= dis_hi),
                    "hub":         (degree >= deg_hi),
                    "interior":    (disagree_rate < np.percentile(disagree_rate, 25)),
                    "low_density": (degree <= deg_lo),
                }

                stab, _ = compute_stability(Xn, gc, seed=seed)
                sc = 1.0 - stab.numpy()
                gt = isn.numpy().astype(bool)

                row = {"dataset": ds, "noise_type": nt, "seed": seed,
                       "N": N, "chance_global": float(gt.mean())}
                for zname, zmask in zones.items():
                    if zmask.sum() < 5: continue
                    z_gt = gt[zmask]
                    z_sc = sc[zmask]
                    chance_z = float(z_gt.mean())
                    if chance_z == 0 or chance_z == 1:
                        row[f"auprc_{zname}"] = chance_z
                        row[f"lift_{zname}"] = 0.
                    else:
                        auprc = _compute_auprc(z_sc, z_gt)
                        row[f"auprc_{zname}"] = auprc
                        row[f"lift_{zname}"] = auprc - chance_z
                    row[f"size_{zname}"] = int(zmask.sum())
                rows.append(row)

    zones_list = ["boundary","hub","interior","low_density"]
    by_key = defaultdict(list)
    for r in rows: by_key[(r["dataset"], r["noise_type"])].append(r)
    print(f"\n{'Dataset':<16} {'Type':<16}  "
          + "  ".join(f"{z:>12}" for z in zones_list))
    print("-"*80)
    for key, rs in sorted(by_key.items()):
        ds, nt = key
        lifts = [np.nanmean([r.get(f"lift_{z}", np.nan) for r in rs])
                 for z in zones_list]
        print(f"{ds:<16} {nt:<16}  "
              + "  ".join(f"{l:>+12.3f}" for l in lifts))
    print("\nHypothesis: boundary > hub > interior (relational structure matters more at edges)")

    _save_csv(rows, out_dir / "noise_exp6_localization.csv")
    return rows


def run_noise_suite(datasets_to_run, seeds, out_dir):
    """Run all 6 noise experiments. --only noise_suite"""
    out_dir.mkdir(parents=True, exist_ok=True)
    run_noise_exp1_edge_benchmark(datasets_to_run, seeds, out_dir)
    run_noise_exp2_node_baselines(datasets_to_run, seeds, out_dir)
    run_noise_exp3_corruption_matrix(datasets_to_run, seeds, out_dir)
    run_noise_exp4_budget_sweep(datasets_to_run, seeds, out_dir)
    run_noise_exp5_graph_sensitivity(datasets_to_run, seeds, out_dir)
    run_noise_exp6_localization(datasets_to_run, seeds, out_dir)
    print("\n" + "="*70)
    print("NOISE SUITE COMPLETE")
    print("  noise_exp1_edge_benchmark.csv   - true edge detection AUPRC")
    print("  noise_exp2_node_baselines.csv   - stability vs 5 pointwise baselines")
    print("  noise_exp3_corruption_matrix.csv- which detector wins per corruption type")
    print("  noise_exp4_budget_sweep.csv     - precision/recall at 9 removal budgets")
    print("  noise_exp5_graph_sensitivity.csv- signal consistency across graph types")
    print("  noise_exp6_localization.csv     - detection by boundary/hub/interior/sparse")
    print("="*70)


# ══════════════════════════════════════════════════════════════════════
# MAIN
# ══════════════════════════════════════════════════════════════════════
def main():
    p = argparse.ArgumentParser(description="Feature-induced regime experiments")
    p.add_argument("--seeds", type=str, default="0,1,2,3,4")
    p.add_argument("--out", type=str, default="outputs/real_experiments")
    p.add_argument("--only", type=str, default=None)
    p.add_argument("--quick", action="store_true")
    p.add_argument("--datasets", type=str, default=None)
    p.add_argument("--threads", type=int, default=None,
                   help="Override thread count")
    args = p.parse_args()
    seeds = [int(s) for s in args.seeds.split(",")]
    out = Path(args.out)

    # Allow thread override for large-scale runs
    if args.threads is not None:
        for env_var in ["OMP_NUM_THREADS", "MKL_NUM_THREADS",
                        "OPENBLAS_NUM_THREADS", "NUMEXPR_NUM_THREADS"]:
            os.environ[env_var] = str(args.threads)
        torch.set_num_threads(args.threads)
        print(f"  Threads overridden to {args.threads}")

    if args.quick: ds_list = QUICK_DATASETS; seeds = seeds[:2]
    elif args.datasets:
        ds_list = [d.strip() for d in args.datasets.split(",")]
        for d in ds_list:
            if d not in DATASETS:
                print(f"ERROR: unknown '{d}'. Available: {sorted(DATASETS.keys())}"); sys.exit(1)
    else: ds_list = list(DATASETS.keys())

    print("=" * 70)
    print(f"EXPERIMENTS ({len(ds_list)} datasets)")
    print(f"  Datasets: {ds_list}")
    print(f"  Seeds:    {seeds}")
    print("=" * 70)

    only = (args.only or "all").lower()
    if only in ("all", "baselines"):     run_baselines(ds_list, seeds, out)
    if only in ("all", "scaling"):       run_scaling(ds_list, seeds, out)
    if only in ("all", "noise_curve"):   run_noise_curve(ds_list, seeds, out)
    if only in ("all", "noise"):         run_claim_a(ds_list, seeds, out)
    if only in ("all", "geometry"):      run_claim_b(ds_list, seeds, out)
    if only in ("all", "signal"):        run_claim_c(ds_list, seeds, out)
    if only in ("all", "reliability"):   run_claim_d(ds_list, seeds, out)
    if only in ("all", "representation"):run_claim_e(seeds, out)
    if only in ("all", "sensitivity"):   run_sensitivity(ds_list, seeds, out)
    if only in ("all", "ablation"):      run_ablation(ds_list, seeds, out)
    if only in ("all", "wallclock"):     run_wallclock(ds_list, seeds, out)
    if only in ("all", "hp_transfer"):   run_hp_transfer(ds_list, seeds, out)
    if only in ("all", "rewiring"):      run_rewiring_control(ds_list, seeds, out)
    if only in ("noise_suite",):          run_noise_suite(ds_list, seeds, out)

    print(f"\n{'='*70}")
    print(f"ALL DONE")
    print(f"  baselines.csv, scaling.csv, noise_curve.csv")
    print(f"  claim_a_noise.csv, claim_b_geometry.csv, claim_c_signal.csv")
    print(f"  claim_d_reliability.csv, claim_e_representation.csv")
    print(f"  sensitivity.csv, ablation.csv, wallclock.csv")
    print(f"  hp_transfer.csv, rewiring_control.csv")
    print(f"{'='*70}")

if __name__ == "__main__":
    main()
