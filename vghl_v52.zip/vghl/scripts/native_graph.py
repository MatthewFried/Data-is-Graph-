#!/usr/bin/env python3
"""The intervention on native citation graphs.

The feature-induced Cora entry uses a kNN graph over bag-of-words features
(phi fails: purity 0.21), which the a priori diagnostic flags. Here we run
the same connectivity-only intervention on the GIVEN citation graph, where
W is supplied externally and is NOT a function of X at all. If the substrate-attribution claim is right:

  given graph:  propagation >> no-prop  (the given W encodes signal absent
                from a linear readout of X under 140 labels)
  destroyed:    collapse under I1 / degree-preserving rewire / random dest
  knn graph:    reproduces the feature-induced failure (phi does not recover it)

Protocol: transductive (standard Planetoid splits: 140 train / 500 val /
1000 test for Cora), features row-normalized, same operator P = D^-1(A+I),
tau = 5, same closed-form ridge readout, retrained per condition.

Loader: torch_geometric if available, else direct download of the raw
Planetoid files (kimiyoung/planetoid) with the standard CiteSeer
isolated-test-node fix. Cache: ~/.cache/vghl_data/planetoid_raw.

Usage:
  python -u scripts/native_graph.py
  python -u scripts/native_graph.py --datasets cora --seeds 0,1,2,3,4
"""
import os, sys
os.environ.setdefault("OMP_NUM_THREADS", "1")
os.environ.setdefault("MKL_NUM_THREADS", "1")

import argparse
import pickle
import random as pyrandom
import urllib.request
import numpy as np
import torch
from pathlib import Path
from collections import defaultdict

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))
sys.path.insert(0, os.path.dirname(__file__))

from run_real_experiments import _save_csv  # noqa: E402
from vghl.models.graph_builder import (  # noqa: E402
    build_base_graph, GraphBuilderConfig, _apply_control,
)
from vghl.models.propagation import propagate, PropagationConfig  # noqa: E402
from vghl.models.probe import ridge_eval  # noqa: E402

RAW_URL = "https://github.com/kimiyoung/planetoid/raw/master/data"
CACHE = Path(os.path.expanduser("~/.cache/vghl_data/planetoid_raw"))


# ── Loading ──────────────────────────────────────────────────────────

def _load_via_pyg(name):
    from torch_geometric.datasets import Planetoid
    ds = Planetoid(root=os.path.expanduser("~/.cache/vghl_data/pyg"),
                   name=name.capitalize())
    d = ds[0]
    return (d.x.float(), d.y.long(), d.edge_index.long(),
            d.train_mask.clone(), d.val_mask.clone(), d.test_mask.clone())


def _fetch(name, ext):
    CACHE.mkdir(parents=True, exist_ok=True)
    fn = CACHE / f"ind.{name}.{ext}"
    if not fn.exists():
        url = f"{RAW_URL}/ind.{name}.{ext}"
        print(f"  downloading {url}")
        urllib.request.urlretrieve(url, fn)
    return fn


def _load_raw_planetoid(name):
    """Standard Planetoid raw-file assembly, mirroring tkipf/gcn utils.py
    exactly, including the CiteSeer isolated-test-node fix."""
    import scipy.sparse as sp
    objs = {}
    for ext in ["x", "y", "tx", "ty", "allx", "ally", "graph"]:
        with open(_fetch(name, ext), "rb") as f:
            objs[ext] = pickle.load(f, encoding="latin1")
    test_idx_reorder = np.loadtxt(_fetch(name, "test.index"), dtype=np.int64)
    test_idx_range = np.sort(test_idx_reorder)

    allx, tx = objs["allx"], objs["tx"]
    ally, ty = objs["ally"], objs["ty"]

    if name == "citeseer":
        # Isolated test nodes: extend tx/ty to the full contiguous index
        # range with zero rows (they get zero features and are excluded
        # from the test mask, as in the canonical loader).
        full = np.arange(test_idx_range.min(), test_idx_range.max() + 1)
        tx_ext = sp.lil_matrix((len(full), allx.shape[1]), dtype=np.float32)
        tx_ext[test_idx_range - test_idx_range.min(), :] = tx
        tx = tx_ext.tocsr()
        ty_ext = np.zeros((len(full), ty.shape[1]), dtype=ty.dtype)
        ty_ext[test_idx_range - test_idx_range.min(), :] = ty
        ty = ty_ext

    X = sp.vstack([allx, tx]).tolil()
    X[test_idx_reorder, :] = X[test_idx_range, :]
    X = torch.tensor(np.asarray(X.todense(), dtype=np.float32))

    Y = np.vstack([ally, ty])
    Y[test_idx_reorder, :] = Y[test_idx_range, :]
    y = torch.tensor(Y.argmax(axis=1), dtype=torch.long)

    src_l, dst_l = [], []
    for u, nbrs in objs["graph"].items():
        for v in nbrs:
            if u != v:
                src_l.append(u); dst_l.append(v)
    ei = torch.tensor([src_l, dst_l], dtype=torch.long)

    n_train = objs["y"].shape[0]        # canonical: first |y| nodes
    N = X.shape[0]
    train_mask = torch.zeros(N, dtype=torch.bool); train_mask[:n_train] = True
    val_mask = torch.zeros(N, dtype=torch.bool)
    val_mask[n_train:n_train + 500] = True
    test_mask = torch.zeros(N, dtype=torch.bool)
    # canonical: isolated (gap) nodes excluded from test
    test_mask[torch.tensor(test_idx_range, dtype=torch.long)] = True
    return X, y, ei, train_mask, val_mask, test_mask


def load_native(name):
    try:
        out = _load_via_pyg(name)
        print(f"  loaded {name} via torch_geometric")
        return out
    except Exception as e:
        print(f"  torch_geometric unavailable ({e}); using raw Planetoid files")
        return _load_raw_planetoid(name)


# ── Graph utilities ─────────────────────────────────────────────────

def symmetrize_dedup(ei: torch.Tensor) -> torch.Tensor:
    both = torch.cat([ei, ei.flip(0)], dim=1)
    key = both[0] * (both.max() + 1) + both[1]
    _, uniq = np.unique(key.numpy(), return_index=True)
    return both[:, torch.tensor(sorted(uniq), dtype=torch.long)]


def make_random_edges(N: int, E: int, seed: int):
    """Protocol I1: independent random src+dst, no self loops, uniform weights."""
    rng = np.random.RandomState(seed + 555)
    src = torch.tensor(rng.randint(0, N, E), dtype=torch.long)
    dst = torch.tensor(rng.randint(0, N, E), dtype=torch.long)
    valid = src != dst
    return torch.stack([src[valid], dst[valid]]), torch.ones(int(valid.sum()))


def control_diagnostics(ei_orig: torch.Tensor, ei_new: torch.Tensor,
                        N: int) -> dict:
    """Control diagnostics: reciprocity, undirected degree
    preservation, overlap with original edges, connected components."""
    import scipy.sparse as sp
    from scipy.sparse.csgraph import connected_components
    pairs_new = set(zip(ei_new[0].tolist(), ei_new[1].tolist()))
    pairs_orig = set(zip(ei_orig[0].tolist(), ei_orig[1].tolist()))
    recip = (sum(1 for (a, b) in pairs_new if (b, a) in pairs_new)
             / max(len(pairs_new), 1))
    deg_o = torch.zeros(N, dtype=torch.long).scatter_add_(
        0, ei_orig[0], torch.ones(ei_orig.shape[1], dtype=torch.long))
    deg_n = torch.zeros(N, dtype=torch.long).scatter_add_(
        0, ei_new[0], torch.ones(ei_new.shape[1], dtype=torch.long))
    A = sp.coo_matrix((np.ones(ei_new.shape[1]),
                       (ei_new[0].numpy(), ei_new[1].numpy())), shape=(N, N))
    ncomp, _ = connected_components(A, directed=False)
    return {
        "reciprocity": round(recip, 3),
        "out_degree_preserved": bool((deg_o == deg_n).all()),
        "edge_overlap_with_orig": round(len(pairs_new & pairs_orig)
                                        / max(len(pairs_new), 1), 3),
        "self_loops": int((ei_new[0] == ei_new[1]).sum()),
        "n_components": int(ncomp),
    }


def row_normalize(X: torch.Tensor) -> torch.Tensor:
    s = X.sum(dim=1, keepdim=True).clamp(min=1e-8)
    return X / s


# ── Experiment ──────────────────────────────────────────────────────

def run(datasets, seeds, tau, k_knn, out_dir):
    out_dir = Path(out_dir)
    rows = []
    for ds in datasets:
        X, y, ei_given, trm, vam, tem = load_native(ds)
        X = row_normalize(X)
        N = X.shape[0]
        nc = int(y.max()) + 1
        ei_given = symmetrize_dedup(ei_given)
        ew_given = torch.ones(ei_given.shape[1])
        E = ei_given.shape[1]
        print(f"\n{ds}: N={N} d={X.shape[1]} E(sym)={E} classes={nc} "
              f"train/val/test = {int(trm.sum())}/{int(vam.sum())}/{int(tem.sum())}")

        pc = PropagationConfig(type="random_walk", steps=tau)
        gc = GraphBuilderConfig(type="knn", k=k_knn)
        g_knn = build_base_graph(X, gc)  # phi(X), for comparison

        for seed in seeds:
            torch.manual_seed(seed); pyrandom.seed(seed)
            conds = {}
            # (1) given citation graph
            conds["given_graph"] = (ei_given, ew_given)
            # (2) I1 random edges, same E
            conds["random_edges"] = make_random_edges(N, E, seed)
            # (3) degree-preserving rewire of the given graph
            conds["degree_rewire"] = _apply_control(ei_given, ew_given, N,
                                                    "degree_preserving_rewire")
            # (4) random destination on the given graph
            conds["random_dest"] = _apply_control(ei_given, ew_given, N,
                                                  "random_destination")
            # (5) kNN-on-features graph (feature-induced construction)
            conds["knn_graph"] = (g_knn["edge_index"], g_knn["edge_weight"])

            r = {"dataset": ds, "seed": seed, "N": N, "E": E, "tau": tau}
            # no-propagation baseline: ridge on raw X (transductive masks)
            r["no_prop"] = ridge_eval(X[trm], y[trm], X[tem], y[tem], n_classes=nc)
            # strong raw-feature baselines on the same labeled nodes
            from sklearn.linear_model import LogisticRegression
            from sklearn.ensemble import RandomForestClassifier
            Xtr_np, ytr_np = X[trm].numpy(), y[trm].numpy()
            Xte_np, yte_np = X[tem].numpy(), y[tem].numpy()
            lr = LogisticRegression(max_iter=2000, random_state=seed)
            lr.fit(Xtr_np, ytr_np)
            r["raw_logreg"] = float((lr.predict(Xte_np) == yte_np).mean())
            rf = RandomForestClassifier(n_estimators=200, random_state=seed, n_jobs=1)
            rf.fit(Xtr_np, ytr_np)
            r["raw_rf"] = float((rf.predict(Xte_np) == yte_np).mean())
            r["best_raw"] = max(r["no_prop"], r["raw_logreg"], r["raw_rf"])
            for cname, (ei, ew) in conds.items():
                H = propagate(X, ei, ew, N, pc)
                r[cname] = ridge_eval(H[trm], y[trm], H[tem], y[tem], n_classes=nc)
            if seed == seeds[0]:
                for cname in ["given_graph", "degree_rewire", "random_edges",
                              "random_dest"]:
                    d = control_diagnostics(ei_given, conds[cname][0], N)
                    print(f"    diag {cname}: {d}", flush=True)
            r["lift_given_over_noprop"] = r["given_graph"] - r["no_prop"]
            r["lift_given_over_best_raw"] = r["given_graph"] - r["best_raw"]
            r["collapse_I1"] = r["given_graph"] - r["random_edges"]
            r["collapse_rewire"] = r["given_graph"] - r["degree_rewire"]
            rows.append(r)
            print(f"  seed {seed}: given={r['given_graph']:.3f} noprop={r['no_prop']:.3f} "
                  f"knn={r['knn_graph']:.3f} rand={r['random_edges']:.3f} "
                  f"rewire={r['degree_rewire']:.3f} rdest={r['random_dest']:.3f}",
                  flush=True)

    cols = ["given_graph", "best_raw", "no_prop", "knn_graph", "random_edges",
            "degree_rewire", "random_dest"]
    print("\n" + "=" * 88)
    print(f"{'Dataset':<10} " + " ".join(f"{c:>13}" for c in cols))
    by = defaultdict(list)
    for r in rows:
        by[r["dataset"]].append(r)
    for ds, rs in by.items():
        vals = []
        for c in cols:
            v = [r[c] for r in rs]
            vals.append(f"{np.mean(v):.3f}±{np.std(v):.3f}")
        print(f"{ds:<10} " + " ".join(f"{v:>13}" for v in vals))
    _save_csv(rows, out_dir / "native_graph.csv")
    return rows


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--datasets", type=str, default="cora,citeseer")
    p.add_argument("--seeds", type=str, default="0,1,2,3,4")
    p.add_argument("--tau", type=int, default=5)
    p.add_argument("--k_knn", type=int, default=16)
    p.add_argument("--out", type=str, default="outputs")
    a = p.parse_args()
    run(a.datasets.split(","), [int(s) for s in a.seeds.split(",")],
        a.tau, a.k_knn, a.out)


if __name__ == "__main__":
    main()
