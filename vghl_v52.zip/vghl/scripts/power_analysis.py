#!/usr/bin/env python3
"""Dataset-level sensitivity analysis for rewire_50x versus symmetric ER.

Rows are paired by (dataset, seed) before aggregation. The inferential unit is
the dataset: paired seed differences are averaged within each dataset, then a
one-sample t analysis is performed across dataset means. The 80%-power MDE is
solved from the exact noncentral-t power function using the observed
between-dataset standard deviation.
"""
import argparse
import csv

import numpy as np
from scipy import optimize, stats


def exact_mde(sd, n, alpha=0.05, target_power=0.80):
    """Smallest positive mean shift attaining target two-sided t-test power."""
    if n < 2:
        raise ValueError("need at least two datasets")
    if sd == 0:
        return 0.0
    df = n - 1
    critical = stats.t.ppf(1 - alpha / 2, df)

    def power(delta):
        ncp = delta * np.sqrt(n) / sd
        return stats.nct.cdf(-critical, df, ncp) + stats.nct.sf(critical, df, ncp)

    hi = sd
    while power(hi) < target_power:
        hi *= 2
        if hi > 100 * sd:
            raise RuntimeError("failed to bracket MDE")
    return optimize.brentq(lambda d: power(d) - target_power, 0.0, hi)


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--csv", default="outputs/swap_sweep.csv")
    p.add_argument("--cells", default="rewire_50x,sym_er")
    a = p.parse_args()

    cells = [x.strip() for x in a.cells.split(",") if x.strip()]
    if len(cells) != 2:
        p.error("--cells must contain exactly two comma-separated cell names")
    c1, c2 = cells

    values = {}
    with open(a.csv, newline="") as f:
        reader = csv.DictReader(f)
        required = {"dataset", "seed", "cell", "acc"}
        if not required <= set(reader.fieldnames or []):
            raise ValueError(f"CSV must contain columns {sorted(required)}")
        for row in reader:
            if row["cell"] not in (c1, c2):
                continue
            key = (row["dataset"], int(row["seed"]), row["cell"])
            if key in values:
                raise ValueError(f"duplicate CSV row for {key}")
            value = float(row["acc"])
            if not np.isfinite(value):
                raise ValueError(f"non-finite accuracy for {key}")
            values[key] = value

    datasets = sorted({d for d, _, c in values if c in (c1, c2)})
    dataset_diffs = []
    print(f"{'dataset':<20}{'paired seeds':>13}{c1:>12}{c2:>12}{'diff':>10}")
    for dataset in datasets:
        seeds1 = {s for d, s, c in values if d == dataset and c == c1}
        seeds2 = {s for d, s, c in values if d == dataset and c == c2}
        paired = sorted(seeds1 & seeds2)
        if not paired:
            print(f"{dataset:<20}{'NONE':>13}  skipped")
            continue
        if seeds1 != seeds2:
            print(
                f"WARNING: {dataset} has unmatched seeds; using intersection {paired}",
                flush=True,
            )
        diffs = np.array([
            values[(dataset, seed, c1)] - values[(dataset, seed, c2)]
            for seed in paired
        ])
        m1 = np.mean([values[(dataset, seed, c1)] for seed in paired])
        m2 = np.mean([values[(dataset, seed, c2)] for seed in paired])
        md = float(diffs.mean())
        dataset_diffs.append(md)
        print(f"{dataset:<20}{len(paired):>13}{m1:>12.3f}{m2:>12.3f}{md:>+10.3f}")

    diffs = np.asarray(dataset_diffs, dtype=float)
    n = len(diffs)
    if n < 2:
        raise ValueError(f"need at least two paired datasets; found {n}")

    mean = float(diffs.mean())
    sd = float(diffs.std(ddof=1))
    se = sd / np.sqrt(n)
    if se == 0:
        t_stat = np.inf if mean != 0 else 0.0
        pval = 0.0 if mean != 0 else 1.0
    else:
        t_stat = mean / se
        pval = float(2 * stats.t.sf(abs(t_stat), n - 1))
    half_width = float(stats.t.ppf(0.95, n - 1) * se)
    mde80 = exact_mde(sd, n, alpha=0.05, target_power=0.80)

    print(
        f"\nn = {n} datasets | mean diff = {mean * 100:+.2f}pp | "
        f"sd = {sd * 100:.2f}pp | se = {se * 100:.2f}pp"
    )
    print(f"one-sample t = {t_stat:.2f}, two-sided p = {pval:.3f}")
    print(
        f"90% CI: [{(mean - half_width) * 100:+.2f}, "
        f"{(mean + half_width) * 100:+.2f}]pp"
    )
    print(f"Exact MDE at 80% power (two-sided alpha=.05): {mde80 * 100:.2f}pp")

    print("\nSummary:")
    print(
        "  Across datasets, the saturated rewired-minus-symmetric-ER "
        f"difference was {mean * 100:+.1f}pp (90% CI "
        f"[{(mean - half_width) * 100:+.1f}, {(mean + half_width) * 100:+.1f}]pp; "
        f"n={n}). Under the observed between-dataset variability, the design "
        f"had 80% power for a two-sided effect of {mde80 * 100:.1f}pp."
    )
    if mde80 <= 0.02:
        print("  A 2pp effect was above the design's 80%-power sensitivity threshold.")
    else:
        print("  A 2pp effect was below the design's 80%-power sensitivity threshold.")


if __name__ == "__main__":
    main()
