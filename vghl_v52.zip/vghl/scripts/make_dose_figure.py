#!/usr/bin/env python3
"""Dose-response figure: mean accuracy against destruction dose p.

Usage:
  python -u scripts/dose_response.py --mode topology
  python -u scripts/make_dose_figure.py \
      --csv outputs/dose_response_topology.csv --exclude adult
"""
import argparse
import csv
from collections import defaultdict


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--csv", required=True, help="CSV written by dose_response.py")
    ap.add_argument("--out", default="dose_response.pdf")
    ap.add_argument("--exclude", default="", help="comma list, e.g. adult")
    a = ap.parse_args()
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    excluded = {d for d in a.exclude.split(",") if d}
    curves = defaultdict(lambda: defaultdict(list))
    with open(a.csv) as f:
        for r in csv.DictReader(f):
            if r["dataset"] in excluded:
                continue
            p = float(r["rewire_frac"] if "rewire_frac" in r else r["p"])
            curves[r["dataset"]][p].append(float(r["acc"]))
    fig, ax = plt.subplots(figsize=(4.6, 3.0))
    for ds, pts in sorted(curves.items()):
        ps = sorted(pts)
        means = [sum(pts[p]) / len(pts[p]) for p in ps]
        ax.plot(ps, means, marker="o", ms=3, lw=1.2, label=ds)
    ax.set_xlabel("destruction dose p")
    ax.set_ylabel("accuracy")
    ax.legend(fontsize=6, ncol=2, frameon=False)
    fig.tight_layout()
    fig.savefig(a.out)
    print("wrote", a.out, "|", len(curves), "datasets")


if __name__ == "__main__":
    main()
