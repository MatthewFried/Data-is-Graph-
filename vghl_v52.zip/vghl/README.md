# vghl

Code for *The Graph Is Data: Feature-Induced Graph Learning Cannot Add Information* (LoG 2026).

The pipeline is fixed throughout: build a graph, propagate features with the random-walk operator `P = D^-1 (A+I)` for `tau` steps, and fit a closed-form ridge readout. Experiments hold features, operator, edge count and readout fixed and change only the connectivity.

## Setup

```bash
python -m pip install -e ".[gnn,test]"
python -m pytest -q tests
python -u scripts/setup_downloads.py      # PyG datasets for the supplied-graph experiments
```

Public datasets (sklearn, OpenML, torchvision, Planetoid and the other PyG graphs) download on first use to `~/.cache/vghl_data` and `~/.cache/vghl_pyg`. FAISS is used for kNN if installed (`.[cpu]` or `.[gpu]`), otherwise scikit-learn. `scripts/meta_analysis.py` also needs `.[meta]`. CARDIA is not included (restricted-access data).

All scripts write CSVs under `outputs/` and print summary tables.

## Feature-induced graphs (kNN on X)

| Script | What it runs |
|---|---|
| `run_real_experiments.py --only ablation` | Main table: Full, No Prop, No Graph, tau=1, Random Edges, Pruned, 20 datasets |
| `run_real_experiments.py --only rewiring` | Symmetric degree-preserving rewire control, with per-run diagnostics |
| `run_real_experiments.py --only hp_transfer` | Three fixed (k, tau) settings without per-dataset tuning |
| `run_real_experiments.py --only signal` | Intervention under label noise |
| `run_real_experiments.py --only noise_curve` | Accuracy under increasing label noise |
| `run_real_experiments.py --only geometry` | Region selection (stable, boundary and random subsets) |
| `run_real_experiments.py --only noise_suite` | Corruption analysis (six experiments) |
| `run_real_experiments.py --only <mode>` | Other modes: `noise`, `reliability`, `representation`, `sensitivity`, `baselines`, `scaling`, `wallclock` |
| `tost.py` | Equivalence test (TOST) for Full vs No Prop from `ablation.csv` |
| `swap_sweep.py`, `power_analysis.py` | Null ladder for the rewire control and its dataset-level power analysis |
| `dose_response.py`, `make_dose_figure.py` | Nested dose-response under partial destruction, and its figure |
| `spectral_predictor.py` | Label-free spectral retention statistic, real vs destroyed |
| `adult_diagnostics.py` | Training-only kNN purity and kNN-minus-ridge gap |
| `gnn_tabular.py` | GCN, GAT and MLP on the kNN graphs under the same interventions |
| `transfer.py` | Geometry of dataset A used to learn dataset B |
| `refine.py` | Stability-guided structural refinement vs random removal |
| `pipeline_diagnostic.py`, `meta_analysis.py` | Scope: where the construction produces an informative substrate |
| `low_label.py` | Low-label regime with label propagation |
| `corruption_table.py` | Corruption x detector table from the noise-suite CSV |

## Supplied graphs

| Script | What it runs |
|---|---|
| `native_graph.py` | Cora and CiteSeer citation graphs: given, random edges, rewired, random destination, kNN |
| `gnn_native.py` | GCN, GAT and MLP on the same conditions |
| `regime_b.py` | Extended roster of 11 supplied graphs, with train-edge homophily and optional GNN readouts |
| `alpha_native.py` | Nested, exact-density endpoint-redirection curves |

## Example

```bash
python -u scripts/run_real_experiments.py --only ablation --seeds 0,1,2,3,4
python -u scripts/tost.py --csv outputs/real_experiments/ablation.csv
python -u scripts/native_graph.py --seeds 0,1,2,3,4
python -u scripts/regime_b.py --skip-gnn
```

## Tests

`tests/test_operator_oracle.py` checks every sparse propagation operator against a dense oracle on symmetric and directed graphs. `tests/test_controls.py` checks the rewiring, random-edge and dose-path controls (seeding, degree preservation, exact edge counts, overlap).
