import os
import sys

import torch

ROOT = os.path.dirname(os.path.dirname(__file__))
sys.path.insert(0, os.path.join(ROOT, "scripts"))
sys.path.insert(0, os.path.join(ROOT, "src"))

from alpha_native import build_replacement_path, dosed_graph, edge_overlap_fraction
from regime_b import _solve_ridge, make_random_edges_exact, propagate
from run_real_experiments import _degree_preserving_rewire


def test_dual_ridge_matches_primal():
    torch.manual_seed(3)
    x = torch.randn(8, 13)
    y = torch.tensor([0, 1, 2, 0, 1, 2, 0, 1])
    actual = _solve_ridge(x, y, 3, 1e-2)
    targets = torch.nn.functional.one_hot(y, 3).double()
    expected = torch.linalg.solve(
        x.double().T @ x.double() + 1e-2 * torch.eye(13, dtype=torch.double),
        x.double().T @ targets,
    ).float()
    assert torch.allclose(actual, expected, atol=2e-4, rtol=2e-4)


def test_propagation_preserves_constants():
    ei = torch.tensor([[0, 1, 1, 2], [1, 0, 2, 1]])
    ones = torch.ones(3, 1)
    assert torch.allclose(propagate(ones, ei, 3, tau=4), ones, atol=1e-6)


def test_random_edges_exact_and_loop_free():
    ei = make_random_edges_exact(7, 500, 4)
    assert ei.shape == (2, 500)
    assert not bool((ei[0] == ei[1]).any())


def test_rewire_is_seeded_and_degree_preserving():
    ei = torch.tensor([
        [0, 1, 1, 2, 2, 3, 3, 4, 4, 0, 0, 2],
        [1, 0, 2, 1, 3, 2, 4, 3, 0, 4, 2, 0],
    ])
    a, da = _degree_preserving_rewire(ei, 5, 5, 123)
    b, db = _degree_preserving_rewire(ei, 5, 5, 123)
    assert torch.equal(a, b)
    assert da["degree_vector_unchanged"] and db["degree_vector_unchanged"]
    assert da["reciprocity"] == db["reciprocity"] == 1.0


def test_alpha_path_preserves_density_and_exact_overlap():
    original = torch.tensor([
        [0, 1, 1, 2, 2, 3, 3, 4, 4, 0],
        [1, 0, 2, 1, 3, 2, 4, 3, 0, 4],
    ])
    ordered, replacements = build_replacement_path(original, 8, 9)
    for p in [0, 0.1, 0.25, 0.5, 0.75, 1]:
        graph, actual, _ = dosed_graph(ordered, replacements, 8, p)
        assert graph.shape[1] == original.shape[1]
        assert abs(edge_overlap_fraction(graph, original) - (1 - actual)) < 1e-12
