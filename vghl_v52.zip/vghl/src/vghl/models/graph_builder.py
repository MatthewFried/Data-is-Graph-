"""Graph Builder: pluggable DATA → GRAPH constructors using scalable kNN backend.

All builders use O(N·k·log N) kNN instead of O(N²) pairwise distances.
Gabriel and MST builders are gated by N threshold for safety.

Base graph types:
  - knn: standard k-nearest-neighbors
  - mutual_knn: mutual k-nearest-neighbors
  - epsilon: epsilon-radius graph (via kNN candidates)
  - adaptive_radius: per-point adaptive radius
  - mst_shortcuts: MST + k shortcut edges (gated by N)
  - gabriel: Gabriel graph approximation (gated by N)
  - hybrid: local kNN + sparse long-range edges
"""
from __future__ import annotations

import logging
import torch
import numpy as np
from typing import Dict, Tuple
from dataclasses import dataclass

from .knn_backend import knn, knn_to_edge_index

logger = logging.getLogger(__name__)

# Maximum N for expensive builders (MST, Gabriel)
_EXPENSIVE_BUILDER_N_MAX = 5000


@dataclass
class GraphBuilderConfig:
    """Configuration for base graph construction."""
    type: str = "knn"              # knn | mutual_knn | epsilon | adaptive_radius |
                                   # mst_shortcuts | gabriel | hybrid
    k: int = 16                    # neighbors for kNN variants
    epsilon: float = 0.5           # radius for epsilon graph
    adaptive_percentile: float = 0.9  # percentile for adaptive radius
    mst_shortcuts: int = 4         # extra edges per node beyond MST
    hybrid_long_frac: float = 0.05 # fraction of long-range edges in hybrid
    hybrid_long_k: int = 1         # long-range neighbors per node in hybrid
    symmetrize: bool = True        # force undirected
    self_loops: bool = False       # include self-loops
    weight_mode: str = "gaussian"  # gaussian | binary | inverse_dist
    sigma: float = 1.0             # bandwidth for gaussian weighting
    control: str = "none"          # none | random_destination | degree_preserving_rewire


# ── Registry ─────────────────────────────────────────────────────────

GRAPH_BUILDER_REGISTRY = {}


def register_graph_builder(name):
    def decorator(fn):
        GRAPH_BUILDER_REGISTRY[name] = fn
        return fn
    return decorator


def build_base_graph(
    points: torch.Tensor,
    cfg: GraphBuilderConfig,
) -> Dict[str, torch.Tensor]:
    """Build base graph from points.

    Args:
        points: (N, d) point coordinates
        cfg: GraphBuilderConfig

    Returns:
        dict with 'edge_index' (2, E), 'edge_weight' (E,), 'edge_dist' (E,)
    """
    if cfg.type not in GRAPH_BUILDER_REGISTRY:
        raise ValueError(
            f"Unknown graph builder '{cfg.type}'. "
            f"Available: {list(GRAPH_BUILDER_REGISTRY.keys())}"
        )
    builder_fn = GRAPH_BUILDER_REGISTRY[cfg.type]
    edge_index, edge_dist = builder_fn(points, cfg)

    # Symmetrize
    if cfg.symmetrize:
        edge_index, edge_dist = _symmetrize(edge_index, edge_dist)

    # Remove self-loops unless requested
    if not cfg.self_loops:
        mask = edge_index[0] != edge_index[1]
        edge_index = edge_index[:, mask]
        edge_dist = edge_dist[mask]

    # Compute weights
    edge_weight = _compute_weights(edge_dist, cfg)

    # Apply causal control (geometry destruction for ablation)
    if cfg.control != "none":
        edge_index, edge_weight = _apply_control(
            edge_index, edge_weight, points.shape[0], cfg.control
        )
        # Recompute edge distances from actual point coordinates
        # (control rewires edges, so distances change)
        src_pts = points[edge_index[0]]
        dst_pts = points[edge_index[1]]
        edge_dist = (src_pts - dst_pts).norm(dim=1)

    return {
        "edge_index": edge_index,
        "edge_weight": edge_weight,
        "edge_dist": edge_dist,
    }


def _apply_control(
    edge_index: torch.Tensor,
    edge_weight: torch.Tensor,
    N: int,
    control: str,
) -> Tuple[torch.Tensor, torch.Tensor]:
    """Apply causal control to destroy geometry while preserving structure.

    random_destination: keep out-degree, randomly reassign destinations.
    degree_preserving_rewire: true degree-preserving double-edge swap on
        undirected graph (preserves node degree exactly).
    Both produce uniform weights (geometry is destroyed).
    """
    device = edge_index.device
    E = edge_index.shape[1]

    if control == "random_destination":
        src, dst = edge_index[0].clone(), edge_index[1].clone()
        for node in range(N):
            mask = src == node
            n_edges = mask.sum().item()
            if n_edges <= 1:
                continue
            candidates = torch.arange(N, device=device)
            candidates = candidates[candidates != node]
            perm = torch.randperm(len(candidates), device=device)[:n_edges]
            dst[mask] = candidates[perm]
        new_ei = torch.stack([src, dst])
        not_self = new_ei[0] != new_ei[1]
        new_ew = torch.ones(not_self.sum(), device=device, dtype=edge_weight.dtype)
        return new_ei[:, not_self], new_ew

    elif control == "degree_preserving_rewire":
        # True degree-preserving rewire on undirected graph.
        # Work on canonical edges (u < v) to avoid duplicates.
        src, dst = edge_index[0], edge_index[1]
        mask_canonical = src < dst
        u_edges = src[mask_canonical].cpu().tolist()
        v_edges = dst[mask_canonical].cpu().tolist()
        n_undirected = len(u_edges)
        if n_undirected < 2:
            return edge_index, edge_weight

        edge_set = set(zip(u_edges, v_edges))
        import random as _rng
        n_swaps = n_undirected * 2
        for _ in range(n_swaps):
            i = _rng.randrange(n_undirected)
            j = _rng.randrange(n_undirected)
            if i == j:
                continue
            a, b = u_edges[i], v_edges[i]
            c, d = u_edges[j], v_edges[j]
            # Try swap: (a,b),(c,d) -> (a,d),(c,b)
            e1 = (min(a, d), max(a, d))
            e2 = (min(c, b), max(c, b))
            if e1[0] == e1[1] or e2[0] == e2[1]:
                continue
            if e1 in edge_set or e2 in edge_set:
                continue
            edge_set.discard((min(a, b), max(a, b)))
            edge_set.discard((min(c, d), max(c, d)))
            edge_set.add(e1)
            edge_set.add(e2)
            u_edges[i], v_edges[i] = e1
            u_edges[j], v_edges[j] = e2

        u_t = torch.tensor(u_edges, device=device, dtype=edge_index.dtype)
        v_t = torch.tensor(v_edges, device=device, dtype=edge_index.dtype)
        new_ei = torch.cat([torch.stack([u_t, v_t]), torch.stack([v_t, u_t])], dim=1)
        new_ew = torch.ones(new_ei.shape[1], device=device, dtype=edge_weight.dtype)
        return new_ei, new_ew

    else:
        logger.warning(f"Unknown control: {control}, returning original graph")
        return edge_index, edge_weight


# ── Utilities ────────────────────────────────────────────────────────

def _symmetrize(
    edge_index: torch.Tensor, edge_dist: torch.Tensor
) -> Tuple[torch.Tensor, torch.Tensor]:
    """Symmetrize directed edges into undirected, deduplicating."""
    rev_index = edge_index.flip(0)
    all_index = torch.cat([edge_index, rev_index], dim=1)
    all_dist = torch.cat([edge_dist, edge_dist], dim=0)

    N = int(all_index.max().item()) + 1
    edge_hash = all_index[0].long() * N + all_index[1].long()
    unique_hash, inverse = edge_hash.unique(return_inverse=True)

    # Scatter min distances
    out_dist = torch.full((unique_hash.shape[0],), float("inf"), device=edge_dist.device)
    out_dist.scatter_reduce_(0, inverse, all_dist, reduce="amin")

    src = unique_hash // N
    dst = unique_hash % N
    edge_index = torch.stack([src, dst], dim=0)
    return edge_index, out_dist


def _compute_weights(
    edge_dist: torch.Tensor, cfg: GraphBuilderConfig
) -> torch.Tensor:
    """Compute edge weights from distances."""
    if cfg.weight_mode == "binary":
        return torch.ones_like(edge_dist)
    elif cfg.weight_mode == "gaussian":
        sigma_sq = cfg.sigma ** 2
        if sigma_sq < 1e-10:
            # Adaptive: use median of edge distances
            pos_dists = edge_dist[edge_dist > 0]
            median_dist = pos_dists.median().item() if pos_dists.numel() > 0 else 1.0
            sigma_sq = median_dist ** 2
        return torch.exp(-edge_dist ** 2 / (2 * sigma_sq))
    elif cfg.weight_mode == "inverse_dist":
        return 1.0 / (edge_dist + 1e-6)
    else:
        raise ValueError(f"Unknown weight_mode: {cfg.weight_mode}")


# ── Graph Builders ───────────────────────────────────────────────────

@register_graph_builder("knn")
def _build_knn(points: torch.Tensor, cfg: GraphBuilderConfig):
    """Standard k-nearest-neighbor graph. O(N·k·log N) via kNN backend."""
    N = points.shape[0]
    k = min(cfg.k, N - 1)
    indices, distances = knn(points, k)
    return knn_to_edge_index(indices, distances, device=points.device)


@register_graph_builder("mutual_knn")
def _build_mutual_knn(points: torch.Tensor, cfg: GraphBuilderConfig):
    """Mutual kNN: edge iff both endpoints are in each other's kNN.

    Vectorized via hash-based membership test (no Python set loops).
    """
    N = points.shape[0]
    k = min(cfg.k, N - 1)
    indices, distances = knn(points, k)

    # Build directed edges as flat arrays
    src_all = np.arange(N, dtype=np.int64).repeat(k)
    dst_all = indices.reshape(-1).astype(np.int64)
    dist_flat = distances.reshape(-1).astype(np.float32)

    # Filter invalid
    valid = dst_all >= 0
    src_all = src_all[valid]
    dst_all = dst_all[valid]
    dist_flat = dist_flat[valid]

    # Compute edge hashes and reverse hashes
    edge_hash = src_all * N + dst_all
    rev_hash = dst_all * N + src_all

    # Sort edge_hash for searchsorted lookup
    sorted_hash, sort_idx = np.unique(edge_hash, return_index=True)

    # Check which reverse edges exist in the forward set
    insert_pos = np.searchsorted(sorted_hash, rev_hash)
    insert_pos = np.clip(insert_pos, 0, len(sorted_hash) - 1)
    is_mutual = sorted_hash[insert_pos] == rev_hash

    if not is_mutual.any():
        logger.warning("No mutual kNN edges found, falling back to kNN")
        return knn_to_edge_index(indices, distances, device=points.device)

    mutual_src = src_all[is_mutual]
    mutual_dst = dst_all[is_mutual]
    mutual_dist = dist_flat[is_mutual]

    device = points.device
    edge_index = torch.tensor(
        np.stack([mutual_src, mutual_dst], axis=0), dtype=torch.long, device=device
    )
    edge_dist = torch.tensor(mutual_dist, dtype=torch.float32, device=device)
    return edge_index, edge_dist


@register_graph_builder("epsilon")
def _build_epsilon(points: torch.Tensor, cfg: GraphBuilderConfig):
    """Epsilon-radius graph via kNN candidates.

    Uses kNN with large k to find candidates, then filters by epsilon.
    Vectorized - no Python loops over edges.
    """
    N = points.shape[0]
    k_search = min(max(cfg.k * 4, 64), N - 1)
    indices, distances = knn(points, k_search)

    # Filter by epsilon
    valid = (indices >= 0) & (distances <= cfg.epsilon)
    if not valid.any():
        median_d = float(np.median(distances[distances > 0])) if (distances > 0).any() else 1.0
        valid = (indices >= 0) & (distances <= median_d * 2)
        logger.warning(f"No edges within epsilon={cfg.epsilon}, using adaptive={median_d * 2:.4f}")

    rows, cols = np.where(valid)
    if rows.size == 0:
        return knn_to_edge_index(indices[:, :min(cfg.k, k_search)],
                                  distances[:, :min(cfg.k, k_search)], device=points.device)

    src = rows.astype(np.int64)
    dst = indices[rows, cols].astype(np.int64)
    dist = distances[rows, cols].astype(np.float32)

    device = points.device
    edge_index = torch.tensor(np.stack([src, dst], axis=0), dtype=torch.long, device=device)
    edge_dist = torch.tensor(dist, dtype=torch.float32, device=device)
    return edge_index, edge_dist


@register_graph_builder("adaptive_radius")
def _build_adaptive_radius(points: torch.Tensor, cfg: GraphBuilderConfig):
    """Per-point adaptive radius: radius_i = percentile of i's kNN distances.

    Vectorized - no Python loops over edges.
    """
    N = points.shape[0]
    k = min(cfg.k, N - 1)
    k_search = min(k * 4, N - 1)
    indices, distances = knn(points, k_search)

    # Per-point radius from kNN distances
    pct_idx = min(int(cfg.adaptive_percentile * k), k - 1)
    col = min(pct_idx, distances.shape[1] - 1)
    radii = distances[:, col]  # (N,)

    # For each (i, j) pair: edge if d[i,j] <= max(radii[i], radii[j]) and valid
    valid_idx = indices >= 0
    # Gather destination radii: radii[indices[i,j]] for valid entries
    dst_radii = np.where(valid_idx, radii[np.clip(indices, 0, N - 1)], 0.0)
    src_radii = radii[:, np.newaxis]  # (N, 1) broadcast to (N, k_search)
    r_max = np.maximum(src_radii, dst_radii)

    mask = valid_idx & (distances <= r_max)

    rows, cols = np.where(mask)
    if rows.size == 0:
        return knn_to_edge_index(indices[:, :k], distances[:, :k], device=points.device)

    src = rows.astype(np.int64)
    dst = indices[rows, cols].astype(np.int64)
    dist = distances[rows, cols].astype(np.float32)

    device = points.device
    edge_index = torch.tensor(np.stack([src, dst], axis=0), dtype=torch.long, device=device)
    edge_dist = torch.tensor(dist, dtype=torch.float32, device=device)
    return edge_index, edge_dist


@register_graph_builder("mst_shortcuts")
def _build_mst_shortcuts(points: torch.Tensor, cfg: GraphBuilderConfig):
    """MST + k shortcut edges per node.

    Gated by N: skips MST for large datasets, falls back to kNN.
    """
    N = points.shape[0]
    device = points.device

    if N > _EXPENSIVE_BUILDER_N_MAX:
        logger.warning(
            f"mst_shortcuts: N={N} > {_EXPENSIVE_BUILDER_N_MAX}, "
            f"skipping MST, falling back to kNN"
        )
        k = min(cfg.k, N - 1)
        indices, distances = knn(points, k)
        return knn_to_edge_index(indices, distances, device=device)

    # For small N: compute MST via scipy on kNN-based sparse distance matrix
    k_sparse = min(max(cfg.k * 2, 32), N - 1)
    indices, distances = knn(points, k_sparse)

    from scipy.sparse import lil_matrix
    from scipy.sparse.csgraph import minimum_spanning_tree

    # Build sparse distance matrix from kNN results
    dist_sparse = lil_matrix((N, N), dtype=np.float64)
    for i in range(N):
        for j in range(k_sparse):
            nbr = indices[i, j]
            if nbr >= 0:
                d = distances[i, j]
                dist_sparse[i, nbr] = d
                dist_sparse[nbr, i] = d

    mst = minimum_spanning_tree(dist_sparse.tocsr())
    mst_coo = mst.tocoo()
    mst_src = torch.tensor(mst_coo.row, dtype=torch.long, device=device)
    mst_dst = torch.tensor(mst_coo.col, dtype=torch.long, device=device)
    mst_dist = torch.tensor(mst_coo.data, dtype=torch.float32, device=device)

    # Shortcut edges from kNN
    k_short = min(cfg.mst_shortcuts, N - 1)
    short_indices, short_distances = knn(points, k_short)
    short_ei, short_ed = knn_to_edge_index(short_indices, short_distances, device=device)

    # Merge MST + shortcuts
    edge_index = torch.cat([
        torch.stack([mst_src, mst_dst], dim=0),
        short_ei,
    ], dim=1)
    edge_dist = torch.cat([mst_dist, short_ed])
    return edge_index, edge_dist


@register_graph_builder("gabriel")
def _build_gabriel(points: torch.Tensor, cfg: GraphBuilderConfig):
    """Gabriel graph approximation via local kNN neighborhoods.

    Edge (i,j) exists iff no third point k in the union of kNN(i) ∪ kNN(j)
    lies inside the diametral ball. O(N·k²) instead of O(N²).

    Gated by N: falls back to kNN for large datasets.
    """
    N = points.shape[0]
    device = points.device

    if N > _EXPENSIVE_BUILDER_N_MAX:
        logger.warning(
            f"gabriel: N={N} > {_EXPENSIVE_BUILDER_N_MAX}, "
            f"skipping Gabriel, falling back to kNN"
        )
        k = min(cfg.k, N - 1)
        indices, distances = knn(points, k)
        return knn_to_edge_index(indices, distances, device=device)

    k = min(cfg.k, N - 1)
    indices, distances = knn(points, k)
    pts = points.detach()

    # Build neighbor sets for local candidate checking
    neighbor_sets = [set(int(indices[i, j]) for j in range(k) if indices[i, j] >= 0) for i in range(N)]

    valid_src, valid_dst, valid_dist = [], [], []
    for i in range(N):
        for j_idx in range(k):
            j = int(indices[i, j_idx])
            if j < 0:
                continue
            d_ij_sq = float(distances[i, j_idx]) ** 2

            # Check Gabriel criterion against local candidates
            # Candidates = kNN(i) ∪ kNN(j) - {i, j}
            candidates = (neighbor_sets[i] | neighbor_sets[j]) - {i, j}

            is_gabriel = True
            for c in candidates:
                # Point c inside diametral ball iff d(i,c)² + d(j,c)² < d(i,j)²
                d_ic_sq = float(((pts[i] - pts[c]) ** 2).sum())
                d_jc_sq = float(((pts[j] - pts[c]) ** 2).sum())
                if d_ic_sq + d_jc_sq < d_ij_sq:
                    is_gabriel = False
                    break

            if is_gabriel:
                valid_src.append(i)
                valid_dst.append(j)
                valid_dist.append(float(distances[i, j_idx]))

    if not valid_src:
        logger.warning("No Gabriel edges found, falling back to kNN")
        return knn_to_edge_index(indices, distances, device=device)

    edge_index = torch.tensor([valid_src, valid_dst], dtype=torch.long, device=device)
    edge_dist = torch.tensor(valid_dist, dtype=torch.float32, device=device)
    return edge_index, edge_dist


@register_graph_builder("hybrid")
def _build_hybrid(points: torch.Tensor, cfg: GraphBuilderConfig):
    """Hybrid: local kNN + sparse long-range edges. Vectorized."""
    N = points.shape[0]
    device = points.device
    k = min(cfg.k, N - 1)
    k_long = max(1, cfg.hybrid_long_k)

    k_total = min(k + k_long + 1, N - 1)
    indices, distances = knn(points, k_total)

    # Local: first k neighbors
    local_idx = indices[:, :k]
    local_dist = distances[:, :k]
    local_ei, local_ed = knn_to_edge_index(local_idx, local_dist, device=device)

    # Long-range: neighbors beyond the k-th
    if k_total > k:
        long_idx = indices[:, k:k + k_long]
        long_dist = distances[:, k:k + k_long]
        long_ei, long_ed = knn_to_edge_index(long_idx, long_dist, device=device)
        if long_ei.shape[1] > 0:
            edge_index = torch.cat([local_ei, long_ei], dim=1)
            edge_dist = torch.cat([local_ed, long_ed])
            return edge_index, edge_dist

    return local_ei, local_ed


# ── Config parsing ───────────────────────────────────────────────────

def graph_builder_config_from_dict(d: dict) -> GraphBuilderConfig:
    """Parse GraphBuilderConfig from a YAML dict."""
    cfg = GraphBuilderConfig()
    for k, v in d.items():
        if hasattr(cfg, k):
            setattr(cfg, k, v)
    return cfg
