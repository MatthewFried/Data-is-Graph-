"""Closed-form ridge classifier and kNN query embedding."""
from __future__ import annotations

import torch


def embed_queries_via_knn(H_train, X_train, X_query, k=8):
    """Embed query points by kNN aggregation of propagated train embeddings.

    For each query point, find k nearest train points and distance-weight
    aggregate their propagated embeddings. Correct inductive protocol.

    Args:
        H_train: (N, d_out) propagated train embeddings
        X_train: (N, d_in) raw train features (for kNN distance)
        X_query: (M, d_in) raw query features
        k: number of neighbors

    Returns:
        H_query: (M, d_out) embedded query features
    """
    from .knn_backend import KNNIndex
    device = H_train.device
    N = H_train.shape[0]

    # Guard: if no train points, return zeros
    if N == 0:
        M = X_query.shape[0]
        d_out = H_train.shape[1] if H_train.dim() == 2 else 1
        return torch.zeros(M, d_out, device=device, dtype=H_train.dtype)

    k_actual = min(k, N)

    # KNNIndex needs CPU numpy arrays
    X_train_np = X_train.detach().cpu()
    X_query_np = X_query.detach().cpu()
    index = KNNIndex(X_train_np)
    indices, distances = index.query(X_query_np, k_actual)

    # Create tensors on the SAME device as H_train
    dist_t = torch.tensor(distances, dtype=torch.float32, device=device)
    weights = 1.0 / (dist_t + 1e-8)  # (M, k)
    weights = weights / weights.sum(dim=1, keepdim=True)  # normalize

    idx_t = torch.tensor(indices, dtype=torch.long, device=device)
    neighbor_embeds = H_train[idx_t]  # (M, k, d_out)
    H_query = (neighbor_embeds * weights.unsqueeze(2)).sum(dim=1)  # (M, d_out)
    return H_query


def fit_ridge_classifier(
    H: torch.Tensor, y: torch.Tensor, n_classes: int, l2: float = 1e-2,
) -> torch.Tensor:
    """Fit ridge classifier in closed form: W = (H^T H + λI)^{-1} H^T Y.

    Args:
        H: (N, d) propagated features.
        y: (N,) integer labels.
        n_classes: number of classes.
        l2: regularization strength.

    Returns:
        W: (d, n_classes) weight matrix.
    """
    device = H.device
    N, d = H.shape

    # One-hot encode targets
    Y = torch.zeros(N, n_classes, device=device)
    Y.scatter_(1, y.unsqueeze(1).long(), 1.0)

    # Ridge: W = (H^T H + λI)^{-1} H^T Y
    HtH = H.T @ H  # (d, d)
    HtH.diagonal().add_(l2)
    HtY = H.T @ Y  # (d, n_classes)

    try:
        L = torch.linalg.cholesky(HtH)
        W = torch.cholesky_solve(HtY, L)
    except RuntimeError:
        W = torch.linalg.lstsq(HtH, HtY).solution

    return W


def predict_logits(H: torch.Tensor, W: torch.Tensor) -> torch.Tensor:
    """Predict logits: logits = H @ W."""
    return H @ W


def accuracy(logits: torch.Tensor, y: torch.Tensor) -> float:
    """Compute classification accuracy."""
    preds = logits.argmax(dim=1)
    return (preds == y).float().mean().item()


def ridge_eval(
    H_train: torch.Tensor, y_train: torch.Tensor,
    H_val: torch.Tensor, y_val: torch.Tensor,
    n_classes: int, l2: float = 1e-2,
) -> float:
    """One-shot: fit ridge on train, score on val. Returns val accuracy."""
    W = fit_ridge_classifier(H_train, y_train, n_classes, l2)
    logits = predict_logits(H_val, W)
    return accuracy(logits, y_val)
