"""Structural pruning: remove nodes/edges flagged as structurally unreliable.

Three families:
  - geometric: anomalous local density, extreme edge lengths
  - stability: bootstrap graph construction, vectorized edge survival + Jaccard
  - label_consistency: (TRAIN-only) remove nodes with label disagreement

Noise is defined structurally: a point is noise if removing it improves the
propagated representation.
"""
from __future__ import annotations

import logging
import torch
from typing import Dict, List, Tuple, Optional
from dataclasses import dataclass, field

logger = logging.getLogger(__name__)


@dataclass
class PruningConfig:
    """Configuration for structural pruning."""
    enabled: bool = False
    methods: List[str] = field(default_factory=lambda: ["geometric"])
    # geometric | stability | label_consistency

    # Geometric pruning
    density_percentile_low: float = 0.05   # remove bottom 5% by local density
    density_percentile_high: float = 0.95  # remove top 5% outliers
    edge_length_percentile: float = 0.95   # remove edges above this percentile

    # Stability pruning (vectorized)
    n_bootstrap: int = 5                    # number of bootstrap samples
    perturb_sigma: float = 0.01            # perturbation magnitude
    edge_survival_threshold: float = 0.5   # keep edges surviving > this fraction
    node_jaccard_min: float = 0.5            # minimum acceptable Jaccard stability;
    # nodes with mean pairwise neighbor-set Jaccard < this are pruned as unstable

    # Label consistency pruning (TRAIN-only, no val/test labels)
    label_agreement_min: float = 0.3       # keep nodes with agreement >= this
    # (replaces influence_samples and influence_threshold)


def prune_graph(
    edge_index: torch.Tensor,
    edge_weight: torch.Tensor,
    points: torch.Tensor,
    cfg: PruningConfig,
    labels: Optional[torch.Tensor] = None,
    graph_builder_fn=None,
    is_train_mask: Optional[torch.Tensor] = None,
) -> Dict[str, torch.Tensor]:
    """Apply pruning to graph.

    Args:
        edge_index: (2, E) edges
        edge_weight: (E,) weights
        points: (N, d) node coordinates
        cfg: PruningConfig
        labels: (N,) optional labels for label_consistency pruning
        graph_builder_fn: callable for stability bootstrapping
        is_train_mask: (N,) bool, True for train nodes (for label_consistency safety)

    Returns:
        dict with pruned edge_index, edge_weight, node_mask, edge_mask, stats
    """
    N = points.shape[0]
    E = edge_index.shape[1]
    device = points.device

    node_mask = torch.ones(N, dtype=torch.bool, device=device)
    edge_mask = torch.ones(E, dtype=torch.bool, device=device)
    stats = {}

    for method in cfg.methods:
        if method == "geometric":
            nm, em, s = _geometric_prune(edge_index, edge_weight, points, cfg)
            node_mask &= nm
            edge_mask &= em
            stats.update({f"geo_{k}": v for k, v in s.items()})

        elif method == "stability":
            nm, em, s = _stability_prune(
                edge_index, edge_weight, points, cfg, graph_builder_fn
            )
            node_mask &= nm
            edge_mask &= em
            stats.update({f"stab_{k}": v for k, v in s.items()})

        elif method == "label_consistency":
            if labels is not None:
                nm, s = _label_consistency_prune(
                    edge_index, edge_weight, points, labels, cfg,
                    train_mask=is_train_mask,
                )
                node_mask &= nm
                stats.update({f"lbl_{k}": v for k, v in s.items()})
            else:
                logger.warning("label_consistency pruning requested but no labels provided")

        elif method == "task_coupled":
            # Backward compat: alias to label_consistency with warning
            logger.warning("'task_coupled' is deprecated, use 'label_consistency'")
            if labels is not None:
                nm, s = _label_consistency_prune(
                    edge_index, edge_weight, points, labels, cfg,
                    train_mask=is_train_mask,
                )
                node_mask &= nm
                stats.update({f"lbl_{k}": v for k, v in s.items()})

        else:
            raise ValueError(f"Unknown pruning method: {method}")

    # Apply node mask to edges
    src_valid = node_mask[edge_index[0]]
    dst_valid = node_mask[edge_index[1]]
    edge_mask &= src_valid & dst_valid

    pruned_edge_index = edge_index[:, edge_mask]
    pruned_edge_weight = edge_weight[edge_mask]

    # Remap node indices if nodes were removed
    if not node_mask.all():
        remap = torch.cumsum(node_mask.long(), dim=0) - 1
        pruned_edge_index = remap[pruned_edge_index]

    stats["n_nodes_removed"] = int((~node_mask).sum().item())
    stats["n_edges_removed"] = int((~edge_mask).sum().item())
    stats["n_nodes_kept"] = int(node_mask.sum().item())
    stats["n_edges_kept"] = int(edge_mask.sum().item())
    stats["node_survival_rate"] = node_mask.float().mean().item()
    stats["edge_survival_rate"] = edge_mask.float().mean().item()

    return {
        "edge_index": pruned_edge_index,
        "edge_weight": pruned_edge_weight,
        "node_mask": node_mask,
        "edge_mask": edge_mask,
        "points": points[node_mask],
        "stats": stats,
    }


# ── Geometric Pruning ────────────────────────────────────────────────

def _geometric_prune(
    edge_index: torch.Tensor,
    edge_weight: torch.Tensor,
    points: torch.Tensor,
    cfg: PruningConfig,
) -> Tuple[torch.Tensor, torch.Tensor, Dict]:
    """Remove nodes with anomalous density and edges with extreme length."""
    N = points.shape[0]
    E = edge_index.shape[1]
    device = points.device

    node_mask = torch.ones(N, dtype=torch.bool, device=device)
    edge_mask = torch.ones(E, dtype=torch.bool, device=device)
    stats = {}

    # Node density: degree as proxy
    degree = torch.zeros(N, device=device)
    degree.scatter_add_(0, edge_index[0], torch.ones(E, device=device))
    degree.scatter_add_(0, edge_index[1], torch.ones(E, device=device))

    if N > 10:
        lo = torch.quantile(degree, cfg.density_percentile_low).item()
        hi = torch.quantile(degree, cfg.density_percentile_high).item()
        node_mask &= (degree >= lo) & (degree <= hi)
        stats["density_lo"] = lo
        stats["density_hi"] = hi

    # Edge length pruning
    edge_dists = (points[edge_index[0]] - points[edge_index[1]]).norm(dim=1)
    if E > 10:
        length_threshold = torch.quantile(edge_dists, cfg.edge_length_percentile).item()
        edge_mask &= edge_dists <= length_threshold
        stats["edge_length_threshold"] = length_threshold

    stats["n_nodes_pruned_geo"] = int((~node_mask).sum().item())
    stats["n_edges_pruned_geo"] = int((~edge_mask).sum().item())

    return node_mask, edge_mask, stats


# ── Stability Pruning (real neighbor-set Jaccard) ─────────────────────

def _build_neighbor_sets(
    edge_index: torch.Tensor, N: int, device: torch.device,
) -> torch.Tensor:
    """Build padded sorted neighbor-id matrix for each node.

    Returns (N, max_deg) long tensor, padded with -1.
    """
    src, dst = edge_index[0], edge_index[1]
    # Both directions for undirected
    all_src = torch.cat([src, dst])
    all_dst = torch.cat([dst, src])

    counts = torch.zeros(N, dtype=torch.long, device=device)
    if all_src.numel() > 0:
        counts.scatter_add_(0, all_src, torch.ones_like(all_src))

    max_deg = max(int(counts.max().item()), 1) if counts.numel() > 0 else 1
    neighbors = torch.full((N, max_deg), -1, dtype=torch.long, device=device)

    if all_src.numel() > 0:
        order = all_src.argsort(stable=True)
        all_dst_sorted = all_dst[order]
        offsets = torch.zeros(N + 1, dtype=torch.long, device=device)
        offsets[1:] = counts.cumsum(0)
        for i in range(N):
            s, e = offsets[i].item(), offsets[i + 1].item()
            if e > s:
                nbrs = all_dst_sorted[s:e].unique()
                neighbors[i, :len(nbrs)] = nbrs.sort()[0]
    return neighbors


def _pairwise_jaccard(boot_sets, N, device):
    """Mean pairwise exact Jaccard of padded neighbor matrices.

    Each entry in boot_sets is (N, max_deg_b) from _build_neighbor_sets.
    Returns (N,) mean Jaccard per node.
    """
    n_boot = len(boot_sets)
    if n_boot < 2:
        return torch.ones(N, device=device)

    jaccard_sum = torch.zeros(N, device=device)
    n_pairs = 0

    for a in range(n_boot):
        for b in range(a + 1, n_boot):
            ma, mb = boot_sets[a], boot_sets[b]
            sa = (ma >= 0).sum(dim=1)  # (N,)
            sb = (mb >= 0).sum(dim=1)
            ka, kb = ma.shape[1], mb.shape[1]

            inter = torch.zeros(N, device=device)
            if ka > 0 and kb > 0 and ka * kb <= 1024:
                # Vectorized broadcast: (N,ka,1)==(N,1,kb)
                match = (ma.unsqueeze(2) == mb.unsqueeze(1))
                valid = (ma >= 0).unsqueeze(2) & (mb >= 0).unsqueeze(1)
                inter = (match & valid).any(dim=2).sum(dim=1).float()
            elif ka > 0 and kb > 0:
                # Per-node fallback for very high degree
                for i in range(N):
                    na = ma[i][ma[i] >= 0]
                    nb = mb[i][mb[i] >= 0]
                    if na.numel() == 0 or nb.numel() == 0:
                        continue
                    pos = torch.searchsorted(nb, na)
                    pos = pos.clamp(max=nb.shape[0] - 1)
                    inter[i] = (nb[pos] == na).sum().float()

            union = sa.float() + sb.float() - inter
            both_empty = (sa == 0) & (sb == 0)
            j = inter / union.clamp(min=1)
            j[both_empty] = 1.0
            jaccard_sum += j
            n_pairs += 1

    return jaccard_sum / max(n_pairs, 1)


def _stability_prune(
    edge_index: torch.Tensor,
    edge_weight: torch.Tensor,
    points: torch.Tensor,
    cfg: PruningConfig,
    graph_builder_fn=None,
) -> Tuple[torch.Tensor, torch.Tensor, Dict]:
    """Bootstrap stability pruning.

    Edge stability: fraction of bootstraps each edge survives.
    Node stability: exact pairwise Jaccard of neighbor sets.
      J_i = mean_{a<b} |N_i^a ∩ N_i^b| / |N_i^a ∪ N_i^b|
    Nodes with Jaccard < node_jaccard_min are removed as structurally unstable.
    """
    N = points.shape[0]
    E = edge_index.shape[1]
    device = points.device
    stats = {}

    if graph_builder_fn is None:
        return (
            torch.ones(N, dtype=torch.bool, device=device),
            torch.ones(E, dtype=torch.bool, device=device),
            {"skipped": True},
        )

    # Canonicalize edges: min(src,dst)*N + max(src,dst) for undirected consistency
    src_orig, dst_orig = edge_index[0].long(), edge_index[1].long()
    u_orig = torch.minimum(src_orig, dst_orig)
    v_orig = torch.maximum(src_orig, dst_orig)
    edge_hash_orig = u_orig * N + v_orig
    # Deduplicate (undirected graph stores both (i,j) and (j,i))
    edge_hash_unique, inverse_map = edge_hash_orig.unique(return_inverse=True)
    edge_hash_sorted, sort_idx = edge_hash_unique.sort()
    n_unique = edge_hash_unique.shape[0]
    edge_survival_unique = torch.zeros(n_unique, device=device)
    boot_neighbor_sets = []

    for b in range(cfg.n_bootstrap):
        noise = torch.randn_like(points) * cfg.perturb_sigma
        result = graph_builder_fn(points + noise)
        pert_ei = result["edge_index"]

        # Canonicalize perturbed edges too
        pert_src, pert_dst = pert_ei[0].long(), pert_ei[1].long()
        pert_u = torch.minimum(pert_src, pert_dst)
        pert_v = torch.maximum(pert_src, pert_dst)
        pert_hash = (pert_u * N + pert_v).unique()  # deduplicated
        pert_sorted = pert_hash.sort()[0]

        if pert_sorted.numel() > 0:
            pos = torch.searchsorted(pert_sorted, edge_hash_sorted)
            pos = pos.clamp(max=pert_sorted.shape[0] - 1)
            found = pert_sorted[pos] == edge_hash_sorted
        else:
            found = torch.zeros(n_unique, dtype=torch.bool, device=device)
        surv = torch.zeros(n_unique, device=device)
        surv[sort_idx] = found.float()
        edge_survival_unique += surv

        # Neighbor sets for Jaccard
        boot_neighbor_sets.append(_build_neighbor_sets(pert_ei, N, device))

    edge_survival_unique /= cfg.n_bootstrap
    # Map back to original edge indices (both directions get same survival)
    edge_survival = edge_survival_unique[inverse_map]
    edge_mask = edge_survival >= cfg.edge_survival_threshold

    # Node mask: Jaccard threshold
    if len(boot_neighbor_sets) >= 2:
        node_jaccard = _pairwise_jaccard(boot_neighbor_sets, N, device)
        node_mask = node_jaccard >= cfg.node_jaccard_min
        stats["mean_jaccard"] = node_jaccard.mean().item()
        stats["jaccard_threshold"] = cfg.node_jaccard_min
    else:
        node_mask = torch.ones(N, dtype=torch.bool, device=device)

    stats["mean_edge_survival"] = edge_survival.mean().item()
    stats["n_edges_pruned_stab"] = int((~edge_mask).sum().item())
    stats["n_nodes_pruned_stab"] = int((~node_mask).sum().item())
    return node_mask, edge_mask, stats


# ── Label Consistency Pruning (TRAIN-only) ───────────────────────────

def _label_consistency_prune(
    edge_index: torch.Tensor,
    edge_weight: torch.Tensor,
    points: torch.Tensor,
    labels: torch.Tensor,
    cfg: PruningConfig,
    train_mask: Optional[torch.Tensor] = None,
) -> Tuple[torch.Tensor, Dict]:
    """Remove nodes whose neighbors have inconsistent labels.

    SAFETY: Only applies to train nodes. Val/test nodes are never pruned
    by this method to prevent label leakage.

    Args:
        edge_index: (2, E) edges
        edge_weight: (E,) weights
        points: (N, d) coordinates
        labels: (N,) class labels
        cfg: PruningConfig
        train_mask: (N,) bool tensor, True for train nodes.
            If None, all nodes treated as train (dangerous in eval).
    """
    N = points.shape[0]
    E = edge_index.shape[1]
    device = points.device
    stats = {}

    if train_mask is None:
        logger.warning("label_consistency_prune called without train_mask; treating all as train")
        train_mask = torch.ones(N, dtype=torch.bool, device=device)

    # Build neighbor label agreement
    n_classes = int(labels.max().item()) + 1
    src, dst = edge_index[0], edge_index[1]

    # Count labels of neighbors: for each dst node, count label of src
    # Use one-hot encoding of src labels
    src_onehot = torch.zeros(E, n_classes, device=device)
    src_onehot.scatter_(1, labels[src].unsqueeze(1), 1.0)

    neighbor_label_count = torch.zeros(N, n_classes, device=device)
    neighbor_label_count.scatter_add_(
        0, dst.unsqueeze(1).expand(-1, n_classes), src_onehot
    )

    # Agreement: fraction of neighbors with same label
    own_label_count = neighbor_label_count.gather(1, labels.unsqueeze(1)).squeeze(1)
    total_neighbors = neighbor_label_count.sum(dim=1).clamp(min=1)
    agreement = own_label_count / total_neighbors

    # Only prune train nodes
    node_mask = torch.ones(N, dtype=torch.bool, device=device)
    prune_condition = (agreement < cfg.label_agreement_min) & train_mask
    node_mask[prune_condition] = False

    stats["mean_agreement"] = agreement[train_mask].mean().item() if train_mask.any() else 0.0
    stats["n_nodes_pruned_lbl"] = int(prune_condition.sum().item())

    return node_mask, stats


# ── Config parsing ───────────────────────────────────────────────────

def pruning_config_from_dict(d: dict) -> PruningConfig:
    """Parse PruningConfig from a YAML dict."""
    cfg = PruningConfig()
    for k, v in d.items():
        if hasattr(cfg, k):
            if k == "methods" and isinstance(v, str):
                v = [x.strip() for x in v.split(",")]
            setattr(cfg, k, v)
    return cfg
