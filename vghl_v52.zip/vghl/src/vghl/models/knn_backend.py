"""Scalable kNN backend: FAISS (preferred) with sklearn fallback.

Replaces O(N²) full pairwise distance computation with O(N·k·log N)
approximate or exact nearest neighbor search.

Includes KNNIndex for caching the built index across repeated queries.

Usage:
    indices, distances = knn(X, k)  # auto-selects best backend
    edge_index, edge_dist = knn_to_edge_index(indices, distances)

    # Cached usage (for repeated queries against same reference):
    index = KNNIndex(X_reference)
    indices, distances = index.query(X_query, k)
"""
from __future__ import annotations

import os
# Force single-thread for all numeric backends to prevent deadlocks
# in repeated kNN calls (especially during test_batch_invariance).
os.environ.setdefault("OMP_NUM_THREADS", "1")
os.environ.setdefault("MKL_NUM_THREADS", "1")
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
os.environ.setdefault("NUMEXPR_NUM_THREADS", "1")

import logging
import torch
import numpy as np
from typing import Tuple, Optional

logger = logging.getLogger(__name__)

_FAISS_AVAILABLE: Optional[bool] = None
_FAISS_GPU_AVAILABLE: Optional[bool] = None
_FAISS_GPU_RES = None  # cached StandardGpuResources


def _check_faiss() -> bool:
    """Check if faiss is importable (cached)."""
    global _FAISS_AVAILABLE
    if _FAISS_AVAILABLE is None:
        try:
            import faiss  # noqa: F401
            _FAISS_AVAILABLE = True
        except ImportError:
            _FAISS_AVAILABLE = False
    return _FAISS_AVAILABLE


def _check_faiss_gpu() -> bool:
    """Check if faiss-gpu is available with at least 1 GPU."""
    global _FAISS_GPU_AVAILABLE
    if _FAISS_GPU_AVAILABLE is None:
        if not _check_faiss():
            _FAISS_GPU_AVAILABLE = False
        else:
            try:
                import faiss
                _FAISS_GPU_AVAILABLE = faiss.get_num_gpus() > 0
                if _FAISS_GPU_AVAILABLE:
                    logger.info(f"FAISS GPU available ({faiss.get_num_gpus()} GPUs)")
            except Exception:
                _FAISS_GPU_AVAILABLE = False
    return _FAISS_GPU_AVAILABLE


def _get_gpu_res():
    """Get cached FAISS GPU resources (singleton)."""
    global _FAISS_GPU_RES
    if _FAISS_GPU_RES is None:
        import faiss
        _FAISS_GPU_RES = faiss.StandardGpuResources()
    return _FAISS_GPU_RES


def _to_np(X) -> np.ndarray:
    """Convert tensor or array to contiguous float32 numpy."""
    if isinstance(X, torch.Tensor):
        return np.ascontiguousarray(X.detach().cpu().float().numpy(), dtype=np.float32)
    return np.ascontiguousarray(X, dtype=np.float32)


# ── Cached kNN Index ─────────────────────────────────────────────────


class KNNIndex:
    """Persistent kNN index: build once on reference data, query many times.

    Avoids the overhead of rebuilding a FAISS/sklearn index on every call
    to attach_queries(). This is the fix for the batch-invariance hang.
    """

    def __init__(self, X_ref: torch.Tensor, backend: str = "auto"):
        """Build index from reference points.

        Args:
            X_ref: (N, d) reference points.
            backend: 'auto' | 'faiss' | 'sklearn'.
        """
        self._X_np = _to_np(X_ref)
        self._N = self._X_np.shape[0]
        self._d = self._X_np.shape[1]

        if backend == "auto":
            backend = "faiss" if _check_faiss() else "sklearn"
        self._backend = backend

        if backend == "faiss":
            import faiss
            index = faiss.IndexFlatL2(self._d)
            index.add(self._X_np)
            if _check_faiss_gpu():
                self._index = faiss.index_cpu_to_gpu(
                    _get_gpu_res(), 0, index)
                logger.info(f"KNNIndex: using FAISS GPU (N={self._N}, d={self._d})")
            else:
                self._index = index
        elif backend == "sklearn":
            from sklearn.neighbors import NearestNeighbors
            # brute is safest; ball_tree can deadlock with OpenMP
            self._index = NearestNeighbors(
                n_neighbors=min(32, self._N), algorithm="brute",
                metric="euclidean", n_jobs=1,
            )
            self._index.fit(self._X_np)
        else:
            raise ValueError(f"Unknown kNN backend: {backend}")

    def query(
        self, Q: torch.Tensor, k: int, is_self: bool = False
    ) -> Tuple[np.ndarray, np.ndarray]:
        """Query the index for k nearest neighbors.

        Args:
            Q: (M, d) query points.
            k: number of neighbors.
            is_self: if True, Q is the same as the reference data (self-kNN),
                     so we search k+1 and strip the self-match.

        Returns:
            indices: (M, k) int64 neighbor indices.
            distances: (M, k) float32 Euclidean distances.
        """
        Q_np = _to_np(Q)
        k_search = min(k + 1, self._N) if is_self else min(k, self._N)

        if self._backend == "faiss":
            sq_dists, indices = self._index.search(Q_np, k_search)
            distances = np.sqrt(np.maximum(sq_dists, 0.0)).astype(np.float32)
            indices = indices.astype(np.int64)
        else:
            # sklearn: set n_neighbors for this query
            self._index.set_params(n_neighbors=k_search)
            distances, indices = self._index.kneighbors(Q_np)
            distances = distances.astype(np.float32)
            indices = indices.astype(np.int64)

        # Strip self-neighbors
        if is_self and k_search > k:
            indices = indices[:, 1:]
            distances = distances[:, 1:]

        # Ensure exactly k columns
        if indices.shape[1] > k:
            indices = indices[:, :k]
            distances = distances[:, :k]

        return indices, distances


# ── Standalone knn() (builds ephemeral index) ────────────────────────


def knn(
    X: torch.Tensor,
    k: int,
    query: Optional[torch.Tensor] = None,
    backend: str = "auto",
) -> Tuple[np.ndarray, np.ndarray]:
    """Compute k-nearest neighbors (ephemeral index, not cached).

    For repeated queries against the same X, use KNNIndex instead.

    Args:
        X: (N, d) reference points (float32 tensor or ndarray).
        k: number of neighbors.
        query: (M, d) optional query points. If None, self-kNN on X.
        backend: 'auto' | 'faiss' | 'sklearn'.

    Returns:
        indices: (M, k) int64 neighbor indices into X.
        distances: (M, k) float32 Euclidean distances.
    """
    X_np = _to_np(X)
    N = X_np.shape[0]

    if query is not None:
        Q_np = _to_np(query)
    else:
        Q_np = X_np

    k_search = min(k + 1, N) if query is None else min(k, N)

    if backend == "auto":
        backend = "faiss" if _check_faiss() else "sklearn"

    if backend == "faiss":
        indices, distances = _knn_faiss(X_np, Q_np, k_search)
    elif backend == "sklearn":
        indices, distances = _knn_sklearn(X_np, Q_np, k_search)
    else:
        raise ValueError(f"Unknown kNN backend: {backend}")

    # Strip self-neighbors for self-kNN
    if query is None and k_search > k:
        indices = indices[:, 1:]
        distances = distances[:, 1:]

    # Ensure we return exactly k columns
    if indices.shape[1] > k:
        indices = indices[:, :k]
        distances = distances[:, :k]

    return indices, distances


def _knn_faiss(
    X: np.ndarray, Q: np.ndarray, k: int
) -> Tuple[np.ndarray, np.ndarray]:
    """FAISS-based exact kNN (L2). Uses GPU if available."""
    import faiss

    d = X.shape[1]
    X_c = np.ascontiguousarray(X, dtype=np.float32)
    Q_c = np.ascontiguousarray(Q, dtype=np.float32)

    index = faiss.IndexFlatL2(d)
    index.add(X_c)
    if _check_faiss_gpu():
        index = faiss.index_cpu_to_gpu(_get_gpu_res(), 0, index)
    sq_dists, indices = index.search(Q_c, k)
    distances = np.sqrt(np.maximum(sq_dists, 0.0))
    return indices.astype(np.int64), distances.astype(np.float32)


def _knn_sklearn(
    X: np.ndarray, Q: np.ndarray, k: int
) -> Tuple[np.ndarray, np.ndarray]:
    """sklearn-based exact kNN (ball_tree for moderate N, brute for small N)."""
    from sklearn.neighbors import NearestNeighbors

    N = X.shape[0]
    nn = NearestNeighbors(n_neighbors=k, algorithm="brute",
                          metric="euclidean", n_jobs=1)
    nn.fit(X)
    distances, indices = nn.kneighbors(Q)
    return indices.astype(np.int64), distances.astype(np.float32)


def knn_to_edge_index(
    indices: np.ndarray,
    distances: np.ndarray,
    device: torch.device = torch.device("cpu"),
    src_offset: int = 0,
) -> Tuple[torch.Tensor, torch.Tensor]:
    """Convert kNN result matrices to COO edge_index + edge_dist.

    Args:
        indices: (M, k) neighbor indices.
        distances: (M, k) neighbor distances.
        device: target device.
        src_offset: offset to add to source node indices (for bipartite graphs).

    Returns:
        edge_index: (2, M*k) long tensor.
        edge_dist: (M*k,) float tensor.
    """
    M, k = indices.shape
    src = np.arange(M, dtype=np.int64).reshape(-1, 1) + src_offset
    src = np.broadcast_to(src, (M, k)).reshape(-1)
    dst = indices.reshape(-1)

    # Filter out invalid indices (faiss returns -1 for missing neighbors)
    valid = dst >= 0
    src = src[valid]
    dst = dst[valid]
    dists = distances.reshape(-1)[valid]

    edge_index = torch.tensor(np.stack([src, dst], axis=0), dtype=torch.long, device=device)
    edge_dist = torch.tensor(dists, dtype=torch.float32, device=device)
    return edge_index, edge_dist
