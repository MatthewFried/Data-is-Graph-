"""Fixed Propagation Operators: sparse, no learned weights, pure graph-driven.

All operators use scatter-based sparse operations for O(E) memory/compute
instead of O(N²) dense matrices. No NxN matrices are ever created.

Operators:
  - identity: pass-through (baseline)
  - random_walk: h^{t+1} = D^{-1}(A+I) h^t
  - ppr: Personalized PageRank iterative approximation
  - heat: Heat kernel via repeated sparse Laplacian multiplications
  - laplacian: Symmetric normalized Laplacian smoothing
  - gated: Edge-gated diffusion (threshold on edge weight)
"""
from __future__ import annotations

import torch
from dataclasses import dataclass


@dataclass
class PropagationConfig:
    """Configuration for fixed propagation operator."""
    type: str = "random_walk"    # random_walk | ppr | heat | laplacian | gated | identity
    steps: int = 5               # diffusion steps
    alpha: float = 0.15          # teleport probability for PPR
    t: float = 1.0               # time for heat kernel
    gate_threshold: float = 0.5  # edge weight percentile threshold for gated


OPERATOR_REGISTRY = {}


def register_operator(name):
    def decorator(fn):
        OPERATOR_REGISTRY[name] = fn
        return fn
    return decorator


def propagate(
    features: torch.Tensor,
    edge_index: torch.Tensor,
    edge_weight: torch.Tensor,
    N: int,
    cfg: PropagationConfig,
) -> torch.Tensor:
    """Apply fixed propagation operator using sparse operations.

    Args:
        features: (N, d) initial node features
        edge_index: (2, E) edges
        edge_weight: (E,) weights
        N: number of nodes
        cfg: PropagationConfig

    Returns:
        (N, d) propagated features
    """
    if cfg.type not in OPERATOR_REGISTRY:
        raise ValueError(
            f"Unknown operator '{cfg.type}'. "
            f"Available: {list(OPERATOR_REGISTRY.keys())}"
        )
    return OPERATOR_REGISTRY[cfg.type](features, edge_index, edge_weight, N, cfg)


# ── Sparse utilities ─────────────────────────────────────────────────

def add_self_loops_sparse(
    edge_index: torch.Tensor,
    edge_weight: torch.Tensor,
    N: int,
    fill_value: float = 1.0,
) -> tuple:
    """Add self-loops to edge_index and edge_weight.

    Returns:
        (new_edge_index, new_edge_weight)
    """
    device = edge_index.device
    loop_idx = torch.arange(N, device=device)
    loop_index = torch.stack([loop_idx, loop_idx], dim=0)
    loop_weight = torch.full((N,), fill_value, device=device, dtype=edge_weight.dtype)
    new_index = torch.cat([edge_index, loop_index], dim=1)
    new_weight = torch.cat([edge_weight, loop_weight], dim=0)
    return new_index, new_weight


def _compute_degree(
    edge_index: torch.Tensor,
    edge_weight: torch.Tensor,
    N: int,
) -> torch.Tensor:
    """Compute out-degree via scatter_add. Returns (N,) float tensor."""
    degree = torch.zeros(N, device=edge_index.device, dtype=edge_weight.dtype)
    degree.scatter_add_(0, edge_index[0], edge_weight)
    return degree


def row_norm_sparse(
    edge_index: torch.Tensor,
    edge_weight: torch.Tensor,
    N: int,
) -> tuple:
    """Row-normalize: scale each edge by 1/deg[src]. Returns (norm_weight, degree)."""
    degree = _compute_degree(edge_index, edge_weight, N)
    deg_inv = torch.zeros_like(degree)
    mask = degree > 1e-12
    deg_inv[mask] = 1.0 / degree[mask]
    norm_weight = edge_weight * deg_inv[edge_index[0]]
    return norm_weight, degree


def sym_norm_sparse(
    edge_index: torch.Tensor,
    edge_weight: torch.Tensor,
    N: int,
) -> tuple:
    """Symmetric normalization: D^{-1/2} A D^{-1/2}. Returns (norm_weight, degree)."""
    degree = _compute_degree(edge_index, edge_weight, N)
    deg_inv_sqrt = torch.zeros_like(degree)
    mask = degree > 1e-12
    deg_inv_sqrt[mask] = degree[mask].pow(-0.5)
    norm_weight = edge_weight * deg_inv_sqrt[edge_index[0]] * deg_inv_sqrt[edge_index[1]]
    return norm_weight, degree


def spmm(
    edge_index: torch.Tensor,
    edge_weight: torch.Tensor,
    N: int,
    h: torch.Tensor,
) -> torch.Tensor:
    """Sparse matrix × dense matrix: A @ h via scatter_add.

    O(E·d) time and O(N·d) memory. No NxN matrix created.
    """
    # Row convention: out[i] = sum_{(i->j)} w_ij * h[j], i.e. node src
    # AVERAGES its out-neighbors (with row_norm this is D^-1 (A+I) h, the
    # documented operator). Aggregating h[src] into dst instead would give
    # the transpose (A+I) D^-1 h; tests/test_operator_oracle.py checks this
    # against a dense oracle.
    src, dst = edge_index[0], edge_index[1]
    msg = h[dst] * edge_weight.unsqueeze(1)
    out = torch.zeros_like(h)
    out.scatter_add_(0, src.unsqueeze(1).expand_as(msg), msg)
    return out


# ── Operators ────────────────────────────────────────────────────────

@register_operator("identity")
def _identity(features, edge_index, edge_weight, N, cfg):
    """Pass-through: no propagation."""
    return features


@register_operator("random_walk")
def _random_walk(features, edge_index, edge_weight, N, cfg):
    """Random walk: h^{t+1} = D^{-1}(A+I) h^t. O(E) per step."""
    ei, ew = add_self_loops_sparse(edge_index, edge_weight, N, fill_value=1.0)
    ew_norm, _ = row_norm_sparse(ei, ew, N)
    h = features
    for _ in range(cfg.steps):
        h = spmm(ei, ew_norm, N, h)
    return h


@register_operator("ppr")
def _ppr(features, edge_index, edge_weight, N, cfg):
    """PPR: h = α·x₀ + (1-α)·D^{-1}(A+I)·h. O(E) per step."""
    ei, ew = add_self_loops_sparse(edge_index, edge_weight, N, fill_value=1.0)
    ew_norm, _ = row_norm_sparse(ei, ew, N)
    h = features
    x0 = features
    alpha = cfg.alpha
    for _ in range(cfg.steps):
        h = alpha * x0 + (1 - alpha) * spmm(ei, ew_norm, N, h)
    return h


@register_operator("heat")
def _heat(features, edge_index, edge_weight, N, cfg):
    """Heat kernel: exp(-tL)x ≈ Σ_{k=0}^T (-t)^k L^k x / k!

    L_sym = I - D^{-1/2} A D^{-1/2}. All sparse O(E) per term.
    """
    ew_sym, _ = sym_norm_sparse(edge_index, edge_weight, N)
    t = cfg.t

    def _L_mv(v):
        """L_sym @ v = v - A_sym @ v"""
        return v - spmm(edge_index, ew_sym, N, v)

    h = features.clone()
    term = features.clone()
    for k in range(1, cfg.steps + 1):
        term = -(t / k) * _L_mv(term)
        h = h + term
    return h


@register_operator("laplacian")
def _laplacian_smooth(features, edge_index, edge_weight, N, cfg):
    """Laplacian smoothing: h^{t+1} = D_hat^{-1/2} A_hat D_hat^{-1/2} h^t."""
    ei, ew = add_self_loops_sparse(edge_index, edge_weight, N, fill_value=1.0)
    ew_sym, _ = sym_norm_sparse(ei, ew, N)
    h = features
    for _ in range(cfg.steps):
        h = spmm(ei, ew_sym, N, h)
    return h


@register_operator("gated")
def _gated_diffusion(features, edge_index, edge_weight, N, cfg):
    """Gated diffusion: per-edge gate by weight threshold. O(E) per step."""
    if edge_weight.numel() == 0:
        return features

    median_w = edge_weight.median()
    threshold = median_w * cfg.gate_threshold

    gate = torch.where(
        edge_weight > threshold,
        torch.ones_like(edge_weight),
        edge_weight / (threshold + 1e-8),
    )
    gated_weight = edge_weight * gate

    ei, ew = add_self_loops_sparse(edge_index, gated_weight, N, fill_value=1.0)
    ew_norm, _ = row_norm_sparse(ei, ew, N)
    h = features
    for _ in range(cfg.steps):
        h = spmm(ei, ew_norm, N, h)
    return h


# ── Config parsing ───────────────────────────────────────────────────

def propagation_config_from_dict(d: dict) -> PropagationConfig:
    """Parse PropagationConfig from a YAML dict."""
    cfg = PropagationConfig()
    for k, v in d.items():
        if hasattr(cfg, k):
            setattr(cfg, k, v)
    return cfg
