"""Experiment configuration used by the dataset loaders."""
from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class DataConfig:
    dataset: str = "piecewise2d"
    n_train: int = 10000
    n_val: int = 2000
    n_test: int = 2000
    d: int = 2
    noise_sigma: float = 0.05
    label_noise: float = 0.0
    n_classes: int = 4
    n_spirals: int = 2
    grid_size: int = 2
    n_manifolds: int = 2
    manifold_noise: float = 0.1
    background_frac: float = 0.1
    n_sources: int = 2
    freq_range: tuple = (1.0, 3.0)
    phase_jitter: float = 0.3


@dataclass
class ExperimentConfig:
    seed: int = 0
    data: DataConfig = field(default_factory=DataConfig)
