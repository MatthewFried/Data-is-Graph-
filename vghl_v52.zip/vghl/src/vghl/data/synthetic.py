"""Synthetic dataset generators for Voronoi-Induced Hierarchical Graph Learning.

Each generator returns a dict with keys:
  - X: (N, d) float tensor  (features / coordinates)
  - y: (N,) long tensor (labels for classification) or float tensor (regression)
  - region_id: (N,) long tensor (ground-truth region assignment, if available)
  - meta: dict with dataset-specific metadata
"""
from __future__ import annotations

import numpy as np
import torch
from typing import Dict, Any, Optional


def make_piecewise2d(
    n: int = 10000,
    grid_size: int = 2,
    noise_sigma: float = 0.05,
    label_noise: float = 0.0,
    seed: int = 0,
) -> Dict[str, Any]:
    """Piecewise-constant regions on [0,1]^2 grid.

    Grid of grid_size x grid_size regions. Each region gets a unique label.
    Gaussian noise added to coordinates.
    """
    rng = np.random.RandomState(seed)
    X = rng.uniform(0, 1, (n, 2)).astype(np.float32)

    # Determine ground-truth region from grid cell
    col = np.clip((X[:, 0] * grid_size).astype(int), 0, grid_size - 1)
    row = np.clip((X[:, 1] * grid_size).astype(int), 0, grid_size - 1)
    region_id = row * grid_size + col
    n_classes = grid_size * grid_size

    # Label = region_id (classification)
    y = region_id.copy()

    # Optionally flip labels
    if label_noise > 0:
        flip_mask = rng.rand(n) < label_noise
        y[flip_mask] = rng.randint(0, n_classes, size=flip_mask.sum())

    # Add coordinate noise
    X_noisy = X + rng.randn(n, 2).astype(np.float32) * noise_sigma

    return {
        "X": torch.from_numpy(X_noisy),
        "y": torch.from_numpy(y.astype(np.int64)),
        "region_id": torch.from_numpy(region_id.astype(np.int64)),
        "meta": {
            "n_classes": n_classes,
            "grid_size": grid_size,
            "d": 2,
            "gt_boundaries": "grid",
        },
    }


def make_spirals(
    n: int = 10000,
    n_spirals: int = 2,
    noise_sigma: float = 0.05,
    label_noise: float = 0.0,
    n_turns: float = 1.5,
    seed: int = 0,
) -> Dict[str, Any]:
    """Two (or more) interleaved spirals."""
    rng = np.random.RandomState(seed)
    points_per_class = n // n_spirals
    X_list, y_list = [], []

    for cls in range(n_spirals):
        r = np.linspace(0.1, 1.0, points_per_class)
        angle_offset = cls * 2 * np.pi / n_spirals
        theta = np.sqrt(r) * n_turns * 2 * np.pi + angle_offset
        x1 = r * np.cos(theta)
        x2 = r * np.sin(theta)
        X_list.append(np.stack([x1, x2], axis=1).astype(np.float32))
        y_list.append(np.full(points_per_class, cls, dtype=np.int64))

    X = np.concatenate(X_list)
    y = np.concatenate(y_list)
    X += rng.randn(*X.shape).astype(np.float32) * noise_sigma

    if label_noise > 0:
        flip = rng.rand(len(y)) < label_noise
        y[flip] = rng.randint(0, n_spirals, size=flip.sum())

    # Shuffle
    perm = rng.permutation(len(X))
    X, y = X[perm], y[perm]

    return {
        "X": torch.from_numpy(X),
        "y": torch.from_numpy(y),
        "region_id": torch.from_numpy(y.copy()),  # class = region for spirals
        "meta": {"n_classes": n_spirals, "d": 2},
    }


def make_circles(
    n: int = 10000,
    noise_sigma: float = 0.05,
    label_noise: float = 0.0,
    n_circles: int = 2,
    seed: int = 0,
) -> Dict[str, Any]:
    """Concentric circles."""
    rng = np.random.RandomState(seed)
    points_per_class = n // n_circles
    X_list, y_list = [], []

    for cls in range(n_circles):
        r_base = 0.3 + cls * 0.5
        theta = rng.uniform(0, 2 * np.pi, points_per_class)
        r = r_base + rng.randn(points_per_class).astype(np.float32) * noise_sigma
        x1 = r * np.cos(theta)
        x2 = r * np.sin(theta)
        X_list.append(np.stack([x1, x2], axis=1).astype(np.float32))
        y_list.append(np.full(points_per_class, cls, dtype=np.int64))

    X = np.concatenate(X_list)
    y = np.concatenate(y_list)

    if label_noise > 0:
        flip = rng.rand(len(y)) < label_noise
        y[flip] = rng.randint(0, n_circles, size=flip.sum())

    perm = rng.permutation(len(X))
    X, y = X[perm], y[perm]

    return {
        "X": torch.from_numpy(X),
        "y": torch.from_numpy(y),
        "region_id": torch.from_numpy(y.copy()),
        "meta": {"n_classes": n_circles, "d": 2},
    }


def make_moons(
    n: int = 10000,
    noise_sigma: float = 0.05,
    label_noise: float = 0.0,
    seed: int = 0,
) -> Dict[str, Any]:
    """Two interleaving half-moons."""
    from sklearn.datasets import make_moons as _make_moons

    X, y = _make_moons(n_samples=n, noise=noise_sigma, random_state=seed)
    X = X.astype(np.float32)
    y = y.astype(np.int64)

    if label_noise > 0:
        rng = np.random.RandomState(seed + 1)
        flip = rng.rand(len(y)) < label_noise
        y[flip] = 1 - y[flip]

    return {
        "X": torch.from_numpy(X),
        "y": torch.from_numpy(y),
        "region_id": torch.from_numpy(y.copy()),
        "meta": {"n_classes": 2, "d": 2},
    }


def make_swiss_roll_with_background(
    n: int = 10000,
    noise_sigma: float = 0.1,
    background_frac: float = 0.1,
    seed: int = 0,
) -> Dict[str, Any]:
    """Swiss roll manifold + uniform background noise points.

    Labels: 0 = swiss roll, 1 = background. Region_id encodes angular position on roll.
    """
    rng = np.random.RandomState(seed)
    n_bg = int(n * background_frac)
    n_roll = n - n_bg

    # Swiss roll
    t = 1.5 * np.pi * (1 + 2 * rng.rand(n_roll))
    x = t * np.cos(t)
    y_coord = 10 * rng.rand(n_roll)
    z = t * np.sin(t)
    roll_points = np.stack([x, y_coord, z], axis=1).astype(np.float32)
    roll_points += rng.randn(n_roll, 3).astype(np.float32) * noise_sigma

    # Discretize t into regions for ground truth
    n_regions = 8
    t_bins = np.digitize(t, np.linspace(t.min(), t.max(), n_regions + 1)) - 1
    t_bins = np.clip(t_bins, 0, n_regions - 1)

    # Background
    bg_points = rng.uniform(
        roll_points.min(0) - 2, roll_points.max(0) + 2, (n_bg, 3)
    ).astype(np.float32)

    X = np.concatenate([roll_points, bg_points])
    # Label: 0 for roll, 1 for background
    labels = np.concatenate([np.zeros(n_roll), np.ones(n_bg)]).astype(np.int64)
    region_id = np.concatenate([t_bins, np.full(n_bg, n_regions)]).astype(np.int64)

    perm = rng.permutation(len(X))
    X, labels, region_id = X[perm], labels[perm], region_id[perm]

    return {
        "X": torch.from_numpy(X),
        "y": torch.from_numpy(labels),
        "region_id": torch.from_numpy(region_id),
        "meta": {"n_classes": 2, "d": 3, "n_gt_regions": n_regions + 1},
    }


def make_layered_periodic(
    n: int = 10000,
    n_sources: int = 2,
    d: int = 2,
    freq_range: tuple = (1.0, 3.0),
    phase_jitter: float = 0.3,
    noise_sigma: float = 0.05,
    seed: int = 0,
) -> Dict[str, Any]:
    """Mixture of near-overlapping periodic sources with phase jitter.

    Each source generates points from a periodic pattern; label = source index.
    """
    rng = np.random.RandomState(seed)
    points_per_source = n // n_sources
    X_list, y_list, region_list = [], [], []

    for src in range(n_sources):
        freq = rng.uniform(freq_range[0], freq_range[1])
        phase = rng.uniform(0, 2 * np.pi)
        # Generate base coordinates
        base = rng.uniform(0, 2 * np.pi, (points_per_source, d)).astype(np.float32)
        # Apply periodic modulation
        modulation = np.sin(freq * base + phase + rng.randn(points_per_source, d).astype(np.float32) * phase_jitter)
        X_src = base + 0.3 * modulation
        X_src += rng.randn(points_per_source, d).astype(np.float32) * noise_sigma

        X_list.append(X_src)
        y_list.append(np.full(points_per_source, src, dtype=np.int64))
        region_list.append(np.full(points_per_source, src, dtype=np.int64))

    X = np.concatenate(X_list)
    y = np.concatenate(y_list)
    region_id = np.concatenate(region_list)

    perm = rng.permutation(len(X))
    X, y, region_id = X[perm], y[perm], region_id[perm]

    return {
        "X": torch.from_numpy(X),
        "y": torch.from_numpy(y),
        "region_id": torch.from_numpy(region_id),
        "meta": {"n_classes": n_sources, "d": d},
    }


def make_blobs_with_boundaries(
    n: int = 10000,
    n_classes: int = 5,
    d: int = 2,
    noise_sigma: float = 0.05,
    label_noise: float = 0.0,
    seed: int = 0,
) -> Dict[str, Any]:
    """Gaussian blobs with clear boundaries - a Voronoi-friendly benchmark.

    Centers are placed and labels come from nearest-center assignment (true Voronoi).
    """
    rng = np.random.RandomState(seed)
    centers = rng.randn(n_classes, d).astype(np.float32) * 2.0

    X = rng.randn(n, d).astype(np.float32) * noise_sigma
    assignments = rng.randint(0, n_classes, n)
    X += centers[assignments]

    # Re-compute labels as nearest center (ground-truth Voronoi)
    from scipy.spatial.distance import cdist
    dists = cdist(X, centers)
    y = dists.argmin(axis=1).astype(np.int64)
    region_id = y.copy()

    if label_noise > 0:
        flip = rng.rand(n) < label_noise
        y[flip] = rng.randint(0, n_classes, size=flip.sum())

    return {
        "X": torch.from_numpy(X),
        "y": torch.from_numpy(y),
        "region_id": torch.from_numpy(region_id),
        "meta": {"n_classes": n_classes, "d": d, "centers": centers},
    }


def make_structured_distractors(
    n: int = 10000,
    noise_sigma: float = 0.05,
    seed: int = 0,
    distractor_frac: float = 0.3,
    **kwargs,
) -> Dict[str, Any]:
    """Piecewise2d signal + structured grid of distractor points.

    Tests whether the model isolates distractors into low-influence regions.
    Ground truth: signal points have real labels, distractors get label=-1
    mapped to a dedicated class.
    """
    rng = np.random.RandomState(seed)
    n_signal = int(n * (1 - distractor_frac))
    n_distract = n - n_signal

    # Signal: 2x2 piecewise grid
    X_sig = rng.rand(n_signal, 2).astype(np.float32)
    X_sig += rng.randn(n_signal, 2).astype(np.float32) * noise_sigma
    grid_x = (X_sig[:, 0] * 2).astype(int).clip(0, 1)
    grid_y = (X_sig[:, 1] * 2).astype(int).clip(0, 1)
    y_sig = (grid_x * 2 + grid_y).astype(np.int64)
    rid_sig = y_sig.copy()
    n_classes = 4

    # Distractors: grid of points outside the signal region
    # Place at regular intervals in [-0.5, 0] x [0, 1] (off to the left)
    side = int(np.ceil(np.sqrt(n_distract)))
    gx = np.linspace(-0.5, -0.05, side)
    gy = np.linspace(0.0, 1.0, side)
    gx, gy = np.meshgrid(gx, gy)
    X_dist = np.stack([gx.ravel(), gy.ravel()], axis=1)[:n_distract].astype(np.float32)
    X_dist += rng.randn(n_distract, 2).astype(np.float32) * noise_sigma * 0.5
    # Distractors get a dedicated "distractor class"
    y_dist = np.full(n_distract, n_classes, dtype=np.int64)
    rid_dist = np.full(n_distract, -1, dtype=np.int64)  # no true region
    n_classes += 1

    X = np.concatenate([X_sig, X_dist], axis=0)
    y = np.concatenate([y_sig, y_dist], axis=0)
    rid = np.concatenate([rid_sig, rid_dist], axis=0)

    # Shuffle
    perm = rng.permutation(len(X))
    X, y, rid = X[perm], y[perm], rid[perm]

    return {
        "X": torch.from_numpy(X),
        "y": torch.from_numpy(y),
        "region_id": torch.from_numpy(rid),
        "meta": {"n_classes": n_classes, "d": 2, "distractor_frac": distractor_frac},
    }


# Registry
SYNTHETIC_DATASETS = {
    "piecewise2d": make_piecewise2d,
    "spirals": make_spirals,
    "circles": make_circles,
    "moons": make_moons,
    "swiss_roll": make_swiss_roll_with_background,
    "layered_periodic": make_layered_periodic,
    "blobs": make_blobs_with_boundaries,
    "distractors": make_structured_distractors,
}


def get_synthetic_dataset(name: str, **kwargs) -> Dict[str, Any]:
    """Get a synthetic dataset by name."""
    if name not in SYNTHETIC_DATASETS:
        raise ValueError(
            f"Unknown dataset '{name}'. Available: {list(SYNTHETIC_DATASETS.keys())}"
        )
    return SYNTHETIC_DATASETS[name](**kwargs)
