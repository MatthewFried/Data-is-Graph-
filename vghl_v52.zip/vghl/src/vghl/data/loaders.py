"""Data loading utilities: real and synthetic datasets with fixed splits."""
from __future__ import annotations

import torch
from typing import Dict, Any, Tuple, Optional
import numpy as np

from .synthetic import get_synthetic_dataset
from ..utils.config import ExperimentConfig


class PointDataset(torch.utils.data.Dataset):
    """Simple dataset wrapping X, y, and optional region_id."""

    def __init__(self, X: torch.Tensor, y: torch.Tensor,
                 region_id: Optional[torch.Tensor] = None):
        self.X = X
        self.y = y
        self.region_id = region_id if region_id is not None else torch.zeros(len(X), dtype=torch.long)

    def __len__(self):
        return len(self.X)

    def __getitem__(self, idx):
        return self.X[idx], self.y[idx], self.region_id[idx]


# ──────────────────────────────────────────────────────────────────────
# Real / external dataset builders
# ──────────────────────────────────────────────────────────────────────

def _load_mnist(train: bool = True, fashion: bool = False, flatten: bool = True):
    """Load MNIST or FashionMNIST via torchvision. Returns X (float32), y (long)."""
    from torchvision import datasets, transforms
    import os
    root = os.path.expanduser("~/.cache/vghl_data")
    cls = datasets.FashionMNIST if fashion else datasets.MNIST
    ds = cls(root, train=train, download=True, transform=transforms.ToTensor())
    X = ds.data.float() / 255.0  # (N, 28, 28) in [0,1]
    if flatten:
        X = X.view(X.shape[0], -1)  # (N, 784)
    y = ds.targets.long()
    return X, y


def _load_sklearn_geometry(name: str, n: int, noise: float, seed: int):
    """Load sklearn geometry datasets with known ground-truth structure.

    Returns X, y, region_id, meta.
    """
    from sklearn import datasets as skds
    rng = np.random.RandomState(seed)

    if name == "sk_moons":
        X, y = skds.make_moons(n_samples=n, noise=noise, random_state=seed)
        region_id = y.copy()
        meta = {"n_classes": 2, "input_dim": 2, "geometry": "two_moons"}

    elif name == "sk_circles":
        X, y = skds.make_circles(n_samples=n, noise=noise, factor=0.5, random_state=seed)
        region_id = y.copy()
        meta = {"n_classes": 2, "input_dim": 2, "geometry": "concentric_circles"}

    elif name == "sk_swiss_roll":
        X_3d, t = skds.make_swiss_roll(n_samples=n, noise=noise, random_state=seed)
        # Classify by position along roll
        n_classes = 4
        y = np.digitize(t, bins=np.linspace(t.min(), t.max(), n_classes + 1)[1:-1])
        X = X_3d
        region_id = y.copy()
        meta = {"n_classes": n_classes, "input_dim": 3, "geometry": "swiss_roll",
                "latent_t": t}

    elif name == "sk_s_curve":
        X_3d, t = skds.make_s_curve(n_samples=n, noise=noise, random_state=seed)
        n_classes = 4
        y = np.digitize(t, bins=np.linspace(t.min(), t.max(), n_classes + 1)[1:-1])
        X = X_3d
        region_id = y.copy()
        meta = {"n_classes": n_classes, "input_dim": 3, "geometry": "s_curve",
                "latent_t": t}

    elif name == "sk_blobs_noisy":
        # Gaussian blobs with bridge points between clusters
        n_classes = 5
        centers = rng.randn(n_classes, 2) * 3
        X, y = skds.make_blobs(n_samples=n, centers=centers, cluster_std=0.5 + noise,
                               random_state=seed)
        # Add bridge points (10% of data) between random cluster pairs
        n_bridge = n // 10
        for _ in range(n_bridge):
            ci, cj = rng.choice(n_classes, 2, replace=False)
            alpha = rng.uniform(0.2, 0.8)
            pt = alpha * centers[ci] + (1 - alpha) * centers[cj]
            pt += rng.randn(2) * (0.3 + noise)
            X = np.vstack([X, pt.reshape(1, -1)])
            y = np.append(y, ci)
        region_id = y.copy()
        meta = {"n_classes": n_classes, "input_dim": 2, "geometry": "blobs_with_bridges"}

    else:
        raise ValueError(f"Unknown sklearn geometry dataset: {name}")

    X = torch.tensor(X, dtype=torch.float32)
    y = torch.tensor(y, dtype=torch.long)
    region_id = torch.tensor(region_id, dtype=torch.long)
    return X, y, region_id, meta


def _load_tabular(name: str, seed: int):
    """Load sklearn tabular datasets: wine, breast_cancer, digits, iris,
    california_housing (binarized), diabetes (binarized)."""
    from sklearn.datasets import (load_wine, load_breast_cancer, load_digits,
                                   load_iris)
    from sklearn.preprocessing import StandardScaler

    loaders = {
        "wine": load_wine,
        "breast_cancer": load_breast_cancer,
        "digits": load_digits,
        "iris": load_iris,
    }

    if name == "california_housing":
        from sklearn.datasets import fetch_california_housing
        data = fetch_california_housing()
        X = StandardScaler().fit_transform(data.data).astype(np.float32)
        # Binarize: above/below median price
        median_price = np.median(data.target)
        y = (data.target > median_price).astype(np.int64)
        n_classes = 2
        rng = np.random.RandomState(seed)
        perm = rng.permutation(len(X))
        X, y = X[perm], y[perm]
        return (
            torch.tensor(X, dtype=torch.float32),
            torch.tensor(y, dtype=torch.long),
            {"n_classes": n_classes, "input_dim": X.shape[1], "dataset": name},
        )

    if name == "diabetes":
        from sklearn.datasets import load_diabetes
        data = load_diabetes()
        X = StandardScaler().fit_transform(data.data).astype(np.float32)
        # Binarize: above/below median progression
        median_prog = np.median(data.target)
        y = (data.target > median_prog).astype(np.int64)
        n_classes = 2
        rng = np.random.RandomState(seed)
        perm = rng.permutation(len(X))
        X, y = X[perm], y[perm]
        return (
            torch.tensor(X, dtype=torch.float32),
            torch.tensor(y, dtype=torch.long),
            {"n_classes": n_classes, "input_dim": X.shape[1], "dataset": name},
        )

    if name not in loaders:
        raise ValueError(f"Unknown tabular dataset: {name}. Available: {list(loaders.keys())}")
    data = loaders[name]()
    X = StandardScaler().fit_transform(data.data).astype(np.float32)
    y = data.target.astype(np.int64)
    n_classes = len(np.unique(y))
    rng = np.random.RandomState(seed)
    perm = rng.permutation(len(X))
    X, y = X[perm], y[perm]
    return (
        torch.tensor(X, dtype=torch.float32),
        torch.tensor(y, dtype=torch.long),
        {"n_classes": n_classes, "input_dim": X.shape[1], "dataset": name},
    )


# ── OpenML dataset registry ──────────────────────────────────────────
# Maps short names to OpenML dataset IDs for benchmark datasets.
# These cover the standard tabular classification benchmarks.
OPENML_REGISTRY = {
    "ionosphere":       34,
    "sonar":            40,
    "hepatitis":        55,
    "vehicle":          54,
    "hill_valley":      1479,
    "spambase":         44,
    "eeg_eye_state":    1471,
    "phoneme":          1489,
    "adult":            1590,
    # "heart" removed - OpenML no longer serves heart v1 reliably; use statlog via data_id=53 with fallback
    "heart":            53,
    "bank_marketing":   1461,
    "spect":            None,  # use spectf below
    "spectf":           None,  # handled separately
    "synthetic_dim":    None,  # handled separately
    "satellite":        182,   # Statlog Landsat Satellite (36d, 6-class, 6435 samples)
    "segment":          36,    # Image Segmentation (19d, 7-class, 2310 samples)
    "pendigits":        32,    # Pen-Based Handwriting (16d, 10-class, 10992 samples)
    "covertype":        1596,  # Covertype (54d, 7-class, 581012 samples - large)
    "letter":           6,     # Letter Recognition (16d, 26-class, 20000 samples)
    "optdigits":        28,    # Optical Digits (64d, 10-class, 5620 samples)
    "waveform":         60,    # Waveform (40d, 3-class, 5000 samples)
}
# PMLB datasets (same interface as OpenML but from PMLB)
PMLB_REGISTRY = {
    "haberman":   None,  # small datasets from PMLB
    "saheart":    None,
    "bupa":       None,
}


def _load_openml(name: str, seed: int):
    """Load dataset from OpenML by name.

    Falls back to fetch_openml. Requires network on first use (cached after).
    """
    from sklearn.datasets import fetch_openml
    from sklearn.preprocessing import StandardScaler, LabelEncoder

    # Map names to OpenML IDs where known; try multiple strategies
    openml_id = OPENML_REGISTRY.get(name)
    data = None
    errors = []

    # Strategy 1: by data_id (most reliable)
    if openml_id is not None:
        try:
            data = fetch_openml(data_id=openml_id, as_frame=False, parser="liac-arff")
        except Exception as e:
            errors.append(f"data_id={openml_id}: {e}")

    # Strategy 2: by name+version
    if data is None:
        try:
            data = fetch_openml(name=name, version=1, as_frame=False, parser="liac-arff")
        except Exception as e:
            errors.append(f"name={name},v=1: {e}")

    # Strategy 3: by name without version
    if data is None:
        try:
            data = fetch_openml(name=name, as_frame=False, parser="liac-arff")
        except Exception as e:
            errors.append(f"name={name}: {e}")

    if data is None:
        raise RuntimeError(
            f"Could not load OpenML dataset '{name}' after trying all strategies. "
            f"Errors: {'; '.join(errors)}"
        )

    X = data.data
    y = data.target

    # Handle string targets
    if y.dtype.kind in ('U', 'S', 'O'):
        le = LabelEncoder()
        y = le.fit_transform(y)

    # Handle NaNs (only for numeric data)
    try:
        if np.isnan(X).any():
            from sklearn.impute import SimpleImputer
            X = SimpleImputer(strategy="median").fit_transform(X)
    except (TypeError, ValueError):
        # X may contain non-numeric data; force to float
        X = X.astype(np.float64)
        if np.isnan(X).any():
            from sklearn.impute import SimpleImputer
            X = SimpleImputer(strategy="median").fit_transform(X)

    X = StandardScaler().fit_transform(X).astype(np.float32)
    y = y.astype(np.int64)
    n_classes = len(np.unique(y))

    rng = np.random.RandomState(seed)
    perm = rng.permutation(len(X))
    X, y = X[perm], y[perm]

    return (
        torch.tensor(X, dtype=torch.float32),
        torch.tensor(y, dtype=torch.long),
        {"n_classes": n_classes, "input_dim": X.shape[1], "dataset": name,
         "n_samples": len(X)},
    )


def _load_cifar10_frozen(seed: int, n_components: int = 50):
    """Load CIFAR-10 with PCA-reduced features (frozen embedding)."""
    from torchvision import datasets
    from sklearn.decomposition import PCA
    from sklearn.preprocessing import StandardScaler
    import os

    root = os.path.expanduser("~/.cache/vghl_data")
    train_ds = datasets.CIFAR10(root, train=True, download=True)
    test_ds = datasets.CIFAR10(root, train=False, download=True)

    X_train = train_ds.data.reshape(len(train_ds.data), -1).astype(np.float32) / 255.0
    y_train = np.array(train_ds.targets, dtype=np.int64)
    X_test = test_ds.data.reshape(len(test_ds.data), -1).astype(np.float32) / 255.0
    y_test = np.array(test_ds.targets, dtype=np.int64)

    scaler = StandardScaler()
    X_train = scaler.fit_transform(X_train)
    X_test = scaler.transform(X_test)
    pca = PCA(n_components=n_components, random_state=seed)
    X_train = pca.fit_transform(X_train).astype(np.float32)
    X_test = pca.transform(X_test).astype(np.float32)

    return (
        torch.tensor(X_train, dtype=torch.float32),
        torch.tensor(y_train, dtype=torch.long),
        torch.tensor(X_test, dtype=torch.float32),
        torch.tensor(y_test, dtype=torch.long),
        {"n_classes": 10, "input_dim": n_components, "dataset": "cifar10_pca"},
    )


def _load_newsgroups_embed(seed: int, n_components: int = 50):
    """Load 20 Newsgroups with TF-IDF + Truncated SVD embedding.

    Produces a 50-dimensional text embedding dataset (no pretrained model needed).
    Categories reduced to 6 macro-groups for cleaner class structure.
    """
    from sklearn.datasets import fetch_20newsgroups
    from sklearn.feature_extraction.text import TfidfVectorizer
    from sklearn.decomposition import TruncatedSVD
    from sklearn.preprocessing import StandardScaler

    # 6 macro-categories for cleaner evaluation
    categories = [
        'comp.graphics', 'comp.os.ms-windows.misc',  # computers
        'rec.autos', 'rec.sport.baseball',            # recreation
        'sci.med', 'sci.space',                        # science
    ]

    train_raw = fetch_20newsgroups(subset='train', categories=categories,
                                    remove=('headers', 'footers', 'quotes'),
                                    random_state=seed)
    test_raw = fetch_20newsgroups(subset='test', categories=categories,
                                   remove=('headers', 'footers', 'quotes'),
                                   random_state=seed)

    tfidf = TfidfVectorizer(max_features=5000, stop_words='english')
    X_tr_tfidf = tfidf.fit_transform(train_raw.data)
    X_te_tfidf = tfidf.transform(test_raw.data)

    svd = TruncatedSVD(n_components=n_components, random_state=seed)
    X_train = svd.fit_transform(X_tr_tfidf)
    X_test = svd.transform(X_te_tfidf)

    scaler = StandardScaler()
    X_train = scaler.fit_transform(X_train).astype(np.float32)
    X_test = scaler.transform(X_test).astype(np.float32)

    y_train = train_raw.target.astype(np.int64)
    y_test = test_raw.target.astype(np.int64)

    return (
        torch.tensor(X_train, dtype=torch.float32),
        torch.tensor(y_train, dtype=torch.long),
        torch.tensor(X_test, dtype=torch.float32),
        torch.tensor(y_test, dtype=torch.long),
        {"n_classes": len(categories), "input_dim": n_components,
         "dataset": "newsgroups_embed"},
    )


def _load_citation_graph(name, seed=0):
    """Load Cora/CiteSeer features. Uses kNN graph (not native citation graph)."""
    try:
        from torch_geometric.datasets import Planetoid
        import os
        dataset = Planetoid(root=os.path.expanduser('~/.cache/vghl_data/pyg'),
                            name=name.capitalize())
        data = dataset[0]
        X = data.x.float()
        y = data.y.long()
    except Exception as e:
        print(f'  torch_geometric failed ({e}), using OpenML fallback')
        from sklearn.datasets import fetch_openml
        from sklearn.preprocessing import LabelEncoder
        import scipy.sparse as sp
        bunch = fetch_openml(data_id=40945 if name == 'cora' else 40946,
                             as_frame=False, parser='auto')
        X_raw = bunch.data.toarray().astype(np.float32) if sp.issparse(bunch.data) \
            else bunch.data.astype(np.float32)
        le = LabelEncoder()
        y_enc = le.fit_transform(bunch.target).astype(np.int64)
        X = torch.tensor(X_raw, dtype=torch.float32)
        y = torch.tensor(y_enc, dtype=torch.long)

    from sklearn.preprocessing import StandardScaler
    X = torch.tensor(StandardScaler().fit_transform(X.numpy()), dtype=torch.float32)
    N = len(X)
    rng = np.random.RandomState(seed)
    perm = rng.permutation(N)
    X, y = X[perm], y[perm]
    n_tr, n_va = min(140, N), min(500, N)
    meta = {'n_classes': int(y.max()) + 1, 'input_dim': X.shape[1], 'dataset': name}
    return (X[:n_tr], y[:n_tr],
            X[n_tr:n_tr + n_va], y[n_tr:n_tr + n_va],
            X[n_tr + n_va:n_tr + n_va + 1000], y[n_tr + n_va:n_tr + n_va + 1000],
            meta)


def build_datasets(cfg: ExperimentConfig) -> Tuple[PointDataset, PointDataset, PointDataset, Dict[str, Any]]:
    """Build train/val/test datasets from config.

    Supports: synthetic generators, sklearn geometry, MNIST/FashionMNIST,
    tabular (wine, breast_cancer), CIFAR-10 with frozen PCA embedding.
    """
    dc = cfg.data
    dataset = dc.dataset

    # ── Tabular datasets (sklearn built-in) ──
    SKLEARN_TABULAR = ("wine", "breast_cancer", "digits", "iris",
                       "california_housing", "diabetes")
    if dataset in SKLEARN_TABULAR:
        X, y, meta = _load_tabular(dataset, cfg.seed)
        n = len(X)
        n_train = min(dc.n_train, int(n * 0.6)) if dc.n_train > 0 else int(n * 0.6)
        n_val = min(dc.n_val, int(n * 0.2)) if dc.n_val > 0 else int(n * 0.2)
        train_ds = PointDataset(X[:n_train], y[:n_train])
        val_ds = PointDataset(X[n_train:n_train + n_val], y[n_train:n_train + n_val])
        test_ds = PointDataset(X[n_train + n_val:], y[n_train + n_val:])
        return train_ds, val_ds, test_ds, meta

    # ── OpenML / external tabular datasets ──
    OPENML_NAMES = set(OPENML_REGISTRY.keys()) | set(PMLB_REGISTRY.keys()) | {
        "haberman", "saheart", "bupa", "hill_valley", "ionosphere",
        "sonar", "hepatitis", "vehicle", "spambase", "eeg_eye_state",
        "phoneme", "spect", "spectf", "synthetic_dim",
        "satellite", "segment", "pendigits", "covertype", "letter",
        "optdigits", "waveform",
    }
    if dataset in OPENML_NAMES:
        X, y, meta = _load_openml(dataset, cfg.seed)
        n = len(X)
        n_train = min(dc.n_train, int(n * 0.6)) if dc.n_train > 0 else int(n * 0.6)
        n_val = min(dc.n_val, int(n * 0.2)) if dc.n_val > 0 else int(n * 0.2)
        train_ds = PointDataset(X[:n_train], y[:n_train])
        val_ds = PointDataset(X[n_train:n_train + n_val], y[n_train:n_train + n_val])
        test_ds = PointDataset(X[n_train + n_val:], y[n_train + n_val:])
        return train_ds, val_ds, test_ds, meta

    # ── 20 Newsgroups text embedding ──
    if dataset == "newsgroups_embed":
        X_tr, y_tr, X_te, y_te, meta = _load_newsgroups_embed(seed=cfg.seed)
        n_val = min(dc.n_val, len(X_tr) // 10) if dc.n_val > 0 else min(500, len(X_tr) // 5)
        perm = torch.randperm(len(X_tr), generator=torch.Generator().manual_seed(cfg.seed))
        X_tr, y_tr = X_tr[perm], y_tr[perm]
        X_val, y_val = X_tr[:n_val], y_tr[:n_val]
        X_tr, y_tr = X_tr[n_val:], y_tr[n_val:]
        if dc.n_train > 0 and dc.n_train < len(X_tr):
            X_tr, y_tr = X_tr[:dc.n_train], y_tr[:dc.n_train]
        if dc.n_test > 0 and dc.n_test < len(X_te):
            X_te, y_te = X_te[:dc.n_test], y_te[:dc.n_test]
        return PointDataset(X_tr, y_tr), PointDataset(X_val, y_val), PointDataset(X_te, y_te), meta

    # ── CIFAR-10 frozen PCA embedding ──
    if dataset in ("cifar10_pca", "cifar10_resnet18"):
        extractor_name = "pca_50" if dataset == "cifar10_pca" else "resnet18"
        from .cifar10_features import load_cifar10_features
        X_tr, y_tr, X_te, y_te, meta = load_cifar10_features(
            extractor_name=extractor_name, seed=cfg.seed,
        )
        n_val = min(dc.n_val, len(X_tr) // 10) if dc.n_val > 0 else 5000
        perm = torch.randperm(len(X_tr), generator=torch.Generator().manual_seed(cfg.seed))
        X_tr, y_tr = X_tr[perm], y_tr[perm]
        X_val, y_val = X_tr[:n_val], y_tr[:n_val]
        X_tr, y_tr = X_tr[n_val:], y_tr[n_val:]
        if dc.n_train > 0 and dc.n_train < len(X_tr):
            X_tr, y_tr = X_tr[:dc.n_train], y_tr[:dc.n_train]
        if dc.n_test > 0 and dc.n_test < len(X_te):
            X_te, y_te = X_te[:dc.n_test], y_te[:dc.n_test]
        return PointDataset(X_tr, y_tr), PointDataset(X_val, y_val), PointDataset(X_te, y_te), meta

    # ── Real image datasets ──
    if dataset in ("mnist", "fashion_mnist", "mnist_embed", "fmnist_embed"):
        fashion = (dataset in ("fashion_mnist", "fmnist_embed"))
        X_train, y_train = _load_mnist(train=True, fashion=fashion)
        X_test, y_test = _load_mnist(train=False, fashion=fashion)

        # For *_embed variants, apply PCA to reduce from 784 to 50 dims
        if dataset in ("mnist_embed", "fmnist_embed"):
            from sklearn.preprocessing import StandardScaler
            from sklearn.decomposition import PCA
            scaler = StandardScaler()
            X_np = scaler.fit_transform(X_train.detach().cpu().numpy())
            pca = PCA(n_components=50, random_state=cfg.seed)
            X_train = torch.tensor(pca.fit_transform(X_np), dtype=torch.float32)
            X_test = torch.tensor(pca.transform(scaler.transform(X_test.detach().cpu().numpy())),
                                  dtype=torch.float32)
        n_val = min(dc.n_val, len(X_train) // 10)
        perm = torch.randperm(len(X_train), generator=torch.Generator().manual_seed(cfg.seed))
        X_train, y_train = X_train[perm], y_train[perm]
        X_val, y_val = X_train[:n_val], y_train[:n_val]
        X_train, y_train = X_train[n_val:], y_train[n_val:]
        # Limit sizes if requested
        if dc.n_train > 0 and dc.n_train < len(X_train):
            X_train, y_train = X_train[:dc.n_train], y_train[:dc.n_train]
        if dc.n_test > 0 and dc.n_test < len(X_test):
            X_test, y_test = X_test[:dc.n_test], y_test[:dc.n_test]
        meta = {"n_classes": 10, "input_dim": X_train.shape[1],
                "dataset": dataset}
        train_ds = PointDataset(X_train, y_train)
        val_ds = PointDataset(X_val, y_val)
        test_ds = PointDataset(X_test, y_test)
        return train_ds, val_ds, test_ds, meta

    # ── Graph-native datasets (Cora, CiteSeer) ──
    if dataset in ("cora", "citeseer"):
        X_tr, y_tr, X_val, y_val, X_te, y_te, meta = _load_citation_graph(
            dataset, seed=cfg.seed)
        return PointDataset(X_tr, y_tr), PointDataset(X_val, y_val), PointDataset(X_te, y_te), meta

    # ── Sklearn geometry datasets ──
    if dataset.startswith("sk_"):
        total_n = dc.n_train + dc.n_val + dc.n_test
        X, y, region_id, meta = _load_sklearn_geometry(
            dataset, total_n, dc.noise_sigma, cfg.seed
        )
        n1 = dc.n_train
        n2 = dc.n_train + dc.n_val
        # Shuffle
        perm = torch.randperm(len(X), generator=torch.Generator().manual_seed(cfg.seed))
        X, y, region_id = X[perm], y[perm], region_id[perm]
        train_ds = PointDataset(X[:n1], y[:n1], region_id[:n1])
        val_ds = PointDataset(X[n1:n2], y[n1:n2], region_id[n1:n2])
        test_ds = PointDataset(X[n2:], y[n2:], region_id[n2:])
        return train_ds, val_ds, test_ds, meta

    # ── Synthetic datasets (original) ──
    total_n = dc.n_train + dc.n_val + dc.n_test
    common_kwargs = {
        "n": total_n,
        "noise_sigma": dc.noise_sigma,
        "seed": cfg.seed,
    }

    if dc.dataset == "piecewise2d":
        common_kwargs.update(grid_size=dc.grid_size, label_noise=dc.label_noise)
    elif dc.dataset == "spirals":
        common_kwargs.update(n_spirals=dc.n_spirals, label_noise=dc.label_noise)
    elif dc.dataset == "circles":
        common_kwargs.update(n_circles=dc.n_classes, label_noise=dc.label_noise)
    elif dc.dataset == "moons":
        common_kwargs.update(label_noise=dc.label_noise)
    elif dc.dataset == "swiss_roll":
        common_kwargs.update(background_frac=dc.background_frac)
    elif dc.dataset == "layered_periodic":
        common_kwargs.update(
            n_sources=dc.n_sources, d=dc.d,
            freq_range=dc.freq_range, phase_jitter=dc.phase_jitter,
        )
    elif dc.dataset == "blobs":
        common_kwargs.update(
            n_classes=dc.n_classes, d=dc.d, label_noise=dc.label_noise,
        )

    data = get_synthetic_dataset(dc.dataset, **common_kwargs)

    X, y, region_id = data["X"], data["y"], data["region_id"]
    meta = data["meta"]

    n1 = dc.n_train
    n2 = dc.n_train + dc.n_val

    train_ds = PointDataset(X[:n1], y[:n1], region_id[:n1])
    val_ds = PointDataset(X[n1:n2], y[n1:n2], region_id[n1:n2])
    test_ds = PointDataset(X[n2:], y[n2:], region_id[n2:])

    return train_ds, val_ds, test_ds, meta
