"""Plotting utilities for structural diagnostics and visualization."""
from __future__ import annotations

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.colors as mcolors
import numpy as np
import torch
from pathlib import Path
from typing import Dict, List, Optional, Any


def _save_fig(fig: plt.Figure, path: Path, dpi: int = 150):
    path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(path, dpi=dpi, bbox_inches="tight")
    plt.close(fig)


def plot_stability_curves(
    stability_data: Dict[str, Dict[float, float]],
    save_path: Path,
    title: str = "Assignment Stability vs Noise",
):
    """Plot assignment stability curves per scale.

    Args:
        stability_data: {scale_name: {sigma: mean_l1_distance}}
    """
    fig, ax = plt.subplots(figsize=(8, 5))
    for scale_name, curve in stability_data.items():
        sigmas = sorted(curve.keys())
        vals = [curve[s] for s in sigmas]
        ax.plot(sigmas, vals, marker="o", label=scale_name, linewidth=2)
    ax.set_xlabel("Noise σ")
    ax.set_ylabel("Mean Assignment L1 Distance")
    ax.set_title(title)
    ax.legend()
    ax.grid(True, alpha=0.3)
    _save_fig(fig, save_path)


def plot_region_usage(
    usage_per_scale: Dict[str, np.ndarray],
    save_path: Path,
    title: str = "Region Usage Distribution",
):
    """Plot region usage (bar/histogram) per scale."""
    n_scales = len(usage_per_scale)
    fig, axes = plt.subplots(1, n_scales, figsize=(5 * n_scales, 4))
    if n_scales == 1:
        axes = [axes]
    for ax, (scale_name, usage) in zip(axes, usage_per_scale.items()):
        m = len(usage)
        ax.bar(range(m), sorted(usage, reverse=True), alpha=0.7)
        ax.axhline(y=1.0 / m, color="r", linestyle="--", label=f"Uniform={1/m:.4f}")
        eff = np.exp(-np.sum(usage * np.log(usage + 1e-10)))
        ax.set_title(f"{scale_name}\nEff. regions: {eff:.1f}/{m}")
        ax.set_xlabel("Region (sorted)")
        ax.set_ylabel("Usage fraction")
        ax.legend(fontsize=8)
    fig.suptitle(title)
    fig.tight_layout()
    _save_fig(fig, save_path)


def plot_within_vs_between(
    within: List[float],
    between: List[float],
    scale_names: List[str],
    save_path: Path,
    metric_name: str = "Label Agreement",
):
    """Plot within-region vs between-region metric per scale."""
    fig, ax = plt.subplots(figsize=(8, 5))
    x = np.arange(len(scale_names))
    w = 0.35
    ax.bar(x - w / 2, within, w, label="Within-region", alpha=0.8)
    ax.bar(x + w / 2, between, w, label="Between-region", alpha=0.8)
    ax.set_xticks(x)
    ax.set_xticklabels(scale_names)
    ax.set_ylabel(metric_name)
    ax.set_title(f"Within vs Between Region {metric_name}")
    ax.legend()
    ax.grid(True, alpha=0.3, axis="y")
    _save_fig(fig, save_path)


def plot_boundary_visualization_2d(
    points: np.ndarray,
    assignments: np.ndarray,
    sites: Optional[np.ndarray],
    labels: Optional[np.ndarray],
    save_path: Path,
    title: str = "Learned Regions (2D)",
    gt_labels: Optional[np.ndarray] = None,
):
    """Scatter plot colored by hard region assignment, with optional ground truth."""
    n_plots = 1 + (1 if gt_labels is not None else 0) + (1 if labels is not None else 0)
    fig, axes = plt.subplots(1, n_plots, figsize=(6 * n_plots, 5))
    if n_plots == 1:
        axes = [axes]
    idx = 0

    # Learned regions
    ax = axes[idx]
    m = int(assignments.max()) + 1
    cmap = plt.cm.get_cmap("tab20", m)
    ax.scatter(points[:, 0], points[:, 1], c=assignments, cmap=cmap, s=3, alpha=0.6)
    if sites is not None:
        ax.scatter(sites[:, 0], sites[:, 1], c="red", marker="x", s=80, linewidths=2,
                   label="Sites", zorder=10)
    ax.set_title("Learned Regions")
    ax.legend(fontsize=8)
    idx += 1

    # True labels
    if labels is not None:
        ax = axes[idx]
        n_cls = int(labels.max()) + 1
        cmap2 = plt.cm.get_cmap("tab10", n_cls)
        ax.scatter(points[:, 0], points[:, 1], c=labels, cmap=cmap2, s=3, alpha=0.6)
        ax.set_title("True Labels")
        idx += 1

    # Ground truth regions
    if gt_labels is not None:
        ax = axes[idx]
        n_gt = int(gt_labels.max()) + 1
        cmap3 = plt.cm.get_cmap("tab20", n_gt)
        ax.scatter(points[:, 0], points[:, 1], c=gt_labels, cmap=cmap3, s=3, alpha=0.6)
        ax.set_title("Ground Truth Regions")
        idx += 1

    fig.suptitle(title)
    fig.tight_layout()
    _save_fig(fig, save_path)


def plot_laplacian_spectrum(
    eigenvalues: np.ndarray,
    save_path: Path,
    title: str = "Region Graph Laplacian Spectrum",
):
    """Plot eigenvalues of region graph Laplacian."""
    fig, axes = plt.subplots(1, 2, figsize=(12, 4))

    ax = axes[0]
    ax.plot(eigenvalues, marker=".", linewidth=1)
    ax.set_xlabel("Index")
    ax.set_ylabel("Eigenvalue")
    ax.set_title("Full Spectrum")
    ax.grid(True, alpha=0.3)

    ax = axes[1]
    n_show = min(20, len(eigenvalues))
    ax.bar(range(n_show), eigenvalues[:n_show], alpha=0.7)
    if n_show > 1:
        gap = eigenvalues[1] - eigenvalues[0]
        ax.set_title(f"First {n_show} eigenvalues (spectral gap={gap:.4f})")
    ax.set_xlabel("Index")
    ax.set_ylabel("Eigenvalue")
    ax.grid(True, alpha=0.3)

    fig.suptitle(title)
    fig.tight_layout()
    _save_fig(fig, save_path)


def plot_training_curves(
    train_log_path: Path,
    save_path: Path,
    keys: Optional[List[str]] = None,
):
    """Plot training curves from JSONL log."""
    import json
    records = []
    with open(train_log_path) as f:
        for line in f:
            records.append(json.loads(line))
    if not records:
        return

    all_keys = set()
    for r in records:
        all_keys.update(r.keys())
    all_keys.discard("step")
    all_keys.discard("timestamp")

    if keys is not None:
        plot_keys = [k for k in keys if k in all_keys]
    else:
        plot_keys = sorted(all_keys)

    if not plot_keys:
        return

    # Group by prefix
    groups: Dict[str, List[str]] = {}
    for k in plot_keys:
        prefix = k.split("/")[0] if "/" in k else "misc"
        groups.setdefault(prefix, []).append(k)

    n_groups = len(groups)
    fig, axes = plt.subplots(n_groups, 1, figsize=(10, 4 * n_groups))
    if n_groups == 1:
        axes = [axes]

    steps = [r["step"] for r in records]
    for ax, (prefix, keys_in_group) in zip(axes, groups.items()):
        for k in keys_in_group:
            vals = [r.get(k) for r in records]
            valid = [(s, v) for s, v in zip(steps, vals) if v is not None]
            if valid:
                ss, vv = zip(*valid)
                ax.plot(ss, vv, label=k.split("/")[-1] if "/" in k else k, linewidth=1)
        ax.set_title(prefix)
        ax.set_xlabel("Step")
        ax.legend(fontsize=7, ncol=2)
        ax.grid(True, alpha=0.3)

    fig.tight_layout()
    _save_fig(fig, save_path)


def plot_edge_weight_distribution(
    edge_weights: np.ndarray,
    save_path: Path,
    title: str = "Region Graph Edge Weights",
):
    """Histogram of edge weights."""
    fig, ax = plt.subplots(figsize=(8, 4))
    n = len(edge_weights)
    data_range = float(edge_weights.max() - edge_weights.min()) if n > 0 else 0
    if n < 2 or data_range < 1e-6:
        ax.text(0.5, 0.5, f"Near-constant (range={data_range:.2e})", transform=ax.transAxes, ha='center')
    else:
        n_bins = min(50, max(5, int(n ** 0.5)))
        try:
            ax.hist(edge_weights, bins=n_bins, alpha=0.7, edgecolor="black", linewidth=0.5)
        except Exception:
            ax.text(0.5, 0.5, "Histogram failed", transform=ax.transAxes, ha='center')
    ax.set_xlabel("Edge Weight")
    ax.set_ylabel("Count")
    ax.set_title(title)
    ax.axvline(edge_weights.mean(), color="r", linestyle="--",
               label=f"Mean={edge_weights.mean():.4f}")
    ax.legend()
    ax.grid(True, alpha=0.3)
    _save_fig(fig, save_path)


def plot_multiscale_assignments(
    points: np.ndarray,
    assignments_per_scale: Dict[str, np.ndarray],
    save_path: Path,
    title: str = "Multi-Scale Assignments",
):
    """Visualize hard assignments at each scale (2D only)."""
    n_scales = len(assignments_per_scale)
    fig, axes = plt.subplots(1, n_scales, figsize=(5 * n_scales, 4))
    if n_scales == 1:
        axes = [axes]
    for ax, (scale_name, asgn) in zip(axes, assignments_per_scale.items()):
        m = int(asgn.max()) + 1
        cmap = plt.cm.get_cmap("tab20", m)
        ax.scatter(points[:, 0], points[:, 1], c=asgn, cmap=cmap, s=3, alpha=0.6)
        ax.set_title(f"{scale_name} ({m} regions)")
    fig.suptitle(title)
    fig.tight_layout()
    _save_fig(fig, save_path)
