"""Noise perturbation and stability regularization.

Multi-sample perturbation consistency, boundary-weighted noise injection,
and flexible stability targets (clean, mean_perturbed, teacher).
"""
from __future__ import annotations

import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import List, Optional, Dict, Tuple
import math


def compute_noise_sigma(
    base_sigma: float,
    epoch: int,
    total_epochs: int,
    schedule: str = "constant",
    sigma_min: float = 0.0,
) -> float:
    """Compute effective sigma for current epoch."""
    if schedule == "constant":
        return base_sigma
    elif schedule == "linear_anneal":
        frac = epoch / max(total_epochs - 1, 1)
        return base_sigma * (1 - frac) + sigma_min * frac
    elif schedule == "cosine":
        frac = epoch / max(total_epochs - 1, 1)
        return sigma_min + (base_sigma - sigma_min) * 0.5 * (1 + math.cos(math.pi * frac))
    return base_sigma


def compute_boundary_score(
    w: torch.Tensor,
    mode: str = "entropy",
    detach: bool = True,
) -> torch.Tensor:
    """Per-point boundary score b_i in [0, 1] from assignments.

    Args:
        w: (B, m) soft assignments
        mode: "entropy" or "margin"
        detach: stop gradient through boundary score

    Returns:
        b: (B,) boundary scores in [0, 1]
    """
    if detach:
        w = w.detach()

    if mode == "entropy":
        # H_i normalized by max entropy log(m)
        eps = 1e-10
        H = -(w * (w + eps).log()).sum(dim=-1)
        H_max = math.log(w.shape[1])
        b = (H / H_max).clamp(0, 1)
    elif mode == "margin":
        # 1 - (top1 - top2)
        topk = w.topk(2, dim=-1).values
        margin = topk[:, 0] - topk[:, 1]
        b = (1 - margin).clamp(0, 1)
    else:
        b = torch.zeros(w.shape[0], device=w.device)

    return b


def compute_per_point_sigma(
    base_sigma: float,
    boundary_score: torch.Tensor,
    kappa: float,
) -> torch.Tensor:
    """Per-point sigma: σ_i = σ_0 * (1 + κ * b_i).

    Returns: (B, 1) for broadcasting with (B, d) inputs.
    """
    return (base_sigma * (1 + kappa * boundary_score)).unsqueeze(1)


def make_perturbations(
    x: torch.Tensor,
    sigma: float,
    M: int,
    per_point_sigma: Optional[torch.Tensor] = None,
    generator: Optional[torch.Generator] = None,
) -> List[torch.Tensor]:
    """Generate M perturbed copies of x.

    Args:
        x: (B, d) input
        sigma: scalar sigma (used if per_point_sigma is None)
        M: number of samples
        per_point_sigma: (B, 1) per-point sigma
        generator: for reproducibility

    Returns:
        list of M tensors, each (B, d)
    """
    perts = []
    for _ in range(M):
        noise = torch.randn(x.shape, device=x.device, dtype=x.dtype, generator=generator)
        if per_point_sigma is not None:
            perts.append(x + noise * per_point_sigma)
        else:
            perts.append(x + noise * sigma)
    return perts


class MultiSampleStabilityLoss(nn.Module):
    """Stability loss with multi-sample perturbation support.

    Targets:
      - clean: D(w_clean, w_pert_m) averaged over M samples
      - mean_perturbed: D(w_pert_m, w_bar) where w_bar = mean of perturbed
      - teacher_clean: D(w_teacher_clean, w_pert_m)
    """

    def __init__(self, divergence: str = "l1"):
        super().__init__()
        self.divergence = divergence

    def _div(self, w_target: torch.Tensor, w_pred: torch.Tensor) -> torch.Tensor:
        """Divergence between assignment vectors."""
        if self.divergence == "l1":
            return (w_target - w_pred).abs().sum(dim=-1).mean()
        elif self.divergence == "l2":
            return ((w_target - w_pred) ** 2).sum(dim=-1).mean()
        elif self.divergence == "kl":
            return F.kl_div(
                (w_pred + 1e-10).log(), w_target + 1e-10, reduction="batchmean"
            )
        raise ValueError(f"Unknown divergence: {self.divergence}")

    def forward(
        self,
        clean_assignments: List[torch.Tensor],
        pert_assignments_list: List[List[torch.Tensor]],
        scale_indices: List[int],
        target: str = "clean",
        teacher_assignments: Optional[List[torch.Tensor]] = None,
    ) -> Tuple[torch.Tensor, Dict[str, float]]:
        """
        Args:
            clean_assignments: L-list of (B, m) clean assignments
            pert_assignments_list: M-list of L-lists of (B, m) perturbed assignments
            scale_indices: which scales to penalize
            target: "clean" | "mean_perturbed" | "teacher_clean"
            teacher_assignments: L-list of (B, m) from EMA teacher (if target=teacher_*)

        Returns:
            (loss, info_dict)
        """
        M = len(pert_assignments_list)
        if M == 0 or len(scale_indices) == 0:
            dev = clean_assignments[0].device
            return torch.tensor(0.0, device=dev), {}

        total = torch.tensor(0.0, device=clean_assignments[0].device)
        drift_vals = []
        count = 0

        for l in scale_indices:
            if l >= len(clean_assignments):
                continue

            w_clean = clean_assignments[l].detach()
            w_perts = [pa[l] for pa in pert_assignments_list if l < len(pa)]

            if target == "clean":
                for w_p in w_perts:
                    d = self._div(w_clean, w_p)
                    total = total + d
                    drift_vals.append(d.item())
                    count += 1

            elif target == "mean_perturbed":
                w_bar = torch.stack([wp.detach() for wp in w_perts]).mean(dim=0)
                for w_p in w_perts:
                    d = self._div(w_bar, w_p)
                    total = total + d
                    drift_vals.append(d.item())
                    count += 1

            elif target == "teacher_clean" and teacher_assignments is not None:
                w_teacher = teacher_assignments[l].detach()
                for w_p in w_perts:
                    d = self._div(w_teacher, w_p)
                    total = total + d
                    drift_vals.append(d.item())
                    count += 1

            else:
                # Fallback to clean target
                for w_p in w_perts:
                    d = self._div(w_clean, w_p)
                    total = total + d
                    drift_vals.append(d.item())
                    count += 1

        loss = total / max(count, 1)
        info = {
            "drift_mean": sum(drift_vals) / max(len(drift_vals), 1),
        }
        return loss, info


class EMATeacher:
    """Exponential moving average of model parameters for stable targets."""

    def __init__(self, model: nn.Module, decay: float = 0.999):
        import copy
        self.teacher = copy.deepcopy(model)
        self.teacher.requires_grad_(False)
        self.teacher.eval()
        self.decay = decay
        self._step = 0

    def update(self, student: nn.Module):
        """Update teacher parameters: θ_t = decay * θ_t + (1-decay) * θ_s."""
        with torch.no_grad():
            for tp, sp in zip(self.teacher.parameters(), student.parameters()):
                tp.data.mul_(self.decay).add_(sp.data, alpha=1 - self.decay)
        self._step += 1

    @torch.no_grad()
    def get_assignments(
        self,
        x: torch.Tensor,
        epoch: int = 0,
    ) -> List[torch.Tensor]:
        """Get teacher's clean assignments."""
        self.teacher.eval()
        z = self.teacher.embed(x)
        part = self.teacher.partition(z, epoch=epoch)
        return part["assignments"]
