"""Reproducibility: deterministic threading + seeding.

Call enforce_reproducibility() at the top of every script entrypoint
BEFORE importing numpy/torch-heavy modules.
"""
import os
import random


def enforce_reproducibility(seed: int = 0):
    """Lock down all sources of non-determinism.

    Must be called BEFORE any heavy computation.
    Sets single-thread env vars, seeds all RNGs, configures torch.
    """
    # 1. Single-thread env vars (must be set before numpy/MKL init)
    for var in ("OMP_NUM_THREADS", "MKL_NUM_THREADS",
                "OPENBLAS_NUM_THREADS", "NUMEXPR_NUM_THREADS",
                "VECLIB_MAXIMUM_THREADS"):
        os.environ[var] = os.environ.get(var, "1")

    # 2. Python random
    random.seed(seed)

    # 3. Numpy
    import numpy as np
    np.random.seed(seed)

    # 4. Torch
    import torch
    torch.manual_seed(seed)
    torch.set_num_threads(1)
    try:
        torch.set_num_interop_threads(1)
    except RuntimeError:
        pass  # already set
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
        torch.backends.cudnn.deterministic = True
        torch.backends.cudnn.benchmark = False

    # 5. Print confirmation
    print(f"  [repro] OMP={os.environ.get('OMP_NUM_THREADS')} "
          f"MKL={os.environ.get('MKL_NUM_THREADS')} "
          f"torch_threads={torch.get_num_threads()} seed={seed}",
          flush=True)
