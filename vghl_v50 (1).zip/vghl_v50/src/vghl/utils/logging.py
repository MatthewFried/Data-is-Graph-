"""Logging utilities: Python logger, JSONL metrics, TensorBoard."""
from __future__ import annotations

import json
import logging
import sys
import time
from pathlib import Path
from typing import Any, Dict, Optional

import torch


def get_logger(name: str, level: int = logging.INFO) -> logging.Logger:
    """Get a configured logger."""
    logger = logging.getLogger(name)
    if not logger.handlers:
        logger.setLevel(level)
        handler = logging.StreamHandler(sys.stdout)
        handler.setLevel(level)
        fmt = logging.Formatter(
            "[%(asctime)s %(name)s %(levelname)s] %(message)s",
            datefmt="%Y-%m-%d %H:%M:%S",
        )
        handler.setFormatter(fmt)
        logger.addHandler(handler)
    return logger


class MetricsLogger:
    """Logs metrics to JSONL file and optionally TensorBoard."""

    def __init__(self, log_dir: str | Path, use_tensorboard: bool = True):
        self.log_dir = Path(log_dir)
        self.log_dir.mkdir(parents=True, exist_ok=True)
        self.jsonl_path = self.log_dir / "train_log.jsonl"
        self.jsonl_file = open(self.jsonl_path, "w")
        self.tb_writer = None
        if use_tensorboard:
            try:
                from torch.utils.tensorboard import SummaryWriter
                self.tb_writer = SummaryWriter(log_dir=str(self.log_dir / "tb"))
            except ImportError:
                pass
        self._step = 0

    def log(
        self,
        metrics: Dict[str, Any],
        step: Optional[int] = None,
        prefix: str = "",
    ):
        """Log a dict of metrics."""
        if step is not None:
            self._step = step
        else:
            self._step += 1

        record = {"step": self._step, "timestamp": time.time()}
        for k, v in metrics.items():
            key = f"{prefix}/{k}" if prefix else k
            if isinstance(v, torch.Tensor):
                v = v.item()
            record[key] = v
            if self.tb_writer is not None:
                self.tb_writer.add_scalar(key, v, self._step)

        self.jsonl_file.write(json.dumps(record) + "\n")
        self.jsonl_file.flush()

    def log_histogram(self, tag: str, values: torch.Tensor, step: Optional[int] = None):
        """Log histogram to TensorBoard."""
        s = step if step is not None else self._step
        if self.tb_writer is not None:
            self.tb_writer.add_histogram(tag, values, s)

    def close(self):
        self.jsonl_file.close()
        if self.tb_writer is not None:
            self.tb_writer.close()
