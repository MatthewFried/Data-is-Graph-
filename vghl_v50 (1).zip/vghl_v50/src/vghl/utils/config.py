"""Experiment configuration dataclass with YAML serialization — v2.

Adds: PointGraphConfig, BoundaryConfig, perf flags (AMP, accum, compile),
      graph_refresh implementation hooks, artifact saving.
"""
from __future__ import annotations

import copy
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import List, Optional

import yaml


@dataclass
class DataConfig:
    dataset: str = "piecewise2d"
    n_train: int = 10000
    n_val: int = 2000
    n_test: int = 2000
    d: int = 2
    noise_sigma: float = 0.05
    label_noise: float = 0.0
    n_classes: int = 4
    n_spirals: int = 2
    grid_size: int = 2
    n_manifolds: int = 2
    manifold_noise: float = 0.1
    background_frac: float = 0.1
    n_sources: int = 2
    freq_range: tuple = (1.0, 3.0)
    phase_jitter: float = 0.3


@dataclass
class EmbedConfig:
    mode: str = "identity"  # identity | mlp
    hidden_sizes: List[int] = field(default_factory=lambda: [64, 64])
    embed_dim: int = 32
    dropout: float = 0.0
    activation: str = "relu"


@dataclass
class PartitionConfig:
    m: int = 64
    L: int = 3
    temps: List[float] = field(default_factory=lambda: [1.0, 0.3, 0.1])
    temp_mode: str = "fixed"  # fixed | learnable | anneal
    temp_anneal_start: float = 2.0
    temp_anneal_end: float = 0.1
    temp_anneal_epochs: int = 100
    distance: str = "euclidean"  # euclidean | mahalanobis_diag | mahalanobis_lowrank
    mahalanobis_rank: int = 4
    init_sites: str = "farthest_point"  # farthest_point | kmeans | random


@dataclass
class PointGraphConfig:
    """Point-level graph: kNN among points in embedding space."""
    enabled: bool = True
    k: int = 16              # kNN neighbors
    layers: int = 2          # point-level MP layers
    type: str = "gcn"        # gcn | sage | gat
    dropout: float = 0.0
    residual: bool = True
    # Boundary-aware edge modulation
    modulate_edges: bool = True  # multiply edge weights by boundary/interior signal


@dataclass
class BoundaryConfig:
    """Boundary detection and handling."""
    mode: str = "entropy"       # none | entropy | margin
    threshold: float = 0.5      # points above this (entropy) or below (margin) are boundary
    frac: float = 0.0           # if >0, top frac% of points by entropy/margin are boundary
    # Boundary loss
    lambda_boundary: float = 0.1
    boundary_loss: str = "consistency"  # consistency | contrastive | laplacian
    # Edge modulation strengths
    interior_interior_weight: float = 1.0
    boundary_boundary_weight: float = 2.0
    boundary_interior_weight: float = 0.5


@dataclass
class RegionGraphConfig:
    method: str = "coact"  # coact | site_knn | both | soft_kernel
    K: int = 8
    sigma: float = 1.0
    graph_refresh: str = "batch"  # batch | epoch | steps:N
    symmetrize: bool = True
    pool_mode: str = "soft"  # soft | top1 | topk
    pool_topk: int = 3
    min_degree: int = 0       # minimum degree per active region (0=off)
    edge_threshold: float = 0.0  # minimum edge weight to keep


@dataclass
class GNNConfig:
    """Region-level GNN config."""
    type: str = "gcn"  # gcn | sage | gat
    layers: int = 1
    hidden_dim: Optional[int] = None
    dropout: float = 0.0
    residual: bool = True
    edge_mask: bool = False
    gat_heads: int = 4
    # Consensus gate: attenuate edges by label agreement
    consensus_gate: bool = False  # if True, gate = exp(-tau * disagreement)
    consensus_tau: float = 5.0    # steepness of gate


@dataclass
class HeadConfig:
    hidden_sizes: List[int] = field(default_factory=lambda: [128, 64])
    dropout: float = 0.1
    task: str = "classification"  # classification | regression


@dataclass
class ConfidenceConfig:
    """Per-point confidence weighting for noise suppression."""
    mode: str = "none"              # none | entropy | drift | entropy+drift
    scales: str = "0"               # which scales to compute alpha on
    beta_entropy: float = 1.0
    beta_drift: float = 1.0
    alpha_min: float = 0.2
    detach: bool = False
    warmup_epochs: int = 5
    apply_pooling: bool = True
    apply_pullback: bool = False
    apply_task_loss: bool = True
    task_scale: int = 0
    report_unweighted_task: bool = True  # always log unweighted task loss too


@dataclass
class NoiseConfig:
    """Input perturbation configuration for stability regularization."""
    enabled: bool = False
    sigma: float = 0.10
    schedule: str = "constant"      # constant | linear_anneal | cosine
    sigma_min: float = 0.0
    samples: int = 1                # M: number of perturbations per batch
    per_point_mode: str = "global"  # global | boundary_weighted
    boundary_kappa: float = 0.0     # κ for boundary-weighted: σ_i = σ*(1+κ*b_i)
    boundary_source: str = "entropy"  # entropy | margin
    detach_boundary: bool = True
    sigma_boundary_cap: float = 0.0  # if >0, clamp per-point sigma to this max
    kappa_warmup_epochs: int = 0     # ramp kappa from 0 over this many epochs
    sigma_warmup_epochs: int = 0     # ramp sigma from 0 over this many epochs
    # Boundary mask mode for splitting boundary/interior
    boundary_mask_mode: str = "quantile"  # threshold | quantile | topk
    boundary_quantile: float = 0.8        # top 20% are boundary (q=0.8)
    boundary_topk_frac: float = 0.2       # fraction for topk mode


@dataclass
class StabilityConfig:
    """Stability loss configuration."""
    enabled: bool = False
    target: str = "clean"           # clean | mean_perturbed | teacher_clean
    divergence: str = "l1"          # l1 | l2 | kl
    scales: str = "0"
    weight: float = 1.0
    average_over_samples: bool = True
    warmup_epochs: int = 0          # ramp weight from 0 over this many epochs


@dataclass
class EMATeacherConfig:
    """EMA teacher for stability targets."""
    enabled: bool = False
    decay: float = 0.999
    update_every: int = 1           # steps
    start_epoch: int = 0


@dataclass
class LossConfig:
    task_weight: float = 1.0
    lambda_balance: float = 1.0
    balance_scales: str = "all"
    lambda_stab: float = 1.0
    stab_scales: str = "0"
    stab_noise_sigma: float = 0.05
    stab_norm: str = "l1"  # l1 | l2 | kl
    lambda_ent: float = 0.01
    ent_scales: str = "0"
    lambda_smooth: float = 0.0
    lambda_cut: float = 0.0
    lambda_edge_l1: float = 0.0
    lambda_within_label: float = 0.0
    # Anti-uniform assignment regularizers
    lambda_assign_entropy: float = 0.0
    lambda_assign_sharp: float = 0.0
    # Geometry regularizers
    lambda_conn: float = 0.0        # connectivity: penalize low lambda_2
    conn_epsilon: float = 0.01      # target minimum lambda_2
    lambda_lap_smooth: float = 0.0  # Laplacian smoothness on region embeddings
    # Boundary loss (uses BoundaryConfig.lambda_boundary)


@dataclass
class TrainConfig:
    epochs: int = 200
    batch_size: int = 512
    lr: float = 1e-3
    weight_decay: float = 1e-4
    optimizer: str = "adam"  # adam | adamw | sgd
    scheduler: str = "cosine"  # none | cosine | step | plateau
    scheduler_step_size: int = 50
    scheduler_gamma: float = 0.5
    scheduler_patience: int = 20
    warmup_epochs: int = 5
    grad_clip: float = 1.0
    early_stop_patience: int = 50
    early_stop_metric: str = "val_loss"
    early_stop_mode: str = "min"
    # Performance
    amp: bool = False
    accum_steps: int = 1
    torch_compile: bool = False
    benchmark_cudnn: bool = True
    pin_memory: bool = True


@dataclass
class LogConfig:
    log_every: int = 1
    tensorboard: bool = True
    save_plots: bool = True
    plot_every: int = 10
    save_checkpoints: bool = True
    verbose: bool = True
    save_artifacts: bool = True   # sites, temps, edge masks, adj snapshots
    save_every: int = 50          # artifact save frequency (epochs)


@dataclass
class ExperimentConfig:
    name: str = "default"
    seed: int = 0
    out_dir: str = "outputs"
    device: str = "auto"
    num_workers: int = 0

    data: DataConfig = field(default_factory=DataConfig)
    embed: EmbedConfig = field(default_factory=EmbedConfig)
    partition: PartitionConfig = field(default_factory=PartitionConfig)
    point_graph: PointGraphConfig = field(default_factory=PointGraphConfig)
    boundary: BoundaryConfig = field(default_factory=BoundaryConfig)
    region_graph: RegionGraphConfig = field(default_factory=RegionGraphConfig)
    gnn: GNNConfig = field(default_factory=GNNConfig)
    head: HeadConfig = field(default_factory=HeadConfig)
    confidence: ConfidenceConfig = field(default_factory=ConfidenceConfig)
    noise: NoiseConfig = field(default_factory=NoiseConfig)
    stability: StabilityConfig = field(default_factory=StabilityConfig)
    ema_teacher: EMATeacherConfig = field(default_factory=EMATeacherConfig)
    loss: LossConfig = field(default_factory=LossConfig)
    train: TrainConfig = field(default_factory=TrainConfig)
    log: LogConfig = field(default_factory=LogConfig)

    def resolve_device(self) -> str:
        import torch
        if self.device == "auto":
            return "cuda" if torch.cuda.is_available() else "cpu"
        return self.device

    @property
    def run_dir(self) -> Path:
        return Path(self.out_dir) / self.name

    def save(self, path: Optional[str] = None):
        if path is None:
            path = self.run_dir / "config.yaml"
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        with open(path, "w") as f:
            yaml.dump(asdict(self), f, default_flow_style=False, sort_keys=False)

    @classmethod
    def load(cls, path: str) -> "ExperimentConfig":
        with open(path) as f:
            d = yaml.safe_load(f)
        return cls._from_dict(d)

    @classmethod
    def _from_dict(cls, d: dict) -> "ExperimentConfig":
        cfg = cls()
        _nested_fields = {
            "data": DataConfig, "embed": EmbedConfig,
            "partition": PartitionConfig, "point_graph": PointGraphConfig,
            "boundary": BoundaryConfig, "region_graph": RegionGraphConfig,
            "gnn": GNNConfig, "head": HeadConfig, "confidence": ConfidenceConfig,
            "noise": NoiseConfig, "stability": StabilityConfig,
            "ema_teacher": EMATeacherConfig,
            "loss": LossConfig, "train": TrainConfig, "log": LogConfig,
        }
        for key, val in d.items():
            if key in _nested_fields and isinstance(val, dict):
                sub_cfg = _nested_fields[key]()
                for sk, sv in val.items():
                    if hasattr(sub_cfg, sk):
                        current = getattr(sub_cfg, sk)
                        if isinstance(current, tuple) and isinstance(sv, list):
                            sv = tuple(sv)
                        setattr(sub_cfg, sk, sv)
                setattr(cfg, key, sub_cfg)
            elif hasattr(cfg, key):
                setattr(cfg, key, val)
        return cfg

    def to_dict(self) -> dict:
        return asdict(self)

    def parse_scale_list(self, spec: str) -> List[int]:
        if spec == "all":
            return list(range(self.partition.L))
        elif spec == "coarse":
            return [0]
        elif spec == "fine":
            return [self.partition.L - 1]
        else:
            return [int(x.strip()) for x in spec.split(",")]

    def copy(self) -> "ExperimentConfig":
        return copy.deepcopy(self)
