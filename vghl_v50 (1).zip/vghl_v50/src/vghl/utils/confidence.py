"""Per-point confidence weighting for noise suppression.

Computes alpha_i in (0, 1] from assignment entropy and/or drift under
perturbation. High entropy / high drift → low confidence → reduced influence
in pooling, task loss, and optionally pullback.
"""
from __future__ import annotations

import torch
import torch.nn.functional as F
from typing import Optional, Dict, List


def compute_confidence(
    w: torch.Tensor,
    w_perts: Optional[List[torch.Tensor]] = None,
    beta_entropy: float = 1.0,
    beta_drift: float = 1.0,
    alpha_min: float = 0.2,
    eps: float = 1e-10,
    detach: bool = False,
) -> Dict[str, torch.Tensor]:
    """Compute per-point confidence weight from assignments.

    Args:
        w: (B, m) clean soft assignments
        w_perts: list of (B, m) perturbed assignments (for drift, can be multi-sample)
        beta_entropy: sensitivity of entropy → alpha
        beta_drift: sensitivity of drift → alpha
        alpha_min: floor on confidence
        eps: numerical epsilon
        detach: if True, stop gradient through alpha

    Returns:
        dict with alpha (B,), entropy (B,), drift (B,)
    """
    B, m = w.shape

    # Entropy: H_i = -sum_k w_ik log(w_ik)
    entropy = -(w * (w + eps).log()).sum(dim=-1)

    # Drift: mean L1 over perturbation samples
    if w_perts is not None and len(w_perts) > 0:
        drifts = [(w.detach() - wp).abs().sum(dim=-1) for wp in w_perts]
        drift = torch.stack(drifts).mean(dim=0)
    else:
        drift = torch.zeros(B, device=w.device)

    # Alpha = exp(-beta_H * H - beta_D * D)
    log_alpha = -beta_entropy * entropy - beta_drift * drift
    alpha = log_alpha.exp().clamp(min=alpha_min, max=1.0)

    if detach:
        alpha = alpha.detach()

    return {"alpha": alpha, "entropy": entropy, "drift": drift}
