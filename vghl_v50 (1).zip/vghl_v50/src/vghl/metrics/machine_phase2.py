"""Phase-2 Machine Metrics: per-level, cross-level, and hierarchy diagnostics.

Logs:
  - Per level: N, E, degree stats, components, giant component fraction
  - Cross level: supernode size distribution, port count distribution
  - Compression curves: nodes/edges at each level
  - Stability: parent assignment consistency
"""
from __future__ import annotations

import torch
import numpy as np
from typing import Dict, List
from ..models.recursion import LevelGraph


def compute_phase2_metrics(
    levels: List[LevelGraph],
    primitives_by_level: List[list] = None,
) -> Dict[str, float]:
    """Compute comprehensive Phase-2 hierarchy metrics.

    Args:
        levels: list of LevelGraph objects.
        primitives_by_level: optional list of primitive lists per level.

    Returns:
        Dict of metric name → value.
    """
    metrics = {}
    metrics["n_levels"] = len(levels)

    for lv_idx, lv in enumerate(levels):
        prefix = f"level{lv_idx}"
        N = lv.n_nodes
        E = lv.edge_index.shape[1] if lv.edge_index is not None else 0

        metrics[f"{prefix}/n_nodes"] = N
        metrics[f"{prefix}/n_edges"] = E
        metrics[f"{prefix}/density"] = E / max(N * (N - 1), 1)

        if E > 0 and N > 0:
            device = lv.edge_index.device
            degree = torch.zeros(N, device=device)
            degree.scatter_add_(0, lv.edge_index[0], torch.ones(E, device=device))
            metrics[f"{prefix}/deg_mean"] = degree.mean().item()
            metrics[f"{prefix}/deg_std"] = degree.std().item()
            metrics[f"{prefix}/deg_max"] = degree.max().item()
            metrics[f"{prefix}/isolated"] = int((degree == 0).sum().item())

        # Edge weight stats
        if E > 0:
            ew = lv.edge_weight
            metrics[f"{prefix}/weight_mean"] = ew.mean().item()
            metrics[f"{prefix}/weight_std"] = ew.std().item() if E > 1 else 0.0

    # Cross-level metrics
    if len(levels) > 1:
        for lv_idx in range(1, len(levels)):
            lv = levels[lv_idx]
            prefix = f"cross_level{lv_idx - 1}_{lv_idx}"

            # Supernode size distribution
            membership = lv.membership
            N_child = membership.shape[0]
            sizes = torch.bincount(membership, minlength=lv.n_nodes).float()
            metrics[f"{prefix}/supernode_size_mean"] = sizes.mean().item()
            metrics[f"{prefix}/supernode_size_std"] = sizes.std().item()
            metrics[f"{prefix}/supernode_size_max"] = sizes.max().item()
            metrics[f"{prefix}/singletons"] = int((sizes == 1).sum().item())
            metrics[f"{prefix}/compression_ratio"] = lv.n_nodes / max(N_child, 1)

            # Port count distribution
            if lv.ports is not None:
                valid_ports = (lv.ports >= 0).sum(dim=1).float()
                metrics[f"{prefix}/ports_per_node_mean"] = valid_ports.mean().item()
                metrics[f"{prefix}/ports_per_node_max"] = valid_ports.max().item()

    # Compression curve
    node_counts = [lv.n_nodes for lv in levels]
    edge_counts = [lv.edge_index.shape[1] for lv in levels]
    metrics["compression/node_counts"] = str(node_counts)
    metrics["compression/edge_counts"] = str(edge_counts)
    if len(node_counts) > 1:
        metrics["compression/total_ratio"] = node_counts[-1] / max(node_counts[0], 1)

    return metrics
