"""Structural evaluation metrics for VGHL.

Measures partition quality, stability, coherence, and graph structure.
"""
from __future__ import annotations

import torch
import torch.nn.functional as F
import numpy as np
from typing import Dict, List, Any, Optional


@torch.no_grad()
def compute_assignment_stability_curve(
    model,
    X: torch.Tensor,
    sigma_values: List[float],
    device: str = "cpu",
    n_samples: int = 5000,
) -> Dict[str, Dict[float, float]]:
    """Compute assignment stability vs noise level per scale.

    Returns:
        {f"scale_{l}": {sigma: mean_l1_distance}} for each scale
    """
    model.eval()
    X = X[:n_samples].to(device)

    # Clean assignments
    z_clean = model.embed(X)
    part_clean = model.partition(z_clean)
    clean_asgn = part_clean["assignments"]

    results = {}
    for l in range(len(clean_asgn)):
        scale_key = f"scale_{l}"
        results[scale_key] = {}
        w_clean = clean_asgn[l]

        for sigma in sigma_values:
            noise = torch.randn_like(X) * sigma
            z_pert = model.embed(X + noise)
            part_pert = model.partition(z_pert)
            w_pert = part_pert["assignments"][l]

            l1_dist = (w_clean - w_pert).abs().sum(dim=-1).mean().item()
            results[scale_key][sigma] = l1_dist

    return results


@torch.no_grad()
def compute_region_usage(
    assignments: List[torch.Tensor],
) -> Dict[str, np.ndarray]:
    """Compute region usage distribution per scale.

    Returns:
        {f"scale_{l}": usage_array} where usage is normalized to sum to 1
    """
    results = {}
    for l, w in enumerate(assignments):
        p = w.mean(dim=0).detach().cpu().numpy()  # (m,)
        results[f"scale_{l}"] = p
    return results


@torch.no_grad()
def compute_effective_regions(assignments: List[torch.Tensor]) -> Dict[str, float]:
    """Effective number of regions per scale (exp of entropy)."""
    results = {}
    for l, w in enumerate(assignments):
        p = w.mean(dim=0)  # (m,)
        p = p / p.sum()
        ent = -(p * (p + 1e-10).log()).sum().item()
        results[f"scale_{l}"] = np.exp(ent)
    return results


@torch.no_grad()
def compute_within_between_label_agreement(
    assignments: List[torch.Tensor],
    labels: torch.Tensor,
    region_graphs: List[Dict[str, torch.Tensor]],
    n_classes: int,
) -> Dict[str, Dict[str, float]]:
    """Compute within-region vs between-region label agreement.

    Returns:
        {f"scale_{l}": {"within": float, "between": float}}
    """
    y_oh = F.one_hot(labels, n_classes).float()  # (B, C)
    results = {}

    for l, (w, graph) in enumerate(zip(assignments, region_graphs)):
        m = w.shape[1]
        mass = w.sum(dim=0).clamp(min=1e-8)  # (m,)

        # Region label distribution
        label_dist = (w.t() @ y_oh) / mass.unsqueeze(1)  # (m, C)

        # Within-region: average "purity" (max class probability per region)
        purity = label_dist.max(dim=1).values  # (m,)
        within = (purity * mass / mass.sum()).sum().item()

        # Between-region: for adjacent regions, compute agreement
        adj = graph["adj_dense"]
        if adj.sum() > 0:
            # Cosine similarity between adjacent region label distributions
            norm_dist = F.normalize(label_dist, dim=1)
            sim = norm_dist @ norm_dist.t()  # (m, m)
            between = (adj * sim).sum().item() / adj.sum().item()
        else:
            between = 0.0

        results[f"scale_{l}"] = {"within": within, "between": between}

    return results


@torch.no_grad()
def compute_graph_sparsity(
    region_graphs: List[Dict[str, torch.Tensor]],
) -> Dict[str, Dict[str, float]]:
    """Compute graph sparsity statistics per scale."""
    results = {}
    for l, graph in enumerate(region_graphs):
        adj = graph["adj_dense"]
        m = adj.shape[0]
        n_edges = (adj > 0).sum().item()
        max_edges = m * (m - 1)
        edge_weights = adj[adj > 0]

        stats = {
            "n_edges": n_edges,
            "density": n_edges / max(max_edges, 1),
            "mean_weight": edge_weights.mean().item() if edge_weights.numel() > 0 else 0,
            "std_weight": edge_weights.std().item() if edge_weights.numel() > 1 else 0,
        }
        results[f"scale_{l}"] = stats

    return results


@torch.no_grad()
def compute_cross_boundary_contrast(
    assignments: List[torch.Tensor],
    X: torch.Tensor,
    region_graphs: List[Dict[str, torch.Tensor]],
) -> Dict[str, float]:
    """Compute within-region vs across-region feature similarity.

    Measures whether regions group similar points together.
    """
    results = {}
    for l, (w, graph) in enumerate(zip(assignments, region_graphs)):
        hard = w.argmax(dim=-1)  # (B,)
        m = w.shape[1]

        # Within-region: average pairwise distance within each region
        within_dists = []
        for k in range(m):
            mask = hard == k
            if mask.sum() > 1:
                pts = X[mask]
                # Sample for efficiency
                if pts.shape[0] > 200:
                    idx = torch.randperm(pts.shape[0])[:200]
                    pts = pts[idx]
                dists = torch.cdist(pts.unsqueeze(0), pts.unsqueeze(0)).squeeze(0)
                # Upper triangle
                triu = dists[torch.triu_indices(pts.shape[0], pts.shape[0], offset=1).unbind()]
                if triu.numel() > 0:
                    within_dists.append(triu.mean().item())

        # Between adjacent regions
        adj = graph["adj_dense"]
        between_dists = []
        edges = (adj > 0).nonzero(as_tuple=False)
        for e in edges[:50]:  # limit for speed
            k1, k2 = e[0].item(), e[1].item()
            mask1 = hard == k1
            mask2 = hard == k2
            if mask1.sum() > 0 and mask2.sum() > 0:
                pts1 = X[mask1][:100]
                pts2 = X[mask2][:100]
                dists = torch.cdist(pts1.unsqueeze(0), pts2.unsqueeze(0)).squeeze(0)
                between_dists.append(dists.mean().item())

        within_mean = np.mean(within_dists) if within_dists else 0.0
        between_mean = np.mean(between_dists) if between_dists else 0.0
        contrast = between_mean - within_mean if (within_dists and between_dists) else 0.0

        results[f"scale_{l}"] = contrast

    return results


@torch.no_grad()
def compute_all_structural_metrics(
    model,
    output: Dict[str, Any],
    X: torch.Tensor,
    y: torch.Tensor,
    n_classes: int,
    device: str = "cpu",
    sigma_values: Optional[List[float]] = None,
) -> Dict[str, Any]:
    """Compute all structural metrics in one call.

    Args:
        model: trained model
        output: model forward output (with assignments, region_graphs)
        X: input features
        y: labels
        n_classes: number of classes
        device: device
        sigma_values: noise levels for stability curve

    Returns:
        comprehensive dict of all structural metrics
    """
    if sigma_values is None:
        sigma_values = [0.0, 0.01, 0.02, 0.05, 0.1, 0.2, 0.5]

    assignments = output.get("assignments", [])
    region_graphs = output.get("region_graphs", [])

    if not assignments:
        return {"note": "No assignments available (baseline model)"}

    results = {}

    # Stability curves
    if hasattr(model, "embed") and hasattr(model, "partition"):
        results["stability_curves"] = compute_assignment_stability_curve(
            model, X, sigma_values, device
        )

    # Region usage
    results["region_usage"] = compute_region_usage(assignments)
    results["effective_regions"] = compute_effective_regions(assignments)

    # Within vs between
    results["label_agreement"] = compute_within_between_label_agreement(
        assignments, y, region_graphs, n_classes
    )

    # Graph sparsity
    results["graph_sparsity"] = compute_graph_sparsity(region_graphs)

    # Cross-boundary contrast
    results["boundary_contrast"] = compute_cross_boundary_contrast(
        assignments, X, region_graphs
    )

    # Boundary-specific metrics
    if "is_boundary" in output:
        results["boundary"] = compute_boundary_metrics(
            output["is_boundary"], output["boundary_score"],
            output["hard_assignments"][0], y,
        )

    return results


@torch.no_grad()
def compute_boundary_f1(
    is_boundary_pred: torch.Tensor,
    X: torch.Tensor,
    region_id: torch.Tensor,
    threshold_dist: float = 0.05,
) -> Dict[str, float]:
    """Compute boundary F1: compare predicted boundary points to true boundaries.

    True boundary points are those whose ground-truth region_id differs from
    at least one of their spatial k-nearest neighbors.
    """
    from .task_metrics import compute_task_metrics
    B = X.shape[0]
    k = min(10, B - 1)

    # Find kNN among points in input space
    if B <= 4096:
        dists = torch.cdist(X.unsqueeze(0), X.unsqueeze(0)).squeeze(0)
        _, topk_idx = dists.topk(k + 1, dim=1, largest=False)
        topk_idx = topk_idx[:, 1:]
    else:
        topk_idx_list = []
        for i in range(0, B, 2048):
            d = torch.cdist(X[i:i+2048].unsqueeze(0), X.unsqueeze(0)).squeeze(0)
            _, tk = d.topk(k + 1, dim=1, largest=False)
            topk_idx_list.append(tk[:, 1:])
        topk_idx = torch.cat(topk_idx_list, dim=0)

    # True boundary = point whose region_id differs from any neighbor
    neighbor_rids = region_id[topk_idx]  # (B, k)
    my_rid = region_id.unsqueeze(1).expand_as(neighbor_rids)
    is_true_boundary = (neighbor_rids != my_rid).any(dim=1)  # (B,)

    # Compute precision, recall, F1
    tp = (is_boundary_pred & is_true_boundary).sum().float()
    fp = (is_boundary_pred & ~is_true_boundary).sum().float()
    fn = (~is_boundary_pred & is_true_boundary).sum().float()

    precision = (tp / (tp + fp + 1e-8)).item()
    recall = (tp / (tp + fn + 1e-8)).item()
    f1 = (2 * precision * recall / (precision + recall + 1e-8))

    return {
        "boundary_f1": f1,
        "boundary_precision": precision,
        "boundary_recall": recall,
        "n_true_boundary": is_true_boundary.sum().item(),
        "n_pred_boundary": is_boundary_pred.sum().item(),
    }


@torch.no_grad()
def compute_boundary_metrics(
    is_boundary: torch.Tensor,
    boundary_score: torch.Tensor,
    hard_assignments: torch.Tensor,
    labels: torch.Tensor,
) -> Dict[str, Any]:
    """Boundary-specific evaluation metrics.

    Returns:
        - boundary_frac: fraction of points classified as boundary
        - boundary_label_entropy: label entropy among boundary points (higher = more mixed)
        - interior_label_entropy: label entropy among interior points (lower = purer)
        - boundary_assignment_stability: are boundary points at region borders?
    """
    n = len(is_boundary)
    n_boundary = is_boundary.sum().item()

    results = {
        "boundary_frac": n_boundary / max(n, 1),
        "n_boundary": int(n_boundary),
    }

    if n_boundary > 0 and n_boundary < n:
        # Label entropy for boundary vs interior
        for name, mask in [("boundary", is_boundary), ("interior", ~is_boundary)]:
            sub_labels = labels[mask].cpu()
            if len(sub_labels) > 0:
                counts = torch.bincount(sub_labels, minlength=labels.max().item() + 1).float()
                probs = counts / counts.sum()
                ent = -(probs * (probs + 1e-10).log()).sum().item()
                results[f"{name}_label_entropy"] = ent

        # Mean boundary score
        results["mean_boundary_score"] = boundary_score[is_boundary].mean().item()
        results["mean_interior_score"] = boundary_score[~is_boundary].mean().item()

    return results
