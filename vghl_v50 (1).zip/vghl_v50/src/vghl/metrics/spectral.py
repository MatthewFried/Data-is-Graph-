"""Spectral diagnostics for region graph Laplacian."""
from __future__ import annotations

import torch
import numpy as np
from typing import Dict, Optional


@torch.no_grad()
def compute_laplacian_spectrum(
    adj: torch.Tensor,
    normalized: bool = True,
) -> Dict[str, np.ndarray]:
    """Compute eigenvalues of the graph Laplacian.

    Args:
        adj: (m, m) adjacency matrix
        normalized: if True, use normalized Laplacian

    Returns:
        dict with 'eigenvalues', 'spectral_gap', 'algebraic_connectivity'
    """
    adj_np = adj.detach().cpu().numpy()
    m = adj_np.shape[0]

    # Degree matrix
    deg = adj_np.sum(axis=1)

    if normalized:
        # L_norm = I - D^{-1/2} A D^{-1/2}
        deg_inv_sqrt = np.where(deg > 0, 1.0 / np.sqrt(deg), 0.0)
        D_inv_sqrt = np.diag(deg_inv_sqrt)
        L = np.eye(m) - D_inv_sqrt @ adj_np @ D_inv_sqrt
    else:
        L = np.diag(deg) - adj_np

    # Eigendecomposition
    eigenvalues = np.linalg.eigvalsh(L)
    eigenvalues = np.sort(eigenvalues)
    # Clamp tiny negative values from numerical noise
    eigenvalues = np.maximum(eigenvalues, 0.0)

    # Spectral gap: lambda_2 - lambda_1
    spectral_gap = eigenvalues[1] - eigenvalues[0] if m > 1 else 0.0

    # Algebraic connectivity = lambda_2 (Fiedler value)
    algebraic_connectivity = eigenvalues[1] if m > 1 else 0.0

    return {
        "eigenvalues": eigenvalues,
        "spectral_gap": float(spectral_gap),
        "algebraic_connectivity": float(algebraic_connectivity),
        "n_components_approx": int((eigenvalues < 1e-6).sum()),
    }


@torch.no_grad()
def compute_modularity(
    adj: torch.Tensor,
    community_labels: torch.Tensor,
) -> float:
    """Compute Newman modularity Q for given community assignments.

    Args:
        adj: (m, m) adjacency
        community_labels: (m,) integer community labels

    Returns:
        modularity Q in [-0.5, 1]
    """
    adj_np = adj.detach().cpu().numpy()
    labels = community_labels.detach().cpu().numpy()
    m_edges = adj_np.sum() / 2
    if m_edges == 0:
        return 0.0

    deg = adj_np.sum(axis=1)
    Q = 0.0
    for i in range(len(labels)):
        for j in range(len(labels)):
            if labels[i] == labels[j]:
                Q += adj_np[i, j] - deg[i] * deg[j] / (2 * m_edges)

    return Q / (2 * m_edges)
