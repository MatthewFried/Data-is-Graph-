"""Task evaluation metrics."""
from __future__ import annotations

import torch
import numpy as np
from typing import Dict
from sklearn.metrics import accuracy_score, f1_score


def compute_task_metrics(
    logits: torch.Tensor,
    targets: torch.Tensor,
    task: str = "classification",
) -> Dict[str, float]:
    if task == "classification":
        preds = logits.argmax(dim=-1).cpu().numpy()
        tgts = targets.cpu().numpy()
        n_classes = logits.shape[1]
        avg = "binary" if n_classes == 2 else "macro"
        return {
            "accuracy": accuracy_score(tgts, preds),
            "f1": f1_score(tgts, preds, average=avg, zero_division=0),
        }
    else:
        preds = logits.squeeze(-1).cpu()
        tgts = targets.float().cpu()
        mse = ((preds - tgts) ** 2).mean().item()
        return {
            "rmse": mse ** 0.5,
            "mae": (preds - tgts).abs().mean().item(),
        }
