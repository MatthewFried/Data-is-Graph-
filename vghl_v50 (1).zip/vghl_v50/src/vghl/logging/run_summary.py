"""Run summary logger: write JSON summaries of every run.

Every run writes:
  - spec (grammar)
  - machine size per level (nodes, edges, primitives)
  - stability metrics
  - edits history (if search)
  - score components
  - final accuracy/loss
  - skipped builders (with reason, N, threshold)
"""
from __future__ import annotations

import json
import os
import time
import logging
from typing import Any, Dict, List, Optional
from dataclasses import dataclass, field, asdict

logger = logging.getLogger(__name__)


@dataclass
class LevelSummary:
    level: int
    n_nodes: int
    n_edges: int
    n_primitives: int = 0
    n_ports: int = 0


@dataclass
class ScoreSummary:
    total: float = 0.0
    acc_val: float = 0.0
    acc_test: float = 0.0
    loss_val: float = 0.0
    complexity_V: int = 0
    complexity_E: int = 0
    node_penalty: float = 0.0
    edge_penalty: float = 0.0
    instability: float = 0.0
    instab_penalty: float = 0.0


@dataclass
class EditRecord:
    iteration: int
    edit_name: str
    params: Dict = field(default_factory=dict)
    accepted: bool = False
    score_before: float = 0.0
    score_after: float = 0.0
    reason: str = ""


@dataclass
class SkippedBuilder:
    builder: str
    reason: str
    N: int = 0
    threshold: str = ""


@dataclass
class RunSummary:
    """Full run summary."""
    # Identity
    run_id: str = ""
    timestamp: str = ""
    dataset: str = ""
    seed: int = 0

    # Grammar spec
    primitive_types: List[str] = field(default_factory=list)
    port_rule: str = ""
    wiring_rule: str = ""
    recursion_depth: int = 0
    operator: str = ""
    query_assignment: str = ""

    # Machine structure
    levels: List[LevelSummary] = field(default_factory=list)

    # Score
    score: ScoreSummary = field(default_factory=ScoreSummary)

    # Search history
    search_enabled: bool = False
    edits: List[EditRecord] = field(default_factory=list)
    search_stages: List[Dict] = field(default_factory=list)

    # Skipped
    skipped: List[SkippedBuilder] = field(default_factory=list)

    # Training
    epochs: int = 0
    final_train_loss: float = 0.0
    final_val_loss: float = 0.0
    final_val_acc: float = 0.0
    final_test_acc: float = 0.0
    wall_time_s: float = 0.0


def create_summary(
    dataset: str, seed: int, run_id: str = "",
) -> RunSummary:
    """Create a new run summary."""
    return RunSummary(
        run_id=run_id or f"{dataset}_{seed}_{int(time.time())}",
        timestamp=time.strftime("%Y-%m-%dT%H:%M:%S"),
        dataset=dataset,
        seed=seed,
    )


def add_machine_info(
    summary: RunSummary,
    levels,
    primitives=None,
    spec=None,
):
    """Add machine structure info from built levels."""
    summary.levels = []
    for i, lv in enumerate(levels):
        ls = LevelSummary(
            level=i,
            n_nodes=lv.n_nodes,
            n_edges=lv.edge_index.shape[1],
        )
        if hasattr(lv, 'ports') and lv.ports is not None:
            ls.n_ports = (lv.ports >= 0).sum().item() if hasattr(lv.ports, 'sum') else 0
        summary.levels.append(ls)

    if primitives is not None:
        if summary.levels:
            summary.levels[0].n_primitives = len(primitives)

    if spec is not None:
        if hasattr(spec, 'primitive_types'):
            summary.primitive_types = spec.primitive_types
        if hasattr(spec, 'port_rule'):
            summary.port_rule = spec.port_rule
        if hasattr(spec, 'wiring_rule'):
            summary.wiring_rule = spec.wiring_rule
        if hasattr(spec, 'depth'):
            summary.recursion_depth = spec.depth


def add_score(summary: RunSummary, score_dict: Dict):
    """Add score components."""
    summary.score = ScoreSummary(
        total=score_dict.get("total", 0),
        acc_val=score_dict.get("acc", score_dict.get("acc_val", 0)),
        complexity_V=score_dict.get("V", score_dict.get("total_nodes", 0)),
        complexity_E=score_dict.get("E", score_dict.get("total_edges", 0)),
        node_penalty=score_dict.get("node_penalty", 0),
        edge_penalty=score_dict.get("edge_penalty", 0),
        instability=score_dict.get("instability", 0),
        instab_penalty=score_dict.get("instab_penalty", score_dict.get("instability_penalty", 0)),
    )


def add_edit(summary: RunSummary, edit: EditRecord):
    """Add an edit record."""
    summary.edits.append(edit)


def add_skipped(summary: RunSummary, builder: str, reason: str, N: int = 0, threshold: str = ""):
    """Record a skipped builder."""
    summary.skipped.append(SkippedBuilder(builder=builder, reason=reason, N=N, threshold=threshold))
    logger.info(f"Skipped: {builder} — {reason} (N={N}, threshold={threshold})")


def save_summary(summary: RunSummary, output_dir: str):
    """Save summary as JSON."""
    os.makedirs(output_dir, exist_ok=True)
    path = os.path.join(output_dir, f"{summary.run_id}.json")
    with open(path, "w") as f:
        json.dump(asdict(summary), f, indent=2, default=str)
    logger.info(f"Run summary saved: {path}")
    return path


def load_summary(path: str) -> Dict:
    """Load a run summary from JSON."""
    with open(path) as f:
        return json.load(f)
