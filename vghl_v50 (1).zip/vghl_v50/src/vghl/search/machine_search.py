"""Machine Discovery Loop: search over grammars and structural edits.

Protocol:
  S0: Grammar sweep (primitive types × port rules × wiring × depth) with weak budget.
  S1: Refinement loop per top grammar: apply structural edits, accept/reject.
  S2: Final evaluation with longer budget.

Score = acc_val - α*log(|V|) - β*log(|E|) - γ*instability
"""
from __future__ import annotations

import logging
import math
import time
import torch
from typing import Dict, List, Optional, Tuple, Any
from dataclasses import dataclass, field

logger = logging.getLogger(__name__)


@dataclass
class MachineSpec:
    """Immutable grammar config for a machine."""
    primitive_types: List[str] = field(default_factory=lambda: ["triangle"])
    port_rule: str = "boundary_top2"
    wiring_rule: str = "shared_boundary"
    depth: int = 1
    pool_mode: str = "mean"
    operator: str = "random_walk"
    prop_steps: int = 5
    query_assignment: str = "nearest_anchor"


@dataclass
class MachineState:
    """Built machine with cached graphs and metrics."""
    spec: MachineSpec
    levels: list          # List[LevelGraph]
    primitives: list      # List[Primitive]
    edge_index: Any       # base graph edges
    edge_weight: Any      # base graph weights
    z: Any                # embedded features
    h: Any                # propagated features
    score: Optional[Dict] = None


@dataclass
class SearchConfig:
    """Configuration for machine discovery."""
    enabled: bool = False
    K_grammars: int = 6        # top grammars to keep from S0
    M_edits: int = 20          # max edit iterations in S1
    edits_per_iter: int = 4    # edit proposals per iteration
    accept: str = "greedy"     # greedy | anneal
    alpha: float = 0.01        # node complexity penalty
    beta: float = 0.01         # edge complexity penalty
    gamma: float = 0.1         # instability penalty
    bootstrap_trials: int = 3
    jitter_sigma: float = 0.01
    # Grammar sweep grid
    primitive_grid: List[str] = field(default_factory=lambda: ["triangle", "star", "triangle,star"])
    port_grid: List[str] = field(default_factory=lambda: ["boundary_top2", "medoid"])
    wiring_grid: List[str] = field(default_factory=lambda: ["shared_boundary", "port_knn"])
    depth_grid: List[int] = field(default_factory=lambda: [1])


def score_machine(levels, val_accuracy: float, instability: float = 0.0,
                   alpha: float = 0.01, beta: float = 0.01, gamma: float = 0.1) -> Dict:
    """Score = val_acc - α*log(|V|) - β*log(|E|) - γ*instability."""
    total_V = sum(lv.n_nodes for lv in levels)
    total_E = sum(lv.edge_index.shape[1] for lv in levels)
    node_pen = alpha * math.log(max(total_V, 1))
    edge_pen = beta * math.log(max(total_E, 1))
    instab_pen = gamma * instability
    total = val_accuracy - node_pen - edge_pen - instab_pen
    return {
        "total": total, "acc": val_accuracy,
        "V": total_V, "E": total_E,
        "node_penalty": node_pen, "edge_penalty": edge_pen,
        "instability": instability, "instab_penalty": instab_pen,
    }


def compute_instability(
    edge_index: torch.Tensor, edge_weight: torch.Tensor,
    N: int, n_bootstrap: int = 3, sigma: float = 0.01,
) -> float:
    """Edge survival instability under bootstrap."""
    E = edge_weight.shape[0]
    if E == 0:
        return 0.0
    survival = torch.zeros(E, device=edge_weight.device)
    for _ in range(n_bootstrap):
        noise = torch.randn(E, device=edge_weight.device) * sigma
        survival += ((edge_weight + noise) > 0).float()
    survival /= n_bootstrap
    # Instability = fraction of edges with < 100% survival
    return (survival < 1.0).float().mean().item()


def accept_edit(
    score_old: Dict, score_new: Dict,
    mode: str = "greedy",
    temperature: float = 1.0,
    rng=None,
) -> bool:
    """Decide whether to accept a structural edit.

    Args:
        score_old, score_new: Score dicts with 'total' key.
        mode: 'greedy' (accept if better) or 'anneal' (simulated annealing).
        temperature: for annealing mode.
        rng: random state for annealing.
    """
    delta = score_new["total"] - score_old["total"]
    if mode == "greedy":
        return delta > 0
    elif mode == "anneal":
        if delta > 0:
            return True
        import math
        import random
        prob = math.exp(delta / max(temperature, 1e-8))
        r = rng.random() if rng else random.random()
        return r < prob
    return delta > 0


def build_machine(
    z: torch.Tensor, edge_index: torch.Tensor, edge_weight: torch.Tensor,
    spec: MachineSpec,
) -> MachineState:
    """Build a machine from embedded features and a grammar spec."""
    from ..models.primitives import PrimitiveConfig, induce_primitives
    from ..models.recursion import RecursionConfig, build_multilevel_graph
    from ..models.multilevel_compute import MultilevelComputeConfig, multilevel_propagate
    from ..models.propagation import PropagationConfig

    prim_cfg = PrimitiveConfig(types=spec.primitive_types, use_in_propagation=True)
    prims = induce_primitives(edge_index, z.detach(), prim_cfg)

    rec_cfg = RecursionConfig(
        enabled=True, depth=spec.depth, port_rule=spec.port_rule,
        wiring_rule=spec.wiring_rule, pool_mode=spec.pool_mode,
    )
    levels = build_multilevel_graph(z.detach(), edge_index, edge_weight, prims, rec_cfg)

    prop_cfg = PropagationConfig(type=spec.operator, steps=spec.prop_steps)
    ml_cfg = MultilevelComputeConfig(pool_mode=spec.pool_mode)
    h = multilevel_propagate(z, levels, prop_cfg, ml_cfg)

    return MachineState(
        spec=spec, levels=levels, primitives=prims,
        edge_index=edge_index, edge_weight=edge_weight, z=z, h=h,
    )


def evaluate_machine(
    state: MachineState, head, X_val: torch.Tensor, y_val: torch.Tensor,
    alpha: float = 0.01, beta: float = 0.01, gamma: float = 0.1,
    n_bootstrap: int = 3, jitter_sigma: float = 0.01,
) -> Dict:
    """Evaluate a machine: accuracy + score components."""
    from ..models.multilevel_compute import multilevel_propagate_queries
    from ..models.propagation import PropagationConfig
    from ..models.multilevel_compute import MultilevelComputeConfig

    device = state.z.device
    N = state.z.shape[0]

    # Compute val features via query propagation
    # Simplified: use state.h (anchor features) directly for scoring
    # In full pipeline, would attach queries and propagate
    with torch.no_grad():
        logits = head(state.h[:X_val.shape[0]]) if state.h.shape[0] >= X_val.shape[0] else head(state.h)
        if logits.shape[0] > y_val.shape[0]:
            logits = logits[:y_val.shape[0]]
        preds = logits.argmax(dim=1)
        acc = (preds == y_val[:preds.shape[0]]).float().mean().item()

    instab = compute_instability(
        state.edge_index, state.edge_weight, N, n_bootstrap, jitter_sigma
    )

    return score_machine(state.levels, acc, instab, alpha, beta, gamma)


def search(
    z: torch.Tensor, edge_index: torch.Tensor, edge_weight: torch.Tensor,
    head, y_train: torch.Tensor, X_val: torch.Tensor, y_val: torch.Tensor,
    cfg: SearchConfig,
) -> Tuple[MachineState, List[Dict]]:
    """Full machine discovery loop.

    S0: Grammar sweep → top K.
    S1: Structural edit refinement.
    S2: Final evaluation.

    Returns (best_state, history).
    """
    from .edits import propose_edits, apply_edit, EditProposal

    history = []
    t0 = time.time()

    # ── S0: Grammar Sweep ─────────────────────────────────────────
    logger.info("S0: Grammar sweep starting")
    grammar_scores = []

    for prims_str in cfg.primitive_grid:
        prim_types = prims_str.split(",")
        for port in cfg.port_grid:
            for wiring in cfg.wiring_grid:
                for depth in cfg.depth_grid:
                    spec = MachineSpec(
                        primitive_types=prim_types, port_rule=port,
                        wiring_rule=wiring, depth=depth,
                    )
                    try:
                        state = build_machine(z, edge_index, edge_weight, spec)
                        sc = evaluate_machine(
                            state, head, X_val, y_val,
                            cfg.alpha, cfg.beta, cfg.gamma,
                            cfg.bootstrap_trials, cfg.jitter_sigma,
                        )
                        state.score = sc
                        grammar_scores.append(state)
                        logger.info(f"  Grammar {prim_types}/{port}/{wiring}/d={depth}: "
                                    f"score={sc['total']:.4f} acc={sc['acc']:.4f}")
                    except Exception as e:
                        logger.warning(f"  Grammar failed: {e}")

    if not grammar_scores:
        raise RuntimeError("All grammar configs failed")

    # Keep top K
    grammar_scores.sort(key=lambda s: s.score["total"], reverse=True)
    top_states = grammar_scores[:cfg.K_grammars]
    history.append({
        "stage": "S0", "n_grammars_tried": len(grammar_scores),
        "top_scores": [s.score["total"] for s in top_states],
        "time_s": time.time() - t0,
    })

    # ── S1: Structural Edit Refinement ────────────────────────────
    logger.info("S1: Structural edit refinement")
    best_state = top_states[0]
    best_score = best_state.score["total"]

    for state in top_states:
        current_ei = state.edge_index
        current_ew = state.edge_weight
        current_z = state.z
        current_score = state.score["total"]

        for it in range(cfg.M_edits):
            N = current_z.shape[0]
            n_levels = len(state.levels)
            edits = propose_edits(N, n_levels)[:cfg.edits_per_iter]

            improved = False
            for edit in edits:
                # Handle REWIRE_PORTS: rebuild with different wiring rule
                if edit.name == "REWIRE_PORTS":
                    new_spec = MachineSpec(
                        primitive_types=state.spec.primitive_types,
                        port_rule=state.spec.port_rule,
                        wiring_rule=edit.params.get("mode", "port_knn"),
                        depth=state.spec.depth,
                        pool_mode=state.spec.pool_mode,
                        operator=state.spec.operator,
                        prop_steps=state.spec.prop_steps,
                    )
                    if new_spec.wiring_rule == state.spec.wiring_rule:
                        continue
                    try:
                        new_state = build_machine(current_z, current_ei, current_ew, new_spec)
                        sc = evaluate_machine(
                            new_state, head, X_val, y_val,
                            cfg.alpha, cfg.beta, cfg.gamma,
                        )
                        new_state.score = sc
                        if accept_edit(state.score, sc, cfg.accept):
                            state = new_state
                            current_score = sc["total"]
                            improved = True
                            logger.info(f"  Rewire to {new_spec.wiring_rule} accepted: {sc['total']:.4f}")
                            break
                    except Exception:
                        continue
                    continue

                result = apply_edit(
                    edit, current_ei, current_ew, current_z, N,
                    levels=state.levels if edit.name in ("SPLIT_SUPERNODE", "MERGE_SUPERNODES_BY_EQUIV") else None,
                )
                new_ei = result["edge_index"]
                new_ew = result["edge_weight"]
                new_N = result["new_N"]

                if new_ei.shape[1] == 0 or new_N < 3:
                    continue

                # If nodes were pruned, update z
                new_z = current_z
                if result["keep_mask"] is not None and new_N < N:
                    new_z = current_z[result["keep_mask"]]

                try:
                    new_state = build_machine(new_z, new_ei, new_ew, state.spec)
                    sc = evaluate_machine(
                        new_state, head, X_val, y_val,
                        cfg.alpha, cfg.beta, cfg.gamma,
                    )
                    new_state.score = sc

                    if accept_edit(state.score, sc, cfg.accept):
                        current_ei, current_ew, current_z = new_ei, new_ew, new_z
                        current_score = sc["total"]
                        state = new_state
                        improved = True
                        logger.info(f"  Edit {edit.name} accepted: {sc['total']:.4f}")
                        break
                except Exception:
                    continue

            if not improved:
                break

        if current_score > best_score:
            best_state = state
            best_score = current_score

    history.append({
        "stage": "S1", "best_score": best_score,
        "time_s": time.time() - t0,
    })

    # ── S2: Final Evaluation ──────────────────────────────────────
    logger.info(f"S2: Best machine score={best_score:.4f}")
    final_sc = evaluate_machine(
        best_state, head, X_val, y_val,
        cfg.alpha, cfg.beta, cfg.gamma,
        cfg.bootstrap_trials, cfg.jitter_sigma,
    )
    best_state.score = final_sc
    history.append({
        "stage": "S2", "final_score": final_sc,
        "time_s": time.time() - t0,
    })

    return best_state, history
