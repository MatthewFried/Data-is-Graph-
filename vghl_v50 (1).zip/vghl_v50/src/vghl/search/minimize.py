"""Guarded Behavioral Merge: minimization-like merging with preservation test.

Merging is NOT arbitrary clustering — it requires:
  1. Behavioral distance (transition signature) below threshold tau.
  2. Preservation guard: after merge, embeddings/logits must stay within eps.

This is the DFA-minimization analogy with a "real-world" correctness guard.
"""
from __future__ import annotations

import logging
import torch
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass

from ..models.merge import MergeConfig, apply_merges
from ..models.propagation import PropagationConfig, propagate

logger = logging.getLogger(__name__)


@dataclass
class GuardedMergeConfig:
    """Config for guarded behavioral merge."""
    enabled: bool = False
    tau: float = 0.10           # behavioral distance threshold (merge if dist < tau)
    eps_emb: float = 0.05       # max mean embedding change
    eps_logit: float = 0.1      # max mean logit change
    num_probes: int = 8         # number of probe signals
    top_m_neighbors: int = 8    # signature dimension
    metric: str = "js"          # js | cosine


def compute_probe_signatures(
    edge_index: torch.Tensor,
    edge_weight: torch.Tensor,
    N: int,
    num_probes: int = 8,
    prop_steps: int = 1,
) -> torch.Tensor:
    """Compute behavioral signatures using probe signals.

    For each probe (random Rademacher vector), run one propagation step
    and record the output as a signature component.

    Returns: (N, num_probes) signature matrix.
    """
    device = edge_index.device
    sigs = torch.zeros(N, num_probes, device=device)

    for p in range(num_probes):
        # Rademacher probe: +1/-1 randomly
        probe = torch.sign(torch.randn(N, 1, device=device))
        probe[probe == 0] = 1.0

        # One propagation step = one transition
        # Build row-normalized sparse matrix
        src, dst = edge_index[0], edge_index[1]
        deg = torch.zeros(N, device=device)
        deg.scatter_add_(0, src, edge_weight)
        deg = deg.clamp(min=1e-8)
        norm_w = edge_weight / deg[src]

        # SpMM: out[dst] += norm_w * probe[src]
        out = torch.zeros(N, 1, device=device)
        out.scatter_add_(0, dst.unsqueeze(1).expand(-1, 1), norm_w.unsqueeze(1) * probe[src])

        sigs[:, p] = out.squeeze(1)

    return sigs


def compute_behavioral_distance(
    sigs: torch.Tensor,
    edge_index: torch.Tensor,
    N: int,
    metric: str = "cosine",
) -> List[Tuple[int, int, float]]:
    """Compute behavioral distance between connected node pairs.

    Returns list of (a, b, distance) sorted by distance ascending.
    """
    src, dst = edge_index[0], edge_index[1]
    pairs = []
    seen = set()

    sig_norm = torch.nn.functional.normalize(sigs, dim=1, eps=1e-8)

    for idx in range(edge_index.shape[1]):
        a, b = src[idx].item(), dst[idx].item()
        if a >= b or (a, b) in seen:
            continue
        seen.add((a, b))

        if metric == "cosine":
            sim = (sig_norm[a] * sig_norm[b]).sum().item()
            dist = 1.0 - sim
        elif metric == "js":
            # Jensen-Shannon on softmaxed signatures
            p = torch.softmax(sigs[a], dim=0)
            q = torch.softmax(sigs[b], dim=0)
            m = 0.5 * (p + q)
            kl_pm = (p * (p / m.clamp(min=1e-10)).log()).sum().item()
            kl_qm = (q * (q / m.clamp(min=1e-10)).log()).sum().item()
            dist = 0.5 * (kl_pm + kl_qm)
        else:
            dist = (sigs[a] - sigs[b]).norm().item()

        pairs.append((a, b, dist))

    pairs.sort(key=lambda x: x[2])
    return pairs


def guarded_merge(
    edge_index: torch.Tensor,
    edge_weight: torch.Tensor,
    N: int,
    h_before: torch.Tensor,
    logits_before: Optional[torch.Tensor],
    cfg: GuardedMergeConfig,
    prop_cfg: Optional[PropagationConfig] = None,
) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor, int, Dict]:
    """Apply guarded behavioral merge.

    1. Compute probe signatures.
    2. Find pairs with behavioral distance < tau.
    3. For each candidate merge, check preservation guard.
    4. Only commit merges that pass the guard.

    Returns: (new_ei, new_ew, compact_map, new_N, stats)
    """
    device = edge_index.device
    stats = {"n_proposed": 0, "n_accepted": 0, "n_rejected_guard": 0}

    if not cfg.enabled or N <= 2:
        return edge_index, edge_weight, torch.arange(N, device=device), N, stats

    # 1. Compute signatures
    sigs = compute_probe_signatures(
        edge_index, edge_weight, N, cfg.num_probes
    )

    # 2. Find merge candidates
    distances = compute_behavioral_distance(sigs, edge_index, N, cfg.metric)
    candidates = [(a, b) for a, b, d in distances if d < cfg.tau]
    stats["n_proposed"] = len(candidates)

    if not candidates:
        return edge_index, edge_weight, torch.arange(N, device=device), N, stats

    # 3. Guard each merge
    accepted = []
    used = set()
    for a, b in candidates:
        if a in used or b in used:
            continue

        # Tentative merge
        test_pairs = [(a, b)]
        new_ei, new_ew, compact, new_N = apply_merges(
            edge_index, edge_weight, N, test_pairs
        )

        # Check embedding preservation
        h_after_merge = h_before.clone()
        # After merge, node b's features go to a
        h_merged = torch.zeros(new_N, h_before.shape[1], device=device)
        counts = torch.zeros(new_N, 1, device=device)
        h_merged.scatter_add_(0, compact.unsqueeze(1).expand_as(h_before), h_before)
        counts.scatter_add_(0, compact.unsqueeze(1),
                           torch.ones(N, 1, device=device))
        h_merged = h_merged / counts.clamp(min=1)

        # Map back to original space for comparison
        h_reconstructed = h_merged[compact]
        delta_emb = (h_before - h_reconstructed).norm(dim=1).mean().item()

        # Check logit preservation if available
        delta_logit = 0.0
        if logits_before is not None and logits_before.shape[0] == N:
            logit_merged = torch.zeros(new_N, logits_before.shape[1], device=device)
            lc = torch.zeros(new_N, 1, device=device)
            logit_merged.scatter_add_(0, compact.unsqueeze(1).expand_as(logits_before),
                                      logits_before)
            lc.scatter_add_(0, compact.unsqueeze(1),
                           torch.ones(N, 1, device=device))
            logit_merged = logit_merged / lc.clamp(min=1)
            logit_recon = logit_merged[compact]
            delta_logit = (logits_before - logit_recon).abs().mean().item()

        # Guard check
        if delta_emb <= cfg.eps_emb and delta_logit <= cfg.eps_logit:
            accepted.append((a, b))
            used.add(a)
            used.add(b)
            stats["n_accepted"] += 1
        else:
            stats["n_rejected_guard"] += 1

    if not accepted:
        return edge_index, edge_weight, torch.arange(N, device=device), N, stats

    # Apply accepted merges
    new_ei, new_ew, compact, new_N = apply_merges(
        edge_index, edge_weight, N, accepted
    )

    logger.info(f"Guarded merge: {stats['n_proposed']} proposed, "
                f"{stats['n_accepted']} accepted, {stats['n_rejected_guard']} rejected")
    return new_ei, new_ew, compact, new_N, stats
