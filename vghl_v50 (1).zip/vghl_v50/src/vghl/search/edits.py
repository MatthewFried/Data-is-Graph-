"""Structural Edit Operators for machine discovery.

Each edit has: name, params, apply(state) -> new_state.
Edits are local when possible — only rebuild affected parts.
"""
from __future__ import annotations

import logging
import torch
import numpy as np
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass, field

logger = logging.getLogger(__name__)


@dataclass
class EditProposal:
    """A proposed structural edit to a machine."""
    name: str
    params: Dict = field(default_factory=dict)
    level: int = 0  # which hierarchy level this targets


# ── Node Pruning ─────────────────────────────────────────────────────

def prune_nodes_by_instability(
    edge_index: torch.Tensor,
    edge_weight: torch.Tensor,
    points: torch.Tensor,
    N: int,
    pct: float = 0.05,
    n_bootstrap: int = 5,
    perturb_sigma: float = 0.02,
) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor, int]:
    """Remove worst-pct nodes by kNN neighbor-set instability under bootstrap.

    Instability = coefficient of variation of weighted degree under noise.
    Returns (new_ei, new_ew, keep_mask, new_N).
    """
    device = edge_index.device
    E = edge_weight.shape[0]

    # Compute degree variance under bootstrap
    deg_samples = []
    for _ in range(n_bootstrap):
        noise = torch.randn(E, device=device) * perturb_sigma
        w_noisy = (edge_weight + noise).clamp(min=0)
        deg = torch.zeros(N, device=device)
        deg.scatter_add_(0, edge_index[0], w_noisy)
        deg_samples.append(deg)

    deg_stack = torch.stack(deg_samples)
    mean_deg = deg_stack.mean(dim=0)
    std_deg = deg_stack.std(dim=0)
    instability = std_deg / mean_deg.clamp(min=1e-8)

    # Remove worst pct
    n_remove = max(1, int(N * pct))
    threshold = torch.topk(instability, n_remove).values[-1]
    keep_mask = instability <= threshold

    keep_nodes = keep_mask.nonzero(as_tuple=True)[0]
    new_N = keep_nodes.shape[0]
    if new_N == N:
        return edge_index, edge_weight, keep_mask, N

    remap = torch.full((N,), -1, dtype=torch.long, device=device)
    remap[keep_nodes] = torch.arange(new_N, device=device)

    src_ok = keep_mask[edge_index[0]]
    dst_ok = keep_mask[edge_index[1]]
    mask = src_ok & dst_ok
    new_ei = torch.stack([remap[edge_index[0, mask]], remap[edge_index[1, mask]]])
    new_ew = edge_weight[mask]

    return new_ei, new_ew, keep_mask, new_N


def prune_nodes_by_edge_outliers(
    edge_index: torch.Tensor,
    edge_weight: torch.Tensor,
    points: torch.Tensor,
    N: int,
    zscore_threshold: float = 2.5,
) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor, int]:
    """Remove nodes whose incident edge lengths are extreme outliers.

    Computes per-node mean edge length, then removes nodes whose
    mean is > zscore_threshold standard deviations above the global mean.
    """
    device = edge_index.device
    dists = (points[edge_index[0]] - points[edge_index[1]]).norm(dim=1)

    # Per-node mean edge length
    node_sum = torch.zeros(N, device=device)
    node_cnt = torch.zeros(N, device=device)
    node_sum.scatter_add_(0, edge_index[0], dists)
    node_cnt.scatter_add_(0, edge_index[0], torch.ones_like(dists))
    node_mean = node_sum / node_cnt.clamp(min=1)

    # Z-score
    global_mean = node_mean[node_cnt > 0].mean()
    global_std = node_mean[node_cnt > 0].std().clamp(min=1e-8)
    zscore = (node_mean - global_mean) / global_std

    keep_mask = zscore <= zscore_threshold
    keep_nodes = keep_mask.nonzero(as_tuple=True)[0]
    new_N = keep_nodes.shape[0]
    if new_N == N:
        return edge_index, edge_weight, keep_mask, N

    remap = torch.full((N,), -1, dtype=torch.long, device=device)
    remap[keep_nodes] = torch.arange(new_N, device=device)
    src_ok = keep_mask[edge_index[0]]
    dst_ok = keep_mask[edge_index[1]]
    mask = src_ok & dst_ok
    new_ei = torch.stack([remap[edge_index[0, mask]], remap[edge_index[1, mask]]])
    new_ew = edge_weight[mask]

    return new_ei, new_ew, keep_mask, new_N


# ── Edge Pruning ─────────────────────────────────────────────────────

def prune_edges_by_survival(
    edge_index: torch.Tensor,
    edge_weight: torch.Tensor,
    points: torch.Tensor,
    tau: float = 0.6,
    n_bootstrap: int = 5,
    jitter_sigma: float = 0.01,
) -> Tuple[torch.Tensor, torch.Tensor]:
    """Keep only edges that survive in >= tau fraction of bootstraps.

    Jitters point positions and rebuilds kNN; keeps edges present in >= tau*B builds.
    Simplified: jitters edge weights and keeps those that stay positive.
    """
    device = edge_index.device
    E = edge_weight.shape[0]

    survival = torch.zeros(E, device=device)
    for _ in range(n_bootstrap):
        noise = torch.randn(E, device=device) * jitter_sigma
        w_noisy = edge_weight + noise
        survival += (w_noisy > 0).float()

    survival /= n_bootstrap
    mask = survival >= tau
    return edge_index[:, mask], edge_weight[mask]


def prune_edges_by_length(
    edge_index: torch.Tensor,
    edge_weight: torch.Tensor,
    points: torch.Tensor,
    pct: float = 0.95,
) -> Tuple[torch.Tensor, torch.Tensor]:
    """Remove top (1-pct) longest edges."""
    dists = (points[edge_index[0]] - points[edge_index[1]]).norm(dim=1)
    threshold = torch.quantile(dists.float(), pct)
    mask = dists <= threshold
    return edge_index[:, mask], edge_weight[mask]


# ── Supernode Split ──────────────────────────────────────────────────

def split_supernode_by_cut(
    levels, level_idx: int, supernode_id: int,
    base_points: torch.Tensor,
) -> bool:
    """Split a supernode into two via spectral bisection of its children.

    Modifies levels in-place. Returns True if split was applied.
    """
    lv = levels[level_idx]
    members = (lv.membership == supernode_id).nonzero(as_tuple=True)[0]
    if len(members) < 4:
        return False  # too small to split

    # Get sub-graph among members at level below
    prev_lv = levels[level_idx - 1] if level_idx > 0 else lv
    child_points = base_points[members]

    # Simple split: k-means with k=2 on coordinates
    from sklearn.cluster import KMeans
    km = KMeans(n_clusters=2, n_init=3, random_state=0)
    labels = km.fit_predict(child_points.detach().cpu().numpy())
    labels = torch.tensor(labels, device=lv.membership.device, dtype=torch.long)

    # Create new supernode
    new_super_id = lv.n_nodes
    mask_1 = labels == 1
    members_to_move = members[mask_1]
    if len(members_to_move) == 0 or len(members_to_move) == len(members):
        return False  # degenerate split

    lv.membership[members_to_move] = new_super_id
    lv.n_nodes += 1

    logger.info(f"Split supernode {supernode_id} at level {level_idx}: "
                f"{len(members) - len(members_to_move)} + {len(members_to_move)}")
    return True


# ── Edit Dispatch ────────────────────────────────────────────────────

def apply_edit(
    edit: EditProposal,
    edge_index: torch.Tensor,
    edge_weight: torch.Tensor,
    points: torch.Tensor,
    N: int,
    levels=None,
) -> Dict:
    """Apply an edit and return results dict.

    Returns dict with keys: edge_index, edge_weight, keep_mask, new_N, levels
    """
    result = {
        "edge_index": edge_index, "edge_weight": edge_weight,
        "keep_mask": None, "new_N": N, "levels": levels,
    }

    if edit.name == "PRUNE_NODES_BY_INSTABILITY":
        ei, ew, mask, n = prune_nodes_by_instability(
            edge_index, edge_weight, points, N, **edit.params)
        result.update(edge_index=ei, edge_weight=ew, keep_mask=mask, new_N=n)

    elif edit.name == "PRUNE_NODES_BY_EDGE_OUTLIERS":
        ei, ew, mask, n = prune_nodes_by_edge_outliers(
            edge_index, edge_weight, points, N, **edit.params)
        result.update(edge_index=ei, edge_weight=ew, keep_mask=mask, new_N=n)

    elif edit.name == "PRUNE_EDGES_BY_SURVIVAL":
        ei, ew = prune_edges_by_survival(
            edge_index, edge_weight, points, **edit.params)
        result.update(edge_index=ei, edge_weight=ew)

    elif edit.name == "PRUNE_EDGES_BY_LENGTH":
        ei, ew = prune_edges_by_length(
            edge_index, edge_weight, points, **edit.params)
        result.update(edge_index=ei, edge_weight=ew)

    elif edit.name == "SPLIT_SUPERNODE":
        if levels is not None:
            split_supernode_by_cut(
                levels, edit.params.get("level_idx", 1),
                edit.params.get("supernode_id", 0), points)
            result["levels"] = levels

    elif edit.name == "MERGE_SUPERNODES_BY_EQUIV":
        if levels is not None and len(levels) > 1:
            from .minimize import GuardedMergeConfig, guarded_merge
            lv_idx = edit.params.get("level_idx", 1)
            lv = levels[lv_idx]
            if lv.edge_index.shape[1] > 0 and lv.n_nodes > 2:
                tau = edit.params.get("tau", 0.10)
                h_lv = points[:lv.n_nodes] if lv.n_nodes <= points.shape[0] else points
                cfg = GuardedMergeConfig(
                    enabled=True, tau=tau,
                    eps_emb=edit.params.get("eps_emb", 0.05),
                    eps_logit=edit.params.get("eps_logit", 0.1),
                    num_probes=edit.params.get("num_probes", 4),
                )
                new_ei, new_ew, compact, new_N, stats = guarded_merge(
                    lv.edge_index, lv.edge_weight, lv.n_nodes,
                    h_lv, None, cfg,
                )
                if new_N < lv.n_nodes:
                    lv.edge_index, lv.edge_weight = new_ei, new_ew
                    lv.membership = compact[lv.membership]
                    lv.n_nodes = new_N
            result["levels"] = levels

    elif edit.name == "REWIRE_PORTS":
        # Change wiring rule: keeps primitives but changes supergraph edges.
        # This requires full hierarchy rebuild with new wiring, handled in search loop.
        result["rewire_to"] = edit.params.get("mode", "port_knn")

    else:
        logger.warning(f"Unknown edit: {edit.name}")

    return result


def propose_edits(N: int, n_levels: int, rng=None) -> List[EditProposal]:
    """Generate a diverse set of edit proposals."""
    edits = [
        EditProposal("PRUNE_EDGES_BY_LENGTH", {"pct": 0.92}),
        EditProposal("PRUNE_EDGES_BY_LENGTH", {"pct": 0.95}),
        EditProposal("PRUNE_EDGES_BY_SURVIVAL", {"tau": 0.5, "n_bootstrap": 3}),
        EditProposal("PRUNE_EDGES_BY_SURVIVAL", {"tau": 0.7, "n_bootstrap": 3}),
        EditProposal("PRUNE_NODES_BY_INSTABILITY", {"pct": 0.03}),
        EditProposal("PRUNE_NODES_BY_INSTABILITY", {"pct": 0.05}),
        EditProposal("PRUNE_NODES_BY_EDGE_OUTLIERS", {"zscore_threshold": 2.0}),
        EditProposal("PRUNE_NODES_BY_EDGE_OUTLIERS", {"zscore_threshold": 2.5}),
    ]
    # Add merge edit if hierarchy exists
    if n_levels > 1:
        edits.append(EditProposal("MERGE_SUPERNODES_BY_EQUIV", {"level_idx": 1, "tau": 0.10}))
        edits.append(EditProposal("MERGE_SUPERNODES_BY_EQUIV", {"level_idx": 1, "tau": 0.15}))
    # Add rewire edits
    edits.append(EditProposal("REWIRE_PORTS", {"mode": "port_knn"}))
    edits.append(EditProposal("REWIRE_PORTS", {"mode": "shared_boundary"}))
    return edits
