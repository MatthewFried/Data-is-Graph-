"""Training loop for Geometric Machine experiments.

Key design principles:
  - Graph is built ONCE on the full training set (not per batch)
  - Propagation happens once on the full graph (cached)
  - Only the readout head is trained via SGD on minibatches
  - Machine metrics are computed on the actual dataset-level graph
  - All variation comes from graph construction, not weight optimization
"""
from __future__ import annotations

import time
import torch
import torch.nn.functional as F
from torch.utils.data import DataLoader, TensorDataset
from pathlib import Path
from typing import Dict, Any, Optional

from ..utils.logging import get_logger, MetricsLogger
from ..utils.io import save_checkpoint, save_results
from ..utils.seed import set_seed
from ..metrics.task_metrics import compute_task_metrics
from ..models.geometric_machine import GeometricMachine, compute_machine_metrics

logger = get_logger("vghl.gm_train")


class GMTrainer:
    """Trainer for GeometricMachine experiments.

    Training protocol:
      1. Build dataset-level graph from full training set (once)
      2. Propagate training features through the graph (once, cached)
      3. Train readout head on propagated features via minibatch SGD
      4. For eval: attach val/test as queries to anchor graph, propagate, predict
    """

    def __init__(
        self,
        model: GeometricMachine,
        train_loader: DataLoader,
        val_loader: DataLoader,
        test_loader: DataLoader,
        n_classes: int,
        device: str,
        run_dir: Path,
        lr: float = 1e-3,
        weight_decay: float = 1e-4,
        epochs: int = 100,
        early_stop_patience: int = 30,
        log_machine_every: int = 5,
        task: str = "classification",
        rebuild_graph_every: int = 0,
        compression_fractions: Optional[list] = None,
        train_embed: bool = False,
    ):
        self.model = model.to(device)
        self.train_loader = train_loader
        self.val_loader = val_loader
        self.test_loader = test_loader
        self.n_classes = n_classes
        self.device = device
        self.run_dir = Path(run_dir)
        self.epochs = epochs
        self.early_stop_patience = early_stop_patience
        self.log_machine_every = log_machine_every
        self.task = task
        self.rebuild_graph_every = rebuild_graph_every
        self.compression_fractions = compression_fractions or []
        self.train_embed = train_embed

        # Only train the head by default. If train_embed, also train embed
        # but MUST rebuild graph frequently so anchors stay consistent.
        if train_embed:
            params = list(model.head.parameters()) + list(model.embed.parameters())
            if rebuild_graph_every < 1:
                logger.warning(
                    "train_embed=True but rebuild_graph_every=0. "
                    "Forcing rebuild_graph_every=1 to keep embeddings consistent."
                )
                self.rebuild_graph_every = 1
        else:
            params = model.head.parameters()
            # Hard freeze: ensure embed cannot accidentally receive gradients
            for p in model.embed.parameters():
                p.requires_grad_(False)

        self.optimizer = torch.optim.Adam(
            params, lr=lr, weight_decay=weight_decay
        )
        self.scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(
            self.optimizer, T_max=epochs, eta_min=lr * 0.01
        )

        self.run_dir.mkdir(parents=True, exist_ok=True)
        self.metrics_logger = MetricsLogger(self.run_dir, use_tensorboard=True)

        self.best_val_loss = float("inf")
        self.best_epoch = 0
        self.patience_counter = 0

        # Cached propagated features for training
        self._train_h: Optional[torch.Tensor] = None
        self._train_y: Optional[torch.Tensor] = None

    def _collect_full_dataset(self, loader: DataLoader):
        """Collect all data from a loader into single tensors."""
        all_x, all_y = [], []
        for batch in loader:
            all_x.append(batch[0])
            all_y.append(batch[1])
        X = torch.cat(all_x, dim=0)
        y = torch.cat(all_y, dim=0)
        return X, y

    @torch.no_grad()
    def _build_and_propagate(self, X_train: torch.Tensor, y_train: torch.Tensor):
        """Build dataset-level graph and propagate training features."""
        logger.info(f"Building dataset graph: N={X_train.shape[0]}, d={X_train.shape[1]}")
        t0 = time.perf_counter()

        # Collect val data for structure selection (edit loop eval_fn)
        X_val, y_val = None, None
        if self.val_loader is not None:
            X_val, y_val = self._collect_full_dataset(self.val_loader)

        self.model.eval()
        self.model.build_graph(
            X_train.to(self.device), labels=y_train.to(self.device),
            X_val=X_val.to(self.device) if X_val is not None else None,
            y_val=y_val.to(self.device) if y_val is not None else None,
        )

        # Get propagated train features
        h_train = self.model.get_propagated_train_features()
        if h_train is None:
            # Fallback: embed + propagate manually
            z = self.model.embed(X_train.to(self.device))
            h_train = z

        self._train_h = h_train
        # If pruning removed nodes, filter labels to match
        y_dev = y_train.to(self.device)
        if self.model._pruning_node_mask is not None:
            y_dev = y_dev[self.model._pruning_node_mask]
        self._train_y = y_dev

        elapsed = time.perf_counter() - t0
        logger.info(
            f"Graph built in {elapsed:.2f}s: "
            f"{self.model._anchor_edge_index.shape[1] if self.model._anchor_edge_index is not None else 0} edges"
        )

    @torch.no_grad()
    def _propagate_queries(self, X_query: torch.Tensor) -> torch.Tensor:
        """Propagate query (val/test) features through anchor graph."""
        self.model.eval()
        output = self.model(X_query.to(self.device), is_query=True)
        return output["logits"]

    def train(self) -> Dict[str, Any]:
        """Full training loop."""
        import time as _time
        _t_total_start = _time.perf_counter()

        n_params = sum(p.numel() for p in self.model.parameters())
        n_trainable = sum(p.numel() for p in self.model.parameters() if p.requires_grad)
        logger.info(
            f"GM Training: {self.epochs} epochs, "
            f"params={n_params:,} (trainable={n_trainable:,}), device={self.device}"
        )

        # Step 1: Collect full training data
        X_train, y_train = self._collect_full_dataset(self.train_loader)

        # Step 2: Build graph and propagate (once)
        _t_graph_start = _time.perf_counter()
        self._build_and_propagate(X_train, y_train)
        _t_graph_end = _time.perf_counter()

        # Step 3: Create dataloader for propagated features
        train_prop_ds = TensorDataset(self._train_h, self._train_y)
        batch_size = self.train_loader.batch_size or 256
        prop_loader = DataLoader(
            train_prop_ds, batch_size=batch_size, shuffle=True,
            pin_memory=False, drop_last=False,
        )

        for epoch in range(self.epochs):
            t0 = time.perf_counter()

            # Optionally rebuild graph (for learned embeddings)
            if (self.rebuild_graph_every > 0 and epoch > 0
                    and epoch % self.rebuild_graph_every == 0):
                self._build_and_propagate(X_train, y_train)
                train_prop_ds = TensorDataset(self._train_h, self._train_y)
                prop_loader = DataLoader(
                    train_prop_ds, batch_size=batch_size, shuffle=True,
                )

            # Train readout head on propagated features
            train_metrics = self._train_epoch_on_propagated(prop_loader)

            # Evaluate on val/test via query attachment
            val_metrics = self._eval_query(self.val_loader, "val")

            # Machine metrics (less frequent)
            machine_metrics = {}
            if epoch % self.log_machine_every == 0:
                machine_metrics = self._compute_dataset_machine_metrics()

            self.scheduler.step()
            elapsed = time.perf_counter() - t0

            all_metrics = {
                **train_metrics,
                **val_metrics,
                **machine_metrics,
                "lr": self.optimizer.param_groups[0]["lr"],
                "epoch_time": elapsed,
            }
            self.metrics_logger.log(all_metrics, step=epoch)

            if epoch % 5 == 0:
                parts = [f"{k}={v:.4f}" for k, v in sorted(all_metrics.items())
                         if isinstance(v, (int, float)) and k != "epoch_time"]
                logger.info(f"E{epoch:4d}/{self.epochs} [{elapsed:.1f}s] {' | '.join(parts[:10])}")

            # Early stopping
            val_loss = val_metrics.get("val/loss", float("inf"))
            if val_loss < self.best_val_loss:
                self.best_val_loss = val_loss
                self.best_epoch = epoch
                self._best_val_acc = val_metrics.get("val/accuracy", None)
                self.patience_counter = 0
                save_checkpoint(
                    self.run_dir / "best.pt",
                    self.model, self.optimizer, epoch, val_metrics,
                )
            else:
                self.patience_counter += 1

            if self.patience_counter >= self.early_stop_patience and epoch > 10:
                logger.info(f"Early stopping at epoch {epoch}")
                break

        # Final save
        save_checkpoint(
            self.run_dir / "final.pt",
            self.model, self.optimizer, epoch, val_metrics,
        )

        # Test eval
        test_metrics = self._eval_query(self.test_loader, "test")
        final_machine = self._compute_dataset_machine_metrics()

        # Compression curve (if requested)
        compression_results = []
        if self.compression_fractions:
            compression_results = self._run_compression_curve(X_train, y_train)

        _t_total_end = _time.perf_counter()

        results = {
            "best_epoch": self.best_epoch,
            "best_val_loss": self.best_val_loss,
            "train": {
                "best_epoch": self.best_epoch,
                "best_val_loss": self.best_val_loss,
                "best_val_accuracy": getattr(self, '_best_val_acc', None),
            },
            "test": test_metrics,
            "machine": final_machine,
            "compression": compression_results,
            "timing": {
                "graph_build_propagate_s": round(_t_graph_end - _t_graph_start, 3),
                "train_s": round(_t_total_end - _t_graph_end, 3),
                "total_s": round(_t_total_end - _t_total_start, 3),
            },
        }
        # Include edit loop log if available
        if hasattr(self.model, '_edit_log') and self.model._edit_log is not None:
            results["edit_log"] = self.model._edit_log
        save_results(self.run_dir / "results.json", results)
        self.metrics_logger.close()
        logger.info(f"Done. Best epoch: {self.best_epoch}, test: {test_metrics}")
        return results

    @torch.no_grad()
    def _run_compression_curve(self, X_train: torch.Tensor, y_train: torch.Tensor) -> list:
        """Evaluate accuracy at various retention fractions.

        Two modes run for each fraction:
          - random: randomly subsample points (baseline)
          - pruning: remove worst-scored points by instability/density

        Writes compression.csv to run_dir.
        """
        import csv
        from ..models.probe import fit_ridge_classifier, predict_logits, accuracy

        logger.info(f"Computing compression curve: fractions={self.compression_fractions}")

        X_val, y_val = self._collect_full_dataset(self.val_loader)
        X_val, y_val = X_val.to(self.device), y_val.to(self.device)

        X_tr = X_train.to(self.device)
        y_tr = y_train.to(self.device)
        N_full = X_tr.shape[0]
        rows = []

        # Compute pruning scores on full graph for pruning-based curve
        pruning_scores = None
        try:
            from ..models.noise_phase2 import compute_node_instability
            ei = self.model._anchor_edge_index
            ew = self.model._anchor_edge_weight
            if ei is not None:
                instab = compute_node_instability(ei, ew, N_full)
                pruning_scores = instab  # higher = worse
        except Exception as e:
            logger.warning(f"Could not compute pruning scores: {e}")

        for frac in self.compression_fractions:
            n_keep = max(1, int(N_full * frac))

            for mode in ["random", "pruning"]:
                if mode == "random":
                    idx = torch.randperm(N_full, device=self.device)[:n_keep]
                elif mode == "pruning" and pruning_scores is not None:
                    # Keep the n_keep MOST stable points (lowest instability)
                    _, sorted_idx = pruning_scores.sort()
                    idx = sorted_idx[:n_keep]
                else:
                    continue

                X_sub = X_tr[idx]
                y_sub = y_tr[idx]

                try:
                    self.model.eval()
                    self.model.build_graph(X_sub, labels=y_sub,
                                          X_val=X_val, y_val=y_val)
                    h_train = self.model.get_propagated_train_features()
                    if h_train is None:
                        continue

                    W = fit_ridge_classifier(h_train, y_sub, self.n_classes)
                    train_logits = predict_logits(h_train, W)
                    train_acc = accuracy(train_logits, y_sub)

                    # Head-based val acc (trained head from full graph)
                    out = self.model(X_val, is_query=True, return_internals=True)
                    head_val_acc = (out["logits"].argmax(1) == y_val).float().mean().item()

                    # Ridge-based val acc (fairer: ridge fit on this subset)
                    h_val_prop = out["propagated"]
                    ridge_val_logits = predict_logits(h_val_prop, W)
                    ridge_val_acc = accuracy(ridge_val_logits, y_val)

                    n_edges = self.model._anchor_edge_index.shape[1] if self.model._anchor_edge_index is not None else 0
                    row = {
                        "mode": mode, "fraction": frac, "n_points": n_keep,
                        "train_acc": train_acc,
                        "ridge_val_acc": ridge_val_acc,
                        "head_val_acc": head_val_acc,
                        "n_edges": n_edges,
                    }
                    rows.append(row)
                    logger.info(f"  {mode} frac={frac:.2f}: n={n_keep}, "
                                f"ridge_val={ridge_val_acc:.4f}, head_val={head_val_acc:.4f}")
                except Exception as e:
                    logger.warning(f"  {mode} frac={frac:.2f}: FAILED — {e}")

        # Rebuild full graph (with val for consistency)
        self.model.build_graph(
            X_tr, labels=y_tr,
            X_val=X_val, y_val=y_val,
        )
        self._train_h = self.model.get_propagated_train_features()
        self._train_y = y_tr

        if rows:
            csv_path = self.run_dir / "compression.csv"
            with open(csv_path, "w", newline="") as f:
                writer = csv.DictWriter(f, fieldnames=rows[0].keys())
                writer.writeheader()
                writer.writerows(rows)
            logger.info(f"Compression curve saved: {csv_path}")

        return rows

    def _train_epoch_on_propagated(self, prop_loader: DataLoader) -> Dict[str, float]:
        """Train readout head on pre-propagated features."""
        self.model.head.train()
        total_loss = 0
        n_batches = 0

        for h_batch, y_batch in prop_loader:
            h_batch = h_batch.to(self.device)
            y_batch = y_batch.to(self.device)

            self.optimizer.zero_grad()
            logits = self.model.head(h_batch)

            if self.task == "classification":
                loss = F.cross_entropy(logits, y_batch)
            else:
                loss = F.mse_loss(logits.squeeze(-1), y_batch.float())

            loss.backward()
            torch.nn.utils.clip_grad_norm_(self.model.head.parameters(), 1.0)
            self.optimizer.step()

            total_loss += loss.item()
            n_batches += 1

        return {"train/loss": total_loss / max(n_batches, 1)}

    @torch.no_grad()
    def _eval_query(self, loader: DataLoader, prefix: str) -> Dict[str, float]:
        """Evaluate by attaching query points to anchor graph."""
        self.model.eval()
        all_logits, all_targets = [], []
        total_loss = 0
        n_batches = 0

        for batch in loader:
            x, y = batch[0].to(self.device), batch[1].to(self.device)
            output = self.model(x, is_query=True)
            logits = output["logits"]

            if self.task == "classification":
                loss = F.cross_entropy(logits, y)
            else:
                loss = F.mse_loss(logits.squeeze(-1), y.float())

            total_loss += loss.item()
            n_batches += 1
            all_logits.append(logits.cpu())
            all_targets.append(y.cpu())

        all_logits = torch.cat(all_logits)
        all_targets = torch.cat(all_targets)
        task_m = compute_task_metrics(all_logits, all_targets, self.task)

        metrics = {f"{prefix}/{k}": v for k, v in task_m.items()}
        metrics[f"{prefix}/loss"] = total_loss / max(n_batches, 1)
        return metrics

    @torch.no_grad()
    def _compute_dataset_machine_metrics(self) -> Dict[str, float]:
        """Compute machine metrics on the actual dataset-level graph."""
        self.model.eval()
        ei = self.model._anchor_edge_index
        ew = self.model._anchor_edge_weight

        if ei is None:
            return {}

        N = self.model._anchor_graph.n_anchors
        ed = self.model._anchor_graph.anchor_edge_dist

        mm = compute_machine_metrics(
            ei, ew, N,
            edge_dist=ed,
            propagated_features=self._train_h,
            original_features=self.model._anchor_graph._anchor_points,
        )
        return {f"machine/{k}": v for k, v in mm.items()}
