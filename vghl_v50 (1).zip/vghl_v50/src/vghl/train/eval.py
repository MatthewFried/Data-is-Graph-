"""Standalone evaluation: task metrics + structural metrics + plots."""
from __future__ import annotations

import torch
from torch.utils.data import DataLoader
from pathlib import Path
from typing import Dict, Any

from ..utils.config import ExperimentConfig
from ..utils.logging import get_logger
from ..utils.io import save_results, load_checkpoint
from ..metrics.task_metrics import compute_task_metrics
from ..metrics.structural import compute_all_structural_metrics
from ..metrics.spectral import compute_laplacian_spectrum, compute_modularity

logger = get_logger("vghl.eval")


@torch.no_grad()
def evaluate_model(
    model,
    loader: DataLoader,
    cfg: ExperimentConfig,
    device: str,
    n_classes: int,
    save_path: str = None,
    compute_structural: bool = True,
    epoch: int = None,
) -> Dict[str, Any]:
    """Full evaluation pipeline.

    Computes task metrics, structural metrics, and spectral diagnostics.

    Args:
        epoch: The epoch to use for temperature annealing. If None, uses
               final epoch (cfg.train.epochs - 1). Critical for correct
               eval when using temp_mode=anneal.
    """
    model.eval()
    model.to(device)

    if epoch is None:
        epoch = cfg.train.epochs - 1

    # Log effective temperature for verification
    if hasattr(model, "partition"):
        temps = model.partition.get_temps(epoch)
        logger.info(f"Eval using epoch={epoch}, temps={temps.detach().cpu().tolist()}")

    all_logits, all_targets, all_rids = [], [], []
    all_x = []

    for batch in loader:
        x, y, rid = [t.to(device) for t in batch]
        output = model(x, epoch=epoch, return_internals=True) if hasattr(model, "partition") else model(x)
        all_logits.append(output["logits"].cpu())
        all_targets.append(y.cpu())
        all_rids.append(rid.cpu())
        all_x.append(x.cpu())

    all_logits = torch.cat(all_logits)
    all_targets = torch.cat(all_targets)
    all_x = torch.cat(all_x)
    all_rids = torch.cat(all_rids)

    # Task metrics
    task_metrics = compute_task_metrics(all_logits, all_targets, cfg.head.task)
    results = {"task": task_metrics}
    logger.info(f"Task metrics: {task_metrics}")

    # Structural metrics (VGHL only)
    if compute_structural and hasattr(model, "partition"):
        X = all_x[:5000].to(device)
        y = all_targets[:5000].to(device)

        output = model(X, epoch=epoch, return_internals=True)
        structural = compute_all_structural_metrics(
            model, output, X, y, n_classes, device
        )
        results["structural"] = structural
        logger.info(f"Effective regions: {structural.get('effective_regions', {})}")

        # Spectral (active regions only)
        spectral_results = {}
        for l, graph in enumerate(output.get("region_graphs", [])):
            adj = graph["adj_dense"]
            active = graph.get("active_mask")
            if active is not None and active.sum() > 2:
                adj_active = adj[active][:, active]
            else:
                adj_active = adj
            spec = compute_laplacian_spectrum(adj_active)
            n_act = active.sum().item() if active is not None else adj.shape[0]
            spectral_results[f"scale_{l}"] = {
                "spectral_gap": spec["spectral_gap"],
                "algebraic_connectivity": spec["algebraic_connectivity"],
                "n_components_approx": spec["n_components_approx"],
                "n_active_regions": int(n_act),
            }
        results["spectral"] = spectral_results
        logger.info(f"Spectral: {spectral_results}")

    if save_path:
        save_results(save_path, results)
        logger.info(f"Results saved to {save_path}")

    return results
