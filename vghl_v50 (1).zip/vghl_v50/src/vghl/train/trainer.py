"""Training loop v2: AMP, gradient accumulation, graph caching, artifact saving."""
from __future__ import annotations

import time, json
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import DataLoader
from torch.amp import autocast, GradScaler
from pathlib import Path
from typing import Dict, Any, Optional
import numpy as np

from ..utils.config import ExperimentConfig
from ..utils.logging import get_logger, MetricsLogger
from ..utils.io import save_checkpoint
from ..losses.regularizers import VGHLLossComputer
from ..metrics.task_metrics import compute_task_metrics
from ..metrics.structural import compute_all_structural_metrics
from ..metrics.spectral import compute_laplacian_spectrum

logger = get_logger("vghl.train")


class Trainer:
    def __init__(self, model, cfg, train_loader, val_loader, test_loader, n_classes, device):
        self.model = model.to(device)
        self.cfg = cfg
        self.train_loader = train_loader
        self.val_loader = val_loader
        self.test_loader = test_loader
        self.n_classes = n_classes
        self.device = device

        tc = cfg.train
        if tc.optimizer == "adam":
            self.optimizer = torch.optim.Adam(model.parameters(), lr=tc.lr, weight_decay=tc.weight_decay)
        elif tc.optimizer == "adamw":
            self.optimizer = torch.optim.AdamW(model.parameters(), lr=tc.lr, weight_decay=tc.weight_decay)
        elif tc.optimizer == "sgd":
            self.optimizer = torch.optim.SGD(model.parameters(), lr=tc.lr, weight_decay=tc.weight_decay, momentum=0.9)
        else:
            raise ValueError(f"Unknown optimizer: {tc.optimizer}")

        if tc.scheduler == "cosine":
            self.scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(self.optimizer, T_max=tc.epochs, eta_min=tc.lr * 0.01)
        elif tc.scheduler == "step":
            self.scheduler = torch.optim.lr_scheduler.StepLR(self.optimizer, step_size=tc.scheduler_step_size, gamma=tc.scheduler_gamma)
        elif tc.scheduler == "plateau":
            self.scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(self.optimizer, mode=tc.early_stop_mode, patience=tc.scheduler_patience, factor=tc.scheduler_gamma)
        else:
            self.scheduler = None

        self.warmup_epochs = tc.warmup_epochs
        self.loss_computer = VGHLLossComputer(cfg)
        self.metrics_logger = MetricsLogger(cfg.run_dir, use_tensorboard=cfg.log.tensorboard)

        # AMP
        self.use_amp = tc.amp and device != "cpu"
        self.scaler = GradScaler('cuda', enabled=self.use_amp)
        self.accum_steps = tc.accum_steps

        # Early stopping
        self.best_metric = float("inf") if tc.early_stop_mode == "min" else float("-inf")
        self.best_epoch = 0
        self.patience_counter = 0

        # CuDNN benchmark
        if tc.benchmark_cudnn and torch.cuda.is_available():
            torch.backends.cudnn.benchmark = True

        # Torch compile
        if tc.torch_compile and hasattr(torch, "compile"):
            try:
                self.model = torch.compile(self.model)
                logger.info("Model compiled with torch.compile")
            except Exception as e:
                logger.warning(f"torch.compile failed: {e}")

        # Set by CLI
        self.max_steps = None
        self.profile = False

        # EMA teacher
        self._ema_teacher = None
        if cfg.ema_teacher.enabled:
            from ..utils.noise import EMATeacher
            self._ema_teacher = EMATeacher(model, cfg.ema_teacher.decay)
            logger.info(f"EMA teacher enabled (decay={cfg.ema_teacher.decay})")

    def _rebuild_optimizer(self, tc):
        """Rebuild optimizer + scheduler to pick up dynamically created parameters."""
        if tc.optimizer == "adam":
            self.optimizer = torch.optim.Adam(self.model.parameters(), lr=tc.lr, weight_decay=tc.weight_decay)
        elif tc.optimizer == "adamw":
            self.optimizer = torch.optim.AdamW(self.model.parameters(), lr=tc.lr, weight_decay=tc.weight_decay)
        elif tc.optimizer == "sgd":
            self.optimizer = torch.optim.SGD(self.model.parameters(), lr=tc.lr, weight_decay=tc.weight_decay, momentum=0.9)
        if tc.scheduler == "cosine":
            self.scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(self.optimizer, T_max=tc.epochs, eta_min=tc.lr * 0.01)
        self.scaler = GradScaler('cuda', enabled=self.use_amp)
        logger.info(f"Optimizer rebuilt to include edge mask params "
                     f"({sum(p.numel() for p in self.model.parameters()):,} total params)")

    def train(self):
        cfg = self.cfg
        tc = cfg.train
        logger.info(f"Training: {tc.epochs} epochs, device={self.device}, "
                     f"params={sum(p.numel() for p in self.model.parameters()):,}, "
                     f"AMP={self.use_amp}, accum={self.accum_steps}")

        val_metrics, train_metrics = {}, {}

        for epoch in range(tc.epochs):
            t0 = time.perf_counter()

            # Clear graph cache if epoch-level refresh
            if hasattr(self.model, "clear_graph_cache"):
                self.model.clear_graph_cache()

            train_metrics = self._train_epoch(epoch)

            # After first epoch, edge mask params may have been created dynamically.
            # Rebuild optimizer to include them.
            if epoch == 0 and cfg.gnn.edge_mask:
                self._rebuild_optimizer(tc)
            val_metrics = self._eval_epoch(self.val_loader, "val", epoch)
            lr = self.optimizer.param_groups[0]["lr"]

            if epoch < self.warmup_epochs:
                warmup_lr = tc.lr * (epoch + 1) / self.warmup_epochs
                for pg in self.optimizer.param_groups:
                    pg["lr"] = warmup_lr
                lr = warmup_lr
            elif self.scheduler is not None:
                if isinstance(self.scheduler, torch.optim.lr_scheduler.ReduceLROnPlateau):
                    self.scheduler.step(val_metrics.get("val/loss", 0))
                else:
                    self.scheduler.step()

            elapsed = max(time.perf_counter() - t0, 0.0)
            all_metrics = {**train_metrics, **val_metrics, "lr": lr, "epoch_time": elapsed}
            self.metrics_logger.log(all_metrics, step=epoch)

            # Log temps and boundary stats
            if hasattr(self.model, "partition") and cfg.log.tensorboard:
                with torch.no_grad():
                    temps = self.model.partition.get_temps(epoch)
                    for l, t in enumerate(temps):
                        self.metrics_logger.log({"temp": t.item()}, step=epoch, prefix=f"scale_{l}")

            if cfg.log.verbose and epoch % cfg.log.log_every == 0:
                parts = [f"{k}={v:.4f}" for k, v in sorted(all_metrics.items())
                         if isinstance(v, (int, float)) and k not in ("epoch_time",)]
                logger.info(f"E{epoch:4d}/{tc.epochs} [{elapsed:.1f}s] {' | '.join(parts[:12])}")

            # Early stopping
            stop_val = val_metrics.get("val/loss", 0)
            for candidate in [tc.early_stop_metric, f"val/{tc.early_stop_metric.replace('val_', '')}"]:
                if candidate in val_metrics:
                    stop_val = val_metrics[candidate]
                    break

            improved = (tc.early_stop_mode == "min" and stop_val < self.best_metric) or \
                       (tc.early_stop_mode == "max" and stop_val > self.best_metric)
            if improved:
                self.best_metric = stop_val
                self.best_epoch = epoch
                self.patience_counter = 0
                if cfg.log.save_checkpoints:
                    save_checkpoint(cfg.run_dir / "best.pt", self.model, self.optimizer, epoch, val_metrics, cfg)
            else:
                self.patience_counter += 1

            if self.patience_counter >= tc.early_stop_patience and epoch > self.warmup_epochs + 10:
                logger.info(f"Early stopping at epoch {epoch}")
                break

            # Periodic plots
            if cfg.log.save_plots and epoch > 0 and epoch % cfg.log.plot_every == 0:
                self._save_periodic_plots(epoch)

            # Periodic artifact save
            if cfg.log.save_artifacts and epoch > 0 and epoch % cfg.log.save_every == 0:
                self._save_artifacts(epoch)

        if cfg.log.save_checkpoints:
            save_checkpoint(cfg.run_dir / "final.pt", self.model, self.optimizer, epoch, val_metrics, cfg)

        if cfg.log.save_plots:
            self._save_final_plots()

        self.metrics_logger.close()
        return {"best_epoch": self.best_epoch, "best_metric": self.best_metric,
                "final_train": train_metrics, "final_val": val_metrics}

    def _train_epoch(self, epoch):
        self.model.train()
        cfg = self.cfg
        nc = cfg.noise
        sc = cfg.stability
        cc = cfg.confidence
        total_losses = {}
        n_batches = 0
        self.optimizer.zero_grad()
        t_profile = {} if self.profile else None
        last_diag = {}
        import math

        # Compute effective noise sigma with warmup
        sigma_eff = 0.0
        if nc.enabled:
            from ..utils.noise import compute_noise_sigma
            sigma_eff = compute_noise_sigma(
                nc.sigma, epoch, cfg.train.epochs, nc.schedule, nc.sigma_min
            )
            # Sigma warmup: ramp from 0
            if nc.sigma_warmup_epochs > 0 and epoch < nc.sigma_warmup_epochs:
                sigma_eff *= (epoch + 1) / nc.sigma_warmup_epochs

        # Effective kappa with warmup
        kappa_eff = nc.boundary_kappa
        if nc.kappa_warmup_epochs > 0 and epoch < nc.kappa_warmup_epochs:
            kappa_eff *= (epoch + 1) / nc.kappa_warmup_epochs

        # Effective stability weight with warmup
        stab_weight_eff = sc.weight
        if sc.warmup_epochs > 0 and epoch < sc.warmup_epochs:
            stab_weight_eff *= (epoch + 1) / sc.warmup_epochs

        for step, batch in enumerate(self.train_loader):
            if self.max_steps is not None and step >= self.max_steps:
                break

            x, y, rid = [t.to(self.device) for t in batch]
            B = x.shape[0]

            if t_profile is not None:
                _t0 = time.perf_counter()

            with autocast('cuda', enabled=self.use_amp):
                # ── 1. Cheap embed+partition pass for alpha computation ──
                # Only runs embed+partition (no pooling/GNN/head).
                # Used to compute boundary scores, perturbations, and alpha.
                external_alpha = {}
                alpha_info = {}
                pert_asgn_list = []
                sigma_info = {}
                noise_boundary_mask = None

                need_pre_pass = (nc.enabled and sigma_eff > 0) or \
                                (cc.mode != "none" and epoch is not None and epoch >= cc.warmup_epochs)

                if need_pre_pass and hasattr(self.model, "partition"):
                    with torch.no_grad():
                        z_pre = self.model.embed(x)
                        part_pre = self.model.partition(z_pre, epoch=epoch)
                        pre_asgn = part_pre["assignments"]  # detached, for alpha/boundary only

                    # ── 2. Perturbations (embed+partition only, no head) ──
                    if nc.enabled and sigma_eff > 0:
                        from ..utils.noise import (
                            compute_boundary_score, compute_per_point_sigma,
                            make_perturbations,
                        )

                        per_point_sigma = None
                        if nc.per_point_mode == "boundary_weighted" and kappa_eff > 0:
                            b_score = compute_boundary_score(
                                pre_asgn[0], nc.boundary_source, detach=True
                            )

                            if nc.boundary_mask_mode == "topk" or nc.boundary_mask_mode == "quantile":
                                frac = nc.boundary_topk_frac if nc.boundary_mask_mode == "topk" else (1.0 - nc.boundary_quantile)
                                k = max(1, min(int(frac * B), B - 1))
                                _, topk_idx = b_score.topk(k)
                                noise_boundary_mask = torch.zeros(B, dtype=torch.bool, device=x.device)
                                noise_boundary_mask[topk_idx] = True
                            else:
                                noise_boundary_mask = b_score >= 0.5

                            per_point_sigma = compute_per_point_sigma(
                                sigma_eff, b_score, kappa_eff
                            )
                            if nc.sigma_boundary_cap > 0:
                                per_point_sigma = per_point_sigma.clamp(max=nc.sigma_boundary_cap)

                            noise_interior_mask = ~noise_boundary_mask
                            sigma_info["sigma_effective_mean"] = per_point_sigma.mean().item()
                            sigma_info["boundary_frac"] = noise_boundary_mask.float().mean().item()
                            sigma_info["interior_frac"] = noise_interior_mask.float().mean().item()
                            if noise_boundary_mask.any():
                                sigma_info["sigma_boundary_mean"] = per_point_sigma[noise_boundary_mask].mean().item()
                            if noise_interior_mask.any():
                                sigma_info["sigma_interior_mean"] = per_point_sigma[noise_interior_mask].mean().item()
                        else:
                            sigma_info["sigma_effective_mean"] = sigma_eff

                        # Generate perturbed assignments (with grad for stability loss)
                        x_perts = make_perturbations(x, sigma_eff, nc.samples, per_point_sigma)
                        for x_p in x_perts:
                            z_p = self.model.embed(x_p)
                            part_p = self.model.partition(z_p, epoch=epoch)
                            pert_asgn_list.append(part_p["assignments"])

                    # ── 3. Confidence alpha (from detached pre-pass assignments) ──
                    if cc.mode != "none" and epoch is not None and epoch >= cc.warmup_epochs:
                        from ..utils.confidence import compute_confidence
                        conf_scales = cfg.parse_scale_list(cc.scales)
                        for l in conf_scales:
                            if l >= len(pre_asgn):
                                continue
                            w = pre_asgn[l]
                            w_perts_l = [pa[l].detach() for pa in pert_asgn_list] if "drift" in cc.mode else None
                            conf = compute_confidence(
                                w, w_perts=w_perts_l,
                                beta_entropy=cc.beta_entropy if "entropy" in cc.mode else 0.0,
                                beta_drift=cc.beta_drift if "drift" in cc.mode else 0.0,
                                alpha_min=cc.alpha_min,
                                detach=True,  # alpha is always detached — it gates, doesn't train
                            )
                            if cc.apply_pooling or cc.apply_pullback:
                                external_alpha[l] = conf["alpha"]
                            if l == cc.task_scale:
                                log_K = math.log(w.shape[1]) if w.shape[1] > 1 else 1.0
                                alpha_info["alpha_mean"] = conf["alpha"].mean().item()
                                alpha_info["alpha_min"] = conf["alpha"].min().item()
                                alpha_info["entropy_mean"] = conf["entropy"].mean().item()
                                alpha_info["entropy_norm_mean"] = (conf["entropy"] / log_K).mean().item()
                                alpha_info["drift_mean"] = conf["drift"].mean().item()

                                bm = noise_boundary_mask if (nc.per_point_mode == "boundary_weighted" and noise_boundary_mask is not None) else None
                                if bm is not None:
                                    if bm.any():
                                        alpha_info["alpha_boundary_mean"] = conf["alpha"][bm].mean().item()
                                    if (~bm).any():
                                        alpha_info["alpha_interior_mean"] = conf["alpha"][~bm].mean().item()

                # ── 4. SINGLE full forward (with alpha injected) ──
                # This is the ONLY forward that contributes to task/peakedness/regularizer losses.
                # Partition runs exactly once with grad, receiving all loss signals.
                if hasattr(self.model, "partition"):
                    output = self.model(
                        x, epoch=epoch, return_internals=True,
                        external_alpha=external_alpha if external_alpha else None,
                    )
                    clean_asgn = output["assignments"]
                    # Set task alpha
                    if cc.apply_task_loss and external_alpha:
                        task_scale = min(cc.task_scale, cfg.partition.L - 1)
                        if task_scale in external_alpha:
                            output["task_alpha"] = external_alpha[task_scale]
                else:
                    output = self.model(x)
                    clean_asgn = None

                if t_profile is not None:
                    t_profile["forward"] = t_profile.get("forward", 0) + (time.perf_counter() - _t0)
                    _t0 = time.perf_counter()

                # ── 5. Task + regularization losses ──
                losses = self.loss_computer(self.model, x, y, output, epoch)

                # ── 6. Stability loss ──
                if sc.enabled and pert_asgn_list and clean_asgn is not None and stab_weight_eff > 0:
                    if not hasattr(self, '_ms_stab_loss'):
                        from ..utils.noise import MultiSampleStabilityLoss
                        self._ms_stab_loss = MultiSampleStabilityLoss(sc.divergence)

                    stab_scales = cfg.parse_scale_list(sc.scales)
                    teacher_asgn = None
                    if "teacher" in sc.target and self._ema_teacher is not None:
                        teacher_asgn = self._ema_teacher.get_assignments(x, epoch)

                    stab_loss, stab_info = self._ms_stab_loss(
                        clean_asgn, pert_asgn_list, stab_scales,
                        target=sc.target, teacher_assignments=teacher_asgn,
                    )
                    losses["stability_new"] = stab_loss * stab_weight_eff
                    losses["total"] = losses["total"] + losses["stability_new"]

                # ── 7. Unweighted task loss (from same forward, no alpha pooling) ──
                if cc.report_unweighted_task and external_alpha:
                    with torch.no_grad():
                        out_noalpha = self.model(x, epoch=epoch)
                        unweighted = F.cross_entropy(out_noalpha["logits"], y).item()
                    losses["task_unweighted"] = unweighted

                # ── 8. Assignment health diagnostics ──
                if clean_asgn is not None:
                    w0 = clean_asgn[0].detach()
                    assign_maxprob = w0.max(dim=-1).values.mean().item()
                    log_K = math.log(w0.shape[1]) if w0.shape[1] > 1 else 1.0
                    assign_entropy_norm = (-(w0 * (w0 + 1e-10).log()).sum(dim=-1) / log_K).mean().item()
                    alpha_info["assign_maxprob_mean"] = assign_maxprob
                    alpha_info["assign_entropy_norm"] = assign_entropy_norm

                # ── 9. Geometry diagnostics (last batch only) ──
                if "region_graphs" in output:
                    for li, graph in enumerate(output["region_graphs"]):
                        adj = graph["adj_dense"].detach()
                        active = graph.get("active_mask")
                        n_act = graph.get("n_active", adj.shape[0])
                        alpha_info[f"geo_s{li}_n_active"] = n_act
                        if active is not None and active.sum() > 1:
                            adj_a = adj[active][:, active]
                        else:
                            adj_a = adj
                        deg = adj_a.sum(dim=1)
                        alpha_info[f"geo_s{li}_deg_mean"] = deg.mean().item()
                        alpha_info[f"geo_s{li}_deg_min"] = deg.min().item()
                        alpha_info[f"geo_s{li}_n_edges"] = (adj_a > 0).sum().item() // 2
                        # Lambda2 (cheap for small m)
                        m_a = adj_a.shape[0]
                        if m_a > 2:
                            deg_inv_sqrt = torch.where(deg > 1e-10, 1.0 / deg.sqrt(), torch.zeros_like(deg))
                            L_sym = torch.eye(m_a, device=adj.device) - torch.diag(deg_inv_sqrt) @ adj_a @ torch.diag(deg_inv_sqrt)
                            eigs = torch.linalg.eigvalsh(L_sym)
                            alpha_info[f"geo_s{li}_lambda2"] = eigs[1].item()

                loss = losses["total"] / self.accum_steps

            self.scaler.scale(loss).backward()

            if t_profile is not None:
                t_profile["backward"] = t_profile.get("backward", 0) + (time.perf_counter() - _t0)

            if (step + 1) % self.accum_steps == 0 or (step + 1) == len(self.train_loader):
                if cfg.train.grad_clip > 0:
                    self.scaler.unscale_(self.optimizer)
                    torch.nn.utils.clip_grad_norm_(self.model.parameters(), cfg.train.grad_clip)
                self.scaler.step(self.optimizer)
                self.scaler.update()
                self.optimizer.zero_grad()

            # EMA teacher update
            if self._ema_teacher is not None and epoch >= cfg.ema_teacher.start_epoch:
                if (step + 1) % cfg.ema_teacher.update_every == 0:
                    self._ema_teacher.update(self.model)

            for k, v in losses.items():
                val = v.item() if isinstance(v, torch.Tensor) else v
                total_losses[k] = total_losses.get(k, 0) + val
            n_batches += 1

            # Capture diagnostics from last batch
            last_diag = {**alpha_info, **sigma_info}
            if "edge_mask_diag" in output:
                for scale, diag in output["edge_mask_diag"].items():
                    for k, v in diag.items():
                        last_diag[f"mask_{scale}_{k}"] = v

        if t_profile and n_batches > 0:
            parts = [f"{k}={v/n_batches*1000:.1f}ms/batch" for k, v in t_profile.items()]
            logger.info(f"Profile E{epoch}: {' | '.join(parts)}")

        result = {f"train/{k}": v / max(n_batches, 1) for k, v in total_losses.items()}
        for k, v in last_diag.items():
            if isinstance(v, float) and math.isnan(v):
                continue  # skip NaN diagnostics
            result[f"train/{k}"] = v
        return result

    @torch.no_grad()
    def _eval_epoch(self, loader, prefix="val", epoch=0):
        self.model.eval()
        all_logits, all_targets = [], []
        total_loss = 0
        n_batches = 0

        for batch in loader:
            x, y, rid = [t.to(self.device) for t in batch]
            output = self.model(x, epoch=epoch) if hasattr(self.model, "partition") else self.model(x)
            if self.cfg.head.task == "classification":
                loss = F.cross_entropy(output["logits"], y)
            else:
                loss = F.mse_loss(output["logits"].squeeze(-1), y.float())
            total_loss += loss.item()
            n_batches += 1
            all_logits.append(output["logits"].cpu())
            all_targets.append(y.cpu())

        all_logits = torch.cat(all_logits)
        all_targets = torch.cat(all_targets)
        task_metrics = compute_task_metrics(all_logits, all_targets, self.cfg.head.task)
        metrics = {f"{prefix}/{k}": v for k, v in task_metrics.items()}
        metrics[f"{prefix}/loss"] = total_loss / max(n_batches, 1)
        return metrics

    @torch.no_grad()
    def _save_artifacts(self, epoch):
        """Save model artifacts: sites, temps, edge masks, adjacency."""
        art_dir = self.cfg.run_dir / "artifacts" / f"epoch_{epoch}"
        art_dir.mkdir(parents=True, exist_ok=True)
        if hasattr(self.model, "partition"):
            np.save(art_dir / "sites.npy", self.model.partition.sites.detach().cpu().numpy())
            np.save(art_dir / "temps.npy", self.model.partition.get_temps(epoch).detach().cpu().numpy())
        if hasattr(self.model, "region_gnns"):
            for l, gnn in enumerate(self.model.region_gnns):
                mask = gnn.get_edge_mask()
                if mask is not None:
                    np.save(art_dir / f"edge_mask_scale_{l}.npy", mask.detach().cpu().numpy())
        logger.info(f"Artifacts saved: {art_dir}")

    def _save_periodic_plots(self, epoch):
        from ..utils.plotting import plot_training_curves
        plot_dir = self.cfg.run_dir / "plots"
        log_path = self.cfg.run_dir / "train_log.jsonl"
        if log_path.exists():
            try:
                plot_training_curves(log_path, plot_dir / f"training_curves_e{epoch}.png")
            except Exception:
                pass

    def _save_final_plots(self):
        from ..utils.plotting import (
            plot_training_curves, plot_stability_curves, plot_region_usage,
            plot_within_vs_between, plot_boundary_visualization_2d,
            plot_laplacian_spectrum, plot_multiscale_assignments, plot_edge_weight_distribution,
        )
        plot_dir = self.cfg.run_dir / "plots"
        log_path = self.cfg.run_dir / "train_log.jsonl"

        if log_path.exists():
            try:
                plot_training_curves(log_path, plot_dir / "training_curves.png")
            except Exception:
                pass

        if not hasattr(self.model, "partition"):
            return

        self.model.eval()
        all_x, all_y, all_rid = [], [], []
        for batch in self.val_loader:
            all_x.append(batch[0])
            all_y.append(batch[1])
            all_rid.append(batch[2])
            if sum(t.shape[0] for t in all_x) > 5000:
                break
        X = torch.cat(all_x)[:5000].to(self.device)
        y = torch.cat(all_y)[:5000]
        rid = torch.cat(all_rid)[:5000]

        with torch.no_grad():
            output = self.model(X, return_internals=True)

        try:
            stability = compute_all_structural_metrics(
                self.model, output, X, y.to(self.device), self.n_classes, self.device)
            if "stability_curves" in stability:
                plot_stability_curves(stability["stability_curves"], plot_dir / "stability_curves.png")
            if "region_usage" in stability:
                plot_region_usage(stability["region_usage"], plot_dir / "region_usage.png")
            if "label_agreement" in stability:
                scales = sorted(stability["label_agreement"].keys())
                within = [stability["label_agreement"][s]["within"] for s in scales]
                between = [stability["label_agreement"][s]["between"] for s in scales]
                plot_within_vs_between(within, between, scales, plot_dir / "within_vs_between.png")
            # Save structural metrics JSON
            from ..utils.io import save_results
            save_results(self.cfg.run_dir / "structural_metrics.json", stability)
        except Exception as e:
            logger.warning(f"Structural metrics failed: {e}")

        if X.shape[1] == 2:
            try:
                hard_asgn = output["hard_assignments"][0].detach().cpu().numpy()
                pts = X.detach().cpu().numpy()
                sites = output["sites"].detach().cpu().numpy() if output["sites"].shape[1] == 2 else None
                plot_boundary_visualization_2d(
                    pts, hard_asgn, sites, y.detach().cpu().numpy(), plot_dir / "boundary_2d.png",
                    gt_labels=rid.detach().cpu().numpy())
                asgn_dict = {f"scale_{l}": output["hard_assignments"][l].detach().cpu().numpy()
                             for l in range(len(output["hard_assignments"]))}
                plot_multiscale_assignments(pts, asgn_dict, plot_dir / "multiscale_2d.png")
            except Exception as e:
                logger.warning(f"2D viz failed: {e}")

        try:
            for l, graph in enumerate(output["region_graphs"]):
                adj = graph["adj_dense"]
                spec = compute_laplacian_spectrum(adj)
                plot_laplacian_spectrum(spec["eigenvalues"], plot_dir / f"laplacian_scale_{l}.png")
                weights = adj[adj > 0].detach().cpu().numpy()
                if len(weights) > 0:
                    plot_edge_weight_distribution(weights, plot_dir / f"edge_weights_scale_{l}.png")
        except Exception as e:
            logger.warning(f"Spectral diagnostics failed: {e}")
