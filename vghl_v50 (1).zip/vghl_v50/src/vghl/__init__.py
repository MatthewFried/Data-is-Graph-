"""Voronoi-Induced Hierarchical Graph Learning."""
__version__ = "0.1.0"
