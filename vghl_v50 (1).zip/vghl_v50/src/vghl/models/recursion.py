"""Recursion: multi-level graph construction from primitives.

Implements the primitive → supergraph → multilevel propagation pipeline.
Phase 1: basic single-level contraction + supergraph wiring.
Phase 2: full recursive depth.

Pipeline:
  1. contract_primitives: assign nodes to supernodes via primitives
  2. wire_supergraph: connect supernodes via port proximity
  3. build_multilevel_graph: compose levels into a hierarchy
"""
from __future__ import annotations

import logging
import torch
import numpy as np
from typing import Dict, List, Tuple, Optional
from dataclasses import dataclass, field

from .primitives import Primitive

logger = logging.getLogger(__name__)


@dataclass
class RecursionConfig:
    """Configuration for multilevel recursion."""
    enabled: bool = False
    depth: int = 1                    # number of recursion levels
    port_rule: str = "endpoints"      # endpoints | centroid | all
    wiring_rule: str = "port_knn"     # port_knn | shared_boundary
    wiring_k: int = 4                 # k for port-based kNN wiring
    pool_mode: str = "mean"           # mean | max | attention
    scatter_mode: str = "add"         # add | replace


@dataclass
class LevelGraph:
    """Graph at one level of the hierarchy."""
    edge_index: torch.Tensor          # (2, E_l)
    edge_weight: torch.Tensor         # (E_l,)
    membership: torch.Tensor          # (N_{l-1},) mapping to this level
    n_nodes: int                      # N_l
    ports: Optional[torch.Tensor] = None  # (N_l, max_ports) port node indices


def contract_primitives(
    primitives: List[Primitive],
    N: int,
    points: torch.Tensor,
    port_rule: str = "boundary_top2",
    edge_index: Optional[torch.Tensor] = None,
) -> Tuple[torch.Tensor, torch.Tensor, int]:
    """Contract base nodes into supernodes via primitive membership.

    Each primitive becomes a supernode. Nodes not in any primitive
    become singleton supernodes. Uses greedy non-overlap by quality.

    Args:
        primitives: list of Primitive objects with .nodes and .ports.
        N: number of base-level nodes.
        points: (N, d) point coordinates.
        port_rule: how to select port nodes per supernode (from port registry).
        edge_index: (2, E) base graph edges, needed for boundary port rules.

    Returns:
        membership: (N,) long tensor mapping node → supernode index.
        port_indices: (n_super, max_ports) port node indices, padded with -1.
        n_super: number of supernodes.
    """
    from .ports import compute_ports
    from .primitives import _build_adj_list

    device = points.device

    # Sort primitives by quality descending for greedy non-overlap
    sorted_prims = sorted(primitives, key=lambda p: p.quality, reverse=True)

    # Build adjacency for boundary-based port rules
    adj = None
    if edge_index is not None and port_rule in ("boundary_top2", "boundary_topk"):
        adj = _build_adj_list(edge_index, N)

    membership = torch.full((N,), -1, dtype=torch.long, device=device)
    port_list: List[List[int]] = []

    super_idx = 0
    for prim in sorted_prims:
        nodes = prim.nodes
        # Only accept if ALL members are unassigned (strict greedy non-overlap)
        if any(membership[n] != -1 for n in nodes):
            continue

        for n in nodes:
            membership[n] = super_idx

        # Compute ports via registry
        ports = compute_ports(nodes, points, adj, rule=port_rule)
        port_list.append(ports)
        super_idx += 1

    # Singleton supernodes for unassigned nodes
    unassigned_mask = membership == -1
    unassigned_nodes = unassigned_mask.nonzero(as_tuple=True)[0]
    for node in unassigned_nodes:
        membership[node] = super_idx
        port_list.append([node.item()])
        super_idx += 1

    n_super = super_idx

    # Pad port indices
    max_ports = max(len(p) for p in port_list) if port_list else 1
    port_indices = torch.full((n_super, max_ports), -1, dtype=torch.long, device=device)
    for i, ports in enumerate(port_list):
        for j, p in enumerate(ports[:max_ports]):
            port_indices[i, j] = p

    return membership, port_indices, n_super


def wire_supergraph(
    port_indices: torch.Tensor,
    points: torch.Tensor,
    n_super: int,
    wiring_rule: str = "port_knn",
    wiring_k: int = 4,
    base_edge_index: Optional[torch.Tensor] = None,
    membership: Optional[torch.Tensor] = None,
) -> Tuple[torch.Tensor, torch.Tensor]:
    """Wire supernodes into a supergraph via their ports.

    Args:
        port_indices: (n_super, max_ports) port node indices.
        points: (N, d) base-level coordinates.
        n_super: number of supernodes.
        wiring_rule: connection strategy.
        wiring_k: k for kNN-based wiring.

    Returns:
        super_edge_index: (2, E_super)
        super_edge_weight: (E_super,)
    """
    device = points.device

    if wiring_rule == "port_knn":
        # Represent each supernode by mean of its port coordinates
        super_coords = torch.zeros(n_super, points.shape[1], device=device)
        counts = torch.zeros(n_super, device=device)
        for i in range(n_super):
            valid_ports = port_indices[i][port_indices[i] >= 0]
            if len(valid_ports) > 0:
                super_coords[i] = points[valid_ports].mean(dim=0)
                counts[i] = len(valid_ports)
            # else: stays at origin (degenerate case)

        # kNN on supernode coordinates
        from .knn_backend import knn, knn_to_edge_index
        k = min(wiring_k, n_super - 1)
        if k <= 0:
            return (
                torch.zeros(2, 0, dtype=torch.long, device=device),
                torch.zeros(0, device=device),
            )
        indices, distances = knn(super_coords, k)
        edge_index, edge_dist = knn_to_edge_index(indices, distances, device=device)

        # Weights: Gaussian
        if edge_dist.numel() > 0:
            median_d = edge_dist[edge_dist > 0].median() if (edge_dist > 0).any() else 1.0
            sigma_sq = float(median_d) ** 2 + 1e-8
            edge_weight = torch.exp(-edge_dist ** 2 / (2 * sigma_sq))
        else:
            edge_weight = torch.ones_like(edge_dist)

        return edge_index, edge_weight

    elif wiring_rule == "shared_boundary":
        # Connect supernodes whose children share edges in the base graph
        src_list, dst_list, w_list = [], [], []
        seen = set()

        if base_edge_index is not None and membership is not None:
            # Use actual base-graph edges: connect super_A and super_B
            # if any edge (u, v) exists where membership[u]=A, membership[v]=B
            src_base = base_edge_index[0]
            dst_base = base_edge_index[1]
            super_src = membership[src_base]
            super_dst = membership[dst_base]
            # Filter cross-supernode edges
            cross = super_src != super_dst
            cross_src = super_src[cross]
            cross_dst = super_dst[cross]

            # Unique super-edges with weight = count of base edges
            for i in range(cross_src.shape[0]):
                a, b = cross_src[i].item(), cross_dst[i].item()
                key = (min(a, b), max(a, b))
                if key not in seen:
                    seen.add(key)
                    src_list.extend([a, b])
                    dst_list.extend([b, a])
                    w_list.extend([1.0, 1.0])
        else:
            # Fallback: shared port membership
            port_to_super = {}
            for i in range(n_super):
                for p in port_indices[i]:
                    p_val = p.item()
                    if p_val >= 0:
                        port_to_super.setdefault(p_val, set()).add(i)

            for port_node, supers in port_to_super.items():
                supers = sorted(supers)
                for a in supers:
                    for b in supers:
                        if a < b and (a, b) not in seen:
                            seen.add((a, b))
                            src_list.extend([a, b])
                            dst_list.extend([b, a])
                            w_list.extend([1.0, 1.0])

        if not src_list:
            return (
                torch.zeros(2, 0, dtype=torch.long, device=device),
                torch.zeros(0, device=device),
            )

        edge_index = torch.tensor([src_list, dst_list], dtype=torch.long, device=device)
        edge_weight = torch.tensor(w_list, dtype=torch.float32, device=device)
        return edge_index, edge_weight

    else:
        raise ValueError(f"Unknown wiring_rule: {wiring_rule}")


def pool_to_supernodes(
    h: torch.Tensor,
    membership: torch.Tensor,
    n_super: int,
    mode: str = "mean",
) -> torch.Tensor:
    """Pool base-level features to supernode representations.

    Args:
        h: (N, d) base node features.
        membership: (N,) supernode assignment.
        n_super: number of supernodes.
        mode: 'mean' | 'max'.

    Returns:
        h_super: (n_super, d) supernode features.
    """
    d = h.shape[1]
    device = h.device

    if mode == "mean":
        h_super = torch.zeros(n_super, d, device=device)
        counts = torch.zeros(n_super, 1, device=device)
        h_super.scatter_add_(0, membership.unsqueeze(1).expand_as(h), h)
        counts.scatter_add_(0, membership.unsqueeze(1), torch.ones(h.shape[0], 1, device=device))
        h_super = h_super / counts.clamp(min=1)
    elif mode == "max":
        h_super = torch.full((n_super, d), float("-inf"), device=device)
        h_super.scatter_reduce_(0, membership.unsqueeze(1).expand_as(h), h, reduce="amax")
        h_super = torch.where(h_super == float("-inf"), torch.zeros_like(h_super), h_super)
    else:
        raise ValueError(f"Unknown pool_mode: {mode}")

    return h_super


def scatter_to_base(
    h_super: torch.Tensor,
    membership: torch.Tensor,
    mode: str = "add",
    h_base: Optional[torch.Tensor] = None,
) -> torch.Tensor:
    """Scatter supernode features back to base nodes.

    Args:
        h_super: (n_super, d) supernode features.
        membership: (N,) supernode assignment.
        mode: 'add' (add to base) | 'replace' (replace base).
        h_base: (N, d) original base features (needed for 'add' mode).

    Returns:
        h_out: (N, d) base-level features with supernode info.
    """
    h_scattered = h_super[membership]  # (N, d)

    if mode == "replace" or h_base is None:
        return h_scattered
    elif mode == "add":
        return h_base + h_scattered
    else:
        raise ValueError(f"Unknown scatter_mode: {mode}")


def build_multilevel_graph(
    points: torch.Tensor,
    base_edge_index: torch.Tensor,
    base_edge_weight: torch.Tensor,
    primitives: List[Primitive],
    cfg: RecursionConfig,
) -> List[LevelGraph]:
    """Build multi-level graph hierarchy from primitives.

    Level 0 = base graph.
    Level 1+ = contracted supergraphs.

    Args:
        points: (N, d) base coordinates.
        base_edge_index: (2, E) base edges.
        base_edge_weight: (E,) base weights.
        primitives: list of detected primitives.
        cfg: RecursionConfig.

    Returns:
        List of LevelGraph objects, one per level.
    """
    levels = []

    # Level 0: base graph
    levels.append(LevelGraph(
        edge_index=base_edge_index,
        edge_weight=base_edge_weight,
        membership=torch.arange(points.shape[0], device=points.device),
        n_nodes=points.shape[0],
    ))

    if not cfg.enabled or not primitives:
        return levels

    current_points = points
    current_prims = primitives

    for depth in range(cfg.depth):
        N_current = current_points.shape[0]

        # Contract
        membership, port_indices, n_super = contract_primitives(
            current_prims, N_current, current_points, cfg.port_rule,
            edge_index=levels[-1].edge_index,
        )

        if n_super <= 1:
            logger.info(f"Recursion depth {depth}: only {n_super} supernodes, stopping")
            break

        # Wire supergraph
        super_ei, super_ew = wire_supergraph(
            port_indices, current_points, n_super,
            cfg.wiring_rule, cfg.wiring_k,
            base_edge_index=levels[-1].edge_index,
            membership=membership,
        )

        # Compute supernode coordinates for next level
        super_coords = pool_to_supernodes(
            current_points, membership, n_super, mode="mean"
        )

        levels.append(LevelGraph(
            edge_index=super_ei,
            edge_weight=super_ew,
            membership=membership,
            n_nodes=n_super,
            ports=port_indices,
        ))

        # Prepare for next level (no primitives at higher levels yet)
        current_points = super_coords
        current_prims = []  # TODO: induce primitives at supergraph level

    logger.info(f"Built {len(levels)} levels: {[l.n_nodes for l in levels]} nodes")
    return levels


def recursion_config_from_dict(d: dict) -> RecursionConfig:
    """Parse RecursionConfig from a YAML dict."""
    cfg = RecursionConfig()
    for k, v in d.items():
        if hasattr(cfg, k):
            setattr(cfg, k, v)
    return cfg
