"""Port Rules: define interface nodes for contracted primitives.

Ports determine how supernodes wire to each other in the supergraph.
Each port rule maps a primitive's member nodes to a subset that acts
as the "interface" or "boundary" of the contracted unit.

Registry-based so new rules can be added via @register_port_rule.
"""
from __future__ import annotations

import torch
import numpy as np
from typing import List, Optional

PORT_RULE_REGISTRY = {}


def register_port_rule(name):
    def decorator(fn):
        PORT_RULE_REGISTRY[name] = fn
        return fn
    return decorator


def compute_ports(
    member_nodes: List[int],
    points: torch.Tensor,
    adj: Optional[List[set]],
    rule: str = "boundary_top2",
    max_ports: int = 4,
) -> List[int]:
    """Compute port nodes for a primitive.

    Args:
        member_nodes: node indices belonging to this primitive.
        points: (N, d) all point coordinates.
        adj: adjacency list of the base graph (needed for boundary rules).
        rule: port rule name from registry.
        max_ports: maximum number of ports to return.

    Returns:
        List of node indices designated as ports.
    """
    if rule not in PORT_RULE_REGISTRY:
        raise ValueError(f"Unknown port rule '{rule}'. Available: {list(PORT_RULE_REGISTRY.keys())}")
    return PORT_RULE_REGISTRY[rule](member_nodes, points, adj, max_ports)


@register_port_rule("boundary_top2")
def _boundary_top2(members: List[int], points: torch.Tensor, adj: Optional[List[set]], max_ports: int) -> List[int]:
    return _boundary_topk(members, points, adj, min(max_ports, 2))


@register_port_rule("boundary_topk")
def _boundary_topk_rule(members: List[int], points: torch.Tensor, adj: Optional[List[set]], max_ports: int) -> List[int]:
    return _boundary_topk(members, points, adj, max_ports)


def _boundary_topk(members: List[int], points: torch.Tensor, adj: Optional[List[set]], k: int) -> List[int]:
    """Top-k members with highest external degree (edges leaving the primitive)."""
    if adj is None or len(members) <= k:
        return members[:k]
    member_set = set(members)
    # Count external edges per member
    ext_deg = []
    for m in members:
        ext = sum(1 for nb in adj[m] if nb not in member_set)
        ext_deg.append((ext, m))
    ext_deg.sort(reverse=True)
    return [m for _, m in ext_deg[:k]]


@register_port_rule("medoid")
def _medoid(members: List[int], points: torch.Tensor, adj: Optional[List[set]], max_ports: int) -> List[int]:
    """Member with minimal average distance to other members."""
    if len(members) <= 1:
        return members
    pts = points[members]
    # Pairwise distances within primitive
    dists = torch.cdist(pts.unsqueeze(0), pts.unsqueeze(0)).squeeze(0)  # (M, M)
    mean_dists = dists.mean(dim=1)
    medoid_local = mean_dists.argmin().item()
    return [members[medoid_local]]


@register_port_rule("farthest_pair")
def _farthest_pair(members: List[int], points: torch.Tensor, adj: Optional[List[set]], max_ports: int) -> List[int]:
    """Two members with maximal pairwise distance."""
    if len(members) <= 2:
        return members
    pts = points[members]
    dists = torch.cdist(pts.unsqueeze(0), pts.unsqueeze(0)).squeeze(0)
    flat_idx = dists.argmax().item()
    i, j = flat_idx // len(members), flat_idx % len(members)
    return [members[i], members[j]]


@register_port_rule("all_vertices")
def _all_vertices(members: List[int], points: torch.Tensor, adj: Optional[List[set]], max_ports: int) -> List[int]:
    """Every member is a port."""
    return members[:max_ports]


@register_port_rule("endpoints")
def _endpoints(members: List[int], points: torch.Tensor, adj: Optional[List[set]], max_ports: int) -> List[int]:
    """First and last member (for paths/sequences); fallback to boundary_top2."""
    if len(members) <= 2:
        return members
    return [members[0], members[-1]]
