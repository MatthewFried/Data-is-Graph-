"""VGHL Model v2: hierarchical point→region graph with boundary-aware learning.

Architecture (Approach 2):
  1. Point embedding: x_i → z_i
  2. Soft Voronoi partition: z_i → {w_i^(l)} multi-scale
  3. Boundary detection from assignment entropy/margin
  4. Point-level kNN graph with boundary-modulated edges
  5. Point-level GNN (message passing among points)
  6. Soft-pool points → region supernodes via w
  7. Region graph from shared boundary mass / co-activation
  8. Region-level GNN (message passing among regions)
  9. Unpool: region info back to points
  10. Concat [point_mp_output, unpooled_region_output, multi-scale] → head

Key difference from v1: points are first-class graph nodes; regions are
supernodes; boundary points get explicit handling.
"""
from __future__ import annotations

import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
from typing import Dict, Any, Optional, List

from ..utils.config import ExperimentConfig
from .embed import PointEmbedding
from .partition import SoftVoronoiPartition
from .point_graph import (
    build_point_knn, detect_boundary_points, modulate_edges, PointGNN,
)
from .region_graph import RegionGraphBuilder
from .region_gnn import RegionGNN
from .head import PredictionHead


from ..utils.confidence import compute_confidence


class VGHLModel(nn.Module):
    """Voronoi-Induced Hierarchical Graph Learning — v3.

    Two-level hierarchy: point graph (bottom) + region graph (top).
    Confidence weighting: noisy/uncertain points get reduced influence
    in pooling, task loss, and optionally pullback.
    """

    def __init__(self, input_dim: int, n_classes: int, cfg: ExperimentConfig):
        super().__init__()
        self.cfg = cfg
        self.input_dim = input_dim
        self.n_classes = n_classes

        # 1. Point embedding
        self.embed = PointEmbedding(input_dim, cfg.embed)
        embed_dim = self.embed.embed_dim

        # 2. Feature transform (content for aggregation, separate from geometry)
        self.feature_transform = nn.Sequential(
            nn.Linear(input_dim, embed_dim),
            nn.ReLU(),
            nn.Linear(embed_dim, embed_dim),
        )

        # 3. Soft Voronoi partition
        self.partition = SoftVoronoiPartition(embed_dim, cfg.partition)

        # 4. Point-level GNN (if enabled)
        self.point_gnn = None
        if cfg.point_graph.enabled:
            self.point_gnn = PointGNN(
                embed_dim, cfg.point_graph, gat_heads=cfg.gnn.gat_heads
            )

        # 5. Region graph builder
        self.graph_builder = RegionGraphBuilder(cfg.partition.m, cfg.region_graph)

        # 6. Region-level GNNs (one per scale)
        self.region_gnns = nn.ModuleList()
        for l in range(cfg.partition.L):
            gnn = RegionGNN(embed_dim, cfg.gnn)
            if cfg.gnn.edge_mask:
                gnn.init_edge_mask(cfg.partition.m)
            self.region_gnns.append(gnn)

        # Output dimensions
        gnn_out_dim = self.region_gnns[0].out_dim if cfg.partition.L > 0 else embed_dim
        point_out_dim = self.point_gnn.out_dim if self.point_gnn else 0

        # Total dim = point_gnn_out + L * region_gnn_out
        total_dim = point_out_dim + gnn_out_dim * cfg.partition.L

        # 7. Prediction head
        self.head = PredictionHead(total_dim, n_classes, cfg.head)

        # Graph caching for epoch-level refresh
        self._cached_region_graphs: Optional[List[Dict]] = None
        self._cache_epoch: int = -1

    def forward(
        self,
        x: torch.Tensor,
        epoch: Optional[int] = None,
        return_internals: bool = False,
        external_alpha: Optional[Dict[int, torch.Tensor]] = None,
    ) -> Dict[str, Any]:
        B = x.shape[0]
        cfg = self.cfg
        cc = cfg.confidence

        # ── 1. Embed ──
        z = self.embed(x)
        u = self.feature_transform(x)

        # ── 2. Partition ──
        part_out = self.partition(z, epoch=epoch)
        assignments = part_out["assignments"]
        hard_asgn = part_out["hard_assignments"]

        # ── 3. Alpha (confidence) ──
        # Use external alpha if provided (from trainer's perturbation pipeline),
        # otherwise compute from entropy only (no internal perturbation).
        confidence_active = (cc.mode != "none" and
                             epoch is not None and
                             epoch >= cc.warmup_epochs)

        alphas = external_alpha if external_alpha is not None else {}

        # If no external alpha but confidence is active, compute entropy-only alpha
        if confidence_active and not alphas and "entropy" in cc.mode:
            conf_scales = cfg.parse_scale_list(cc.scales)
            for l in conf_scales:
                if l >= len(assignments):
                    continue
                conf = compute_confidence(
                    assignments[l],
                    beta_entropy=cc.beta_entropy,
                    beta_drift=0.0,
                    alpha_min=cc.alpha_min,
                    detach=cc.detach,
                )
                alphas[l] = conf["alpha"]

        def _get_alpha(l):
            if confidence_active and l in alphas:
                return alphas[l]
            return torch.ones(B, device=x.device)

        # ── 4. Boundary detection ──
        is_boundary, boundary_score = detect_boundary_points(
            assignments[0],
            mode=cfg.boundary.mode,
            threshold=cfg.boundary.threshold,
            frac=cfg.boundary.frac,
        )

        # ── 5. Point-level graph + GNN ──
        point_out = None
        point_edge_index = None
        point_edge_weight = None
        if self.point_gnn is not None:
            point_edge_index, point_edge_dist = build_point_knn(z, cfg.point_graph.k)
            if cfg.point_graph.modulate_edges and cfg.boundary.mode != "none":
                point_edge_weight = modulate_edges(
                    point_edge_index, is_boundary, cfg.boundary
                )
            else:
                point_edge_weight = torch.ones(
                    point_edge_index.shape[1], device=x.device
                )
            point_out = self.point_gnn(u, point_edge_index, point_edge_weight)

        # ── 6–8. Confidence-weighted pool → region graph → GNN → unpool ──
        pullback_list = []
        region_graphs = []
        region_embeds_list = []

        use_cache = (cfg.region_graph.graph_refresh == "epoch" and
                     self._cached_region_graphs is not None and
                     self._cache_epoch == epoch)

        for l in range(cfg.partition.L):
            w = assignments[l]
            alpha_l = _get_alpha(l)
            pool_features = point_out if point_out is not None else u
            pool_mode = cfg.region_graph.pool_mode

            # Confidence-weighted pooling
            if confidence_active and cc.apply_pooling and l in alphas:
                w_weighted = w * alpha_l.unsqueeze(1)
            else:
                w_weighted = w

            if pool_mode == "soft":
                mass = w_weighted.sum(dim=0, keepdim=True).clamp(min=1e-8)
                h = (w_weighted.t() @ pool_features) / mass.t()
            elif pool_mode == "top1":
                hard = w.argmax(dim=-1)
                h = torch.zeros(cfg.partition.m, pool_features.shape[1], device=x.device)
                counts = torch.zeros(cfg.partition.m, device=x.device)
                feat_w = pool_features * alpha_l.unsqueeze(1) if (confidence_active and cc.apply_pooling and l in alphas) else pool_features
                h.scatter_add_(0, hard.unsqueeze(-1).expand_as(feat_w), feat_w)
                count_w = alpha_l if (confidence_active and cc.apply_pooling and l in alphas) else torch.ones(B, device=x.device)
                counts.scatter_add_(0, hard, count_w)
                h = h / counts.clamp(min=1).unsqueeze(-1)
            elif pool_mode == "topk":
                topk_w, topk_idx = w.topk(cfg.region_graph.pool_topk, dim=-1)
                topk_w = topk_w / topk_w.sum(dim=-1, keepdim=True).clamp(min=1e-8)
                if confidence_active and cc.apply_pooling and l in alphas:
                    topk_w = topk_w * alpha_l.unsqueeze(1)
                h = torch.zeros(cfg.partition.m, pool_features.shape[1], device=x.device)
                mass_topk = torch.zeros(cfg.partition.m, device=x.device)
                for ki in range(cfg.region_graph.pool_topk):
                    idx = topk_idx[:, ki]
                    wt = topk_w[:, ki]
                    weighted = pool_features * wt.unsqueeze(-1)
                    h.scatter_add_(0, idx.unsqueeze(-1).expand_as(weighted), weighted)
                    mass_topk.scatter_add_(0, idx, wt)
                h = h / mass_topk.clamp(min=1e-8).unsqueeze(-1)
            else:
                raise ValueError(f"Unknown pool_mode: {pool_mode}")

            # Region graph
            if use_cache:
                graph = self._cached_region_graphs[l]
            else:
                graph = self.graph_builder(w, part_out["sites"], is_boundary=is_boundary)
            region_graphs.append(graph)

            # Consensus gate: attenuate edges by region embedding similarity
            adj_eff = graph["adj_dense"]
            if cfg.gnn.consensus_gate and h.shape[0] > 1:
                h_norm = F.normalize(h, dim=-1)
                sim = h_norm @ h_norm.t()  # cosine similarity in [-1, 1]
                disagreement = (1 - sim).clamp(min=0) / 2  # in [0, 1]
                gate = torch.exp(-cfg.gnn.consensus_tau * disagreement)
                adj_eff = adj_eff * gate

            # Region GNN
            if cfg.gnn.layers > 0:
                h_tilde = self.region_gnns[l](
                    h, adj_eff, edge_index=graph["edge_index"]
                )
            else:
                h_tilde = h
            region_embeds_list.append(h_tilde)

            # Unpool + optional confidence scaling
            v = w @ h_tilde
            if confidence_active and cc.apply_pullback and l in alphas:
                v = v * alpha_l.unsqueeze(1)
            pullback_list.append(v)

        # Cache
        if cfg.region_graph.graph_refresh == "epoch" and not use_cache:
            self._cached_region_graphs = [
                {k: v.detach() for k, v in g.items()} for g in region_graphs
            ]
            self._cache_epoch = epoch

        # ── 9. Concatenate and predict ──
        parts = []
        if point_out is not None:
            parts.append(point_out)
        parts.extend(pullback_list)
        v_cat = torch.cat(parts, dim=-1)
        logits = self.head(v_cat)

        # Task-loss alpha
        task_scale = min(cc.task_scale, cfg.partition.L - 1)
        if confidence_active and cc.apply_task_loss and task_scale in alphas:
            task_alpha = alphas[task_scale]
        else:
            task_alpha = torch.ones(B, device=x.device)

        result = {
            "logits": logits,
            "assignments": assignments,
            "hard_assignments": hard_asgn,
            "region_graphs": region_graphs,
            "sites": part_out["sites"],
            "temps": part_out["temps"],
            "dists": part_out["dists"],
            "is_boundary": is_boundary,
            "boundary_score": boundary_score,
            "task_alpha": task_alpha,
        }

        if return_internals:
            result.update({
                "embeddings": z,
                "features": u,
                "point_out": point_out,
                "point_edge_index": point_edge_index,
                "point_edge_weight": point_edge_weight,
                "region_embeds": region_embeds_list,
                "pullbacks": pullback_list,
                "v_cat": v_cat,
            })

            # Edge mask diagnostics (sparse edge-vector)
            if hasattr(self, "region_gnns") and cfg.gnn.edge_mask:
                mask_diag = {}
                for l, gnn in enumerate(self.region_gnns):
                    vals = gnn.get_edge_mask_values()  # (E,) sigmoid values
                    if vals is not None and vals.numel() > 0:
                        mask_diag[f"scale_{l}"] = {
                            "mask_mean": vals.mean().item(),
                            "mask_min": vals.min().item(),
                            "mask_max": vals.max().item(),
                            "mask_std": vals.std().item() if vals.numel() > 1 else 0,
                            "frac_below_0.5": (vals < 0.5).float().mean().item(),
                            "frac_below_0.3": (vals < 0.3).float().mean().item(),
                            "frac_below_0.1": (vals < 0.1).float().mean().item(),
                            "n_edges": vals.numel(),
                        }
                result["edge_mask_diag"] = mask_diag

        return result

    def init_sites(self, dataloader, device: str):
        all_z = []
        with torch.no_grad():
            for batch in dataloader:
                x = batch[0].to(device)
                z = self.embed(x)
                all_z.append(z.cpu())
                if sum(t.shape[0] for t in all_z) > 50000:
                    break
        all_z = torch.cat(all_z, dim=0)
        self.partition.init_sites_from_data(all_z, method=self.cfg.partition.init_sites)

    def clear_graph_cache(self):
        self._cached_region_graphs = None
        self._cache_epoch = -1


# ════════════════════════════════════════════════════════════════
# Baselines
# ════════════════════════════════════════════════════════════════

class MLPBaseline(nn.Module):
    def __init__(self, input_dim: int, n_classes: int, cfg: ExperimentConfig):
        super().__init__()
        hidden = cfg.head.hidden_sizes
        layers: list = []
        d_in = input_dim
        for h in hidden:
            layers.extend([nn.Linear(d_in, h), nn.ReLU(), nn.Dropout(cfg.head.dropout)])
            d_in = h
        out_dim = n_classes if cfg.head.task == "classification" else 1
        layers.append(nn.Linear(d_in, out_dim))
        self.net = nn.Sequential(*layers)

    def forward(self, x, **kw):
        return {"logits": self.net(x)}


class PointGNNBaseline(nn.Module):
    """GNN directly on point kNN graph (no regions)."""

    def __init__(self, input_dim: int, n_classes: int, cfg: ExperimentConfig):
        super().__init__()
        self.embed = PointEmbedding(input_dim, cfg.embed)
        self.point_gnn = PointGNN(self.embed.embed_dim, cfg.point_graph, gat_heads=cfg.gnn.gat_heads)
        head_hidden = cfg.head.hidden_sizes[0] if cfg.head.hidden_sizes else 64
        out_dim = n_classes if cfg.head.task == "classification" else 1
        self.head = nn.Sequential(
            nn.Linear(self.point_gnn.out_dim, head_hidden),
            nn.ReLU(), nn.Dropout(cfg.head.dropout),
            nn.Linear(head_hidden, out_dim),
        )
        self.k = cfg.point_graph.k

    def forward(self, x, **kw):
        z = self.embed(x)
        edge_index, _ = build_point_knn(z, self.k)
        h = self.point_gnn(z, edge_index)
        return {"logits": self.head(h)}


class FixedClusterGNNBaseline(nn.Module):
    """Frozen k-means partition + region GNN (tests if learning geometry matters)."""

    def __init__(self, input_dim: int, n_classes: int, cfg: ExperimentConfig):
        super().__init__()
        self.cfg = cfg
        self.embed = PointEmbedding(input_dim, cfg.embed)
        embed_dim = self.embed.embed_dim
        m = cfg.partition.m

        self.register_buffer("sites", torch.randn(m, embed_dim) * 0.1)
        self.feature_transform = nn.Sequential(
            nn.Linear(input_dim, embed_dim), nn.ReLU(), nn.Linear(embed_dim, embed_dim))
        self.graph_builder = RegionGraphBuilder(m, cfg.region_graph)
        self.region_gnn = RegionGNN(embed_dim, cfg.gnn)

        out_dim = n_classes if cfg.head.task == "classification" else 1
        head_h = cfg.head.hidden_sizes[0] if cfg.head.hidden_sizes else 64
        self.head = nn.Sequential(
            nn.Linear(self.region_gnn.out_dim, head_h),
            nn.ReLU(), nn.Dropout(cfg.head.dropout),
            nn.Linear(head_h, out_dim))
        self.temp = cfg.partition.temps[0] if cfg.partition.temps else 1.0

    def init_sites(self, dataloader, device):
        all_z = []
        with torch.no_grad():
            for batch in dataloader:
                z = self.embed(batch[0].to(device))
                all_z.append(z.cpu())
                if sum(t.shape[0] for t in all_z) > 50000:
                    break
        from .partition import _kmeans_init_safe
        centers = _kmeans_init_safe(torch.cat(all_z), self.sites.shape[0])
        self.sites.copy_(centers.to(device))

    def forward(self, x, **kw):
        z = self.embed(x)
        u = self.feature_transform(x)
        dists = torch.cdist(z.unsqueeze(0), self.sites.unsqueeze(0)).squeeze(0) ** 2
        w = F.softmax(-dists / self.temp, dim=-1)
        mass = w.sum(dim=0, keepdim=True).clamp(min=1e-8)
        h = (w.t() @ u) / mass.t()
        graph = self.graph_builder(w, self.sites)
        h_tilde = self.region_gnn(h, graph["adj_dense"])
        v = w @ h_tilde
        return {"logits": self.head(v), "assignments": [w], "hard_assignments": [w.argmax(-1)]}


# ════════════════════════════════════════════════════════════════
# Registry
# ════════════════════════════════════════════════════════════════

MODEL_REGISTRY = {
    "vghl": VGHLModel,
    "mlp": MLPBaseline,
    "point_gnn": PointGNNBaseline,
    "fixed_cluster_gnn": FixedClusterGNNBaseline,
}


def build_model(name: str, input_dim: int, n_classes: int, cfg: ExperimentConfig) -> nn.Module:
    if name not in MODEL_REGISTRY:
        raise ValueError(f"Unknown model '{name}'. Available: {list(MODEL_REGISTRY.keys())}")
    return MODEL_REGISTRY[name](input_dim, n_classes, cfg)
