"""Geometric Machine: unified pipeline for geometry-as-computation experiments.

Pipeline:
  1. Build dataset-level graph (anchor or transductive, NOT per-batch)
  2. Optionally induce primitives
  3. Optionally prune
  4. Propagate features through fixed operator (sparse, O(E))
  5. Optional multilevel recursion
  6. Linear readout head (weak head to isolate geometry signal)

All variation comes from geometry, not from learned compute.
Graph is built ONCE on the full training set, not per minibatch.
"""
from __future__ import annotations

import torch
import torch.nn as nn
from typing import Dict, Any, Optional, List
from dataclasses import dataclass

from .graph_builder import GraphBuilderConfig, build_base_graph, graph_builder_config_from_dict
from .primitives import PrimitiveConfig, induce_primitives, primitive_stats
from .propagation import PropagationConfig, propagate, propagation_config_from_dict, spmm
from .propagation import add_self_loops_sparse, row_norm_sparse, sym_norm_sparse
from .pruning import PruningConfig, prune_graph, pruning_config_from_dict
from .anchor_graph import AnchorGraphConfig, AnchorGraph, anchor_graph_config_from_dict
from .recursion import (
    RecursionConfig, recursion_config_from_dict, LevelGraph,
    contract_primitives, wire_supergraph, pool_to_supernodes,
    scatter_to_base, build_multilevel_graph,
)
from .multilevel_compute import (
    MultilevelComputeConfig, multilevel_propagate, multilevel_propagate_queries,
)
from .merge import MergeConfig, compute_transition_signatures, find_merge_candidates, apply_merges
from .edit_loop import EditLoopConfig, run_edit_loop, score_machine


class LinearHead(nn.Module):
    """Minimal linear readout — forces geometry to carry the signal."""
    def __init__(self, in_dim: int, n_classes: int):
        super().__init__()
        self.linear = nn.Linear(in_dim, n_classes)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.linear(x)


class MLPHead(nn.Module):
    """Optional stronger head for Phase 2 comparison."""
    def __init__(self, in_dim: int, n_classes: int, hidden: int = 64, dropout: float = 0.1):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(in_dim, hidden),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(hidden, n_classes),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.net(x)


def propagate_queries_operator_consistent(
    h_anchors: torch.Tensor,
    z_queries: torch.Tensor,
    anchor_edge_index: torch.Tensor,
    anchor_edge_weight: torch.Tensor,
    bi_edge_index: torch.Tensor,
    bi_edge_weight: torch.Tensor,
    n_anchors: int,
    prop_cfg,
) -> torch.Tensor:
    """Propagate query features using the SAME operator as anchors, with anchor clamping.

    Builds an augmented graph [anchors + queries], runs the configured
    propagation operator for T steps, but clamps anchor features back
    to their frozen values after each step so only queries update.

    This ensures that changing prop_cfg.type changes both anchor AND
    query propagation, making operator sweeps meaningful.

    Args:
        h_anchors: (N, d) frozen propagated anchor features.
        z_queries: (M, d) raw/embedded query features.
        anchor_edge_index: (2, E_aa) anchor-anchor edges.
        anchor_edge_weight: (E_aa,) anchor-anchor weights.
        bi_edge_index: (2, E_bi) bipartite edges in augmented indexing
            (anchors 0..N-1, queries N..N+M-1).
        bi_edge_weight: (E_bi,) bipartite weights.
        n_anchors: N.
        prop_cfg: PropagationConfig controlling operator type/steps.

    Returns:
        (M, d) propagated query features.
    """
    M = z_queries.shape[0]
    N = n_anchors
    N_total = N + M

    # Concatenate features: [frozen_anchors; raw_queries]
    H = torch.cat([h_anchors, z_queries], dim=0)  # (N+M, d)
    H0_anchors = h_anchors  # save for clamping

    # Build combined edge list: anchor-anchor + bipartite (already in augmented indexing)
    combined_ei = torch.cat([anchor_edge_index, bi_edge_index], dim=1)
    combined_ew = torch.cat([anchor_edge_weight, bi_edge_weight], dim=0)

    # Run one-step-at-a-time with anchor clamping
    # We use the same normalization logic as the configured operator
    op_type = prop_cfg.type

    if op_type == "identity":
        return z_queries

    elif op_type == "ppr":
        ei, ew = add_self_loops_sparse(combined_ei, combined_ew, N_total, fill_value=1.0)
        ew_norm, _ = row_norm_sparse(ei, ew, N_total)
        alpha = prop_cfg.alpha
        x0 = H.clone()
        for _ in range(prop_cfg.steps):
            H = alpha * x0 + (1 - alpha) * spmm(ei, ew_norm, N_total, H)
            H[:N] = H0_anchors  # clamp anchors
        return H[N:]

    elif op_type == "heat":
        # NOTE: Anchor clamping is applied to h_out but NOT to the Taylor
        # term accumulator. This means the Taylor expansion is an approximation
        # of true "heat diffusion with frozen anchors" — the error is second-order
        # through anchor-anchor-query paths. This is acceptable because the
        # dominant information flow is anchor→query via bipartite edges.
        ew_sym, _ = sym_norm_sparse(combined_ei, combined_ew, N_total)
        t = prop_cfg.t
        def _L_mv(v):
            return v - spmm(combined_ei, ew_sym, N_total, v)
        h_out = H.clone()
        term = H.clone()
        for k in range(1, prop_cfg.steps + 1):
            term = -(t / k) * _L_mv(term)
            h_out = h_out + term
            h_out[:N] = H0_anchors
        return h_out[N:]

    elif op_type == "laplacian":
        ei, ew = add_self_loops_sparse(combined_ei, combined_ew, N_total, fill_value=1.0)
        ew_sym, _ = sym_norm_sparse(ei, ew, N_total)
        for _ in range(prop_cfg.steps):
            H = spmm(ei, ew_sym, N_total, H)
            H[:N] = H0_anchors
        return H[N:]

    elif op_type == "gated":
        if combined_ew.numel() == 0:
            return z_queries
        median_w = combined_ew.median()
        threshold = median_w * prop_cfg.gate_threshold
        gate = torch.where(
            combined_ew > threshold,
            torch.ones_like(combined_ew),
            combined_ew / (threshold + 1e-8),
        )
        gated_w = combined_ew * gate
        ei, ew = add_self_loops_sparse(combined_ei, gated_w, N_total, fill_value=1.0)
        ew_norm, _ = row_norm_sparse(ei, ew, N_total)
        for _ in range(prop_cfg.steps):
            H = spmm(ei, ew_norm, N_total, H)
            H[:N] = H0_anchors
        return H[N:]

    else:
        # Default: random_walk with anchor clamping
        ei, ew = add_self_loops_sparse(combined_ei, combined_ew, N_total, fill_value=1.0)
        ew_norm, _ = row_norm_sparse(ei, ew, N_total)
        for _ in range(prop_cfg.steps):
            H = spmm(ei, ew_norm, N_total, H)
            H[:N] = H0_anchors
        return H[N:]


class GeometricMachine(nn.Module):
    """The geometric machine: dataset-level graph → propagation → readout.

    The graph IS the hypothesis. The head is deliberately weak.

    Two modes (controlled by anchor_cfg.mode):
      - transductive_full_graph: single graph on full train set.
      - inductive_anchor_graph: train anchors + bipartite query attachment.

    Both modes ensure the graph is determined by dataset geometry,
    NOT by minibatch composition.
    """

    def __init__(
        self,
        input_dim: int,
        n_classes: int,
        graph_cfg: GraphBuilderConfig,
        prop_cfg: PropagationConfig,
        anchor_cfg: Optional[AnchorGraphConfig] = None,
        pruning_cfg: Optional[PruningConfig] = None,
        primitive_cfg: Optional[PrimitiveConfig] = None,
        recursion_cfg: Optional[RecursionConfig] = None,
        multilevel_cfg: Optional[MultilevelComputeConfig] = None,
        merge_cfg: Optional[MergeConfig] = None,
        edit_loop_cfg: Optional[EditLoopConfig] = None,
        head_type: str = "linear",
        head_hidden: int = 64,
        head_dropout: float = 0.1,
        embed_dim: Optional[int] = None,
    ):
        super().__init__()
        self.input_dim = input_dim
        self.n_classes = n_classes
        self.graph_cfg = graph_cfg
        self.prop_cfg = prop_cfg
        self.anchor_cfg = anchor_cfg or AnchorGraphConfig()
        self.pruning_cfg = pruning_cfg
        self.primitive_cfg = primitive_cfg
        self.recursion_cfg = recursion_cfg or RecursionConfig()
        self.multilevel_cfg = multilevel_cfg or MultilevelComputeConfig()
        self.merge_cfg = merge_cfg or MergeConfig()
        self.edit_loop_cfg = edit_loop_cfg or EditLoopConfig()

        # Optional learned embedding
        if embed_dim is not None and embed_dim != input_dim:
            self.embed = nn.Sequential(
                nn.Linear(input_dim, embed_dim),
                nn.ReLU(),
                nn.Linear(embed_dim, embed_dim),
            )
            feat_dim = embed_dim
        else:
            self.embed = nn.Identity()
            feat_dim = input_dim

        # Head
        if head_type == "linear":
            self.head = LinearHead(feat_dim, n_classes)
        elif head_type == "mlp":
            self.head = MLPHead(feat_dim, n_classes, head_hidden, head_dropout)
        else:
            raise ValueError(f"Unknown head_type: {head_type}")

        self.feat_dim = feat_dim

        # Anchor graph manager (handles dataset-level graph caching)
        self._anchor_graph = AnchorGraph(graph_cfg, self.anchor_cfg)

        # Cached propagated anchor features
        self._propagated_anchors: Optional[torch.Tensor] = None
        self._anchor_edge_index: Optional[torch.Tensor] = None
        self._anchor_edge_weight: Optional[torch.Tensor] = None
        self._pruning_node_mask: Optional[torch.Tensor] = None  # bool mask if nodes were pruned

        # Phase-2: cached hierarchy
        self._levels: Optional[List[LevelGraph]] = None
        self._primitives: Optional[list] = None
        self._edit_log: Optional[Dict] = None

    @property
    def anchor_graph_built(self) -> bool:
        return self._anchor_graph.is_built

    @torch.no_grad()
    def build_graph(self, X_train: torch.Tensor, labels: Optional[torch.Tensor] = None,
                     X_val: Optional[torch.Tensor] = None, y_val: Optional[torch.Tensor] = None):
        """Build the dataset-level graph from training data.

        Call this ONCE before training (or on rebuild schedule).

        Args:
            X_train: (N_train, d) raw training features.
            labels: (N_train,) labels for label_consistency pruning.
            X_val: (N_val, d) optional val features for structure selection.
            y_val: (N_val,) optional val labels for structure selection.
        """
        device = next(self.parameters()).device if len(list(self.parameters())) > 0 else X_train.device

        # Embed
        z = self.embed(X_train.to(device))

        # Build anchor graph
        self._anchor_graph.device = device
        graph = self._anchor_graph.build_anchor_graph(z.detach())

        edge_index = graph["edge_index"]
        edge_weight = graph["edge_weight"]
        N = z.shape[0]

        # Optional pruning
        self._pruning_node_mask = None  # reset each build
        if self.pruning_cfg is not None and self.pruning_cfg.enabled:
            def _rebuild(pts):
                return build_base_graph(pts, self.graph_cfg)

            train_mask = torch.ones(N, dtype=torch.bool, device=device)
            pruned = prune_graph(
                edge_index, edge_weight, z.detach(),
                self.pruning_cfg, labels=labels,
                graph_builder_fn=_rebuild,
                is_train_mask=train_mask,
            )
            edge_index = pruned["edge_index"]
            edge_weight = pruned["edge_weight"]
            # Pruning remaps indices; sync everything into anchor_graph
            node_mask = pruned["node_mask"]
            if node_mask is not None and not node_mask.all():
                z = z[node_mask]
            else:
                node_mask = torch.ones(N, dtype=torch.bool, device=device)

            # Remove isolated nodes (degree 0) created by edge pruning
            N_cur = z.shape[0]
            if edge_index.numel() > 0 and N_cur > 0:
                deg = torch.zeros(N_cur, device=device)
                valid = (edge_index[0] < N_cur) & (edge_index[1] < N_cur)
                if valid.any():
                    src = edge_index[0][valid]
                    deg.scatter_add_(0, src, torch.ones_like(src, dtype=deg.dtype))
                connected = deg > 0
                if not connected.all():
                    n_isolated = int((~connected).sum())
                    import logging
                    logging.getLogger(__name__).info(
                        f"Pruning: removing {n_isolated} isolated nodes "
                        f"(deg=0) from {N_cur}"
                    )
                    # Remap edges to new indices
                    old_to_new = torch.full((N_cur,), -1, dtype=torch.long, device=device)
                    old_to_new[connected] = torch.arange(
                        int(connected.sum()), device=device
                    )
                    keep_edges = connected[edge_index[0]] & connected[edge_index[1]]
                    edge_index = old_to_new[edge_index[:, keep_edges]]
                    edge_weight = edge_weight[keep_edges]
                    z = z[connected]
                    # Update the overall node mask
                    orig_indices = node_mask.nonzero(as_tuple=True)[0]
                    node_mask = torch.zeros(N, dtype=torch.bool, device=device)
                    node_mask[orig_indices[connected]] = True

            self._pruning_node_mask = node_mask if not node_mask.all() else None
            self._anchor_graph._anchor_points = z
            self._anchor_graph._n_anchors = z.shape[0]
            # Sync pruned edges so attach_queries uses correct graph
            self._anchor_graph._anchor_edge_index = edge_index
            self._anchor_graph._anchor_edge_weight = edge_weight
            # Rebuild kNN index on (potentially pruned) anchor points
            from .knn_backend import KNNIndex
            self._anchor_graph._knn_index = KNNIndex(z)
            N = z.shape[0]

        # Propagate on anchor graph — Phase 1 or Phase 2
        if (self.recursion_cfg.enabled and self.primitive_cfg is not None
                and self.primitive_cfg.use_in_propagation):
            # ── Phase 2: multilevel computation ──────────────────────
            import logging
            _logger = logging.getLogger(__name__)

            # 1. Induce primitives on the base graph
            prims = induce_primitives(edge_index, z.detach(), self.primitive_cfg)
            self._primitives = prims
            _logger.info(f"Phase 2: induced {len(prims)} primitives")

            if self.edit_loop_cfg.enabled:
                # ── Phase 2 with structural edit loop ────────────────
                # Build real eval_fn using ridge probe on val data
                eval_fn = None
                if X_val is not None and y_val is not None and labels is not None:
                    from .probe import ridge_eval

                    z_val = self.embed(X_val.to(device)).detach()
                    n_classes = self.n_classes
                    y_train_dev = labels.to(device)
                    y_val_dev = y_val.to(device)

                    def _eval_fn(cand_h, cand_ei=None, cand_ew=None):
                        """Score candidate: ridge on train, eval on val.
                        
                        Args:
                            cand_h: propagated train features from candidate graph.
                            cand_ei: candidate base edge_index (optional, falls back to original).
                            cand_ew: candidate base edge_weight (optional).
                        """
                        bi_ei, bi_ew = self._anchor_graph.attach_queries(z_val)
                        n_anch = self._anchor_graph.n_anchors
                        # Use candidate edges if provided, else original
                        aa_ei = cand_ei if cand_ei is not None else edge_index
                        aa_ew = cand_ew if cand_ew is not None else edge_weight
                        h_val = propagate_queries_operator_consistent(
                            cand_h, z_val,
                            aa_ei, aa_ew,
                            bi_ei, bi_ew, n_anch,
                            self.prop_cfg,
                        )
                        return ridge_eval(
                            cand_h, y_train_dev,
                            h_val, y_val_dev,
                            n_classes,
                        )
                    eval_fn = _eval_fn

                levels, prims, best_ei, best_ew, edit_log = run_edit_loop(
                    z=z.detach(),
                    edge_index=edge_index,
                    edge_weight=edge_weight,
                    primitives=prims,
                    recursion_cfg=self.recursion_cfg,
                    multilevel_cfg=self.multilevel_cfg,
                    prop_cfg=self.prop_cfg,
                    merge_cfg=self.merge_cfg,
                    edit_cfg=self.edit_loop_cfg,
                    eval_fn=eval_fn,
                )
                self._levels = levels
                self._primitives = prims
                self._edit_log = edit_log
                # Cache the EDITED base graph (not the pre-edit one)
                edge_index = best_ei
                edge_weight = best_ew
                # Resync AnchorGraph internal caches to match edited graph
                self._anchor_graph._anchor_edge_index = best_ei
                self._anchor_graph._anchor_edge_weight = best_ew
                # Recompute edge distances for the edited edges
                anchor_pts = self._anchor_graph._anchor_points
                if anchor_pts is not None and best_ei.shape[1] > 0:
                    src_pts = anchor_pts[best_ei[0]]
                    dst_pts = anchor_pts[best_ei[1]]
                    self._anchor_graph._anchor_edge_dist = (src_pts - dst_pts).norm(dim=1)
                else:
                    self._anchor_graph._anchor_edge_dist = torch.zeros(
                        best_ei.shape[1], device=best_ei.device
                    )
                h = multilevel_propagate(z, levels, self.prop_cfg, self.multilevel_cfg)
                _logger.info(f"Phase 2 edit loop: {len(levels)} levels, "
                             f"nodes={[l.n_nodes for l in levels]}")
            else:
                # ── Phase 2 single-shot ──────────────────────────────
                levels = build_multilevel_graph(
                    z.detach(), edge_index, edge_weight, prims, self.recursion_cfg
                )
                self._levels = levels
                _logger.info(f"Phase 2: {len(levels)} levels, "
                             f"nodes={[l.n_nodes for l in levels]}")

                # Optional merge
                if self.merge_cfg.enabled:
                    for lv_idx in range(1, len(levels)):
                        lv = levels[lv_idx]
                        if lv.edge_index.shape[1] == 0:
                            continue
                        sigs = compute_transition_signatures(
                            lv.edge_index, lv.edge_weight, lv.n_nodes,
                            self.merge_cfg.signature_dim,
                        )
                        pairs = find_merge_candidates(
                            sigs, lv.edge_index, lv.n_nodes, self.merge_cfg
                        )
                        if pairs:
                            new_ei, new_ew, compact, new_N = apply_merges(
                                lv.edge_index, lv.edge_weight, lv.n_nodes, pairs
                            )
                            lv.edge_index = new_ei
                            lv.edge_weight = new_ew
                            lv.membership = compact[lv.membership]
                            lv.n_nodes = new_N

                h = multilevel_propagate(z, levels, self.prop_cfg, self.multilevel_cfg)
        else:
            # ── Phase 1: flat propagation ────────────────────────────
            h = propagate(z, edge_index, edge_weight, N, self.prop_cfg)
            self._levels = None
            self._primitives = None

        # Cache
        self._propagated_anchors = h
        self._anchor_edge_index = edge_index
        self._anchor_edge_weight = edge_weight

    def forward(
        self,
        x: torch.Tensor,
        is_query: bool = True,
        return_internals: bool = False,
    ) -> Dict[str, Any]:
        """Forward pass.

        In anchor mode: x are query points. They connect to cached anchors
        via bipartite edges and receive propagated features.

        In transductive mode during training: x are (a subset of) training points.
        Their features come from the cached propagated anchors via index lookup.

        Args:
            x: (B, d) input features.
            is_query: if True, attach as query to anchor graph.
                      if False, assume x are anchor points (use cached features).
            return_internals: if True, return graph structure details.

        Returns:
            dict with 'logits' and optionally graph metadata.
        """
        B = x.shape[0]
        device = x.device

        if is_query:
            # Query mode: embed raw features
            z = self.embed(x)
        else:
            # Transductive training: x is already propagated, do NOT re-embed
            z = x

        if not self._anchor_graph.is_built:
            # Fallback: build graph on current batch (legacy behavior)
            graph = build_base_graph(z.detach(), self.graph_cfg)
            h = propagate(
                z, graph["edge_index"], graph["edge_weight"],
                B, self.prop_cfg,
            )
            edge_index = graph["edge_index"]
            edge_weight = graph["edge_weight"]
        elif is_query:
            # Query mode (val/test): attach to anchor graph and propagate.
            n_anchors = self._anchor_graph.n_anchors

            if self._levels is not None and len(self._levels) > 1:
                # ── Phase 2: multilevel query propagation ────────────
                bi_ei, bi_ew = self._anchor_graph.attach_queries(z.detach())
                h = multilevel_propagate_queries(
                    h_query=z,
                    h_anchors_level0=self._propagated_anchors,
                    levels=self._levels,
                    query_edge_index=bi_ei,
                    query_edge_weight=bi_ew,
                    n_anchors=n_anchors,
                    prop_cfg=self.prop_cfg,
                    compute_cfg=self.multilevel_cfg,
                )
                edge_index = bi_ei
                edge_weight = bi_ew
            else:
                # ── Phase 1: freeze anchors, update queries only ─────
                bi_ei, bi_ew = self._anchor_graph.attach_queries(z.detach())
                h = propagate_queries_operator_consistent(
                    self._propagated_anchors, z,
                    self._anchor_edge_index, self._anchor_edge_weight,
                    bi_ei, bi_ew, n_anchors,
                    self.prop_cfg,
                )
                edge_index = bi_ei
                edge_weight = bi_ew
        else:
            # Transductive training path: caller (GMTrainer) feeds
            # already-propagated features via cached prop_loader,
            # so h = z is a pass-through of propagated features.
            h = z
            edge_index = self._anchor_edge_index
            edge_weight = self._anchor_edge_weight

        # Readout
        logits = self.head(h)

        result = {"logits": logits}

        if return_internals:
            result.update({
                "embeddings": z,
                "propagated": h,
                "edge_index": edge_index,
                "edge_weight": edge_weight,
                "n_edges": edge_index.shape[1] if edge_index is not None else 0,
                "n_nodes": B,
            })

        return result

    def get_propagated_train_features(self) -> Optional[torch.Tensor]:
        """Return cached propagated features for all anchor/train points."""
        return self._propagated_anchors


# ── Machine metrics for logging ──────────────────────────────────────

@torch.no_grad()
def compute_machine_metrics(
    edge_index: torch.Tensor,
    edge_weight: torch.Tensor,
    N: int,
    edge_dist: Optional[torch.Tensor] = None,
    propagated_features: Optional[torch.Tensor] = None,
    original_features: Optional[torch.Tensor] = None,
) -> Dict[str, float]:
    """Compute comprehensive graph metrics for a single machine.

    Enhanced with:
      - Edge-length distribution stats
      - Operator diagnostics (mixing proxy, over-smoothing proxy)
      - All sparse — no NxN dense matrices created
    """
    E = edge_index.shape[1]
    device = edge_index.device
    metrics = {}

    metrics["n_nodes"] = N
    metrics["n_edges"] = E
    metrics["density"] = E / max(N * (N - 1), 1)

    # Degree stats
    degree = torch.zeros(N, device=device)
    degree.scatter_add_(0, edge_index[0], torch.ones(E, device=device))

    if N > 0:
        metrics["deg_mean"] = degree.mean().item()
        metrics["deg_std"] = degree.std().item()
        metrics["deg_min"] = degree.min().item()
        metrics["deg_max"] = degree.max().item()
        metrics["isolated_nodes"] = int((degree == 0).sum().item())
    else:
        metrics.update({k: 0 for k in ["deg_mean", "deg_std", "deg_min", "deg_max", "isolated_nodes"]})

    # Edge weight stats
    if E > 0:
        metrics["weight_mean"] = edge_weight.mean().item()
        metrics["weight_std"] = edge_weight.std().item() if E > 1 else 0
        metrics["weight_min"] = edge_weight.min().item()
        metrics["weight_max"] = edge_weight.max().item()

    # Edge-length distribution (if distances available)
    if edge_dist is not None and edge_dist.numel() > 0:
        metrics["edge_dist_mean"] = edge_dist.mean().item()
        metrics["edge_dist_std"] = edge_dist.std().item() if edge_dist.numel() > 1 else 0
        metrics["edge_dist_median"] = edge_dist.median().item()
        for q_name, q_val in [("p10", 0.1), ("p25", 0.25), ("p75", 0.75), ("p90", 0.9)]:
            metrics[f"edge_dist_{q_name}"] = torch.quantile(edge_dist.float(), q_val).item()

    # Connected components (sparse BFS, gated by N)
    if N <= 10000:
        try:
            n_comp, largest = _sparse_components(edge_index, N)
            metrics["n_components"] = n_comp
            metrics["largest_component"] = largest
            metrics["largest_component_frac"] = largest / max(N, 1)
        except Exception:
            pass

    # Clustering coefficient (optional, gated by N)
    if N <= 2000 and E > 0:
        try:
            cc = _sparse_clustering_coeff(edge_index, N)
            metrics["clustering_coeff"] = cc
        except Exception:
            pass

    # Operator diagnostics: over-smoothing and mixing proxies
    if propagated_features is not None and original_features is not None:
        try:
            # Mixing proxy: ||h_prop - h_orig|| / ||h_orig||
            diff_norm = (propagated_features - original_features).norm().item()
            orig_norm = original_features.norm().item()
            metrics["mixing_ratio"] = diff_norm / max(orig_norm, 1e-8)

            # Over-smoothing proxy: mean pairwise cosine similarity of propagated features
            if N <= 5000:
                h_normed = torch.nn.functional.normalize(propagated_features, dim=1)
                # Sample if too large
                if N > 1000:
                    idx = torch.randperm(N, device=device)[:1000]
                    h_sample = h_normed[idx]
                else:
                    h_sample = h_normed
                cos_sim = (h_sample @ h_sample.t()).fill_diagonal_(0)
                n_pairs = h_sample.shape[0] * (h_sample.shape[0] - 1)
                metrics["oversmooth_cos_sim"] = (cos_sim.sum() / max(n_pairs, 1)).item()
        except Exception:
            pass

    # Spectral gap: sparse lobpcg preferred, dense fallback for tiny N
    if N <= 5000 and E > 0:
        try:
            from .propagation import sym_norm_sparse
            ew_sym, _ = sym_norm_sparse(edge_index, edge_weight, N)
            # Build sparse normalized adjacency
            A_sparse = torch.sparse_coo_tensor(edge_index, ew_sym, (N, N)).coalesce()

            if N > 64:
                # Build sparse L_sym = I - A_sym for lobpcg
                # Identity as sparse
                diag_idx = torch.arange(N, device=device)
                I_sparse = torch.sparse_coo_tensor(
                    torch.stack([diag_idx, diag_idx]),
                    torch.ones(N, device=device),
                    (N, N),
                )
                L_sparse = (I_sparse - A_sparse).coalesce()

                # lobpcg with sparse tensor input (not callable)
                X0 = torch.randn(N, 2, device=device, dtype=L_sparse.values().dtype)
                eigenvalues, _ = torch.lobpcg(
                    A=L_sparse, k=2, X=X0, largest=False, niter=100
                )
                eigs_sorted = eigenvalues.sort().values
                metrics["spectral_gap"] = (eigs_sorted[1] - eigs_sorted[0]).item() if len(eigs_sorted) > 1 else 0
                metrics["lambda2"] = eigs_sorted[1].item() if len(eigs_sorted) > 1 else 0
            elif N <= 1000:
                # Dense fallback for very small N (safe)
                A_dense = A_sparse.to_dense()
                L_sym = torch.eye(N, device=device) - A_dense
                eigs = torch.linalg.eigvalsh(L_sym).clamp(min=0)
                metrics["spectral_gap_dense_guarded"] = (eigs[1] - eigs[0]).item() if N > 1 else 0
                metrics["lambda2"] = eigs[1].item() if N > 1 else 0
                metrics["eigenvalue_ratio_2_N"] = (eigs[1] / eigs[-1]).item() if eigs[-1] > 1e-8 else 0
        except Exception:
            pass

    return metrics


def _sparse_components(edge_index: torch.Tensor, N: int) -> tuple:
    """Find connected components using sparse BFS. Returns (n_comp, largest_size)."""
    adj = [[] for _ in range(N)]
    src_list = edge_index[0].cpu().tolist()
    dst_list = edge_index[1].cpu().tolist()
    for s, d in zip(src_list, dst_list):
        adj[s].append(d)
        adj[d].append(s)

    visited = [False] * N
    n_comp = 0
    largest = 0
    for start in range(N):
        if visited[start]:
            continue
        n_comp += 1
        # BFS
        queue = [start]
        head = 0
        size = 0
        while head < len(queue):
            node = queue[head]
            head += 1
            if visited[node]:
                continue
            visited[node] = True
            size += 1
            for nb in adj[node]:
                if not visited[nb]:
                    queue.append(nb)
        largest = max(largest, size)
    return n_comp, largest


def _sparse_clustering_coeff(edge_index: torch.Tensor, N: int) -> float:
    """Approximate clustering coefficient without dense NxN matrix.

    Uses adjacency set intersection for triangle counting.
    Samples if N is large.
    """
    adj = [set() for _ in range(N)]
    for s, d in zip(edge_index[0].cpu().tolist(), edge_index[1].cpu().tolist()):
        adj[s].add(d)
        adj[d].add(s)

    # Sample nodes for large N
    import random
    nodes = list(range(N))
    if N > 500:
        random.shuffle(nodes)
        nodes = nodes[:500]

    total_cc = 0.0
    count = 0
    for u in nodes:
        neighbors = list(adj[u])
        k = len(neighbors)
        if k < 2:
            continue
        # Count triangles through u
        triangles = 0
        for i in range(k):
            for j in range(i + 1, k):
                if neighbors[j] in adj[neighbors[i]]:
                    triangles += 1
        possible = k * (k - 1) / 2
        total_cc += triangles / possible
        count += 1

    return total_cc / max(count, 1)
