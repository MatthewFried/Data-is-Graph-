"""Behavioral Equivalence Merging: merge supernodes with similar transition signatures.

After propagation, compute per-node "transition signatures" that capture
how each node distributes mass to its neighbors. Nodes with similar
signatures are behaviorally equivalent and can be merged without loss.

This implements the DFA-minimization analogy: states with identical
transition functions are merged.
"""
from __future__ import annotations

import logging
import torch
from typing import Dict, Tuple, Optional
from dataclasses import dataclass

logger = logging.getLogger(__name__)


@dataclass
class MergeConfig:
    """Configuration for behavioral equivalence merging."""
    enabled: bool = False
    metric: str = "cosine"        # cosine | l1 | l2
    tau: float = 0.95             # similarity threshold for merging
    max_merges_per_level: int = 50
    signature_dim: int = 16       # project signature to this dim for speed


def compute_transition_signatures(
    edge_index: torch.Tensor,
    edge_weight: torch.Tensor,
    N: int,
    signature_dim: int = 16,
) -> torch.Tensor:
    """Compute transition signature for each node.

    Signature = sorted top-k outgoing edge weights, zero-padded.
    This captures the distribution of mass a node sends to neighbors.

    Args:
        edge_index: (2, E) graph edges.
        edge_weight: (E,) edge weights.
        N: number of nodes.
        signature_dim: dimension of signature vector.

    Returns:
        signatures: (N, signature_dim) float tensor.
    """
    device = edge_index.device
    sigs = torch.zeros(N, signature_dim, device=device)

    src, dst = edge_index[0], edge_index[1]

    # For each node, collect outgoing weights and sort descending
    for i in range(N):
        mask = src == i
        if not mask.any():
            continue
        weights = edge_weight[mask]
        # Normalize to transition probabilities
        total = weights.sum()
        if total > 1e-8:
            weights = weights / total
        # Sort descending and take top-k
        sorted_w, _ = weights.sort(descending=True)
        k = min(len(sorted_w), signature_dim)
        sigs[i, :k] = sorted_w[:k]

    return sigs


def find_merge_candidates(
    signatures: torch.Tensor,
    edge_index: torch.Tensor,
    N: int,
    cfg: MergeConfig,
) -> list:
    """Find pairs of nodes that can be merged based on signature similarity.

    Args:
        signatures: (N, d) transition signatures.
        edge_index: (2, E) graph edges.
        N: number of nodes.
        cfg: merge config.

    Returns:
        List of (node_a, node_b) pairs to merge.
    """
    if not cfg.enabled or N <= 2:
        return []

    # Compute pairwise similarity (only between connected or nearby nodes)
    # For efficiency, only compare neighbors
    pairs = []
    sig_norm = torch.nn.functional.normalize(signatures, dim=1)

    src, dst = edge_index[0], edge_index[1]
    seen = set()

    for idx in range(edge_index.shape[1]):
        a, b = src[idx].item(), dst[idx].item()
        if a >= b or (a, b) in seen:
            continue
        seen.add((a, b))

        if cfg.metric == "cosine":
            sim = (sig_norm[a] * sig_norm[b]).sum().item()
        elif cfg.metric == "l1":
            sim = 1.0 / (1.0 + (signatures[a] - signatures[b]).abs().sum().item())
        elif cfg.metric == "l2":
            sim = 1.0 / (1.0 + (signatures[a] - signatures[b]).norm().item())
        else:
            sim = 0.0

        if sim >= cfg.tau:
            pairs.append((a, b, sim))

    # Sort by similarity descending, cap
    pairs.sort(key=lambda x: -x[2])
    pairs = pairs[:cfg.max_merges_per_level]
    return [(a, b) for a, b, _ in pairs]


def apply_merges(
    edge_index: torch.Tensor,
    edge_weight: torch.Tensor,
    N: int,
    merge_pairs: list,
) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor, int]:
    """Apply node merges: redirect edges from merged nodes to their targets.

    Uses greedy non-overlapping assignment: each node merged at most once.

    Args:
        edge_index: (2, E) graph edges.
        edge_weight: (E,) edge weights.
        N: number of nodes.
        merge_pairs: list of (a, b) pairs where b merges into a.

    Returns:
        new_edge_index, new_edge_weight, node_remap (N,), new_N
    """
    device = edge_index.device
    remap = torch.arange(N, device=device, dtype=torch.long)

    merged = set()
    for a, b in merge_pairs:
        if a in merged or b in merged:
            continue
        remap[b] = a
        merged.add(b)

    # Compact node ids
    surviving = set(range(N)) - merged
    surviving = sorted(surviving)
    compact = torch.zeros(N, dtype=torch.long, device=device)
    for new_id, old_id in enumerate(surviving):
        compact[old_id] = new_id
    # Merged nodes map to their target's compact id
    for b in merged:
        compact[b] = compact[remap[b].item()]

    new_N = len(surviving)

    # Remap edges
    new_src = compact[edge_index[0]]
    new_dst = compact[edge_index[1]]

    # Remove self-loops created by merging
    mask = new_src != new_dst
    new_edge_index = torch.stack([new_src[mask], new_dst[mask]])
    new_edge_weight = edge_weight[mask]

    return new_edge_index, new_edge_weight, compact, new_N


def merge_stats(merge_pairs: list, N_before: int, N_after: int) -> Dict[str, float]:
    """Log merge statistics."""
    return {
        "n_merges": len(merge_pairs),
        "n_before": N_before,
        "n_after": N_after,
        "compression_ratio": N_after / max(N_before, 1),
    }
