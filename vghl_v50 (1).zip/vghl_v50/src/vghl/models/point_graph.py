"""Point-level graph: kNN in embedding space with boundary-aware edge modulation.

This is the core of Approach 2: points are nodes, edges are modulated by
boundary/interior status derived from Voronoi assignment entropy/margin.
"""
from __future__ import annotations

import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Dict, Optional, Tuple

from ..utils.config import PointGraphConfig, BoundaryConfig


# ── Point kNN graph construction ─────────────────────────────────────

def build_point_knn(z: torch.Tensor, k: int) -> Tuple[torch.Tensor, torch.Tensor]:
    """Build kNN graph among points in embedding space.

    Uses chunked cdist for memory efficiency on large batches.

    Args:
        z: (B, d') point embeddings
        k: number of neighbors

    Returns:
        edge_index: (2, E) directed edges (src -> dst)
        edge_dist: (E,) squared distances
    """
    B = z.shape[0]
    k = min(k, B - 1)
    device = z.device

    if B <= 4096:
        dists = torch.cdist(z.unsqueeze(0), z.unsqueeze(0)).squeeze(0)  # (B, B)
        # k+1 to exclude self, then drop self
        topk_dists, topk_idx = dists.topk(k + 1, dim=1, largest=False)
        topk_dists = topk_dists[:, 1:]  # (B, k)
        topk_idx = topk_idx[:, 1:]      # (B, k)
    else:
        chunk_size = 2048
        topk_idx_list, topk_dist_list = [], []
        for i in range(0, B, chunk_size):
            z_chunk = z[i:i + chunk_size]
            d = torch.cdist(z_chunk.unsqueeze(0), z.unsqueeze(0)).squeeze(0)
            tk_d, tk_i = d.topk(k + 1, dim=1, largest=False)
            topk_dist_list.append(tk_d[:, 1:])
            topk_idx_list.append(tk_i[:, 1:])
        topk_idx = torch.cat(topk_idx_list, dim=0)
        topk_dists = torch.cat(topk_dist_list, dim=0)

    # Build edge_index: (2, B*k) — directed from each node to its neighbors
    src = torch.arange(B, device=device).unsqueeze(1).expand(-1, k).reshape(-1)
    dst = topk_idx.reshape(-1)
    edge_index = torch.stack([src, dst], dim=0)
    edge_dist = topk_dists.reshape(-1)

    return edge_index, edge_dist


# ── Boundary detection ───────────────────────────────────────────────

def detect_boundary_points(
    assignments: torch.Tensor,
    mode: str = "entropy",
    threshold: float = 0.5,
    frac: float = 0.0,
) -> Tuple[torch.Tensor, torch.Tensor]:
    """Detect boundary points from soft Voronoi assignments.

    Args:
        assignments: (B, m) soft assignment weights
        mode: 'entropy' | 'margin'
        threshold: decision threshold
        frac: if >0, use top frac% instead of threshold

    Returns:
        is_boundary: (B,) bool mask
        boundary_score: (B,) continuous score (higher = more boundary-like)
    """
    if mode == "none":
        B = assignments.shape[0]
        return torch.zeros(B, dtype=torch.bool, device=assignments.device), \
               torch.zeros(B, device=assignments.device)

    if mode == "entropy":
        # High entropy = near boundary
        ent = -(assignments * (assignments + 1e-10).log()).sum(dim=-1)  # (B,)
        max_ent = assignments.shape[1]  # log(m) if uniform
        score = ent / (max_ent + 1e-10).log() if hasattr(max_ent, 'log') else ent / torch.tensor(max_ent).float().log()
        # Normalize to roughly [0, 1]
        import math
        score = ent / math.log(assignments.shape[1] + 1e-10)
    elif mode == "margin":
        # Low margin between top-2 = near boundary
        top2 = assignments.topk(2, dim=-1).values  # (B, 2)
        margin = top2[:, 0] - top2[:, 1]  # (B,)
        score = 1.0 - margin  # high score = low margin = boundary
    else:
        raise ValueError(f"Unknown boundary mode: {mode}")

    if frac > 0:
        n_boundary = max(1, int(frac * len(score)))
        topk_idx = score.topk(n_boundary).indices
        is_boundary = torch.zeros_like(score, dtype=torch.bool)
        is_boundary[topk_idx] = True
    else:
        is_boundary = score > threshold

    return is_boundary, score


# ── Edge modulation based on boundary status ─────────────────────────

def modulate_edges(
    edge_index: torch.Tensor,
    is_boundary: torch.Tensor,
    cfg: BoundaryConfig,
) -> torch.Tensor:
    """Compute per-edge weights based on boundary/interior status of endpoints.

    Args:
        edge_index: (2, E) edges
        is_boundary: (B,) bool
        cfg: boundary config with weight multipliers

    Returns:
        edge_weights: (E,) modulation weights
    """
    src_boundary = is_boundary[edge_index[0]]  # (E,)
    dst_boundary = is_boundary[edge_index[1]]  # (E,)

    weights = torch.ones(edge_index.shape[1], device=edge_index.device)

    # interior <-> interior
    ii = ~src_boundary & ~dst_boundary
    weights[ii] = cfg.interior_interior_weight

    # boundary <-> boundary
    bb = src_boundary & dst_boundary
    weights[bb] = cfg.boundary_boundary_weight

    # boundary <-> interior (either direction)
    bi = src_boundary ^ dst_boundary  # XOR
    weights[bi] = cfg.boundary_interior_weight

    return weights


# ── Point-level GNN layers ───────────────────────────────────────────

class PointGCNLayer(nn.Module):
    """GCN on sparse point graph with edge weights."""

    def __init__(self, in_dim: int, out_dim: int, dropout: float = 0.0):
        super().__init__()
        self.linear = nn.Linear(in_dim, out_dim)
        self.dropout = nn.Dropout(dropout) if dropout > 0 else nn.Identity()

    def forward(self, h: torch.Tensor, edge_index: torch.Tensor,
                edge_weight: Optional[torch.Tensor] = None) -> torch.Tensor:
        """
        Args:
            h: (B, d) node features
            edge_index: (2, E) sparse edges
            edge_weight: (E,) optional weights
        """
        B = h.shape[0]
        src, dst = edge_index

        if edge_weight is None:
            edge_weight = torch.ones(edge_index.shape[1], device=h.device)

        # Degree normalization
        deg = torch.zeros(B, device=h.device)
        deg.scatter_add_(0, dst, edge_weight)
        deg = deg.clamp(min=1e-6)
        deg_inv_sqrt = deg.pow(-0.5)
        norm = deg_inv_sqrt[src] * edge_weight * deg_inv_sqrt[dst]

        # Message: weighted neighbor features
        msg = h[src] * norm.unsqueeze(-1)  # (E, d)
        # Aggregate
        out = torch.zeros_like(h)
        out.scatter_add_(0, dst.unsqueeze(-1).expand_as(msg), msg)

        # Add self-loop
        out = out + h

        out = self.linear(out)
        out = self.dropout(out)
        return out


class PointSAGELayer(nn.Module):
    """GraphSAGE mean on sparse point graph."""

    def __init__(self, in_dim: int, out_dim: int, dropout: float = 0.0):
        super().__init__()
        self.linear = nn.Linear(2 * in_dim, out_dim)
        self.dropout = nn.Dropout(dropout) if dropout > 0 else nn.Identity()

    def forward(self, h: torch.Tensor, edge_index: torch.Tensor,
                edge_weight: Optional[torch.Tensor] = None) -> torch.Tensor:
        B = h.shape[0]
        src, dst = edge_index

        if edge_weight is None:
            edge_weight = torch.ones(edge_index.shape[1], device=h.device)

        # Weighted mean of neighbors
        msg = h[src] * edge_weight.unsqueeze(-1)
        agg = torch.zeros_like(h)
        agg.scatter_add_(0, dst.unsqueeze(-1).expand_as(msg), msg)
        count = torch.zeros(B, device=h.device)
        count.scatter_add_(0, dst, edge_weight)
        count = count.clamp(min=1e-6)
        agg = agg / count.unsqueeze(-1)

        out = torch.cat([h, agg], dim=-1)
        out = self.linear(out)
        out = self.dropout(out)
        return out


class PointGATLayer(nn.Module):
    """GAT on sparse point graph with proper edge weight/mask integration."""

    def __init__(self, in_dim: int, out_dim: int, n_heads: int = 4, dropout: float = 0.0):
        super().__init__()
        assert out_dim % n_heads == 0
        self.n_heads = n_heads
        self.head_dim = out_dim // n_heads
        self.out_dim = out_dim

        self.W = nn.Linear(in_dim, out_dim, bias=False)
        self.attn = nn.Parameter(torch.randn(n_heads, 2 * self.head_dim) * 0.01)
        self.dropout = nn.Dropout(dropout) if dropout > 0 else nn.Identity()
        self.leaky_relu = nn.LeakyReLU(0.2)

    def forward(self, h: torch.Tensor, edge_index: torch.Tensor,
                edge_weight: Optional[torch.Tensor] = None) -> torch.Tensor:
        B = h.shape[0]
        H, d_h = self.n_heads, self.head_dim
        src, dst = edge_index
        E = edge_index.shape[1]

        Wh = self.W(h).view(B, H, d_h)  # (B, H, d_h)

        # Attention per edge
        src_feat = Wh[src]  # (E, H, d_h)
        dst_feat = Wh[dst]  # (E, H, d_h)
        cat_feat = torch.cat([src_feat, dst_feat], dim=-1)  # (E, H, 2*d_h)
        e = (cat_feat * self.attn.unsqueeze(0)).sum(dim=-1)  # (E, H)
        e = self.leaky_relu(e)

        # Incorporate edge weights into attention (the fix for the review)
        if edge_weight is not None:
            e = e + (edge_weight.unsqueeze(-1) + 1e-8).log().clamp(min=-10)

        # Softmax per destination node
        e_max = torch.zeros(B, H, device=h.device)
        e_max.scatter_reduce_(0, dst.unsqueeze(-1).expand(E, H), e, reduce="amax", include_self=True)
        e_stable = e - e_max[dst]
        alpha = e_stable.exp()

        alpha_sum = torch.zeros(B, H, device=h.device)
        alpha_sum.scatter_add_(0, dst.unsqueeze(-1).expand(E, H), alpha)
        alpha = alpha / (alpha_sum[dst] + 1e-10)
        alpha = self.dropout(alpha)

        # Weighted aggregation
        msg = src_feat * alpha.unsqueeze(-1)  # (E, H, d_h)
        out = torch.zeros(B, H, d_h, device=h.device)
        out.scatter_add_(0, dst.unsqueeze(-1).unsqueeze(-1).expand(E, H, d_h), msg)

        return out.reshape(B, -1)


class PointGNN(nn.Module):
    """Multi-layer point-level GNN with boundary-aware edge modulation."""

    def __init__(self, in_dim: int, cfg: PointGraphConfig, gat_heads: int = 4):
        super().__init__()
        self.cfg = cfg
        hidden = in_dim  # keep dim consistent for residuals

        self.layers = nn.ModuleList()
        self.norms = nn.ModuleList()

        for i in range(cfg.layers):
            d_in = in_dim if i == 0 else hidden
            if cfg.type == "gcn":
                self.layers.append(PointGCNLayer(d_in, hidden, cfg.dropout))
            elif cfg.type == "sage":
                self.layers.append(PointSAGELayer(d_in, hidden, cfg.dropout))
            elif cfg.type == "gat":
                self.layers.append(PointGATLayer(d_in, hidden, n_heads=gat_heads, dropout=cfg.dropout))
            else:
                raise ValueError(f"Unknown point GNN type: {cfg.type}")
            self.norms.append(nn.LayerNorm(hidden))

        self.residual = cfg.residual
        if in_dim != hidden and cfg.residual:
            self.res_proj = nn.Linear(in_dim, hidden)
        else:
            self.res_proj = None
        self.out_dim = hidden

    def forward(self, h: torch.Tensor, edge_index: torch.Tensor,
                edge_weight: Optional[torch.Tensor] = None) -> torch.Tensor:
        h_in = h
        for i, (layer, norm) in enumerate(zip(self.layers, self.norms)):
            h_new = layer(h, edge_index, edge_weight)
            h_new = norm(h_new)
            h_new = F.relu(h_new)
            if self.residual:
                if i == 0 and self.res_proj is not None:
                    h_new = h_new + self.res_proj(h_in)
                elif h_new.shape == h.shape:
                    h_new = h_new + h
            h = h_new
        return h
