"""Phase-2 Structural Noise Pruning: identify and remove noise at multiple levels.

Operates on the hierarchy to prune:
  - Edges: by length percentile or bootstrap stability
  - Primitives: by quality score
  - Nodes: by neighbor-set instability

All pruning is TRAIN-ONLY when label information is involved.
"""
from __future__ import annotations

import logging
import torch
import numpy as np
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass

from .primitives import Primitive

logger = logging.getLogger(__name__)


@dataclass
class Phase2PruneConfig:
    """Configuration for Phase-2 structural pruning."""
    enabled: bool = False
    # Edge pruning
    edge_length_percentile: float = 0.95    # remove edges above this percentile
    # Primitive pruning
    primitive_quality_min: float = 0.1      # drop primitives below this quality
    # Node pruning
    node_instability_max: float = 0.8       # drop nodes with instability above this


def prune_edges_by_length(
    edge_index: torch.Tensor,
    edge_weight: torch.Tensor,
    points: torch.Tensor,
    percentile: float = 0.95,
) -> Tuple[torch.Tensor, torch.Tensor]:
    """Remove edges whose length exceeds the given percentile.

    Args:
        edge_index: (2, E)
        edge_weight: (E,)
        points: (N, d)
        percentile: keep edges below this length percentile.

    Returns:
        pruned edge_index, edge_weight.
    """
    dists = (points[edge_index[0]] - points[edge_index[1]]).norm(dim=1)
    threshold = torch.quantile(dists.float(), percentile)
    mask = dists <= threshold
    return edge_index[:, mask], edge_weight[mask]


def prune_primitives_by_quality(
    primitives: List[Primitive],
    min_quality: float = 0.1,
) -> List[Primitive]:
    """Remove primitives with quality below threshold.

    Args:
        primitives: list of Primitive objects.
        min_quality: minimum quality to keep.

    Returns:
        Filtered list of primitives.
    """
    before = len(primitives)
    kept = [p for p in primitives if p.quality >= min_quality]
    if len(kept) < before:
        logger.info(f"Primitive pruning: {before} → {len(kept)} (min_quality={min_quality})")
    return kept


def compute_node_instability(
    edge_index: torch.Tensor,
    edge_weight: torch.Tensor,
    N: int,
    n_bootstrap: int = 5,
    perturb_sigma: float = 0.01,
    points: Optional[torch.Tensor] = None,
) -> torch.Tensor:
    """Compute per-node instability via bootstrap of edge weights.

    Perturb edge weights and measure how much each node's neighborhood changes.
    Unstable nodes have neighbors that change significantly under perturbation.

    Args:
        edge_index: (2, E)
        edge_weight: (E,)
        N: number of nodes
        n_bootstrap: number of bootstrap samples
        perturb_sigma: noise scale for perturbation
        points: (N, d) optional, not used in this implementation

    Returns:
        instability: (N,) float tensor, higher = more unstable.
    """
    device = edge_index.device
    E = edge_weight.shape[0]

    # Compute degree under original weights
    orig_deg = torch.zeros(N, device=device)
    orig_deg.scatter_add_(0, edge_index[0], edge_weight)

    # Bootstrap: perturb weights, recompute degree, measure variance
    deg_samples = []
    for _ in range(n_bootstrap):
        noise = torch.randn(E, device=device) * perturb_sigma
        w_noisy = (edge_weight + noise).clamp(min=0)
        deg = torch.zeros(N, device=device)
        deg.scatter_add_(0, edge_index[0], w_noisy)
        deg_samples.append(deg)

    deg_stack = torch.stack(deg_samples)  # (B, N)
    # Coefficient of variation as instability proxy
    mean_deg = deg_stack.mean(dim=0)
    std_deg = deg_stack.std(dim=0)
    instability = std_deg / mean_deg.clamp(min=1e-8)

    return instability


def prune_unstable_nodes(
    edge_index: torch.Tensor,
    edge_weight: torch.Tensor,
    N: int,
    instability: torch.Tensor,
    max_instability: float = 0.8,
) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor, int]:
    """Remove nodes with instability above threshold.

    Args:
        edge_index, edge_weight: graph.
        N: number of nodes.
        instability: (N,) instability scores.
        max_instability: threshold.

    Returns:
        new_edge_index, new_edge_weight, node_mask (N,), new_N.
    """
    node_mask = instability <= max_instability
    keep_nodes = node_mask.nonzero(as_tuple=True)[0]
    new_N = keep_nodes.shape[0]

    if new_N == N:
        return edge_index, edge_weight, node_mask, N

    # Remap
    remap = torch.full((N,), -1, dtype=torch.long, device=edge_index.device)
    remap[keep_nodes] = torch.arange(new_N, device=edge_index.device)

    # Filter edges
    src_ok = node_mask[edge_index[0]]
    dst_ok = node_mask[edge_index[1]]
    mask = src_ok & dst_ok

    new_ei = torch.stack([remap[edge_index[0, mask]], remap[edge_index[1, mask]]])
    new_ew = edge_weight[mask]

    logger.info(f"Node pruning: {N} → {new_N} nodes (max_instability={max_instability})")
    return new_ei, new_ew, node_mask, new_N


def phase2_prune_stats(
    n_edges_before: int, n_edges_after: int,
    n_prims_before: int, n_prims_after: int,
    n_nodes_before: int, n_nodes_after: int,
) -> Dict[str, float]:
    """Log Phase-2 pruning statistics."""
    return {
        "edges_before": n_edges_before,
        "edges_after": n_edges_after,
        "edge_survival": n_edges_after / max(n_edges_before, 1),
        "prims_before": n_prims_before,
        "prims_after": n_prims_after,
        "nodes_before": n_nodes_before,
        "nodes_after": n_nodes_after,
    }
