"""Point embedding module: identity or MLP."""
from __future__ import annotations

import torch
import torch.nn as nn
from typing import List

from ..utils.config import EmbedConfig


class PointEmbedding(nn.Module):
    """Embeds raw point features into embedding space.

    Modes:
      - identity: pass-through (embed_dim must match input dim or is ignored)
      - mlp: multi-layer perceptron
    """

    def __init__(self, input_dim: int, cfg: EmbedConfig):
        super().__init__()
        self.mode = cfg.mode
        self.input_dim = input_dim

        if cfg.mode == "identity":
            self.embed_dim = input_dim
            self.net = nn.Identity()
        elif cfg.mode == "mlp":
            self.embed_dim = cfg.embed_dim
            layers: List[nn.Module] = []
            in_d = input_dim
            act_fn = {"relu": nn.ReLU, "gelu": nn.GELU, "silu": nn.SiLU}[cfg.activation]
            for h in cfg.hidden_sizes:
                layers.append(nn.Linear(in_d, h))
                layers.append(act_fn())
                if cfg.dropout > 0:
                    layers.append(nn.Dropout(cfg.dropout))
                in_d = h
            layers.append(nn.Linear(in_d, cfg.embed_dim))
            self.net = nn.Sequential(*layers)
        else:
            raise ValueError(f"Unknown embedding mode: {cfg.mode}")

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        Args:
            x: (B, d) raw features
        Returns:
            z: (B, d') embeddings
        """
        return self.net(x)
