"""Primitive Induction: motif-based structural building blocks.

Finds local geometric primitives (triangles, cliques, stars, paths, cycles)
in the base graph. Each primitive has quality scores for downstream selection.

Stage B of the geometric machine learning pipeline.
"""
from __future__ import annotations

import torch
import numpy as np
from typing import Dict, List, Tuple, Optional
from dataclasses import dataclass, field


@dataclass
class PrimitiveConfig:
    """Configuration for primitive induction."""
    types: List[str] = field(default_factory=lambda: ["triangle"])
    # triangle | clique_k | star | path_k | cycle_k
    max_clique_size: int = 4
    max_path_length: int = 3
    max_primitives_per_type: int = 500   # cap per type
    quality_metric: str = "compactness"   # compactness | edge_consistency | stability
    min_quality: float = 0.0              # minimum quality to keep
    use_in_propagation: bool = False       # Phase 2: wire primitives into forward path


@dataclass
class Primitive:
    """A single geometric primitive."""
    type: str                    # triangle, clique, star, path, cycle
    nodes: List[int]             # node indices in base graph
    quality: float = 0.0        # quality score
    ports: Optional[List[int]] = None  # interface nodes for recursion


def induce_primitives(
    edge_index: torch.Tensor,
    points: torch.Tensor,
    cfg: PrimitiveConfig,
) -> List[Primitive]:
    """Find geometric primitives in the base graph.

    Args:
        edge_index: (2, E) base graph edges
        points: (N, d) point coordinates
        cfg: PrimitiveConfig

    Returns:
        list of Primitive objects
    """
    N = points.shape[0]
    device = points.device

    # Build adjacency lists (on CPU for motif search)
    adj_list = _build_adj_list(edge_index, N)
    edge_dists = _compute_edge_dists(edge_index, points)

    all_primitives = []

    for ptype in cfg.types:
        if ptype == "triangle":
            prims = _find_triangles(adj_list, points, edge_dists, cfg.max_primitives_per_type)
        elif ptype.startswith("clique_"):
            k = int(ptype.split("_")[1])
            prims = _find_cliques(adj_list, points, k, cfg.max_primitives_per_type)
        elif ptype == "star":
            prims = _find_stars(adj_list, points, cfg.max_primitives_per_type)
        elif ptype.startswith("path_"):
            k = int(ptype.split("_")[1])
            prims = _find_paths(adj_list, points, k, cfg.max_primitives_per_type)
        elif ptype.startswith("cycle_"):
            k = int(ptype.split("_")[1])
            prims = _find_cycles(adj_list, points, k, cfg.max_primitives_per_type)
        else:
            raise ValueError(f"Unknown primitive type: {ptype}")

        # Filter by quality
        prims = [p for p in prims if p.quality >= cfg.min_quality]
        all_primitives.extend(prims)

    return all_primitives


def _build_adj_list(edge_index: torch.Tensor, N: int) -> List[set]:
    """Build adjacency list from edge_index."""
    adj = [set() for _ in range(N)]
    src, dst = edge_index[0].cpu().tolist(), edge_index[1].cpu().tolist()
    for s, d in zip(src, dst):
        adj[s].add(d)
        adj[d].add(s)
    return adj


def _compute_edge_dists(
    edge_index: torch.Tensor, points: torch.Tensor
) -> Dict[Tuple[int, int], float]:
    """Compute edge distances as a dict."""
    src, dst = edge_index[0].cpu().tolist(), edge_index[1].cpu().tolist()
    dists = (points[edge_index[0]] - points[edge_index[1]]).norm(dim=1).cpu().tolist()
    edge_dists = {}
    for s, d, dist in zip(src, dst, dists):
        edge_dists[(s, d)] = dist
        edge_dists[(d, s)] = dist
    return edge_dists


def _compactness(nodes: List[int], points: torch.Tensor) -> float:
    """Compactness: ratio of mean intra-distance to bounding radius."""
    if len(nodes) < 2:
        return 1.0
    pts = points[nodes].cpu()
    centroid = pts.mean(dim=0)
    dists_to_center = (pts - centroid).norm(dim=1)
    bounding_r = dists_to_center.max().item()
    mean_dist = dists_to_center.mean().item()
    if bounding_r < 1e-8:
        return 1.0
    return 1.0 - (mean_dist / bounding_r)


# ── Triangle finder ──────────────────────────────────────────────────

def _find_triangles(
    adj: List[set],
    points: torch.Tensor,
    edge_dists: Dict,
    max_count: int,
) -> List[Primitive]:
    """Find triangles via common-neighbor intersection."""
    N = len(adj)
    triangles = []
    seen = set()

    for u in range(N):
        if len(triangles) >= max_count:
            break
        neighbors_u = adj[u]
        for v in neighbors_u:
            if v <= u:
                continue
            common = neighbors_u & adj[v]
            for w in common:
                if w <= v:
                    continue
                tri = tuple(sorted([u, v, w]))
                if tri not in seen:
                    seen.add(tri)
                    quality = _compactness(list(tri), points)
                    triangles.append(Primitive(
                        type="triangle",
                        nodes=list(tri),
                        quality=quality,
                        ports=[tri[0], tri[2]],  # endpoints
                    ))
                    if len(triangles) >= max_count:
                        break
            if len(triangles) >= max_count:
                break

    return triangles


# ── Clique finder ────────────────────────────────────────────────────

def _find_cliques(
    adj: List[set],
    points: torch.Tensor,
    k: int,
    max_count: int,
) -> List[Primitive]:
    """Find k-cliques via neighborhood intersection.

    For k=4, looks for nodes forming complete subgraphs.
    """
    if k <= 3:
        return _find_triangles(adj, points, {}, max_count)

    N = len(adj)
    cliques = []
    seen = set()

    # Start from triangles and try to extend
    for u in range(N):
        if len(cliques) >= max_count:
            break
        for v in adj[u]:
            if v <= u:
                continue
            common_uv = adj[u] & adj[v]
            for w in common_uv:
                if w <= v:
                    continue
                if k == 4:
                    # Extend triangle to 4-clique
                    common_uvw = common_uv & adj[w]
                    for x in common_uvw:
                        if x <= w:
                            continue
                        clique = tuple(sorted([u, v, w, x]))
                        if clique not in seen:
                            seen.add(clique)
                            quality = _compactness(list(clique), points)
                            cliques.append(Primitive(
                                type=f"clique_{k}",
                                nodes=list(clique),
                                quality=quality,
                                ports=[clique[0], clique[-1]],
                            ))
                            if len(cliques) >= max_count:
                                return cliques

    return cliques


# ── Star finder ──────────────────────────────────────────────────────

def _find_stars(
    adj: List[set],
    points: torch.Tensor,
    max_count: int,
) -> List[Primitive]:
    """Find star motifs: high-degree nodes with their neighbors."""
    N = len(adj)
    degrees = [(len(adj[i]), i) for i in range(N)]
    degrees.sort(reverse=True)

    stars = []
    for deg, center in degrees[:max_count]:
        if deg < 3:
            break
        neighbors = sorted(adj[center])[:min(deg, 8)]  # cap star size
        nodes = [center] + neighbors
        quality = _compactness(nodes, points)
        stars.append(Primitive(
            type="star",
            nodes=nodes,
            quality=quality,
            ports=neighbors[:2],  # two outermost as ports
        ))

    return stars


# ── Path finder ──────────────────────────────────────────────────────

def _find_paths(
    adj: List[set],
    points: torch.Tensor,
    length: int,
    max_count: int,
) -> List[Primitive]:
    """Find paths of given length via BFS-like exploration."""
    N = len(adj)
    paths = []
    seen = set()

    for start in range(N):
        if len(paths) >= max_count:
            break
        # DFS for paths of given length
        stack = [([start], {start})]
        while stack and len(paths) < max_count:
            path, visited = stack.pop()
            if len(path) == length + 1:
                key = tuple(sorted(path))
                if key not in seen:
                    seen.add(key)
                    quality = _compactness(path, points)
                    paths.append(Primitive(
                        type=f"path_{length}",
                        nodes=path,
                        quality=quality,
                        ports=[path[0], path[-1]],
                    ))
                continue
            last = path[-1]
            for nxt in adj[last]:
                if nxt not in visited:
                    stack.append((path + [nxt], visited | {nxt}))
                    if len(stack) > 1000:  # cap exploration
                        break

    return paths


# ── Cycle finder ─────────────────────────────────────────────────────

def _find_cycles(
    adj: List[set],
    points: torch.Tensor,
    length: int,
    max_count: int,
) -> List[Primitive]:
    """Find cycles of given length."""
    N = len(adj)
    cycles = []
    seen = set()

    for start in range(N):
        if len(cycles) >= max_count:
            break
        # DFS for cycles back to start
        stack = [([start], {start})]
        while stack and len(cycles) < max_count:
            path, visited = stack.pop()
            if len(path) == length:
                # Check if last node connects back to start
                if start in adj[path[-1]]:
                    key = tuple(sorted(path))
                    if key not in seen:
                        seen.add(key)
                        quality = _compactness(path, points)
                        cycles.append(Primitive(
                            type=f"cycle_{length}",
                            nodes=path,
                            quality=quality,
                            ports=[path[0], path[length // 2]],
                        ))
                continue
            last = path[-1]
            for nxt in adj[last]:
                if nxt not in visited or (nxt == start and len(path) == length - 1):
                    if nxt != start:
                        stack.append((path + [nxt], visited | {nxt}))
                    if len(stack) > 1000:
                        break

    return cycles


# ── Primitive summary statistics ─────────────────────────────────────

def primitive_stats(primitives: List[Primitive]) -> Dict[str, int]:
    """Compute counts and quality stats per primitive type."""
    from collections import Counter
    type_counts = Counter(p.type for p in primitives)
    stats = {}
    for ptype, count in type_counts.items():
        quals = [p.quality for p in primitives if p.type == ptype]
        stats[f"n_{ptype}"] = count
        stats[f"quality_{ptype}_mean"] = float(np.mean(quals)) if quals else 0.0
        stats[f"quality_{ptype}_std"] = float(np.std(quals)) if len(quals) > 1 else 0.0
    stats["n_total"] = len(primitives)
    return stats
