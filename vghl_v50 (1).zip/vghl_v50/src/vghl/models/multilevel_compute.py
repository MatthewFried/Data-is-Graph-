"""Multilevel Computation: fixed propagation over a hierarchy of graphs.

Implements bottom-up pooling + propagation and top-down scatter + fusion.
No learned weights in the propagation — only the readout head is trainable.

MVP scheme: Bottom-up + Top-down residual fusion
  1. Propagate at level 0 for T0 steps.
  2. Pool to level 1 supernodes (mean/max).
  3. Propagate at level 1 for T1 steps.
  4. Repeat up to level L.
  5. Top-down: broadcast parent features, fuse with child features via sum.
  6. Final level-0 features go to readout head.
"""
from __future__ import annotations

import logging
import torch
from typing import List, Optional
from dataclasses import dataclass

from .propagation import PropagationConfig, propagate
from .recursion import LevelGraph, pool_to_supernodes, scatter_to_base

logger = logging.getLogger(__name__)


@dataclass
class MultilevelComputeConfig:
    """Configuration for multilevel computation."""
    scheme: str = "bottom_up_top_down"  # bottom_up_top_down | bottom_up_only
    steps_per_level: int = 3
    pool_mode: str = "mean"             # mean | max
    fusion_mode: str = "sum"            # sum | replace
    top_down_scale: float = 0.5
    query_assignment: str = "nearest_anchor"  # nearest_anchor | nearest_port


def multilevel_propagate(
    h0: torch.Tensor,
    levels: List[LevelGraph],
    prop_cfg: PropagationConfig,
    compute_cfg: MultilevelComputeConfig,
) -> torch.Tensor:
    """Run multilevel computation over a hierarchy.

    Args:
        h0: (N0, d) initial features at level 0.
        levels: list of LevelGraph objects (level 0, 1, ..., L).
        prop_cfg: propagation config (operator type, alpha, etc.).
        compute_cfg: multilevel computation settings.

    Returns:
        h_final: (N0, d) final level-0 features after multilevel computation.
    """
    if len(levels) <= 1:
        # No hierarchy — just propagate at level 0
        lv0 = levels[0]
        return propagate(h0, lv0.edge_index, lv0.edge_weight, lv0.n_nodes, prop_cfg)

    # ── Bottom-up ────────────────────────────────────────────────────
    level_features = []  # h at each level after propagation
    h = h0

    for lv_idx, lv in enumerate(levels):
        # Propagation config for this level
        lv_prop = PropagationConfig(
            type=prop_cfg.type,
            steps=compute_cfg.steps_per_level,
            alpha=prop_cfg.alpha,
            t=prop_cfg.t,
        )

        # Propagate at this level
        if lv.edge_index.shape[1] > 0:
            h = propagate(h, lv.edge_index, lv.edge_weight, lv.n_nodes, lv_prop)

        level_features.append(h)

        # Pool to next level (if not the last)
        if lv_idx < len(levels) - 1:
            next_lv = levels[lv_idx + 1]
            h = pool_to_supernodes(
                h, next_lv.membership, next_lv.n_nodes,
                mode=compute_cfg.pool_mode,
            )

    if compute_cfg.scheme == "bottom_up_only":
        # Just scatter top-level features back to level 0
        h_out = level_features[0]
        for lv_idx in range(len(levels) - 1, 0, -1):
            h_parent = level_features[lv_idx]
            membership = levels[lv_idx].membership
            h_out = h_out + compute_cfg.top_down_scale * scatter_to_base(
                h_parent, membership, mode="replace"
            )
        return h_out

    # ── Top-down (default: bottom_up_top_down) ───────────────────────
    # Start from highest level and fuse downward
    h_out = level_features[-1]

    for lv_idx in range(len(levels) - 1, 0, -1):
        membership = levels[lv_idx].membership
        # Broadcast parent features to children
        h_broadcast = scatter_to_base(h_out, membership, mode="replace")

        # Fuse with child's own propagated features
        h_child = level_features[lv_idx - 1]

        if compute_cfg.fusion_mode == "sum":
            h_out = h_child + compute_cfg.top_down_scale * h_broadcast
        elif compute_cfg.fusion_mode == "replace":
            h_out = h_broadcast
        else:
            raise ValueError(f"Unknown fusion_mode: {compute_cfg.fusion_mode}")

    return h_out


def multilevel_propagate_queries(
    h_query: torch.Tensor,
    h_anchors_level0: torch.Tensor,
    levels: List[LevelGraph],
    query_edge_index: torch.Tensor,
    query_edge_weight: torch.Tensor,
    n_anchors: int,
    prop_cfg: PropagationConfig,
    compute_cfg: MultilevelComputeConfig,
) -> torch.Tensor:
    """Propagate query features through the multilevel hierarchy.

    Queries attach at level 0 via bipartite edges to anchors.
    They receive information from higher levels via nearest-anchor mapping.

    Args:
        h_query: (M, d) raw query features (embedded).
        h_anchors_level0: (N0, d) propagated anchor features at level 0.
        levels: hierarchy (from build_multilevel_graph).
        query_edge_index: (2, E_bi) bipartite edges (query offset by n_anchors).
        query_edge_weight: (E_bi,) bipartite edge weights.
        n_anchors: number of anchor nodes.
        prop_cfg: propagation config.
        compute_cfg: multilevel computation config.

    Returns:
        h_query_out: (M, d) query features after multilevel propagation.
    """
    M = h_query.shape[0]
    N_total = n_anchors + M

    # Level 0: propagate queries with anchors via augmented graph
    all_h = torch.cat([h_anchors_level0, h_query], dim=0)
    # Combine anchor edges + bipartite edges
    anchor_ei = levels[0].edge_index
    aug_ei = torch.cat([anchor_ei, query_edge_index], dim=1)
    aug_ew = torch.cat([levels[0].edge_weight, query_edge_weight], dim=0)

    lv_prop = PropagationConfig(
        type=prop_cfg.type,
        steps=min(compute_cfg.steps_per_level, 2),  # fewer steps for queries
        alpha=prop_cfg.alpha,
        t=prop_cfg.t,
    )
    h_all = propagate(all_h, aug_ei, aug_ew, N_total, lv_prop)

    h_query_prop = h_all[n_anchors:]
    h_anchor_prop = h_all[:n_anchors]

    if len(levels) <= 1:
        return h_query_prop

    # Higher levels: map queries to nearest anchor's supernode
    # Two modes: nearest_anchor (via bipartite edges) or nearest_port (via port distances)
    if (compute_cfg.query_assignment == "nearest_port"
            and len(levels) > 1 and levels[1].ports is not None):
        query_to_super = _get_query_nearest_port(
            h_query, h_anchor_prop, levels[1].ports, levels[1].membership, n_anchors
        )
        use_port = True
    else:
        query_to_anchor = _get_query_nearest_anchor(
            query_edge_index, query_edge_weight, n_anchors, M
        )
        use_port = False

    # Collect level features for anchors via bottom-up
    anchor_level_features = [h_anchor_prop]
    h_up = h_anchor_prop
    for lv_idx in range(1, len(levels)):
        lv = levels[lv_idx]
        h_up = pool_to_supernodes(h_up, lv.membership, lv.n_nodes, compute_cfg.pool_mode)
        if lv.edge_index.shape[1] > 0:
            lv_p = PropagationConfig(
                type=prop_cfg.type, steps=compute_cfg.steps_per_level,
                alpha=prop_cfg.alpha, t=prop_cfg.t,
            )
            h_up = propagate(h_up, lv.edge_index, lv.edge_weight, lv.n_nodes, lv_p)
        anchor_level_features.append(h_up)

    # Top-down for queries: broadcast from highest level back down
    h_top = anchor_level_features[-1]
    for lv_idx in range(len(levels) - 1, 0, -1):
        membership = levels[lv_idx].membership
        h_top = scatter_to_base(h_top, membership, mode="replace")
        h_child = anchor_level_features[lv_idx - 1]
        h_top = h_child + compute_cfg.top_down_scale * h_top

    # h_top is now (n_anchors, d) — map to queries
    if use_port:
        # Map via port-assigned supernodes: get level-1 features for each query
        h_super1 = anchor_level_features[1] if len(anchor_level_features) > 1 else h_top
        h_query_hierarchical = h_super1[query_to_super]  # (M, d)
    else:
        h_query_hierarchical = h_top[query_to_anchor]  # (M, d)

    # Fuse query's own propagated features with hierarchical info
    return h_query_prop + compute_cfg.top_down_scale * h_query_hierarchical


def _get_query_nearest_anchor(
    query_edge_index: torch.Tensor,
    query_edge_weight: torch.Tensor,
    n_anchors: int,
    n_queries: int,
) -> torch.Tensor:
    """For each query, find its nearest anchor from bipartite edges.

    Uses the bipartite edge with highest weight for each query.

    Returns: (n_queries,) tensor of anchor indices.
    """
    device = query_edge_index.device
    nearest = torch.zeros(n_queries, dtype=torch.long, device=device)

    src, dst = query_edge_index[0], query_edge_index[1]

    # Collect all (query_idx, anchor_idx, weight) from both edge directions
    # query→anchor edges: src >= n_anchors, dst < n_anchors
    mask_qa = (src >= n_anchors) & (dst < n_anchors)
    # anchor→query edges: dst >= n_anchors, src < n_anchors
    mask_aq = (dst >= n_anchors) & (src < n_anchors)

    q_indices = []
    a_indices = []
    weights = []

    if mask_qa.any():
        q_indices.append(src[mask_qa] - n_anchors)
        a_indices.append(dst[mask_qa])
        weights.append(query_edge_weight[mask_qa])

    if mask_aq.any():
        q_indices.append(dst[mask_aq] - n_anchors)
        a_indices.append(src[mask_aq])
        weights.append(query_edge_weight[mask_aq])

    if not q_indices:
        return nearest

    all_q = torch.cat(q_indices)
    all_a = torch.cat(a_indices)
    all_w = torch.cat(weights)

    # For each query, find the edge with max weight
    best_w = torch.full((n_queries,), -float("inf"), device=device)
    best_a = torch.zeros(n_queries, dtype=torch.long, device=device)
    for i in range(all_q.shape[0]):
        qi = all_q[i].item()
        if all_w[i] > best_w[qi]:
            best_w[qi] = all_w[i]
            best_a[qi] = all_a[i]

    return best_a


def _get_query_nearest_port(
    h_query: torch.Tensor,
    h_anchors: torch.Tensor,
    port_indices: torch.Tensor,
    membership: torch.Tensor,
    n_anchors: int,
) -> torch.Tensor:
    """Map each query to the nearest port node's supernode.

    Ports are interface nodes of supernodes — this gives a cleaner
    mapping than nearest-anchor because it respects the machine's
    structural boundaries.

    Args:
        h_query: (M, d) query features.
        h_anchors: (N, d) anchor features at level 0.
        port_indices: (n_super, max_ports) port node indices, -1 padded.
        membership: (N,) anchor → supernode mapping.
        n_anchors: number of anchors.

    Returns:
        (M,) tensor of supernode indices for each query.
    """
    device = h_query.device
    M = h_query.shape[0]
    n_super = port_indices.shape[0]

    # Collect valid port nodes and their supernode IDs
    valid_mask = port_indices >= 0
    port_flat = port_indices[valid_mask]
    super_ids = torch.arange(n_super, device=device).unsqueeze(1).expand_as(port_indices)
    port_super = super_ids[valid_mask]

    if port_flat.shape[0] == 0:
        return torch.zeros(M, dtype=torch.long, device=device)

    # Port features from anchor features
    port_feats = h_anchors[port_flat]  # (P, d)

    # For each query, find nearest port
    dists = torch.cdist(h_query.unsqueeze(0), port_feats.unsqueeze(0)).squeeze(0)  # (M, P)
    nearest_port_local = dists.argmin(dim=1)  # (M,)

    return port_super[nearest_port_local]
