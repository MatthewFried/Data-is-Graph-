"""Phase-2 Structural Edit Loop: iterative machine refinement.

Implements the outer loop:
  build_machine → score → structural_edit → rebuild → score → accept/reject

Structural edits:
  - prune_edges: remove long/unstable edges, rebuild hierarchy
  - prune_primitives: drop low-quality primitives, rebuild
  - merge_equivalent: merge behaviorally equivalent supernodes

Each edit is scored via: val_accuracy - α*log(|V|) - β*log(|E|) - γ*instability
"""
from __future__ import annotations

import logging
import math
import time as _time
import torch
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass

from .primitives import Primitive
from .recursion import (
    RecursionConfig, LevelGraph, build_multilevel_graph,
)
from .multilevel_compute import (
    MultilevelComputeConfig, multilevel_propagate,
)
from .merge import (
    MergeConfig, compute_transition_signatures,
    find_merge_candidates, apply_merges,
)
from .noise_phase2 import (
    prune_edges_by_length, prune_primitives_by_quality,
)

logger = logging.getLogger(__name__)


@dataclass
class EditLoopConfig:
    """Configuration for the structural edit loop."""
    enabled: bool = False
    max_iterations: int = 3
    # Scoring weights
    alpha_nodes: float = 0.01
    beta_edges: float = 0.01
    gamma_instability: float = 0.1
    # Edit operators
    try_edge_prune: bool = True
    edge_prune_percentile: float = 0.95
    try_primitive_prune: bool = True
    primitive_quality_step: float = 0.05
    try_merge: bool = True
    # Acceptance / budget
    min_improvement: float = 0.001
    max_proposals: int = 50        # total proposals before forced stop
    max_no_improve: int = 2        # consecutive no-improve iterations → stop


def score_machine(
    levels: List[LevelGraph],
    val_accuracy: float,
    instability: float = 0.0,
    alpha: float = 0.01,
    beta: float = 0.01,
    gamma: float = 0.1,
) -> Tuple[float, Dict[str, float]]:
    """Score a machine: val_acc - α*log(|V|) - β*log(|E|) - γ*instability."""
    total_nodes = sum(lv.n_nodes for lv in levels)
    total_edges = sum(lv.edge_index.shape[1] for lv in levels)

    node_pen = alpha * math.log(max(total_nodes, 1))
    edge_pen = beta * math.log(max(total_edges, 1))
    instab_pen = gamma * instability

    score = val_accuracy - node_pen - edge_pen - instab_pen
    details = {
        "score": score, "val_accuracy": val_accuracy,
        "total_nodes": total_nodes, "total_edges": total_edges,
        "node_penalty": node_pen, "edge_penalty": edge_pen,
        "instability_penalty": instab_pen,
    }
    return score, details


def run_edit_loop(
    z: torch.Tensor,
    edge_index: torch.Tensor,
    edge_weight: torch.Tensor,
    primitives: List[Primitive],
    recursion_cfg: RecursionConfig,
    multilevel_cfg: MultilevelComputeConfig,
    prop_cfg,
    merge_cfg: MergeConfig,
    edit_cfg: EditLoopConfig,
    eval_fn=None,
) -> Tuple[List[LevelGraph], List[Primitive], torch.Tensor, torch.Tensor, Dict]:
    """Run the structural edit loop: build → score → edit → rebuild → score.

    Args:
        z: (N, d) embedded anchor features.
        edge_index, edge_weight: base graph.
        primitives: initial primitive list.
        eval_fn: callable(h_propagated) → float (val accuracy). None = proxy.

    Returns:
        best_levels, best_primitives, best_edge_index, best_edge_weight, iteration_log
    """
    # Build initial hierarchy
    best_prims = list(primitives)
    best_levels = build_multilevel_graph(z, edge_index, edge_weight, best_prims, recursion_cfg)
    best_h = multilevel_propagate(z, best_levels, prop_cfg, multilevel_cfg)
    best_acc = eval_fn(best_h) if eval_fn is not None else 0.5

    # Compute instability for initial machine
    instab = _compute_edit_instability(z, edge_index, edge_weight, best_h, eval_fn)
    best_score, best_details = score_machine(
        best_levels, best_acc, instability=instab,
        alpha=edit_cfg.alpha_nodes, beta=edit_cfg.beta_edges,
        gamma=edit_cfg.gamma_instability,
    )
    log = {"iteration_0": best_details}
    logger.info(f"Edit loop iter 0: score={best_score:.4f}, acc={best_acc:.4f}")

    current_ei = edge_index
    current_ew = edge_weight
    best_ei = edge_index
    best_ew = edge_weight
    current_prims = list(primitives)
    current_min_quality = 0.0
    total_proposals = 0
    total_accepts = 0
    no_improve_streak = 0
    iteration = 0
    t0 = _time.perf_counter()

    for iteration in range(1, edit_cfg.max_iterations + 1):
        improved = False

        # Budget check
        if total_proposals >= edit_cfg.max_proposals:
            logger.info(f"Edit loop budget exhausted: {total_proposals} proposals")
            break

        # ── Edge pruning ──────────────────────────────────────────
        if edit_cfg.try_edge_prune:
            pruned_ei, pruned_ew = prune_edges_by_length(
                current_ei, current_ew, z, edit_cfg.edge_prune_percentile
            )
            total_proposals += 1
            if pruned_ei.shape[1] > 0:
                cand_levels = build_multilevel_graph(z, pruned_ei, pruned_ew, current_prims, recursion_cfg)
                cand_h = multilevel_propagate(z, cand_levels, prop_cfg, multilevel_cfg)
                acc = eval_fn(cand_h, pruned_ei, pruned_ew) if eval_fn else 0.5
                instab = _compute_edit_instability(z, pruned_ei, pruned_ew, cand_h, eval_fn)
                sc, det = score_machine(cand_levels, acc, instability=instab,
                    alpha=edit_cfg.alpha_nodes, beta=edit_cfg.beta_edges,
                    gamma=edit_cfg.gamma_instability)
                if sc > best_score + edit_cfg.min_improvement:
                    best_score, best_details, best_levels, best_h, best_acc = sc, det, cand_levels, cand_h, acc
                    best_prims = list(current_prims)
                    current_ei, current_ew = pruned_ei, pruned_ew
                    best_ei, best_ew = pruned_ei, pruned_ew
                    improved = True
                    total_accepts += 1
                    logger.info(f"  Edge prune accepted: score={sc:.4f}")

        # ── Primitive quality pruning ─────────────────────────────
        if edit_cfg.try_primitive_prune:
            new_min = current_min_quality + edit_cfg.primitive_quality_step
            pruned_prims = prune_primitives_by_quality(current_prims, new_min)
            total_proposals += 1
            if len(pruned_prims) > 0:
                cand_levels = build_multilevel_graph(z, current_ei, current_ew, pruned_prims, recursion_cfg)
                cand_h = multilevel_propagate(z, cand_levels, prop_cfg, multilevel_cfg)
                acc = eval_fn(cand_h) if eval_fn else 0.5
                instab = _compute_edit_instability(z, current_ei, current_ew, cand_h, eval_fn)
                sc, det = score_machine(cand_levels, acc, instability=instab,
                    alpha=edit_cfg.alpha_nodes, beta=edit_cfg.beta_edges,
                    gamma=edit_cfg.gamma_instability)
                if sc > best_score + edit_cfg.min_improvement:
                    best_score, best_details, best_levels, best_h, best_acc = sc, det, cand_levels, cand_h, acc
                    best_prims = pruned_prims
                    current_prims = pruned_prims
                    current_min_quality = new_min
                    improved = True
                    total_accepts += 1
                    logger.info(f"  Primitive prune accepted: score={sc:.4f}")

        # ── Merge ─────────────────────────────────────────────────
        if edit_cfg.try_merge and merge_cfg.enabled and len(best_levels) > 1:
            for lv_idx in range(1, len(best_levels)):
                lv = best_levels[lv_idx]
                if lv.edge_index.shape[1] == 0 or lv.n_nodes <= 2:
                    continue
                sigs = compute_transition_signatures(
                    lv.edge_index, lv.edge_weight, lv.n_nodes,
                    merge_cfg.signature_dim,
                )
                pairs = find_merge_candidates(sigs, lv.edge_index, lv.n_nodes, merge_cfg)
                if not pairs:
                    continue
                total_proposals += 1
                new_ei, new_ew, compact, new_N = apply_merges(
                    lv.edge_index, lv.edge_weight, lv.n_nodes, pairs
                )
                # Tentatively update
                old = (lv.edge_index, lv.edge_weight, lv.membership, lv.n_nodes)
                lv.edge_index, lv.edge_weight = new_ei, new_ew
                lv.membership, lv.n_nodes = compact[lv.membership], new_N

                cand_h = multilevel_propagate(z, best_levels, prop_cfg, multilevel_cfg)
                acc = eval_fn(cand_h) if eval_fn else 0.5
                instab = _compute_edit_instability(z, current_ei, current_ew, cand_h, eval_fn)
                sc, det = score_machine(best_levels, acc, instability=instab,
                    alpha=edit_cfg.alpha_nodes, beta=edit_cfg.beta_edges,
                    gamma=edit_cfg.gamma_instability)
                if sc > best_score + edit_cfg.min_improvement:
                    best_score, best_details, best_h, best_acc = sc, det, cand_h, acc
                    improved = True
                    total_accepts += 1
                    logger.info(f"  Merge accepted at level {lv_idx}: score={sc:.4f}")
                else:
                    lv.edge_index, lv.edge_weight, lv.membership, lv.n_nodes = old

        log[f"iteration_{iteration}"] = best_details
        logger.info(f"Edit loop iter {iteration}: score={best_score:.4f}, improved={improved}")
        if not improved:
            no_improve_streak += 1
            if no_improve_streak >= edit_cfg.max_no_improve:
                logger.info(f"No improvement for {no_improve_streak} iterations, stopping")
                break
        else:
            no_improve_streak = 0

    elapsed = _time.perf_counter() - t0
    last_iter = iteration if edit_cfg.max_iterations > 0 else 0
    log["budget"] = {
        "total_proposals": total_proposals,
        "total_accepts": total_accepts,
        "accept_rate": total_accepts / max(total_proposals, 1),
        "iterations_used": last_iter,
        "elapsed_seconds": round(elapsed, 3),
    }
    logger.info(
        f"Edit loop done: {total_proposals} proposals, {total_accepts} accepts, "
        f"{elapsed:.2f}s"
    )

    return best_levels, best_prims, best_ei, best_ew, log


def _compute_edit_instability(
    z: torch.Tensor,
    edge_index: torch.Tensor,
    edge_weight: torch.Tensor,
    h: torch.Tensor,
    eval_fn,
    n_trials: int = 3,
    jitter_sigma: float = 0.01,
) -> float:
    """Estimate instability via prediction flip rate under feature perturbation.

    Fits ridge probe on h once, gets baseline predictions on val (through eval_fn),
    then perturbs h and measures how many predictions flip.

    Args:
        z, edge_index, edge_weight: base graph (reserved for future use).
        h: (N, d) propagated features.
        eval_fn: callable(h) → float accuracy. Must internally fit ridge
            and predict on val. We use it to get predictions.
        n_trials: number of perturbation trials.
        jitter_sigma: noise scale.

    Returns:
        float instability in [0, 1]: mean fraction of predictions that flip.
    """
    if eval_fn is None:
        return 0.0

    try:
        # We need predictions, not just accuracy. Since eval_fn only returns
        # accuracy, we compute flip rate as:
        #   flip_rate ≈ 2 * |acc_base - acc_perturbed|
        # This is an upper bound on flip rate. For small perturbations and
        # well-calibrated classifiers, it's a reasonable proxy.
        # A flip rate of 0.1 means ~10% of predictions change under jitter.
        base_acc = eval_fn(h)
        flip_rates = []
        for _ in range(n_trials):
            h_noisy = h + torch.randn_like(h) * jitter_sigma
            noisy_acc = eval_fn(h_noisy)
            # Accuracy change is a lower bound on flip rate
            # (some flips cancel: correct→wrong and wrong→correct)
            # We use 2*|Δacc| as conservative proxy
            flip_rates.append(min(2.0 * abs(noisy_acc - base_acc), 1.0))
        return sum(flip_rates) / max(len(flip_rates), 1)
    except Exception:
        return 0.0
