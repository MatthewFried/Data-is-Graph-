"""Region graph construction module.

Builds adjacency between regions using:
  - Co-activation: W^T W where W is the assignment matrix
  - Site-kNN: kNN among sites in embedding space
  - Both: union of edges from both methods
  - Soft kernel with guaranteed connectivity
"""
from __future__ import annotations

import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Tuple, Optional, Dict, List

from ..utils.config import RegionGraphConfig


class RegionGraphBuilder(nn.Module):
    """Builds region-level adjacency from assignments and/or sites."""

    def __init__(self, m: int, cfg: RegionGraphConfig):
        super().__init__()
        self.m = m
        self.method = cfg.method
        self.K = cfg.K
        self.sigma = cfg.sigma
        self.symmetrize = cfg.symmetrize
        self.min_degree = getattr(cfg, 'min_degree', 0)
        self.edge_threshold = getattr(cfg, 'edge_threshold', 0.0)

    def forward(
        self,
        assignments: torch.Tensor,
        sites: torch.Tensor,
        is_boundary: Optional[torch.Tensor] = None,
    ) -> Dict[str, torch.Tensor]:
        """Build region graph.

        Args:
            assignments: (B, m) soft assignment weights for one scale
            sites: (m, d') site embeddings
            is_boundary: (B,) optional boundary mask

        Returns:
            dict with edge_index, edge_weight, adj_dense, active_mask
        """
        # Identify active regions (non-trivial assignment mass)
        region_mass = assignments.sum(dim=0)  # (m,)
        active_mask = region_mass > (assignments.shape[0] * 0.01)  # > 1% of points
        n_active = active_mask.sum().item()

        if self.method == "coact":
            adj = self._coactivation_adjacency(assignments)
        elif self.method == "site_knn":
            adj = self._site_knn_adjacency(sites)
        elif self.method == "boundary_mass":
            adj = self._boundary_mass_adjacency(assignments, is_boundary)
        elif self.method == "both":
            adj1 = self._coactivation_adjacency(assignments)
            adj2 = self._site_knn_adjacency(sites)
            adj = torch.max(adj1, adj2)
        elif self.method == "soft_kernel":
            adj = self._soft_kernel_adjacency(sites, assignments)
        else:
            raise ValueError(f"Unknown method: {self.method}")

        # Convert to sparse
        edge_index, edge_weight = self._dense_to_sparse(adj)

        return {
            "edge_index": edge_index,
            "edge_weight": edge_weight,
            "adj_dense": adj,
            "active_mask": active_mask,
            "n_active": n_active,
        }

    def _soft_kernel_adjacency(
        self, sites: torch.Tensor, assignments: torch.Tensor
    ) -> torch.Tensor:
        """Soft Gaussian kernel on sites, weighted by region activity.

        No hard top-K cutoff. Instead: Gaussian weights + edge threshold.
        Guarantees connectivity among active regions by keeping all edges
        above threshold and enforcing minimum degree.
        """
        m = sites.shape[0]

        # Region mass for activity weighting
        region_mass = assignments.sum(dim=0)  # (m,)
        mass_norm = region_mass / (region_mass.sum() + 1e-10)

        # Pairwise distances in embedding space
        dists_sq = torch.cdist(sites.unsqueeze(0), sites.unsqueeze(0)).squeeze(0) ** 2

        # Adaptive bandwidth: median of pairwise distances among active regions
        active_mask = region_mass > (assignments.shape[0] * 0.01)
        if active_mask.sum() > 1:
            active_dists = dists_sq[active_mask][:, active_mask]
            # Use median of nonzero distances as bandwidth
            nonzero_dists = active_dists[active_dists > 0]
            if nonzero_dists.numel() > 0:
                sigma_sq = nonzero_dists.median().item()
            else:
                sigma_sq = self.sigma ** 2
        else:
            sigma_sq = self.sigma ** 2

        sigma_sq = max(sigma_sq, 1e-6)

        # Gaussian kernel
        W = torch.exp(-dists_sq / (2 * sigma_sq))
        W.fill_diagonal_(0)

        # Weight by geometric mean of region masses (active regions connect strongly)
        mass_outer = (mass_norm.unsqueeze(0) * mass_norm.unsqueeze(1)).sqrt()
        W = W * mass_outer

        # Symmetrize
        W = (W + W.t()) / 2

        # Threshold small edges
        threshold = max(self.edge_threshold, W.max().item() * 0.01)
        W = W * (W > threshold).float()

        # Ensure minimum degree among active regions
        if self.min_degree > 0 and active_mask.sum() > 1:
            for i in range(m):
                if not active_mask[i]:
                    continue
                deg_i = (W[i] > 0).sum().item()
                if deg_i < self.min_degree:
                    # Add edges to nearest active neighbors
                    active_dists_i = dists_sq[i].clone()
                    active_dists_i[~active_mask] = float('inf')
                    active_dists_i[i] = float('inf')
                    need = self.min_degree - int(deg_i)
                    _, nearest = active_dists_i.topk(need, largest=False)
                    for j in nearest:
                        val = torch.exp(-dists_sq[i, j] / (2 * sigma_sq))
                        W[i, j] = max(W[i, j].item(), val.item())
                        W[j, i] = max(W[j, i].item(), val.item())

        # Normalize to [0, 1]
        max_val = W.max()
        if max_val > 0:
            W = W / max_val

        return W

    def _coactivation_adjacency(self, W: torch.Tensor) -> torch.Tensor:
        """Co-activation adjacency: C = W^T W, then top-K."""
        W_norm = W / (W.sum(dim=0, keepdim=True) + 1e-10)
        C = W_norm.t() @ W_norm
        C.fill_diagonal_(0)
        adj = self._topk_sparsify(C)
        return adj

    def _site_knn_adjacency(self, sites: torch.Tensor) -> torch.Tensor:
        """kNN adjacency among sites."""
        dists = torch.cdist(sites.unsqueeze(0), sites.unsqueeze(0)).squeeze(0) ** 2
        weights = torch.exp(-dists / (2 * self.sigma ** 2))
        weights.fill_diagonal_(0)
        adj = self._topk_sparsify(weights)
        return adj

    def _boundary_mass_adjacency(
        self, W: torch.Tensor, is_boundary: Optional[torch.Tensor] = None,
    ) -> torch.Tensor:
        """Adjacency from shared boundary-point mass."""
        if is_boundary is None or not is_boundary.any():
            return self._coactivation_adjacency(W)
        W_b = W[is_boundary]
        W_b_norm = W_b / (W_b.sum(dim=0, keepdim=True) + 1e-10)
        C = W_b_norm.t() @ W_b_norm
        C.fill_diagonal_(0)
        return self._topk_sparsify(C)

    def _topk_sparsify(self, C: torch.Tensor) -> torch.Tensor:
        """Keep only top-K neighbors per node, then optionally symmetrize."""
        m = C.shape[0]
        K = min(self.K, m - 1)
        topk_vals, topk_idx = C.topk(K, dim=1)
        mask = torch.zeros_like(C)
        mask.scatter_(1, topk_idx, 1.0)
        adj = C * mask
        if self.symmetrize:
            adj = torch.max(adj, adj.t())
        max_val = adj.max()
        if max_val > 0:
            adj = adj / max_val
        return adj

    def _dense_to_sparse(
        self, adj: torch.Tensor
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """Convert dense adjacency to sparse edge_index + weights."""
        nonzero = adj.nonzero(as_tuple=False)
        if nonzero.numel() == 0:
            return (
                torch.zeros(2, 0, dtype=torch.long, device=adj.device),
                torch.zeros(0, device=adj.device),
            )
        edge_index = nonzero.t().contiguous()
        edge_weight = adj[edge_index[0], edge_index[1]]
        return edge_index, edge_weight
