"""Anchor Graph: dataset-level graph construction for the Geometric Machine.

Two modes:
  - transductive_full_graph: Build one graph on full TRAIN set, propagate once.
    At eval, attach val/test nodes to train anchors via bipartite edges.
  - inductive_anchor_graph: Same train graph as anchors. Query samples connect
    to k-nearest anchors for bipartite propagation.

Both modes decouple graph structure from minibatch composition,
ensuring predictions depend on dataset geometry, not batch sampling.
"""
from __future__ import annotations

import logging
import torch
import numpy as np
from typing import Dict, Tuple, Optional
from dataclasses import dataclass

from .knn_backend import knn, knn_to_edge_index, KNNIndex
from .graph_builder import GraphBuilderConfig, build_base_graph

logger = logging.getLogger(__name__)


@dataclass
class AnchorGraphConfig:
    """Configuration for anchor/transductive graph modes."""
    mode: str = "transductive_full_graph"
    # transductive_full_graph | inductive_anchor_graph
    anchor_k: int = 8           # k nearest anchors for query attachment
    bipartite_steps: int = 1    # propagation steps on bipartite query→anchor edges
    rebuild_every: int = 0      # re-build anchor graph every N epochs (0 = never)
    query_query_k: int = 0      # if >0 (inductive only), build query-query kNN edges


class AnchorGraph:
    """Manages dataset-level graph construction and query attachment.

    Lifecycle:
        1. build_anchor_graph(X_train, cfg) — called once (or on rebuild)
        2. get_propagated_train() — propagated train features (cached)
        3. attach_queries(X_query) — connect query to anchors, propagate
    """

    def __init__(
        self,
        graph_cfg: GraphBuilderConfig,
        anchor_cfg: AnchorGraphConfig,
        device: str = "cpu",
    ):
        self.graph_cfg = graph_cfg
        self.anchor_cfg = anchor_cfg
        self.device = device

        # Cached state
        self._anchor_points: Optional[torch.Tensor] = None
        self._anchor_edge_index: Optional[torch.Tensor] = None
        self._anchor_edge_weight: Optional[torch.Tensor] = None
        self._anchor_edge_dist: Optional[torch.Tensor] = None
        self._n_anchors: int = 0
        self._built: bool = False
        self._knn_index: Optional[KNNIndex] = None  # cached for fast query attachment

    @property
    def is_built(self) -> bool:
        return self._built

    @property
    def n_anchors(self) -> int:
        return self._n_anchors

    @property
    def anchor_edge_index(self) -> Optional[torch.Tensor]:
        return self._anchor_edge_index

    @property
    def anchor_edge_weight(self) -> Optional[torch.Tensor]:
        return self._anchor_edge_weight

    @property
    def anchor_edge_dist(self) -> Optional[torch.Tensor]:
        return self._anchor_edge_dist

    @torch.no_grad()
    def build_anchor_graph(self, X_train: torch.Tensor) -> Dict[str, torch.Tensor]:
        """Build the anchor graph from the full training set.

        Args:
            X_train: (N_train, d) training point features (in embedding space).

        Returns:
            dict with edge_index, edge_weight, edge_dist for the anchor graph.
        """
        self._anchor_points = X_train.to(self.device)
        self._n_anchors = X_train.shape[0]

        logger.info(
            f"Building anchor graph: N={self._n_anchors}, "
            f"type={self.graph_cfg.type}, k={self.graph_cfg.k}"
        )

        graph = build_base_graph(self._anchor_points, self.graph_cfg)
        self._anchor_edge_index = graph["edge_index"]
        self._anchor_edge_weight = graph["edge_weight"]
        self._anchor_edge_dist = graph["edge_dist"]
        self._built = True

        # Build cached kNN index for fast query attachment
        self._knn_index = KNNIndex(self._anchor_points)

        logger.info(
            f"Anchor graph: {self._anchor_edge_index.shape[1]} edges, "
            f"density={self._anchor_edge_index.shape[1] / max(self._n_anchors * (self._n_anchors - 1), 1):.6f}"
        )
        return graph

    @torch.no_grad()
    def attach_queries(
        self,
        X_query: torch.Tensor,
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """Attach query points to anchor graph via k-nearest anchors.

        Creates bipartite edges: query → nearest anchors.

        Args:
            X_query: (M, d) query point features.

        Returns:
            bipartite_edge_index: (2, M*k) edges from query nodes to anchor nodes.
                Source indices are offset by N_anchors (query node i → N_anchors + i).
            bipartite_edge_weight: (M*k,) edge weights.
        """
        assert self._built, "Must call build_anchor_graph first"

        X_query = X_query.to(self.device)
        M = X_query.shape[0]
        k = min(self.anchor_cfg.anchor_k, self._n_anchors)

        # kNN: query → anchor (uses cached index — no rebuild per call)
        if self._knn_index is not None:
            indices, distances = self._knn_index.query(X_query, k)
        else:
            # Fallback if index not built (e.g. after pruning changed anchors)
            indices, distances = knn(self._anchor_points, k, query=X_query)

        # Build bipartite edges: src = query offset, dst = anchor
        edge_index, edge_dist = knn_to_edge_index(
            indices, distances,
            device=self.device,
            src_offset=self._n_anchors,  # query nodes indexed after anchors
        )

        # Also add reverse edges (anchor → query) for bidirectional propagation
        rev_edge_index = edge_index.flip(0)
        edge_index = torch.cat([edge_index, rev_edge_index], dim=1)
        edge_dist = torch.cat([edge_dist, edge_dist], dim=0)

        # Compute weights
        from .graph_builder import _compute_weights
        edge_weight = _compute_weights(edge_dist, self.graph_cfg)

        return edge_index, edge_weight

    @torch.no_grad()
    def build_augmented_graph(
        self, X_query: torch.Tensor
    ) -> Dict[str, torch.Tensor]:
        """Build augmented graph: anchor graph + bipartite query edges.

        For inductive mode: the full graph is anchors + queries with
        anchor-anchor edges preserved and query-anchor edges added.

        Args:
            X_query: (M, d) query features.

        Returns:
            dict with:
                edge_index: (2, E_anchor + E_bipartite) combined edges
                edge_weight: combined weights
                n_total: N_anchors + M
                query_mask: bool tensor, True for query nodes
        """
        assert self._built, "Must call build_anchor_graph first"

        M = X_query.shape[0]
        N_total = self._n_anchors + M

        # Get bipartite edges
        bi_edge_index, bi_edge_weight = self.attach_queries(X_query)

        # Combine with anchor edges
        edge_index = torch.cat([self._anchor_edge_index, bi_edge_index], dim=1)
        edge_weight = torch.cat([self._anchor_edge_weight, bi_edge_weight], dim=0)

        # Optional query-query edges (inductive mode only)
        qq_k = self.anchor_cfg.query_query_k
        if qq_k > 0 and M > 1:
            qq_k_actual = min(qq_k, M - 1)
            qq_indices, qq_distances = knn(X_query, qq_k_actual)
            qq_ei, qq_ed = knn_to_edge_index(
                qq_indices, qq_distances,
                device=self.device,
                src_offset=self._n_anchors,  # query nodes start after anchors
            )
            # Offset destination indices too (they're within query space)
            qq_ei[1] += self._n_anchors
            from .graph_builder import _compute_weights
            qq_ew = _compute_weights(qq_ed, self.graph_cfg)
            edge_index = torch.cat([edge_index, qq_ei], dim=1)
            edge_weight = torch.cat([edge_weight, qq_ew], dim=0)

        # Query mask
        query_mask = torch.zeros(N_total, dtype=torch.bool, device=self.device)
        query_mask[self._n_anchors:] = True

        return {
            "edge_index": edge_index,
            "edge_weight": edge_weight,
            "n_total": N_total,
            "n_anchors": self._n_anchors,
            "n_queries": M,
            "query_mask": query_mask,
        }

    def clear(self):
        """Clear cached state."""
        self._anchor_points = None
        self._anchor_edge_index = None
        self._anchor_edge_weight = None
        self._anchor_edge_dist = None
        self._n_anchors = 0
        self._built = False
        self._knn_index = None


def anchor_graph_config_from_dict(d: dict) -> AnchorGraphConfig:
    """Parse AnchorGraphConfig from a YAML dict."""
    cfg = AnchorGraphConfig()
    for k, v in d.items():
        if hasattr(cfg, k):
            setattr(cfg, k, v)
    return cfg
