"""Region-level GNN layers.

Implements GCN, GraphSAGE (mean), and GAT from scratch on small dense/sparse
region graphs (m <= 512). No dependency on PyG.

Edge mask is stored as a vector over actual edges only — no wasted parameters
on non-edges, no gradient leakage.
"""
from __future__ import annotations

import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Optional

from ..utils.config import GNNConfig


class GCNLayer(nn.Module):
    """Graph Convolutional Network layer on region graph."""

    def __init__(self, in_dim: int, out_dim: int, dropout: float = 0.0):
        super().__init__()
        self.linear = nn.Linear(in_dim, out_dim)
        self.dropout = nn.Dropout(dropout) if dropout > 0 else nn.Identity()

    def forward(self, h, adj, edge_mask=None):
        if edge_mask is not None:
            adj = adj * edge_mask
        adj_hat = adj + torch.eye(adj.shape[0], device=adj.device)
        deg = adj_hat.sum(dim=1).clamp(min=1e-6)
        deg_inv_sqrt = deg.pow(-0.5)
        norm = deg_inv_sqrt.unsqueeze(1) * adj_hat * deg_inv_sqrt.unsqueeze(0)
        out = norm @ h
        out = self.linear(out)
        out = self.dropout(out)
        return out


class SAGELayer(nn.Module):
    """GraphSAGE mean aggregator layer."""

    def __init__(self, in_dim: int, out_dim: int, dropout: float = 0.0):
        super().__init__()
        self.linear = nn.Linear(2 * in_dim, out_dim)
        self.dropout = nn.Dropout(dropout) if dropout > 0 else nn.Identity()

    def forward(self, h, adj, edge_mask=None):
        if edge_mask is not None:
            adj = adj * edge_mask
        deg = adj.sum(dim=1, keepdim=True).clamp(min=1e-6)
        neigh_agg = (adj @ h) / deg
        combined = torch.cat([h, neigh_agg], dim=-1)
        out = self.linear(combined)
        out = self.dropout(out)
        return out


class GATLayer(nn.Module):
    """Graph Attention Network layer."""

    def __init__(self, in_dim, out_dim, n_heads=4, dropout=0.0):
        super().__init__()
        assert out_dim % n_heads == 0
        self.n_heads = n_heads
        self.head_dim = out_dim // n_heads
        self.W = nn.Linear(in_dim, out_dim, bias=False)
        self.attn_src = nn.Parameter(torch.randn(n_heads, self.head_dim) * 0.01)
        self.attn_dst = nn.Parameter(torch.randn(n_heads, self.head_dim) * 0.01)
        self.dropout = nn.Dropout(dropout) if dropout > 0 else nn.Identity()
        self.leaky_relu = nn.LeakyReLU(0.2)

    def forward(self, h, adj, edge_mask=None):
        m = h.shape[0]
        Wh = self.W(h).view(m, self.n_heads, self.head_dim)
        e_src = (Wh * self.attn_src.unsqueeze(0)).sum(-1)
        e_dst = (Wh * self.attn_dst.unsqueeze(0)).sum(-1)
        e = self.leaky_relu(e_src.unsqueeze(1) + e_dst.unsqueeze(0))

        neighbor_mask = (adj > 0).unsqueeze(-1).expand_as(e)

        if edge_mask is not None:
            mask_bias = edge_mask.clamp(min=1e-8).log().unsqueeze(-1).expand_as(e)
            mask_bias = mask_bias * neighbor_mask.float()
            e = e + mask_bias

        e = e.masked_fill(~neighbor_mask, float("-inf"))
        alpha = F.softmax(e, dim=1)
        alpha = self.dropout(alpha)
        out = torch.einsum("nmh,mhd->nhd", alpha, Wh)
        out = out.reshape(m, -1)
        return out


class RegionGNN(nn.Module):
    """Multi-layer region-level GNN with sparse edge mask.

    Edge mask is a vector of learnable logits, one per actual graph edge.
    Scattered to dense (m,m) for layer computation. No parameters on non-edges.
    """

    def __init__(self, in_dim: int, cfg: GNNConfig):
        super().__init__()
        self.cfg = cfg
        self.residual = cfg.residual
        self._use_edge_mask = cfg.edge_mask
        self._m = None

        hidden_dim = cfg.hidden_dim if cfg.hidden_dim is not None else in_dim
        self.layers = nn.ModuleList()
        self.norms = nn.ModuleList()

        for i in range(cfg.layers):
            d_in = in_dim if i == 0 else hidden_dim
            d_out = hidden_dim
            if cfg.type == "gcn":
                self.layers.append(GCNLayer(d_in, d_out, cfg.dropout))
            elif cfg.type == "sage":
                self.layers.append(SAGELayer(d_in, d_out, cfg.dropout))
            elif cfg.type == "gat":
                self.layers.append(GATLayer(d_in, d_out, n_heads=cfg.gat_heads, dropout=cfg.dropout))
            else:
                raise ValueError(f"Unknown GNN type: {cfg.type}")
            self.norms.append(nn.LayerNorm(d_out))

        if hidden_dim != in_dim and cfg.residual:
            self.res_proj = nn.Linear(in_dim, hidden_dim)
        else:
            self.res_proj = None

        self.out_dim = hidden_dim

        # Sparse edge mask state
        self._use_edge_mask = cfg.edge_mask
        self._edge_index = None
        self._num_edges = 0
        # Register as named parameter so optimizer finds it even if created late
        if cfg.edge_mask:
            # Placeholder — will be replaced in _sync_edge_mask
            self.edge_mask_logits = nn.Parameter(torch.zeros(1))
            self._mask_initialized = False
        else:
            self.edge_mask_logits = None
            self._mask_initialized = False

    def init_edge_mask(self, m: int):
        """Store m for later. Actual param created on first forward."""
        if self._use_edge_mask:
            self._m = m

    def _sync_edge_mask(self, edge_index: torch.Tensor):
        """Create edge mask on first call, then freeze topology.

        After initialization, the mask parameter is never reallocated even if
        the region graph topology changes between batches. The frozen edge_index
        from the first call is reused, ensuring the mask learns meaningful
        sparsity over a stable edge set.
        """
        if not self._use_edge_mask:
            return
        if self._mask_initialized:
            # Topology frozen — don't update edge_index or reallocate
            return
        # First call — initialize
        E = edge_index.shape[1]
        self.edge_mask_logits = nn.Parameter(
            torch.zeros(E, device=edge_index.device)
        )
        self._edge_index = edge_index.detach()
        self._num_edges = E
        self._mask_initialized = True

    def _scatter_to_dense(self, vals: torch.Tensor) -> torch.Tensor:
        """Scatter edge values to dense (m, m) matrix.

        Non-frozen edges get 1.0 (pass-through), frozen edges get learned values.
        """
        m = self._m
        dense = torch.ones(m, m, device=vals.device)  # pass-through default
        ei = self._edge_index
        dense[ei[0], ei[1]] = vals
        return dense

    # ── Public accessors ──

    def get_edge_mask(self) -> Optional[torch.Tensor]:
        """(m, m) dense mask, nonzero only on edges."""
        if not self._mask_initialized or self._edge_index is None:
            return None
        return self._scatter_to_dense(torch.sigmoid(self.edge_mask_logits))

    def get_edge_mask_values(self) -> Optional[torch.Tensor]:
        """(E,) sigmoid values on edges only. For regularizers."""
        if not self._mask_initialized:
            return None
        return torch.sigmoid(self.edge_mask_logits)

    def get_num_edges(self) -> int:
        return self._num_edges

    # ── Forward ──

    def forward(self, h, adj, edge_index=None):
        """
        Args:
            h: (m, p) region embeddings
            adj: (m, m) adjacency
            edge_index: (2, E) optional — for edge mask sync
        """
        if edge_index is not None and self._use_edge_mask:
            self._sync_edge_mask(edge_index)

        edge_mask_dense = self.get_edge_mask()
        h_in = h

        for i, (layer, norm) in enumerate(zip(self.layers, self.norms)):
            h_new = layer(h, adj, edge_mask=edge_mask_dense)
            h_new = norm(h_new)
            h_new = F.relu(h_new)
            if self.residual:
                if i == 0 and self.res_proj is not None:
                    h_new = h_new + self.res_proj(h_in)
                elif h_new.shape == h.shape:
                    h_new = h_new + h
            h = h_new

        return h
