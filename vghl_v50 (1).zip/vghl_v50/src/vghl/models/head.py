"""Prediction head for classification or regression."""
from __future__ import annotations

import torch
import torch.nn as nn
from typing import List

from ..utils.config import HeadConfig


class PredictionHead(nn.Module):
    """MLP head for final predictions."""

    def __init__(self, in_dim: int, n_classes: int, cfg: HeadConfig):
        super().__init__()
        self.task = cfg.task

        layers: List[nn.Module] = []
        d_in = in_dim
        for h in cfg.hidden_sizes:
            layers.append(nn.Linear(d_in, h))
            layers.append(nn.ReLU())
            if cfg.dropout > 0:
                layers.append(nn.Dropout(cfg.dropout))
            d_in = h

        out_dim = n_classes if cfg.task == "classification" else 1
        layers.append(nn.Linear(d_in, out_dim))
        self.net = nn.Sequential(*layers)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        Args:
            x: (B, in_dim) point representations
        Returns:
            logits: (B, n_classes) for classification, (B, 1) for regression
        """
        return self.net(x)
