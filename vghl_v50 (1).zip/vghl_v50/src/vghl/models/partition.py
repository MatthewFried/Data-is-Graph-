"""Soft Voronoi-induced partition module.

Implements multi-scale soft assignment of points to regions using learned sites
and temperature-controlled softmax over distances.
"""
from __future__ import annotations

import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
from typing import List, Optional, Tuple, Dict

from ..utils.config import PartitionConfig


class SoftVoronoiPartition(nn.Module):
    """Multi-scale soft Voronoi partition.

    Maintains m learnable sites in embedding space.
    For each scale l, computes soft assignments using temperature t_l.

    Supports:
      - Euclidean distance
      - Diagonal Mahalanobis (per-site learnable diagonal)
      - Low-rank Mahalanobis (per-site)
    """

    def __init__(self, embed_dim: int, cfg: PartitionConfig):
        super().__init__()
        self.m = cfg.m
        self.L = cfg.L
        self.embed_dim = embed_dim
        self.distance_type = cfg.distance
        self.temp_mode = cfg.temp_mode

        # Learnable sites: (m, embed_dim)
        self.sites = nn.Parameter(torch.randn(cfg.m, embed_dim) * 0.1)

        # Temperature parameters
        if cfg.temp_mode == "fixed":
            assert len(cfg.temps) == cfg.L, \
                f"Number of temperatures ({len(cfg.temps)}) must match L ({cfg.L})"
            self.register_buffer("temps", torch.tensor(cfg.temps, dtype=torch.float32))
        elif cfg.temp_mode == "learnable":
            # Initialize from config temps
            init_temps = cfg.temps if len(cfg.temps) == cfg.L else \
                [cfg.temp_anneal_start * (cfg.temp_anneal_end / cfg.temp_anneal_start) ** (l / max(cfg.L - 1, 1))
                 for l in range(cfg.L)]
            self.log_temps = nn.Parameter(torch.log(torch.tensor(init_temps, dtype=torch.float32)))
        elif cfg.temp_mode == "anneal":
            self.register_buffer("temps", torch.tensor(cfg.temps, dtype=torch.float32))
            self._anneal_start = cfg.temp_anneal_start
            self._anneal_end = cfg.temp_anneal_end
            self._anneal_epochs = cfg.temp_anneal_epochs
        else:
            raise ValueError(f"Unknown temp_mode: {cfg.temp_mode}")

        # Distance parameters
        if cfg.distance == "mahalanobis_diag":
            # Per-site diagonal: (m, embed_dim), initialized to 1
            self.log_diag = nn.Parameter(torch.zeros(cfg.m, embed_dim))
        elif cfg.distance == "mahalanobis_lowrank":
            # Per-site low-rank factor: (m, embed_dim, rank)
            self.lr_factor = nn.Parameter(
                torch.randn(cfg.m, embed_dim, cfg.mahalanobis_rank) * 0.01
            )

    def get_temps(self, epoch: Optional[int] = None) -> torch.Tensor:
        """Get current temperatures for all scales."""
        if self.temp_mode == "learnable":
            return torch.exp(self.log_temps)
        elif self.temp_mode == "anneal" and epoch is not None:
            frac = min(epoch / max(self._anneal_epochs, 1), 1.0)
            factor = self._anneal_start * (self._anneal_end / self._anneal_start) ** frac
            # Scale the base temps by the anneal factor relative to start
            return self.temps * (factor / self._anneal_start)
        return self.temps

    def compute_distances(self, z: torch.Tensor) -> torch.Tensor:
        """Compute squared distances from each point to each site.

        Args:
            z: (B, d') point embeddings

        Returns:
            dists: (B, m) squared distances
        """
        if self.distance_type == "euclidean":
            # (B, 1, d') - (1, m, d') -> (B, m, d') -> sum -> (B, m)
            diff = z.unsqueeze(1) - self.sites.unsqueeze(0)
            return (diff ** 2).sum(dim=-1)

        elif self.distance_type == "mahalanobis_diag":
            # Per-site diagonal precision
            diag = torch.exp(self.log_diag)  # (m, d'), positive
            diff = z.unsqueeze(1) - self.sites.unsqueeze(0)  # (B, m, d')
            return (diff ** 2 * diag.unsqueeze(0)).sum(dim=-1)  # (B, m)

        elif self.distance_type == "mahalanobis_lowrank":
            # dist_k(z) = ||L_k^T (z - s_k)||^2 where L_k is (d', rank)
            diff = z.unsqueeze(1) - self.sites.unsqueeze(0)  # (B, m, d')
            # (B, m, d') @ (m, d', rank) -> need einsum
            projected = torch.einsum("bmd,mdr->bmr", diff, self.lr_factor)
            return (projected ** 2).sum(dim=-1)  # (B, m)

        else:
            raise ValueError(f"Unknown distance type: {self.distance_type}")

    def forward(
        self,
        z: torch.Tensor,
        epoch: Optional[int] = None,
    ) -> Dict[str, torch.Tensor]:
        """Compute multi-scale soft assignments.

        Args:
            z: (B, d') point embeddings
            epoch: current epoch (for temp annealing)

        Returns:
            dict with:
              - assignments: list of L tensors, each (B, m) soft assignments
              - hard_assignments: list of L tensors, each (B,) hard assignments
              - dists: (B, m) squared distances
              - sites: (m, d') current sites
        """
        dists = self.compute_distances(z)  # (B, m)
        temps = self.get_temps(epoch)  # (L,)

        assignments = []
        hard_assignments = []
        for l in range(self.L):
            t = temps[l].clamp(min=1e-6)
            w = F.softmax(-dists / t, dim=-1)  # (B, m)
            assignments.append(w)
            hard_assignments.append(w.argmax(dim=-1))  # (B,)

        return {
            "assignments": assignments,
            "hard_assignments": hard_assignments,
            "dists": dists,
            "sites": self.sites,
            "temps": temps,
        }

    def init_sites_from_data(
        self,
        z: torch.Tensor,
        method: str = "farthest_point",
        n_iter: int = 20,
    ):
        """Initialize sites from data embeddings.

        Args:
            z: (N, d') all point embeddings (detached)
            method: 'kmeans', 'random', or 'farthest_point'
        """
        m = self.m

        if method == "kmeans":
            centers = _kmeans_init_safe(z.detach(), m, n_iter=n_iter)
        elif method == "random":
            z_d = z.detach()
            indices = np.random.choice(len(z_d), m, replace=len(z_d) < m)
            centers = z_d[indices]
        elif method == "farthest_point":
            centers = _farthest_point_sampling(z.detach(), m)
        else:
            raise ValueError(f"Unknown init method: {method}")

        with torch.no_grad():
            self.sites.copy_(centers.to(self.sites.device))


def _kmeans_init_safe(z: torch.Tensor, m: int, n_iter: int = 20) -> torch.Tensor:
    """KMeans with thread guard and fallback to farthest_point on failure/hang."""
    import os, threading

    z_np = z.cpu().numpy()

    # Thread guard to prevent OpenMP/MKL deadlocks on WSL/Linux
    old_omp = os.environ.get("OMP_NUM_THREADS")
    old_mkl = os.environ.get("MKL_NUM_THREADS")
    os.environ["OMP_NUM_THREADS"] = "1"
    os.environ["MKL_NUM_THREADS"] = "1"

    result = [None]
    exc = [None]

    def _run():
        try:
            from sklearn.cluster import KMeans
            km = KMeans(n_clusters=m, n_init=3, max_iter=n_iter, random_state=0)
            km.fit(z_np)
            result[0] = torch.from_numpy(km.cluster_centers_.astype(np.float32))
        except Exception as e:
            exc[0] = e

    t = threading.Thread(target=_run, daemon=True)
    t.start()
    t.join(timeout=60)  # 60s timeout

    # Restore env
    if old_omp is not None:
        os.environ["OMP_NUM_THREADS"] = old_omp
    else:
        os.environ.pop("OMP_NUM_THREADS", None)
    if old_mkl is not None:
        os.environ["MKL_NUM_THREADS"] = old_mkl
    else:
        os.environ.pop("MKL_NUM_THREADS", None)

    if result[0] is not None:
        return result[0]

    # Fallback
    import logging
    logging.getLogger("vghl.partition").warning(
        f"KMeans init failed/timed out{f': {exc[0]}' if exc[0] else ''}, "
        f"falling back to farthest_point"
    )
    return _farthest_point_sampling(z, m)


def _farthest_point_sampling(z: torch.Tensor, m: int) -> torch.Tensor:
    """Farthest point sampling from z."""
    N = z.shape[0]
    selected = [np.random.randint(N)]
    min_dists = torch.full((N,), float("inf"), device=z.device)

    for _ in range(m - 1):
        last = z[selected[-1]].unsqueeze(0)
        dists = ((z - last) ** 2).sum(dim=-1)
        min_dists = torch.min(min_dists, dists)
        selected.append(min_dists.argmax().item())

    return z[selected]
