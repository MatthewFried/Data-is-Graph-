"""CIFAR-10 frozen feature extraction.

FeatureExtractor interface:
    fit(X_train) -> self  (optional, for PCA/CNN)
    transform(X) -> embeddings

Extractors:
    pca_50:  StandardScaler + PCA(50) — works everywhere, no pretrained weights.
    pca_128: StandardScaler + PCA(128) — higher dim baseline.
    random_conv: random 3-layer conv features (self-supervised-like, no training).
"""
from __future__ import annotations

import numpy as np
import torch
from typing import Tuple, Dict, Optional


class FeatureExtractor:
    """Base class for frozen feature extractors."""
    def fit(self, X: np.ndarray) -> "FeatureExtractor":
        return self
    def transform(self, X: np.ndarray) -> np.ndarray:
        raise NotImplementedError
    def fit_transform(self, X: np.ndarray) -> np.ndarray:
        return self.fit(X).transform(X)


class PCAExtractor(FeatureExtractor):
    """PCA on flattened pixels."""
    def __init__(self, n_components: int = 50):
        self.n_components = n_components
        self._scaler = None
        self._pca = None

    def fit(self, X: np.ndarray) -> "PCAExtractor":
        from sklearn.preprocessing import StandardScaler
        from sklearn.decomposition import PCA
        self._scaler = StandardScaler()
        X_scaled = self._scaler.fit_transform(X)
        self._pca = PCA(n_components=self.n_components, random_state=0)
        self._pca.fit(X_scaled)
        return self

    def transform(self, X: np.ndarray) -> np.ndarray:
        return self._pca.transform(self._scaler.transform(X)).astype(np.float32)


class RandomConvExtractor(FeatureExtractor):
    """Random 3-layer conv features (no training required).

    Random convolution + BatchNorm + ReLU + GlobalAvgPool gives
    surprisingly reasonable features for geometric methods.
    """
    def __init__(self, out_dim: int = 128, seed: int = 0):
        self.out_dim = out_dim
        self.seed = seed
        self._model = None

    def fit(self, X: np.ndarray) -> "RandomConvExtractor":
        torch.manual_seed(self.seed)
        # X is (N, 3072) flattened CIFAR — reshape to (N, 3, 32, 32) in transform
        self._model = torch.nn.Sequential(
            torch.nn.Conv2d(3, 32, 3, padding=1),
            torch.nn.BatchNorm2d(32),
            torch.nn.ReLU(),
            torch.nn.Conv2d(32, 64, 3, padding=1),
            torch.nn.BatchNorm2d(64),
            torch.nn.ReLU(),
            torch.nn.AdaptiveAvgPool2d(4),
            torch.nn.Flatten(),
            torch.nn.Linear(64 * 4 * 4, self.out_dim),
        )
        self._model.eval()
        return self

    def transform(self, X: np.ndarray) -> np.ndarray:
        # X: (N, 3072) -> (N, 3, 32, 32)
        X_t = torch.tensor(X, dtype=torch.float32).reshape(-1, 3, 32, 32)
        with torch.no_grad():
            feats = self._model(X_t).numpy()
        return feats.astype(np.float32)


class ResNet18Extractor(FeatureExtractor):
    """Frozen pretrained ResNet-18 feature extractor.

    Extracts 512-dim features from the avgpool layer of a pretrained
    ResNet-18. No training required — uses torchvision pretrained weights.
    """
    def __init__(self, out_dim: int = 512):
        self.out_dim = out_dim
        self._model = None

    def fit(self, X: np.ndarray) -> "ResNet18Extractor":
        from torchvision import models
        resnet = models.resnet18(weights=models.ResNet18_Weights.DEFAULT)
        # Remove final classification head
        self._model = torch.nn.Sequential(
            *list(resnet.children())[:-1],  # up to avgpool
            torch.nn.Flatten(),
        )
        self._model.eval()
        return self

    def transform(self, X: np.ndarray) -> np.ndarray:
        # X: (N, 3072) flattened CIFAR -> (N, 3, 32, 32)
        X_t = torch.tensor(X, dtype=torch.float32).reshape(-1, 3, 32, 32)
        # ResNet expects ImageNet normalization
        mean = torch.tensor([0.485, 0.456, 0.406]).view(1, 3, 1, 1)
        std = torch.tensor([0.229, 0.224, 0.225]).view(1, 3, 1, 1)
        X_t = (X_t - mean) / std

        # Use GPU if available, move model once, move data per-batch
        device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        self._model = self._model.to(device)

        feats = []
        with torch.no_grad():
            for i in range(0, len(X_t), 128):
                chunk = X_t[i:i+128]
                # Upsample per-batch to avoid storing all 224x224 images in RAM
                chunk = torch.nn.functional.interpolate(
                    chunk, size=(224, 224), mode="bilinear", align_corners=False)
                f = self._model(chunk.to(device))
                feats.append(f.cpu())
        return torch.cat(feats, dim=0).numpy().astype(np.float32)


def get_extractor(name: str = "pca_50") -> FeatureExtractor:
    """Factory for feature extractors."""
    if name == "pca_50":
        return PCAExtractor(50)
    elif name == "pca_128":
        return PCAExtractor(128)
    elif name == "resnet18":
        return ResNet18Extractor()
    elif name.startswith("random_conv"):
        dim = int(name.split("_")[-1]) if "_" in name[len("random_conv"):] else 128
        return RandomConvExtractor(dim)
    else:
        raise ValueError(f"Unknown extractor: {name}")


def load_cifar10_raw(seed: int = 42) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """Load raw CIFAR-10 as flattened float32 arrays."""
    from torchvision import datasets
    import os

    root = os.path.expanduser("~/.cache/vghl_data")
    train = datasets.CIFAR10(root, train=True, download=True)
    test = datasets.CIFAR10(root, train=False, download=True)

    X_train = train.data.reshape(len(train.data), -1).astype(np.float32) / 255.0
    y_train = np.array(train.targets, dtype=np.int64)
    X_test = test.data.reshape(len(test.data), -1).astype(np.float32) / 255.0
    y_test = np.array(test.targets, dtype=np.int64)

    return X_train, y_train, X_test, y_test


def load_cifar10_features(
    extractor_name: str = "pca_50",
    seed: int = 42,
    n_train: int = 0,
    n_test: int = 0,
) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor, Dict]:
    """Load CIFAR-10 with frozen feature extraction.

    Returns X_train, y_train, X_test, y_test, meta.
    """
    X_tr, y_tr, X_te, y_te = load_cifar10_raw(seed)

    extractor = get_extractor(extractor_name)
    X_tr_feat = extractor.fit_transform(X_tr)
    X_te_feat = extractor.transform(X_te)

    if n_train > 0:
        X_tr_feat, y_tr = X_tr_feat[:n_train], y_tr[:n_train]
    if n_test > 0:
        X_te_feat, y_te = X_te_feat[:n_test], y_te[:n_test]

    meta = {
        "n_classes": 10, "input_dim": X_tr_feat.shape[1],
        "dataset": f"cifar10_{extractor_name}", "extractor": extractor_name,
    }
    return (torch.tensor(X_tr_feat), torch.tensor(y_tr),
            torch.tensor(X_te_feat), torch.tensor(y_te), meta)
