"""Tabular dataset loaders: Wine, Breast Cancer, optionally Adult.

All datasets are standardized (z-score) and split into train/val/test.
Uses sklearn built-in datasets (no downloads needed).
"""
from __future__ import annotations

import numpy as np
import torch
from typing import Tuple, Dict


def load_wine(seed: int = 42) -> Tuple[torch.Tensor, torch.Tensor, Dict]:
    """Load Wine dataset (178 samples, 13 features, 3 classes)."""
    return _load_sklearn("wine", seed)


def load_breast_cancer(seed: int = 42) -> Tuple[torch.Tensor, torch.Tensor, Dict]:
    """Load Breast Cancer dataset (569 samples, 30 features, 2 classes)."""
    return _load_sklearn("breast_cancer", seed)


def _load_sklearn(name: str, seed: int) -> Tuple[torch.Tensor, torch.Tensor, Dict]:
    from sklearn.datasets import load_wine as _lw, load_breast_cancer as _lbc
    from sklearn.preprocessing import StandardScaler

    loader = {"wine": _lw, "breast_cancer": _lbc}[name]
    data = loader()
    X = StandardScaler().fit_transform(data.data).astype(np.float32)
    y = data.target.astype(np.int64)
    n_classes = len(np.unique(y))

    rng = np.random.RandomState(seed)
    perm = rng.permutation(len(X))
    X, y = X[perm], y[perm]

    meta = {"n_classes": n_classes, "input_dim": X.shape[1], "dataset": name,
            "n_samples": len(X)}
    return torch.tensor(X), torch.tensor(y), meta


def split_tabular(
    X: torch.Tensor, y: torch.Tensor,
    train_frac: float = 0.6, val_frac: float = 0.2,
) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor,
           torch.Tensor, torch.Tensor, torch.Tensor]:
    """Split tabular data into train/val/test."""
    n = len(X)
    n_train = int(n * train_frac)
    n_val = int(n * val_frac)
    return (X[:n_train], y[:n_train],
            X[n_train:n_train+n_val], y[n_train:n_train+n_val],
            X[n_train+n_val:], y[n_train+n_val:])
