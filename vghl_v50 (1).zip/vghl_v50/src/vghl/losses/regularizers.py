"""All regularization losses for VGHL.

Includes: load balance, stability, parsimony/entropy, region smoothness,
cut penalty, edge mask sparsity, within-region label smoothness.
"""
from __future__ import annotations

import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import List, Optional, Dict, Any


class LoadBalanceLoss(nn.Module):
    """Encourage uniform region utilization.

    L_balance = sum_k (p_k - 1/m)^2  where p_k = mean_i w_{ik}
    """

    def forward(self, assignments: List[torch.Tensor], scale_indices: List[int]) -> torch.Tensor:
        total = torch.tensor(0.0, device=assignments[0].device)
        count = 0
        for l in scale_indices:
            if l >= len(assignments):
                continue
            w = assignments[l]  # (B, m)
            m = w.shape[1]
            p = w.mean(dim=0)  # (m,)
            target = 1.0 / m
            total = total + ((p - target) ** 2).sum()
            count += 1
        return total / max(count, 1)


class StabilityLoss(nn.Module):
    """Coarse assignment stability under input noise.

    Perturb inputs, recompute partition assignments, penalize difference.
    """

    def __init__(self, noise_sigma: float = 0.05, norm: str = "l1"):
        super().__init__()
        self.noise_sigma = noise_sigma
        self.norm = norm

    def forward(
        self,
        model: nn.Module,
        x: torch.Tensor,
        clean_assignments: List[torch.Tensor],
        scale_indices: List[int],
        epoch: int = 0,
    ) -> torch.Tensor:
        if self.noise_sigma <= 0 or len(scale_indices) == 0:
            return torch.tensor(0.0, device=x.device)

        noise = torch.randn_like(x) * self.noise_sigma
        x_perturbed = x + noise

        # Forward perturbed through embed + partition
        # Keep grad for partition parameters (sites, temps)
        z_pert = model.embed(x_perturbed)
        part_pert = model.partition(z_pert, epoch=epoch)
        pert_assignments = part_pert["assignments"]

        total = torch.tensor(0.0, device=x.device)
        for l in scale_indices:
            if l >= len(clean_assignments) or l >= len(pert_assignments):
                continue
            w_clean = clean_assignments[l].detach()  # stop grad on clean side
            w_pert = pert_assignments[l]

            if self.norm == "l1":
                diff = (w_clean - w_pert).abs().sum(dim=-1).mean()
            elif self.norm == "l2":
                diff = ((w_clean - w_pert) ** 2).sum(dim=-1).mean()
            elif self.norm == "kl":
                diff = F.kl_div(
                    (w_pert + 1e-10).log(), w_clean, reduction="batchmean"
                )
            else:
                raise ValueError(f"Unknown norm: {self.norm}")
            total = total + diff

        return total / max(len(scale_indices), 1)


class EntropyLoss(nn.Module):
    """Parsimony: penalize entropy of assignments to encourage crisp partitions.

    L_ent = mean_i H(w_i) = -mean_i sum_k w_{ik} log(w_{ik})
    """

    def forward(self, assignments: List[torch.Tensor], scale_indices: List[int]) -> torch.Tensor:
        total = torch.tensor(0.0, device=assignments[0].device)
        count = 0
        for l in scale_indices:
            if l >= len(assignments):
                continue
            w = assignments[l]  # (B, m)
            ent = -(w * (w + 1e-10).log()).sum(dim=-1).mean()
            total = total + ent
            count += 1
        return total / max(count, 1)


class RegionSmoothnessLoss(nn.Module):
    """Encourage neighboring regions to have similar embeddings.

    L_smooth = sum_{(k,l) in E} a_{kl} ||h_k - h_l||^2
    """

    def forward(
        self,
        region_embeds: List[torch.Tensor],
        region_graphs: List[Dict[str, torch.Tensor]],
    ) -> torch.Tensor:
        total = torch.tensor(0.0, device=region_embeds[0].device)
        count = 0
        for h, graph in zip(region_embeds, region_graphs):
            adj = graph["adj_dense"]  # (m, m)
            # h: (m, p)
            diff = h.unsqueeze(0) - h.unsqueeze(1)  # (m, m, p)
            sq_dist = (diff ** 2).sum(dim=-1)  # (m, m)
            loss = (adj * sq_dist).sum()
            total = total + loss
            count += 1
        return total / max(count, 1)


class ConnectivityLoss(nn.Module):
    """Penalize low algebraic connectivity (lambda_2) of region graph.

    L_conn = max(0, epsilon - lambda_2(L_sym))
    Computed only over active regions (regions with > 1% assignment mass).
    """

    def __init__(self, epsilon: float = 0.01):
        super().__init__()
        self.epsilon = epsilon

    def forward(
        self,
        region_graphs: List[Dict[str, torch.Tensor]],
    ) -> torch.Tensor:
        total = torch.tensor(0.0, device=region_graphs[0]["adj_dense"].device)
        count = 0
        for graph in region_graphs:
            adj = graph["adj_dense"]
            active = graph.get("active_mask")

            if active is not None and active.sum() > 2:
                adj_active = adj[active][:, active]
            else:
                adj_active = adj

            m = adj_active.shape[0]
            if m < 3:
                continue

            deg = adj_active.sum(dim=1)
            deg_inv_sqrt = torch.where(deg > 1e-10, 1.0 / deg.sqrt(), torch.zeros_like(deg))
            D_inv_sqrt = torch.diag(deg_inv_sqrt)
            L_sym = torch.eye(m, device=adj.device) - D_inv_sqrt @ adj_active @ D_inv_sqrt

            eigenvalues = torch.linalg.eigvalsh(L_sym)
            lambda2 = eigenvalues[1]

            total = total + F.relu(self.epsilon - lambda2)
            count += 1

        return total / max(count, 1)


class LaplacianSmoothnessLoss(nn.Module):
    """Laplacian smoothness: Tr(Z^T L Z) on region embeddings.

    Encourages region embeddings to vary smoothly over graph topology.
    Computed only over active regions.
    """

    def forward(
        self,
        region_embeds: List[torch.Tensor],
        region_graphs: List[Dict[str, torch.Tensor]],
    ) -> torch.Tensor:
        total = torch.tensor(0.0, device=region_embeds[0].device)
        count = 0
        for h, graph in zip(region_embeds, region_graphs):
            adj = graph["adj_dense"]
            active = graph.get("active_mask")

            if active is not None and active.sum() > 2:
                adj_a = adj[active][:, active]
                h_a = h[active]
            else:
                adj_a = adj
                h_a = h

            m = adj_a.shape[0]
            if m < 2:
                continue

            deg = adj_a.sum(dim=1)
            L = torch.diag(deg) - adj_a
            smooth = (h_a.t() @ L @ h_a).trace()
            total = total + smooth / m
            count += 1

        return total / max(count, 1)


class CutPenaltyLoss(nn.Module):
    """Encourage learned edge masks to cut cross-boundary edges.

    L_cut = mean_{(i,j) in E} mask_{ij} * disagreement_{ij}

    Operates on sparse edge mask (nonzero only on graph edges by construction).
    """

    def forward(
        self,
        assignments: List[torch.Tensor],
        labels: torch.Tensor,
        region_graphs: List[Dict[str, torch.Tensor]],
        n_classes: int,
        model: Optional[nn.Module] = None,
    ) -> torch.Tensor:
        total = torch.tensor(0.0, device=assignments[0].device)
        count = 0

        y_oh = F.one_hot(labels, n_classes).float()

        for l, (w, graph) in enumerate(zip(assignments, region_graphs)):
            adj = graph["adj_dense"]
            edge_index = graph["edge_index"]  # (2, E)
            mass = w.sum(dim=0).clamp(min=1e-8)
            label_dist = (w.t() @ y_oh) / mass.unsqueeze(1)  # (m, C)

            # Per-edge disagreement
            src, dst = edge_index[0], edge_index[1]
            diff = label_dist[src] - label_dist[dst]  # (E, C)
            disagreement = (diff ** 2).sum(dim=-1)  # (E,)

            # Get edge mask values directly as (E,) vector
            mask_vals = None
            if model is not None and hasattr(model, "region_gnns"):
                gnns = model.region_gnns
                if l < len(gnns):
                    mask_vals = gnns[l].get_edge_mask_values()

            if mask_vals is not None and mask_vals.shape[0] == disagreement.shape[0]:
                # Mean over edges: mask * disagreement
                loss = (mask_vals * disagreement).mean()
            else:
                # Fallback: adj-weighted disagreement on edges
                adj_weights = adj[src, dst]
                loss = (adj_weights * disagreement).mean()

            total = total + loss
            count += 1

        return total / max(count, 1)


class EdgeMaskSparsityLoss(nn.Module):
    """L1 penalty on learned edge mask values — operates on (E,) vector directly.

    Since mask is now stored as edge-vector, L1 is automatically restricted
    to actual edges. Normalized by number of edges for scale invariance.
    """

    def forward(
        self,
        model: nn.Module,
        region_graphs: Optional[List[Dict[str, torch.Tensor]]] = None,
    ) -> torch.Tensor:
        total = torch.tensor(0.0)
        count = 0
        for gnn in getattr(model, "region_gnns", []):
            vals = gnn.get_edge_mask_values()  # (E,) or None
            if vals is not None and vals.numel() > 0:
                total = total + vals.mean()  # mean L1 over edges
                count += 1
        if count == 0:
            return torch.tensor(0.0, device=next(model.parameters()).device)
        return total / count


class WithinRegionLabelLoss(nn.Module):
    """Encourage within-region label smoothness.

    Weighted variance of labels within each region.
    """

    def forward(
        self,
        assignments: List[torch.Tensor],
        labels: torch.Tensor,
        scale_indices: List[int],
        n_classes: int,
    ) -> torch.Tensor:
        total = torch.tensor(0.0, device=assignments[0].device)
        count = 0

        y_oh = F.one_hot(labels, n_classes).float()  # (B, C)

        for l in scale_indices:
            if l >= len(assignments):
                continue
            w = assignments[l]  # (B, m)
            mass = w.sum(dim=0).clamp(min=1e-8)  # (m,)

            # Weighted mean label per region
            mean_label = (w.t() @ y_oh) / mass.unsqueeze(1)  # (m, C)

            # Weighted variance: sum_i w_{ik} ||y_i - mean_k||^2
            # = sum_k sum_i w_{ik} ||y_i - mean_k||^2
            # Efficient: E[x^2] - E[x]^2 per region
            sq_mean = (w.t() @ (y_oh ** 2)) / mass.unsqueeze(1)  # (m, C)
            var = (sq_mean - mean_label ** 2).clamp(min=0).sum(dim=-1)  # (m,)
            loss = (var * mass / mass.sum()).sum()
            total = total + loss
            count += 1

        return total / max(count, 1)


class BoundaryLoss(nn.Module):
    """Boundary-specific losses for point-level learning.

    Modes:
      - consistency: boundary points with same hard assignment should have
        similar representations (penalize variance within boundary-groups)
      - contrastive: boundary points in different regions should be pushed apart
      - laplacian: Laplacian smoothing on boundary subgraph
    """

    def __init__(self, mode: str = "consistency"):
        super().__init__()
        self.mode = mode

    def forward(
        self,
        point_features: torch.Tensor,
        is_boundary: torch.Tensor,
        hard_assignments: torch.Tensor,
        point_edge_index: Optional[torch.Tensor] = None,
    ) -> torch.Tensor:
        if not is_boundary.any() or point_features is None:
            return torch.tensor(0.0, device=is_boundary.device)

        boundary_mask = is_boundary
        boundary_feat = point_features[boundary_mask]  # (B_b, d)
        boundary_asgn = hard_assignments[boundary_mask]  # (B_b,)

        if self.mode == "consistency":
            return self._consistency_loss(boundary_feat, boundary_asgn)
        elif self.mode == "contrastive":
            return self._contrastive_loss(boundary_feat, boundary_asgn)
        elif self.mode == "laplacian":
            return self._laplacian_loss(
                point_features, is_boundary, point_edge_index
            )
        else:
            raise ValueError(f"Unknown boundary loss mode: {self.mode}")

    def _consistency_loss(self, feat: torch.Tensor, asgn: torch.Tensor) -> torch.Tensor:
        """Boundary points in same region should be similar."""
        regions = asgn.unique()
        total = torch.tensor(0.0, device=feat.device)
        count = 0
        for r in regions:
            mask = asgn == r
            if mask.sum() < 2:
                continue
            group = feat[mask]
            mean = group.mean(dim=0, keepdim=True)
            var = ((group - mean) ** 2).sum(dim=-1).mean()
            total = total + var
            count += 1
        return total / max(count, 1)

    def _contrastive_loss(self, feat: torch.Tensor, asgn: torch.Tensor) -> torch.Tensor:
        """Push apart boundary points from different regions."""
        n = feat.shape[0]
        if n < 2:
            return torch.tensor(0.0, device=feat.device)

        # Sample pairs for efficiency
        n_pairs = min(n * 4, 2048)
        idx_a = torch.randint(n, (n_pairs,), device=feat.device)
        idx_b = torch.randint(n, (n_pairs,), device=feat.device)

        same_region = asgn[idx_a] == asgn[idx_b]
        dists = ((feat[idx_a] - feat[idx_b]) ** 2).sum(dim=-1)

        # Pull same-region, push different-region
        margin = 1.0
        pos_loss = dists[same_region].mean() if same_region.any() else torch.tensor(0.0, device=feat.device)
        neg_loss = F.relu(margin - dists[~same_region]).mean() if (~same_region).any() else torch.tensor(0.0, device=feat.device)

        return pos_loss + neg_loss

    def _laplacian_loss(
        self,
        point_features: torch.Tensor,
        is_boundary: torch.Tensor,
        edge_index: Optional[torch.Tensor],
    ) -> torch.Tensor:
        """Laplacian smoothing on boundary subgraph edges."""
        if edge_index is None:
            return torch.tensor(0.0, device=point_features.device)

        src, dst = edge_index
        # Keep only edges where both endpoints are boundary
        boundary_edges = is_boundary[src] & is_boundary[dst]
        if not boundary_edges.any():
            return torch.tensor(0.0, device=point_features.device)

        b_src = src[boundary_edges]
        b_dst = dst[boundary_edges]
        diff = point_features[b_src] - point_features[b_dst]
        return (diff ** 2).sum(dim=-1).mean()


class VGHLLossComputer(nn.Module):
    """Computes all losses for VGHL model training."""

    def __init__(self, cfg):
        super().__init__()
        self.cfg = cfg
        lc = cfg.loss

        self.task_loss = TaskLoss(cfg.head.task)
        self.balance_loss = LoadBalanceLoss()
        self.stability_loss = StabilityLoss(
            noise_sigma=lc.stab_noise_sigma, norm=lc.stab_norm
        )
        self.entropy_loss = EntropyLoss()
        self.smooth_loss = RegionSmoothnessLoss()
        self.cut_loss = CutPenaltyLoss()
        self.edge_mask_loss = EdgeMaskSparsityLoss()
        self.within_label_loss = WithinRegionLabelLoss()
        self.boundary_loss = BoundaryLoss(mode=cfg.boundary.boundary_loss)
        self.connectivity_loss = ConnectivityLoss(epsilon=lc.conn_epsilon)
        self.lap_smooth_loss = LaplacianSmoothnessLoss()

        self.balance_scales = cfg.parse_scale_list(lc.balance_scales)
        self.stab_scales = cfg.parse_scale_list(lc.stab_scales)
        self.ent_scales = cfg.parse_scale_list(lc.ent_scales)

    def forward(
        self,
        model: nn.Module,
        x: torch.Tensor,
        y: torch.Tensor,
        output: Dict[str, Any],
        epoch: int = 0,
    ) -> Dict[str, torch.Tensor]:
        lc = self.cfg.loss
        bc = self.cfg.boundary
        losses = {}

        # Task loss with optional confidence weighting
        task_alpha = output.get("task_alpha")
        losses["task"] = self.task_loss(output["logits"], y, alpha=task_alpha) * lc.task_weight

        if "assignments" in output and output["assignments"]:
            assignments = output["assignments"]

            if lc.lambda_balance > 0:
                losses["balance"] = self.balance_loss(assignments, self.balance_scales) * lc.lambda_balance

            if lc.lambda_stab > 0 and hasattr(model, "embed") and hasattr(model, "partition"):
                losses["stability"] = self.stability_loss(
                    model, x, assignments, self.stab_scales, epoch
                ) * lc.lambda_stab

            if lc.lambda_ent > 0:
                losses["entropy"] = self.entropy_loss(assignments, self.ent_scales) * lc.lambda_ent

            if lc.lambda_smooth > 0 and "region_embeds" in output:
                losses["smooth"] = self.smooth_loss(
                    output["region_embeds"], output["region_graphs"]
                ) * lc.lambda_smooth

            if lc.lambda_cut > 0:
                n_classes = output["logits"].shape[1] if output["logits"].dim() > 1 else 2
                losses["cut"] = self.cut_loss(
                    assignments, y, output["region_graphs"], n_classes, model=model
                ) * lc.lambda_cut

            if lc.lambda_edge_l1 > 0:
                losses["edge_l1"] = self.edge_mask_loss(
                    model, region_graphs=output.get("region_graphs")
                ) * lc.lambda_edge_l1

            if lc.lambda_within_label > 0:
                n_classes = output["logits"].shape[1] if output["logits"].dim() > 1 else 2
                losses["within_label"] = self.within_label_loss(
                    assignments, y, self.balance_scales, n_classes
                ) * lc.lambda_within_label

            # Boundary loss
            if bc.lambda_boundary > 0 and "is_boundary" in output:
                _po = output.get("point_out")
                point_feat = _po if _po is not None else output.get("features")
                hard_asgn = output["hard_assignments"][0]  # coarsest
                losses["boundary"] = self.boundary_loss(
                    point_feat, output["is_boundary"], hard_asgn,
                    point_edge_index=output.get("point_edge_index"),
                ) * bc.lambda_boundary

            # Anti-uniform assignment regularizers
            if lc.lambda_assign_entropy > 0:
                # Penalize HIGH entropy → encourage crisp assignments
                ae_total = torch.tensor(0.0, device=x.device)
                for w in assignments:
                    H = -(w * (w + 1e-10).log()).sum(dim=-1).mean()
                    ae_total = ae_total + H
                losses["assign_entropy"] = ae_total / len(assignments) * lc.lambda_assign_entropy

            if lc.lambda_assign_sharp > 0:
                # L2 peakedness: peaked = (w**2).sum(-1).mean()
                # Uniform → 1/K, one-hot → 1. Loss = 1 - peaked.
                # Differentiable everywhere, effective gradient even at uniform.
                as_total = torch.tensor(0.0, device=x.device)
                for w in assignments:
                    peaked = (w ** 2).sum(dim=-1).mean()
                    as_total = as_total + (1.0 - peaked)
                losses["assign_sharp"] = as_total / len(assignments) * lc.lambda_assign_sharp

            # Geometry regularizers
            if lc.lambda_conn > 0 and "region_graphs" in output:
                losses["connectivity"] = self.connectivity_loss(
                    output["region_graphs"]
                ) * lc.lambda_conn

            if lc.lambda_lap_smooth > 0 and "region_embeds" in output:
                losses["lap_smooth"] = self.lap_smooth_loss(
                    output["region_embeds"], output["region_graphs"]
                ) * lc.lambda_lap_smooth

        losses["total"] = sum(losses.values())
        return losses


# Re-export TaskLoss for convenience
from .task import TaskLoss
