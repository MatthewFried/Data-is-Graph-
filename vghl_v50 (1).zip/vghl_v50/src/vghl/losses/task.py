"""Task losses: classification and regression with optional confidence weighting."""
import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Optional


class TaskLoss(nn.Module):
    """Task loss with optional per-sample confidence weighting.

    When alpha is provided: L = sum(alpha_i * loss_i) / sum(alpha_i)
    When alpha is None: standard mean reduction.
    """

    def __init__(self, task: str = "classification"):
        super().__init__()
        self.task = task

    def forward(
        self,
        logits: torch.Tensor,
        targets: torch.Tensor,
        alpha: Optional[torch.Tensor] = None,
    ) -> torch.Tensor:
        if self.task == "classification":
            per_sample = F.cross_entropy(logits, targets, reduction="none")
        else:
            per_sample = F.mse_loss(logits.squeeze(-1), targets.float(), reduction="none")

        if alpha is not None:
            return (alpha * per_sample).sum() / (alpha.sum() + 1e-8)
        else:
            return per_sample.mean()
