"""Dense-matrix oracle tests for every sparse propagation operator.

These are real assertions (they raise on failure). They pin the sparse
implementation to the documented dense operator on BOTH a symmetric graph
with irregular degrees and a directed graph, which is exactly the case
where the v44 transpose bug was invisible/visible respectively.
"""
import os, sys
import torch
import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))
from vghl.models.propagation import propagate, PropagationConfig  # noqa: E402


def dense_ops(ei, ew, N):
    A = torch.zeros(N, N)
    A[ei[0], ei[1]] = ew
    AI = A + torch.eye(N)
    D = torch.diag(AI.sum(dim=1))
    Dinv = torch.linalg.inv(D)
    dhalf = AI.sum(dim=1).pow(-0.5)
    S = torch.diag(dhalf) @ AI @ torch.diag(dhalf)
    return AI, Dinv, S


def graphs():
    # symmetric path graph with irregular degrees (star + path)
    ei_sym = torch.tensor([[0, 1, 1, 2, 1, 3], [1, 0, 2, 1, 3, 1]])
    ew_sym = torch.tensor([1.0, 1.0, 2.0, 2.0, 0.5, 0.5])
    # directed graph (the case where transpose bugs show up hardest)
    ei_dir = torch.tensor([[0, 1, 2, 2], [1, 2, 0, 3]])
    ew_dir = torch.tensor([1.0, 2.0, 1.0, 3.0])
    return [(ei_sym, ew_sym, 4), (ei_dir, ew_dir, 4)]


@pytest.mark.parametrize("ei,ew,N", graphs())
def test_identity(ei, ew, N):
    X = torch.randn(N, 3)
    out = propagate(X, ei, ew, N, PropagationConfig(type="identity"))
    assert torch.allclose(out, X)


@pytest.mark.parametrize("ei,ew,N", graphs())
@pytest.mark.parametrize("steps", [1, 3])
def test_random_walk_matches_dense(ei, ew, N, steps):
    torch.manual_seed(0)
    X = torch.randn(N, 3)
    out = propagate(X, ei, ew, N,
                    PropagationConfig(type="random_walk", steps=steps))
    AI, Dinv, _ = dense_ops(ei, ew, N)
    P = Dinv @ AI
    ref = X.clone()
    for _ in range(steps):
        ref = P @ ref
    assert torch.allclose(out, ref, atol=1e-5), \
        f"random_walk != D^-1(A+I): max err {(out-ref).abs().max():.2e}"


@pytest.mark.parametrize("ei,ew,N", graphs())
def test_ppr_matches_dense(ei, ew, N):
    torch.manual_seed(1)
    X = torch.randn(N, 3)
    alpha, steps = 0.15, 4
    out = propagate(X, ei, ew, N,
                    PropagationConfig(type="ppr", alpha=alpha, steps=steps))
    AI, Dinv, _ = dense_ops(ei, ew, N)
    P = Dinv @ AI
    ref = X.clone()
    for _ in range(steps):
        ref = alpha * X + (1 - alpha) * (P @ ref)
    assert torch.allclose(out, ref, atol=1e-5)


@pytest.mark.parametrize("ei,ew,N", graphs())
def test_laplacian_matches_dense(ei, ew, N):
    torch.manual_seed(2)
    X = torch.randn(N, 3)
    steps = 2
    out = propagate(X, ei, ew, N,
                    PropagationConfig(type="laplacian", steps=steps))
    _, _, S = dense_ops(ei, ew, N)
    ref = X.clone()
    for _ in range(steps):
        ref = S @ ref
    assert torch.allclose(out, ref, atol=1e-5)


def test_row_stochastic():
    """P = D^-1 (A+I) must have rows summing to 1 (a constant vector is
    fixed) -- the property the transpose operator violates."""
    for ei, ew, N in graphs():
        ones = torch.ones(N, 1)
        out = propagate(ones, ei, ew, N,
                        PropagationConfig(type="random_walk", steps=3))
        assert torch.allclose(out, ones, atol=1e-5), \
            "random_walk is not row-stochastic (constant vector not fixed)"
