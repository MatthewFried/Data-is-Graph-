# v49 evidence-path audit

## Verdict

The original four-command path was not ready to run unchanged. The principal defects were: an undeclared PyG dependency; an unnecessarily cubic primal ridge solve on high-dimensional graphs; unseeded and undiagnosed degree rewiring; a node-ID-dependent alpha path with drifting edge counts; unmatched-cell power calculations and an approximate/overstated MDE; and an Adult diagnostic that used non-stratified folds and a different ridge estimator from the paper.

The revised archive fixes those evidence-path defects and adds `tests/test_rebuttal_v49.py`.

## Recommended setup

```bash
python -m pip install -e ".[rebuttal]"
python -m pytest -q tests/test_rebuttal_v49.py
python -u scripts/setup_downloads.py
```

## Runs

```bash
python -u scripts/rebuttal_regimeB_extended.py 2>&1 | tee regimeB.log
python -u scripts/rebuttal_alpha_native.py     2>&1 | tee alpha_native.log
python -u scripts/rebuttal_power_analysis.py   2>&1 | tee power.log
python -u scripts/rebuttal_adult_diag.py       2>&1 | tee adult_diag.log
```

`rebuttal_power_analysis.py` still requires `outputs/rebuttal/rebuttal_swap_sweep.csv` with columns `dataset,seed,cell,acc`.

## Material changes

- Added a `rebuttal` optional dependency containing `torch-geometric`.
- Setup now tests GCN/GAT execution, validates all 11 PyG datasets, and exits nonzero on any failure.
- Closed-form ridge now chooses the mathematically equivalent dual solve when `n_train < d`.
- Rewiring now uses a seeded successful-swap implementation and records swap count, overlap, degree preservation, reciprocity, and under-mixing.
- Scope prediction is computed from the stated homophily threshold; the number of labeled-labeled edges is reported.
- Directed random edges retain exactly the requested number of non-self edge instances.
- Learned operators support CUDA, and directed edges are transposed for PyG so their aggregation matches the fixed operator's adjacency convention.
- The alpha path is node-label invariant, exact-density, nested, and has exactly known retained-edge overlap at every dose.
- Power rows are paired by `(dataset, seed)` before dataset aggregation; the MDE uses the exact noncentral-t power function; wording no longer says an effect “would have been detected.”
- Adult CV is stratified and uses the same closed-form one-hot ridge probe as the main artifact. The default is now `adult`; use `--datasets all` only intentionally.

## Remaining caveats

1. The complete default Regime-B run launches 231 separate 200-epoch learned-model fits. The old “1–3 h CPU” comment is not a reliable expectation, especially with GAT on Coauthor graphs. Use CUDA where memory permits, or run `--skip-gnn` first.
2. The Adult provenance path reproduces the artifact loader. That loader standardizes before splitting, and OpenML categorical features are ordinal-coded under the current `as_frame=False` path. A leakage-free one-hot Adult sensitivity should be run before making a strong mechanistic claim from that diagnostic.
3. The full repository test suite still has three pre-existing Phase-2 failures (`Primitive(center=...)`, changed edit-loop return arity, and a failed Phase-2 accuracy assertion). Those modules are outside the four-script evidence path, but the repository as a whole is not green.
