# VGHL v20: Geometric Machine

> **Thesis:** The graph induced by data geometry IS the computational machine.
> All variation comes from graph construction, not learned weights.

## Setup

```bash
pip install torch numpy scikit-learn pyyaml tensorboard
```

## Architecture

```
DATA → embed(optional) → build_graph → propagate(fixed operator) → linear_head → predictions
         frozen by          geometry        no learned weights       only trained
         default            is the                                   parameters
                            hypothesis
```

**Phase 1 (flat):** graph + operator + weak head. No primitives, no recursion.
**Phase 2 (multilevel):** primitives + recursion + optional edit loop for structure discovery.

## File Map

| File | Role |
|------|------|
| `scripts/train_gm.py` | Single experiment runner |
| `scripts/sweep_gm.py` | Multi-config sweep runner |
| `scripts/run_causality_ablation.py` | Paper-ready causality ablation (multi-seed, multi-dataset, figure+table) |
| `scripts/run_pruning_ablation.py` | Paper-ready pruning/compression ablation (multi-seed, figure+table) |
| `scripts/run_noise_injection_test.py` | Noise injection test: does pruning identify noise? |
| `scripts/run_phase2_tests.py` | Test 3 (stable vs unstable subsets) + Test 4 (refinement trajectory) |
| `scripts/transfer_gm.py` | Transfer experiment: Geometry(A) → Learn(B) |
| `scripts/refine_gm.py` | Iterative refinement convergence: optimization in structure space |
| `scripts/inductive_control.py` | Inductive control: proves no transductive leakage |
| `src/vghl/models/geometric_machine.py` | Unified pipeline + operator-consistent query propagation |
| `src/vghl/models/graph_builder.py` | 7 graph constructors + 2 causal controls |
| `src/vghl/models/propagation.py` | 6 fixed propagation operators |
| `src/vghl/models/anchor_graph.py` | Dataset-level graph + bipartite query attachment |
| `src/vghl/models/pruning.py` | 3 pruning families |
| `src/vghl/models/primitives.py` | Motif induction |
| `src/vghl/models/edit_loop.py` | Phase-2 structural edit loop with budget tracking |
| `src/vghl/models/probe.py` | Fast ridge classifier for edit-loop scoring |
| `src/vghl/train/gm_trainer.py` | Training loop (head-only by default, embed hard-frozen) |

## CLI Reference: `train_gm.py`

### Data

| Flag | Default | Values |
|------|---------|--------|
| `--dataset` | `sk_moons` | `sk_moons`, `sk_circles`, `sk_swiss_roll`, `sk_s_curve`, `sk_blobs_noisy`, `breast_cancer`, `wine`, `digits`, `mnist`, `fashion_mnist`, `cifar10_pca`, `piecewise2d`, `spirals`, `blobs` |
| `--n_train` | 5000 | int (set 0 for tabular datasets to use default splits) |
| `--n_val` | 500 | int |
| `--n_test` | 500 | int |
| `--noise_sigma` | 0.1 | float |

### Graph Construction

| Flag | Default | Values |
|------|---------|--------|
| `--graph_type` | `knn` | `knn`, `mutual_knn`, `epsilon`, `adaptive_radius`, `mst_shortcuts`, `gabriel`, `hybrid` |
| `--k` | 16 | int (for knn-family types) |
| `--epsilon` | 0.5 | float (for epsilon type) |
| `--weight_mode` | `gaussian` | weight computation mode |
| `--control` | `none` | `none`, `random_destination`, `degree_preserving_rewire` |

### Propagation Operator

| Flag | Default | Values |
|------|---------|--------|
| `--operator` | `random_walk` | `identity`, `random_walk`, `ppr`, `heat`, `laplacian`, `gated` |
| `--prop_steps` | 5 | int (diffusion steps T) |
| `--ppr_alpha` | 0.15 | float (teleport probability for `ppr`) |
| `--heat_t` | 1.0 | float (diffusion time for `heat`) |

### Anchor Graph Mode

| Flag | Default | Values |
|------|---------|--------|
| `--gm_mode` | `transductive_full_graph` | `transductive_full_graph`, `inductive_anchor_graph` |
| `--anchor_k` | 8 | int (query→anchor kNN for inductive mode) |
| `--bipartite_steps` | 1 | int |

### Head

| Flag | Default | Values |
|------|---------|--------|
| `--head` | `linear` | `linear`, `mlp` |
| `--head_hidden` | 64 | int (mlp only) |
| `--head_dropout` | 0.1 | float (mlp only) |

### Embedding (optional)

| Flag | Default | Notes |
|------|---------|-------|
| `--embed_dim` | None | If set, adds a 2-layer MLP embedding projection |
| `--train_embed` | off | If on, trains embedding + forces graph rebuild every epoch |

### Pruning (Phase 1)

| Flag | Default | Notes |
|------|---------|-------|
| `--prune` | off | Enable pruning |
| `--prune_methods` | `geometric` | Comma-separated: `geometric`, `stability`, `label_consistency` |
| `--compression_fractions` | None | e.g. `1.0,0.8,0.6,0.4,0.2` — runs compression curve |

### Primitives & Recursion (Phase 2)

| Flag | Default | Notes |
|------|---------|-------|
| `--primitives` | `""` | Comma-separated: `triangle`, `star`, `clique_4`, `path_3`, `cycle_4` |
| `--primitives_in_propagation` | off | **Required for Phase 2:** uses primitives in computation path |
| `--recursion` | off | Enable multilevel recursion |
| `--recursion_depth` | 1 | int |

### Edit Loop (Phase 2 structure search)

| Flag | Default | Notes |
|------|---------|-------|
| `--edit_loop` | off | Enable val-driven structural edit loop |
| `--edit_loop_iters` | 3 | Max iterations |
| `--edit_max_proposals` | 50 | Budget: total proposals before forced stop |
| `--edit_max_no_improve` | 2 | Consecutive no-improve iterations → stop |
| `--edit_alpha` | 0.01 | Node count penalty weight |
| `--edit_beta` | 0.01 | Edge count penalty weight |
| `--edit_gamma` | 0.1 | Instability penalty weight |
| `--merge` | off | Enable supernode merging in edit loop |

### Training

| Flag | Default | Notes |
|------|---------|-------|
| `--epochs` | 100 | int |
| `--lr` | 0.001 | float |
| `--batch_size` | 256 | int |
| `--weight_decay` | 0.0001 | float |
| `--early_stop` | 30 | Patience epochs |
| `--seed` | 0 | int |
| `--device` | auto | `cpu`, `cuda`, `cuda:0`, etc. |

### Output

| Flag | Default | Notes |
|------|---------|-------|
| `--name` | auto-generated | Run name (becomes subdirectory) |
| `--out` | `outputs/gm` | Base output directory |
| `--quiet` | off | Suppress per-epoch logging |
| `--log_machine_every` | 5 | Epochs between machine metric logging |

**Auto-generated name format:** `gm_{dataset}_{graph_type}_{operator}_{head}_k{k}_s{seed}`

**Output directory structure:**
```
outputs/gm/{name}/
├── results.json        # Final test metrics, machine metrics, edit log, compression
├── config.yaml         # Full config snapshot (reproducible)
├── best.pt             # Best val checkpoint
├── final.pt            # Final checkpoint
├── compression.csv     # Compression curve (if --compression_fractions set)
└── events.out.*        # TensorBoard logs
```

## CLI Reference: `sweep_gm.py`

### Auto Phase 1 Sweep

| Flag | Default | Notes |
|------|---------|-------|
| `--auto_phase1` | off | Auto-generate Phase 1 sweep grid |
| `--datasets` | `sk_moons` | Comma-separated dataset names |
| `--seeds` | `0,1,2` | Comma-separated seeds (3 for statistical validity) |
| `--k_values` | `8,16` | Comma-separated k values |
| `--graph_types` | all 7 | Comma-separated (default: all) |
| `--operators` | all 6 | Comma-separated (default: all) |
| `--steps` | `3,5` | Comma-separated prop steps |
| `--controls` | `none` | Comma-separated: `none`, `random_destination`, `degree_preserving_rewire` |
| `--epochs` | 50 | int |
| `--out` | `outputs/gm_sweep` | Output directory |
| `--dry_run` | off | Print commands without running |

**Sweep output:**
```
outputs/gm_sweep/
├── sweep_results.csv       # Per-run status + key metrics
├── aggregate.csv           # All results.json flattened into one CSV
├── summary_by_config.csv   # Mean/std across seeds, grouped by config
└── {run_name}/             # Individual run directories (same structure as train_gm)
```

### YAML Sweep

```bash
python scripts/sweep_gm.py --sweep path/to/sweep.yaml --out outputs/my_sweep
```

## Causal Controls

Controls destroy geometry while preserving graph structure, to verify the pipeline genuinely uses geometry.

| `--control` value | What it does | What it preserves |
|---|---|---|
| `none` | Real geometry (default) | Everything |
| `degree_preserving_rewire` | Undirected double-edge swap (true degree-preserving) | Exact node degree, edge count |
| `random_destination` | Per-node random reassignment of edge destinations | Out-degree per node |

**Usage:** Run identical configs with `--control none` vs `--control degree_preserving_rewire`. If real geometry doesn't significantly outperform the control, the pipeline isn't using geometry meaningfully.

## Testing Guide

### Step 1: Smoke Test

```bash
python scripts/train_gm.py \
  --dataset sk_moons --n_train 2000 --n_val 500 --n_test 500 \
  --graph_type knn --k 16 --operator random_walk --prop_steps 5 \
  --epochs 30 --head linear --seed 0 --name smoke_test
```

**Pass:** Runs to completion, val/test accuracy well above 50%, no NaN.

### Step 2: Causality Ablation (Paper-Ready)

The automated script runs multi-seed, multi-dataset, multi-k ablations and generates a publication figure + LaTeX table:

```bash
# Full ablation: 2 datasets × 4 k-values × 3 controls × 5 seeds = 120 runs
python scripts/run_causality_ablation.py

# Quick version (fewer seeds)
python scripts/run_causality_ablation.py --seeds 0,1,2 --k_values 8,16

# Add more datasets
python scripts/run_causality_ablation.py --datasets sk_moons,breast_cancer,sk_circles

# Regenerate figures from existing results (no re-running)
python scripts/run_causality_ablation.py --plot_only
```

**Output:**
```
outputs/causality_ablation/
├── causality_ablation.csv      # All individual run results
├── causality_summary.csv       # Mean ± std grouped by (dataset, k, control)
├── causality_table.tex         # LaTeX table ready for paper
├── causality_ablation.pdf      # Publication figure: accuracy vs k
├── causality_ablation.png      # Same figure as PNG
└── causal_{dataset}_{ctrl}_k{k}_s{seed}/   # Individual run dirs
```

**Pass:** Real geometry significantly outperforms both controls across all datasets and seeds. The figure shows real geometry rising with k then plateauing, while controls stay near chance.

**Quick single-run check** (if you just want to verify the pipeline works):
```bash
python scripts/train_gm.py \
  --dataset sk_moons --n_train 5000 --n_val 1000 --n_test 1000 \
  --graph_type knn --k 16 --operator random_walk --prop_steps 5 \
  --control none --epochs 50 --head linear --seed 0 --name causal_real
```

### Step 3: Phase 1 Coarse Sweep

```bash
python scripts/sweep_gm.py --auto_phase1 \
  --datasets sk_moons,sk_circles \
  --seeds 0,1,2 --epochs 50 \
  --out outputs/gm_sweep_phase1
```

**Pass:** Stable ranking region visible in `summary_by_config.csv` — some graph/operator combos consistently win across seeds.

### Step 4: Pruning Test

```bash
# Baseline
python scripts/train_gm.py \
  --dataset sk_moons --n_train 5000 --n_val 1000 --n_test 1000 \
  --graph_type knn --k 16 --operator random_walk --prop_steps 5 \
  --epochs 50 --head linear --seed 0 --name prune_baseline

# With pruning
python scripts/train_gm.py \
  --dataset sk_moons --n_train 5000 --n_val 1000 --n_test 1000 \
  --graph_type knn --k 16 --operator random_walk --prop_steps 5 \
  --prune --prune_methods geometric \
  --epochs 50 --head linear --seed 0 --name prune_geo

# Compression curve
python scripts/train_gm.py \
  --dataset sk_moons --n_train 5000 --n_val 1000 --n_test 1000 \
  --graph_type knn --k 16 --operator random_walk --prop_steps 5 \
  --prune --compression_fractions 1.0,0.8,0.6,0.4,0.2 \
  --epochs 30 --head linear --seed 0 --name prune_curve
```

**Pass:** Pruning preserves or improves accuracy while reducing |V|/|E|. Compression curve shows "flat then cliff" behavior.

### Step 5: Phase 2 (only after Steps 1-4 pass)

```bash
# A. Single-shot hierarchy (no edit loop)
python scripts/train_gm.py \
  --dataset sk_moons --n_train 5000 --n_val 1000 --n_test 1000 \
  --graph_type knn --k 16 --operator random_walk --prop_steps 5 \
  --primitives triangle,path_3 --primitives_in_propagation --recursion --recursion_depth 1 \
  --epochs 50 --head linear --seed 0 --name phase2_singleshot

# B. With edit loop
python scripts/train_gm.py \
  --dataset sk_moons --n_train 5000 --n_val 1000 --n_test 1000 \
  --graph_type knn --k 16 --operator random_walk --prop_steps 5 \
  --primitives triangle,path_3 --primitives_in_propagation --recursion --recursion_depth 1 \
  --edit_loop --edit_loop_iters 2 --edit_max_proposals 30 --edit_max_no_improve 2 \
  --epochs 50 --head linear --seed 0 --name phase2_editloop

# C. Phase 2 + causality control (must still collapse)
python scripts/train_gm.py \
  --dataset sk_moons --n_train 5000 --n_val 1000 --n_test 1000 \
  --graph_type knn --k 16 --operator random_walk --prop_steps 5 \
  --primitives triangle,path_3 --primitives_in_propagation --recursion --recursion_depth 1 \
  --edit_loop --edit_loop_iters 2 --edit_max_proposals 30 --edit_max_no_improve 2 \
  --control degree_preserving_rewire \
  --epochs 50 --head linear --seed 0 --name phase2_control
```

**Pass:** Phase 2 improves modestly over Phase 1, test doesn't degrade, controls still collapse performance.

## What NOT To Do

- **Don't use `--train_embed`** until Phase 1/2 results are solid — it confounds the thesis.
- **Don't run raw pixels** (MNIST/CIFAR) without `--embed_dim` — Euclidean distance in pixel space is meaningless.
- **Don't skip causality checks** — without them you can't claim geometry matters.
- **Don't enable Phase 2 before Phase 1 baseline** — you need something to compare against.

## Design Decisions (v20)

- **Operator-consistent query propagation:** Query features propagated using the SAME configured operator as anchors (with anchor clamping), not a hardcoded rule. This makes operator sweeps meaningful.
- **AnchorGraph cache resync:** After Phase-2 edits, all cached edges/distances are updated to match the edited graph.
- **Head-only training by default:** Embedding is hard-frozen (`requires_grad=False`). Only `--train_embed` unfreezes it (and forces graph rebuilds).
- **Edit loop budget:** `max_proposals` and `max_no_improve` prevent val-overfitting in Phase 2.
- **Flip-rate instability:** Edit loop instability metric uses `2*|Δacc|` under feature perturbation as a conservative proxy for prediction flip rate.
- **Multi-seed sweeps:** Default 3 seeds; `summary_by_config.csv` reports mean ± std across seeds.
