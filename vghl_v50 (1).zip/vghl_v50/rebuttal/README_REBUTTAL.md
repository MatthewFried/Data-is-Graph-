# VGHL v45: NeurIPS Rebuttal Experiments (corrected)

v45 supersedes v43/v44 entirely. Numbers produced by v44 or earlier for
rewiring, dose-response, and any propagation-based experiment SHOULD NOT BE
CITED; regenerate everything with v45.

## v45 corrections (all verified in-session)

1. OPERATOR: the sparse random walk (and ppr/gated; laplacian/heat via the
   same spmm) computed the transpose (A+I)D^-1 h instead of the documented
   D^-1(A+I)h. Fixed; pinned by tests/test_operator_oracle.py (dense-oracle
   asserts on symmetric AND directed graphs + row-stochasticity; 11 tests,
   all real assertions). Empirical impact measured before fixing: <= 1.5pp
   on tabular, +0.3pp on cora given-graph, zero qualitative changes -- the
   fix is provenance-critical, not results-threatening.
2. REWIRING CONTROL: the Table-6 generator swapped destinations in the
   directed representation (measured reciprocity after: 12.9%), which is
   not an undirected degree-preserving swap. Replaced with true symmetric
   double-edge swaps on canonical undirected edges; every run now prints
   and ASSERTS diagnostics (reciprocity=1.0, degree vector unchanged, no
   self-loops, swap count, original-edge overlap). Old rewiring_control.csv
   is superseded.
3. DOSE-RESPONSE: p=0 is now the exact original graph (verified equal to
   the untouched pipeline to 1e-9); interventions are NESTED prefixes of
   one fixed random sequence; hit edges receive exactly the paper's
   destroyed-edge convention (random destination, weight 1.0) so p=1.0 is
   the paper's I2 endpoint. --mode topology|weights decomposes the two
   channels (note: topology-only is near-flat on small-kernel-weight
   datasets like digits because the operator goes inert -- itself evidence
   that operator behavior is fully substrate-mediated). Monotonicity
   refuter is scoped a priori: purity > 0.6 AND kNN-ridge gap > 0.
   Verified: digits monotone 0.946 -> 0.083, per-run rho = -1.0.
4. SPECTRAL PREDICTOR: predictor and outcome now use INDEPENDENT null
   draws (no mechanical coupling); wording corrected (norm-ratio retention
   statistic, label-free AND readout-free -- not "without running an
   intervention"); leave-one-dataset-out Spearman range reported.
5. LOW-LABEL: labeled subsets are NESTED across L; headline is
   PREREGISTERED on the labeled-only diagnostic purity_excess > 0.10
   (pilot separation: digits +0.33..0.38 vs adult -0.03) with the
   win/no-win INTERACTION as the falsifiable claim; both noprop_attach
   (paper protocol) and noprop_raw (clean no-graph) reported; label prop
   runs to convergence; best_raw explicitly labeled an oracle envelope
   (conservative against us); all four raw baselines in the CSV.
6. TOST: n>=2 guard, NaN-pair guard, heterogeneity report (per-dataset
   range, count outside each margin, leave-one-out mean range), and
   restricted language: TOST here concerns the MEAN difference only.
7. run_all_diagnostics.sh quote bug fixed.

## Verified v45 headline numbers (3 seeds, this session)

native cora:     given 0.809  best_raw 0.582  no_prop 0.571  knn 0.666
                 random 0.141  rewire 0.212  rdest 0.153
native citeseer: given 0.712  best_raw 0.615  no_prop 0.607  knn 0.231
                 random 0.178  rewire 0.234  rdest 0.192
Control diagnostics (printed every run): rewire reciprocity 1.0, degree
vector preserved, edge overlap ~2%; random_edges reciprocity 0.0 -> framed
as secondary DIRECTED control; the symmetric rewire is the primary control.

## Run order (mapped to AC priorities)

0. [AC 2,3] Regenerate Table 1 provenance + TOST input (HIGHEST RISK):
     python -u scripts/run_real_experiments.py --only ablation --seeds 0,1,2,3,4
     python -u scripts/rebuttal_tost.py --csv outputs/real_experiments/ablation.csv
1. [AC 1,5] python -u scripts/rebuttal_native_graph.py --seeds 0,1,2,3,4
2. [AC 1]   python -u scripts/rebuttal_low_label.py --seeds 0,1,2
3. [GMYt]   python -u scripts/rebuttal_spectral_predictor.py --seeds 0,1,2
4. [AC 4]   python -u scripts/rebuttal_dose_response.py --seeds 0,1,2
            (+ optional --mode topology and --mode weights decompositions)
5. [hygiene] python -u scripts/rebuttal_regen_table4.py
6. [AC 2]   Rerun rewiring under the corrected control:
     python -u scripts/run_real_experiments.py --only rewiring --seeds 0,1,2,3,4

## Excluded from the rebuttal (do not cite)

- predictive_validity (v2): predictions were argmax over FEATURE
  dimensions, no classifier fitted; provenance CSV has 240/240 NaN rho
  values. Requires a fitted-classifier redesign before any use.
- "adversarial_edges": the experiment is label-informed feature-space
  bridge poisoning, not an edge attack. Rename in the paper; if GMYt-type
  reviewers want structural attacks, that is future work.
- Anything from GeometricMachine / Phase-2 / multilevel / machine_search:
  known-defective modules, NOT in the evidence path of any paper table or
  rebuttal script (verified: no rebuttal script or run_real_experiments
  path imports them).

## Open provenance risks (resolve during your runs)

- Table 1 per-seed CSV still has no raw logs until step 0 completes;
  expect shifts of roughly <=1.5pp under the corrected operator.
- ADULT DIAGNOSTIC CONFLICT: in-script kNN-ridge gap on adult came out
  +0.12 (kNN beats ridge) under this protocol, while the paper's
  falsifiability text relies on adult having gap <= 0. Recompute the
  paper's exact diagnostic during the ablation regen and reconcile the
  text BEFORE citing the adult scope argument.
- Table 2 spectral, CARDIA, 32-pair transfer, Tables 11-14, 17: still no
  raw logs anywhere. Regenerate what the rebuttal cites; do not cite what
  cannot be traced.

## Intervention dictionary (paste into rebuttal; resolves GMYt Q4 / AC 2)

| Paper name | Exact operation (code) | Split | Notes |
|---|---|---|---|
| Random Edges (T1) | I1: src AND dst uniform iid, self-loops dropped, uniform weights | test | directed; NOT degree-preserving |
| Random destination (I2) | per-edge dst resampled, out-degree preserved | -- | directed |
| Degree-pres. rewire (I3) | v45: symmetric double-edge swaps on undirected canonical edges, 2x|E_und| swaps, diagnostics asserted | test | paper text said "10|E|": fix to 2x|E_und| |
| "Destroyed Geom." (T7/T16) | I2 via make_geometry_destroyed_graph | VALIDATION, 10% label noise | different protocol+split from T1: explains +0.218 vs +0.449 |
| "Randomized" (T7) | random NODE pruning, 15% | validation | MISLABELED column; rename |
| No Prop. (T1) | ridge on raw X, queries kNN-attached | test | touches graph at attach |
| No Graph (T1) | ridge on raw X directly | test | only truly graph-free condition |

## Checked-in provenance (results_provenance/)
- noise_exp3_corruption_matrix.csv backs Tables 4/8 (regen fixes T4 drift;
  note: feat+label vs feat-only identity on pointwise detectors is a
  CONSTRUCTION identity -- same perturbations, same seed -- report it as a
  consistency check, not as independent evidence; also relabel margin and
  centroid_dist as supervised/relational, not pointwise-unsupervised).
- rewiring_control.csv and old dose CSVs: SUPERSEDED by v45 reruns.


## v46 STATUS (final, 2026-07-24): all runs complete on taiku@Meir

All numbers recorded in rebuttal_numbers.md (delivered separately).
Rebuttal drafts in rebuttal_drafts.md; revision checklist in
silent_fixes.md. Summary of outcomes:
- Table 1 regenerated: Full 0.736 / No Prop 0.739 / Random 0.285
  (collapse 45.1pp); matches submission within rounding.
- TOST: equivalent at +/-2.5pp (p=1e-4), not at +/-1pp.
- Native graphs (5 seeds): cora +22.6pp, citeseer +9.7pp over best raw;
  all destructions collapse; diagnostics clean.
- Rewiring (corrected symmetric control): real 0.736 / rewired 0.520 /
  random 0.285. Submitted "rewired ~ random" superseded. Run
  scripts/rebuttal_swap_sweep.py (new in v46) for the null ladder
  (rewire 2x/10x/50x + symmetric ER) that settles the interpretation.
- Dose-response mode=both: 18/18 in-scope runs monotone-negative,
  sign test p=3.8e-6; decomposition: weights channel never harmful,
  topology channel collapses.
- Spectral: categorical separation 19/19 (retention 0.651-1.000 real vs
  0.000-0.006 random); magnitude regression FAILED preregistered bar
  (Spearman 0.116): appendix-only with readout-relativity explanation.
- Low-label: preregistered group test FAILED (-2.0pp, p=0.40) vs oracle
  envelope; universal collapse 30/30 rows held. Appendix-only.
- v46 additions: under-mixed rewire warning (cora accepts 43/4202 swaps:
  near-null; never cite cora rewired), scripts/rebuttal_swap_sweep.py.


## v47 FINAL (2026-07-24): swap sweep resolved, rebuttal numerically complete

Swap sweep (8 datasets, 3 seeds): rewire converges by 10x-50x|E_und| swaps
to a density-matched symmetric ER null (rw50x 0.536 vs symER 0.540;
rw2x 0.588 was mildly under-mixed). Conclusions:
  - Degree sequence contributes NOTHING beyond symmetry class + density.
  - Symmetric nulls (~0.54) vs directed random edges (0.285): the gap is
    symmetry class (normal vs non-normal operator dynamics); report
    separately, never conflate.
  - Sharpest attribution: real 0.850 vs maximally mixed degree-preserving
    null 0.536 = 31.4pp within matched symmetry class.
  - Caveats: wine saturated (overlap 0.18, all cells 0.405); satellite
    rw50x below its symER at 3 seeds (single cell, do not build on it).
Final companion documents (delivered separately): rebuttal_drafts.md
(placeholders filled), rebuttal_numbers.md (section 4b added),
silent_fixes.md (items 25-26: camera-ready Table 6 at 10x swaps with
symER column across all 20 datasets via scripts/rebuttal_swap_sweep.py).
This archive is the reference version for the rebuttal and revision.

## v49 (LoG revision experiments) - RUN ORDER
1. python -u scripts/setup_downloads.py            # downloads all 10 pyg datasets first
2. python -u scripts/rebuttal_regimeB_extended.py 2>&1 | tee regimeB.log      # ~1-3h CPU
   (Physics/CS are the slow ones; --skip-rf or --datasets to subset)
3. python -u scripts/rebuttal_alpha_native.py 2>&1 | tee alpha_native.log     # ~20-40min
4. python -u scripts/rebuttal_power_analysis.py 2>&1 | tee power.log          # seconds; needs
   outputs/rebuttal/rebuttal_swap_sweep.csv from the v48 full-roster sweep
5. python -u scripts/rebuttal_adult_diag.py 2>&1 | tee adult_diag.log         # ~10-20min
Smoke-verified in-session: texas end-to-end (incl. GCN), computers (Shchur
split; NEW Regime B win: given .709 > best_raw .651, collapse .05-.16),
cora alpha (p=0 exactness assert passes, rho=-1.0), power on real
19-dataset means (-0.5pp, CI [-1.5,+0.5], MDE80=1.7pp).
