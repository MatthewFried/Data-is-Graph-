#!/usr/bin/env python3
"""VGHL Multidimensional Geometry Sweep.

The current pipeline reduces geometry to pairwise L2 distance → kNN graph.
This loses multidimensional structure. This script tests richer approaches:

GRAPH CONSTRUCTION (how we build geometry from data):
  1. knn_l2         — baseline: k-NN on raw L2 distance
  2. knn_cosine     — cosine similarity (direction, not magnitude)
  3. knn_mahalanobis — Mahalanobis distance (class-conditional covariance)
  4. mutual_knn     — mutual kNN (only keep edge if both agree) → higher purity
  5. knn_pca        — PCA → kNN (reduce d first, then build graph)
  6. knn_lda        — LDA → kNN (supervised dim reduction → graph)
  7. knn_umap       — UMAP embedding → kNN (nonlinear manifold → graph)
  8. knn_random_proj — random projection → kNN (JL lemma preserves distances)
  9. multi_scale     — union of kNN at k=4,8,16,32 (multi-resolution)
  10. hybrid_local_global — local kNN + random long-range edges

PROPAGATION (how information flows on graph):
  For each graph: random_walk T=5, ppr α=0.85, identity (no prop)

READOUT (how we classify from propagated features):
  For each propagated representation: ridge, kNN, MLP

This gives us: 10 graphs × 3 propagations × 3 readouts = 90 configs per dataset.
We also test the same readouts on raw features (3 baselines).

Usage:
    python -u scripts/multidim_geometry.py                    # all datasets
    python -u scripts/multidim_geometry.py --only existing    # original 20
    python -u scripts/multidim_geometry.py --quick            # fast subset
"""
import os, sys, argparse, csv, time, warnings
import numpy as np
import torch
from pathlib import Path
from collections import defaultdict

warnings.filterwarnings("ignore", category=FutureWarning)
warnings.filterwarnings("ignore", category=UserWarning)

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from vghl.models.graph_builder import build_base_graph, GraphBuilderConfig
from vghl.models.propagation import propagate, PropagationConfig
from vghl.models.probe import ridge_eval, embed_queries_via_knn
from vghl.models.knn_backend import knn, knn_to_edge_index


def _save_csv(rows, path):
    if not rows: return
    path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    keys = list(rows[0].keys())
    extra = sorted({k for r in rows for k in r.keys()} - set(keys))
    keys.extend(extra)
    tmp = str(path) + f".tmp.{os.getpid()}"
    with open(tmp, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=keys); w.writeheader()
        for r in rows: w.writerow({k: r.get(k, "") for k in keys})
        f.flush(); os.fsync(f.fileno())
    os.replace(tmp, str(path))
    print(f"  Saved: {path}")


# ══════════════════════════════════════════════════════════════════════
# DATASET LOADING
# ══════════════════════════════════════════════════════════════════════

def load_dataset(ds_name, seed, n_train=5000, n_val=500, n_test=2000):
    """Unified loader."""
    try:
        from vghl.utils.config import ExperimentConfig
        from vghl.data.loaders import build_datasets
        cfg = ExperimentConfig()
        cfg.data.dataset = ds_name
        cfg.data.n_train = n_train
        cfg.data.n_val = n_val
        cfg.data.n_test = n_test
        cfg.seed = seed
        tr, va, te, meta = build_datasets(cfg)
        return tr.X, tr.y, te.X, te.y, meta
    except Exception:
        root = os.path.expanduser("~/.cache/vghl_data")
        cache = os.path.join(root, f"{ds_name}_cache.pt")
        if os.path.exists(cache):
            c = torch.load(cache, weights_only=True)
            X_tr, y_tr, X_te, y_te = c["X_tr"], c["y_tr"], c["X_te"], c["y_te"]
            rng = np.random.RandomState(seed)
            perm = rng.permutation(len(X_tr))
            n_tr = min(n_train, len(X_tr))
            n_te = min(n_test, len(X_te))
            X_tr, y_tr = X_tr[perm[:n_tr]], y_tr[perm[:n_tr]]
            nc = max(int(y_tr.max()) + 1, int(y_te.max()) + 1)
            return X_tr, y_tr, X_te[:n_te], y_te[:n_te], {"n_classes": nc, "input_dim": X_tr.shape[1]}
        # Try OpenML direct
        from sklearn.datasets import fetch_openml
        from sklearn.preprocessing import StandardScaler, LabelEncoder
        OPENML_IDS = {
            "shuttle": 40685, "magic": 1120, "texture": 40499, "phoneme": 1489,
            "vehicle": 54, "ecoli": 39, "yeast": 181, "glass": 41, "vowel": 307,
            "balance_scale": 11, "isolet": 300, "mfeat_fourier": 14,
            "mfeat_karhunen": 16, "madelon": 1485, "connect_4": 40668,
            "har": 1478, "steel_plates": 1504, "wall_robot": 1497, "gas_drift": 1476,
        }
        oid = OPENML_IDS.get(ds_name)
        if oid is None:
            raise ValueError(f"Unknown dataset: {ds_name}")
        data = fetch_openml(data_id=oid, as_frame=False, parser="liac-arff")
        X, y = data.data, data.target
        if y.dtype.kind in ('U', 'S', 'O'):
            y = LabelEncoder().fit_transform(y)
        X = X.astype(np.float64)
        mask = np.isfinite(X).all(axis=1)
        X, y = X[mask], y[mask]
        if np.isnan(X).any():
            from sklearn.impute import SimpleImputer
            X = SimpleImputer(strategy="median").fit_transform(X)
        X = StandardScaler().fit_transform(X).astype(np.float32)
        y = y.astype(np.int64)
        rng = np.random.RandomState(seed)
        perm = rng.permutation(len(X))
        X, y = X[perm], y[perm]
        n_tr = min(n_train if n_train > 0 else 5000, int(len(X) * 0.7))
        n_te = min(n_test if n_test > 0 else 2000, len(X) - n_tr)
        X_tr, y_tr = X[:n_tr], y[:n_tr]
        X_te, y_te = X[n_tr:n_tr+n_te], y[n_tr:n_tr+n_te]
        nc = len(np.unique(np.concatenate([y_tr, y_te])))
        return (torch.tensor(X_tr), torch.tensor(y_tr, dtype=torch.long),
                torch.tensor(X_te), torch.tensor(y_te, dtype=torch.long),
                {"n_classes": nc, "input_dim": X_tr.shape[1]})


ALL_DATASETS = [
    # (name, n_train, n_test, k)
    ("iris", 0, 0, 16), ("wine", 0, 0, 16), ("breast_cancer", 0, 0, 16),
    ("digits", 0, 0, 16), ("diabetes", 0, 0, 16),
    ("california_housing", 5000, 1000, 16), ("segment", 0, 0, 16),
    ("waveform", 3000, 500, 16), ("satellite", 3000, 500, 16),
    ("pendigits", 5000, 1000, 16), ("optdigits", 3000, 500, 16),
    ("letter", 5000, 1000, 16), ("covertype", 5000, 1000, 16),
    ("adult", 5000, 1000, 16), ("mnist_embed", 5000, 1000, 16),
    ("fmnist_embed", 5000, 1000, 16), ("cifar10_pca", 5000, 1000, 16),
    ("cifar10_resnet18", 5000, 1000, 16), ("newsgroups_embed", 3000, 500, 16),
    ("cora", 0, 0, 16),
    # New
    ("shuttle", 5000, 2000, 16), ("magic", 5000, 2000, 16),
    ("texture", 3000, 1000, 16), ("phoneme", 3000, 1000, 16),
    ("vehicle", 0, 0, 16), ("ecoli", 0, 0, 16), ("yeast", 0, 0, 16),
    ("glass", 0, 0, 16), ("vowel", 0, 0, 16),
    ("isolet", 3000, 1000, 16), ("mfeat_fourier", 0, 0, 16),
    ("mfeat_karhunen", 0, 0, 16), ("madelon", 0, 0, 16),
    ("har", 3000, 1000, 16), ("wall_robot", 3000, 1000, 16),
    ("gas_drift", 5000, 2000, 16),
    ("cifar100_resnet18", 5000, 2000, 16),
    ("svhn_resnet18", 5000, 2000, 16),
    ("stl10_resnet18", 4000, 1000, 16),
]

QUICK_DATASETS = [
    ("iris", 0, 0, 16), ("digits", 0, 0, 16), ("satellite", 3000, 500, 16),
    ("pendigits", 5000, 1000, 16), ("letter", 5000, 1000, 16),
    ("mnist_embed", 5000, 1000, 16), ("cifar10_resnet18", 5000, 1000, 16),
    ("cora", 0, 0, 16), ("vowel", 0, 0, 16),
]


# ══════════════════════════════════════════════════════════════════════
# GRAPH CONSTRUCTION METHODS
# ══════════════════════════════════════════════════════════════════════

def _compute_gaussian_weights(X, edge_index):
    """Gaussian weights from actual point distances."""
    src_pts = X[edge_index[0]]
    dst_pts = X[edge_index[1]]
    dists = (src_pts - dst_pts).norm(dim=1)
    sigma = dists.median() + 1e-8
    return torch.exp(-dists ** 2 / sigma ** 2)


def _build_knn_from_transformed(X_tr_t, X_te_t, X_tr_raw, X_te_raw, k, name):
    """Build kNN graph on transformed features, return graph + transformed features.
    
    Returns (edge_index, edge_weight, N, X_tr_for_prop, X_te_for_embed)
    where X_tr_for_prop is what we propagate, X_te_for_embed is what we use for kNN lookup.
    """
    N = len(X_tr_t)
    k_eff = min(k, N - 1)
    # Build graph on transformed space
    from vghl.models.knn_backend import KNNIndex
    index = KNNIndex(X_tr_t)
    indices, distances = index.query(X_tr_t, k_eff + 1)
    # Remove self
    indices = indices[:, 1:]
    distances = distances[:, 1:]
    # Build edge index
    src = np.repeat(np.arange(N), k_eff)
    dst = indices.reshape(-1)
    ei = torch.tensor(np.stack([src, dst]), dtype=torch.long)
    dists_t = torch.tensor(distances.reshape(-1), dtype=torch.float32)
    sigma = dists_t.median() + 1e-8
    ew = torch.exp(-dists_t ** 2 / sigma ** 2)
    # Symmetrize
    ei_rev = ei.flip(0)
    ei = torch.cat([ei, ei_rev], dim=1)
    ew = torch.cat([ew, ew])
    # Deduplicate
    edge_hash = ei[0] * N + ei[1]
    _, unique_idx = torch.unique(edge_hash, return_inverse=True)
    # Keep first occurrence
    _, first_idx = np.unique(unique_idx.numpy(), return_index=True)
    ei = ei[:, first_idx]
    ew = ew[first_idx]
    return ei, ew, N, X_tr_t, X_te_t, k_eff


def build_graph_knn_l2(X_tr, y_tr, X_te, k):
    """Standard kNN on L2 distance."""
    gc = GraphBuilderConfig(type="knn", k=min(k, len(X_tr)-1))
    g = build_base_graph(X_tr, gc)
    return g["edge_index"], g["edge_weight"], len(X_tr), X_tr, X_te, min(k, len(X_tr)-1)


def build_graph_mutual_knn(X_tr, y_tr, X_te, k):
    """Mutual kNN — only keep edge if BOTH nodes list each other as neighbors."""
    gc = GraphBuilderConfig(type="mutual_knn", k=min(k, len(X_tr)-1))
    g = build_base_graph(X_tr, gc)
    return g["edge_index"], g["edge_weight"], len(X_tr), X_tr, X_te, min(k, len(X_tr)-1)


def build_graph_cosine(X_tr, y_tr, X_te, k):
    """kNN on cosine similarity (normalize features first)."""
    X_tr_n = X_tr / (X_tr.norm(dim=1, keepdim=True) + 1e-8)
    X_te_n = X_te / (X_te.norm(dim=1, keepdim=True) + 1e-8)
    return _build_knn_from_transformed(X_tr_n.numpy(), X_te_n.numpy(),
                                        X_tr, X_te, k, "cosine")


def build_graph_mahalanobis(X_tr, y_tr, X_te, k):
    """kNN on Mahalanobis distance (pooled within-class covariance)."""
    nc = int(y_tr.max()) + 1
    N, d = X_tr.shape
    X_np = X_tr.numpy()
    y_np = y_tr.numpy()
    # Compute pooled within-class covariance
    S_w = np.zeros((d, d))
    for c in range(nc):
        mask = y_np == c
        if mask.sum() < 2: continue
        X_c = X_np[mask]
        X_c_centered = X_c - X_c.mean(axis=0)
        S_w += X_c_centered.T @ X_c_centered
    S_w /= max(N - nc, 1)
    S_w += np.eye(d) * 1e-4  # regularize
    try:
        L = np.linalg.cholesky(np.linalg.inv(S_w))
    except np.linalg.LinAlgError:
        # Fall back to pseudo-inverse
        U, s, Vt = np.linalg.svd(S_w)
        s_inv = np.where(s > 1e-6, 1.0/s, 0)
        S_w_inv = (Vt.T * s_inv) @ U.T
        try:
            L = np.linalg.cholesky(S_w_inv)
        except:
            L = np.eye(d)
    X_tr_m = (X_np @ L).astype(np.float32)
    X_te_m = (X_te.numpy() @ L).astype(np.float32)
    return _build_knn_from_transformed(X_tr_m, X_te_m, X_tr, X_te, k, "mahal")


def build_graph_pca(X_tr, y_tr, X_te, k, n_components=None):
    """PCA → kNN. Auto-selects dim to capture 95% variance."""
    from sklearn.decomposition import PCA
    from sklearn.preprocessing import StandardScaler
    d = X_tr.shape[1]
    if n_components is None:
        n_components = min(d, max(16, d // 4))
    n_components = min(n_components, d, X_tr.shape[0])
    scaler = StandardScaler()
    X_tr_s = scaler.fit_transform(X_tr.numpy())
    X_te_s = scaler.transform(X_te.numpy())
    pca = PCA(n_components=n_components)
    X_tr_p = pca.fit_transform(X_tr_s).astype(np.float32)
    X_te_p = pca.transform(X_te_s).astype(np.float32)
    return _build_knn_from_transformed(X_tr_p, X_te_p, X_tr, X_te, k, "pca")


def build_graph_lda(X_tr, y_tr, X_te, k):
    """LDA → kNN. Supervised dimensionality reduction before graph."""
    from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
    nc = int(y_tr.max()) + 1
    n_comp = min(nc - 1, X_tr.shape[1], X_tr.shape[0] - nc)
    if n_comp < 1:
        n_comp = 1
    lda = LinearDiscriminantAnalysis(n_components=n_comp)
    X_tr_l = lda.fit_transform(X_tr.numpy(), y_tr.numpy()).astype(np.float32)
    X_te_l = lda.transform(X_te.numpy()).astype(np.float32)
    return _build_knn_from_transformed(X_tr_l, X_te_l, X_tr, X_te, k, "lda")


def build_graph_umap(X_tr, y_tr, X_te, k):
    """UMAP → kNN. Nonlinear manifold embedding before graph construction."""
    try:
        import umap
    except ImportError:
        return None
    nc = int(y_tr.max()) + 1
    n_comp = min(32, X_tr.shape[1])
    reducer = umap.UMAP(n_components=n_comp, n_neighbors=min(k, len(X_tr)-1),
                         random_state=42, metric='euclidean')
    X_tr_u = reducer.fit_transform(X_tr.numpy()).astype(np.float32)
    X_te_u = reducer.transform(X_te.numpy()).astype(np.float32)
    return _build_knn_from_transformed(X_tr_u, X_te_u, X_tr, X_te, k, "umap")


def build_graph_random_proj(X_tr, y_tr, X_te, k):
    """Random projection (JL lemma) → kNN. Preserves distances approximately."""
    from sklearn.random_projection import GaussianRandomProjection
    d = X_tr.shape[1]
    n_comp = min(max(16, d // 4), d, X_tr.shape[0])
    rp = GaussianRandomProjection(n_components=n_comp, random_state=42)
    X_tr_r = rp.fit_transform(X_tr.numpy()).astype(np.float32)
    X_te_r = rp.transform(X_te.numpy()).astype(np.float32)
    return _build_knn_from_transformed(X_tr_r, X_te_r, X_tr, X_te, k, "rproj")


def build_graph_multi_scale(X_tr, y_tr, X_te, k):
    """Multi-scale graph: union of kNN at k=4,8,16,32."""
    N = len(X_tr)
    all_ei = []
    all_ew = []
    for ki in [4, 8, 16, 32]:
        ki_eff = min(ki, N - 1)
        gc = GraphBuilderConfig(type="knn", k=ki_eff)
        g = build_base_graph(X_tr, gc)
        all_ei.append(g["edge_index"])
        all_ew.append(g["edge_weight"])
    ei = torch.cat(all_ei, dim=1)
    ew = torch.cat(all_ew)
    # Deduplicate (keep max weight)
    edge_hash = ei[0] * N + ei[1]
    uniq, inv = torch.unique(edge_hash, return_inverse=True)
    # Scatter max for weights
    ew_dedup = torch.zeros(len(uniq))
    ew_dedup.scatter_reduce_(0, inv, ew, reduce='amax')
    ei_dedup = torch.stack([uniq // N, uniq % N])
    return ei_dedup, ew_dedup, N, X_tr, X_te, min(k, N - 1)


def build_graph_hybrid(X_tr, y_tr, X_te, k):
    """Hybrid: local kNN + sparse long-range edges."""
    gc = GraphBuilderConfig(type="hybrid", k=min(k, len(X_tr)-1),
                             hybrid_long_frac=0.1, hybrid_long_k=2)
    g = build_base_graph(X_tr, gc)
    return g["edge_index"], g["edge_weight"], len(X_tr), X_tr, X_te, min(k, len(X_tr)-1)


# Registry of all graph builders
GRAPH_BUILDERS = {
    "knn_l2":        build_graph_knn_l2,
    "cosine":        build_graph_cosine,
    "mahalanobis":   build_graph_mahalanobis,
    "mutual_knn":    build_graph_mutual_knn,
    "pca_knn":       build_graph_pca,
    "lda_knn":       build_graph_lda,
    "umap_knn":      build_graph_umap,
    "random_proj":   build_graph_random_proj,
    "multi_scale":   build_graph_multi_scale,
    "hybrid":        build_graph_hybrid,
}


# ══════════════════════════════════════════════════════════════════════
# EVALUATION ENGINE
# ══════════════════════════════════════════════════════════════════════

def evaluate_config(h_tr, y_tr, h_te, y_te, X_tr_embed, X_te_embed, nc, k_eff, readout):
    """Evaluate a single (graph, prop, readout) configuration."""
    if readout == "ridge":
        return ridge_eval(h_tr, y_tr, h_te, y_te, n_classes=nc)
    elif readout == "knn":
        from sklearn.neighbors import KNeighborsClassifier
        clf = KNeighborsClassifier(n_neighbors=min(k_eff, len(h_tr)-1), n_jobs=-1)
        clf.fit(h_tr.numpy(), y_tr.numpy())
        return float(clf.score(h_te.numpy(), y_te.numpy()))
    elif readout == "mlp":
        from sklearn.neural_network import MLPClassifier
        mlp = MLPClassifier(hidden_layer_sizes=(128,), max_iter=500,
                             random_state=42, early_stopping=True,
                             validation_fraction=0.1)
        mlp.fit(h_tr.numpy(), y_tr.numpy())
        return float(mlp.score(h_te.numpy(), y_te.numpy()))
    return -1.0


def run_sweep(datasets, seeds, out_dir):
    print(f"\n{'='*80}")
    print(f"MULTIDIMENSIONAL GEOMETRY SWEEP")
    print(f"  {len(datasets)} datasets × {len(seeds)} seeds")
    print(f"  {len(GRAPH_BUILDERS)} graph types × 3 propagations × 3 readouts = "
          f"{len(GRAPH_BUILDERS)*3*3} configs per dataset")
    print(f"{'='*80}\n")

    all_rows = []
    prop_configs = [
        ("rw_T5", PropagationConfig(type="random_walk", steps=5)),
        ("ppr85", PropagationConfig(type="ppr", steps=5, alpha=0.85)),
        ("identity", PropagationConfig(type="identity", steps=0)),
    ]
    readouts = ["ridge", "knn", "mlp"]

    for ds_name, n_tr, n_te, k in datasets:
        for seed in seeds:
            try:
                X_tr, y_tr, X_te, y_te, meta = load_dataset(ds_name, seed, n_tr, 500, n_te)
            except Exception as e:
                print(f"  SKIP {ds_name}: {e}")
                continue

            N, d = X_tr.shape
            nc = max(int(y_tr.max()) + 1, int(y_te.max()) + 1)
            base = {"dataset": ds_name, "seed": seed, "N": N, "d": d, "C": nc}

            # Raw baselines (no graph)
            for ro in readouts:
                try:
                    acc = evaluate_config(X_tr, y_tr, X_te, y_te, X_tr, X_te, nc, k, ro)
                    all_rows.append({**base, "graph": "none", "prop": "none",
                                     "readout": ro, "acc": acc})
                except Exception:
                    pass

            # Graph-based configs
            best_acc = 0
            best_config = ""
            for g_name, g_builder in GRAPH_BUILDERS.items():
                try:
                    result = g_builder(X_tr, y_tr, X_te, k)
                    if result is None:
                        continue
                    ei, ew, N_g, X_tr_g, X_te_g, k_eff = result
                except Exception as e:
                    print(f"    {ds_name}/{g_name}: graph build failed: {e}")
                    continue

                # Ensure tensors
                X_tr_g = torch.tensor(X_tr_g, dtype=torch.float32) if not isinstance(X_tr_g, torch.Tensor) else X_tr_g
                X_te_g = torch.tensor(X_te_g, dtype=torch.float32) if not isinstance(X_te_g, torch.Tensor) else X_te_g

                for p_name, p_cfg in prop_configs:
                    try:
                        if p_name == "identity":
                            h_tr = X_tr_g.clone()
                        else:
                            h_tr = propagate(X_tr_g, ei, ew, N_g, p_cfg)
                        # Embed test via kNN in the graph's feature space
                        h_te = embed_queries_via_knn(h_tr, X_tr_g, X_te_g, k=k_eff)
                    except Exception as e:
                        continue

                    for ro in readouts:
                        try:
                            acc = evaluate_config(h_tr, y_tr, h_te, y_te,
                                                   X_tr_g, X_te_g, nc, k_eff, ro)
                            all_rows.append({**base, "graph": g_name, "prop": p_name,
                                             "readout": ro, "acc": acc})
                            if acc > best_acc:
                                best_acc = acc
                                best_config = f"{g_name}/{p_name}/{ro}"
                        except Exception:
                            pass

            # Summary for this dataset
            raw_best = max((r["acc"] for r in all_rows
                            if r["dataset"] == ds_name and r["seed"] == seed
                            and r["graph"] == "none"), default=0)
            graph_best = max((r["acc"] for r in all_rows
                              if r["dataset"] == ds_name and r["seed"] == seed
                              and r["graph"] != "none"), default=0)
            lift = graph_best - raw_best
            print(f"  {ds_name:<25} d={d:>4} raw_best={raw_best:.4f} "
                  f"graph_best={graph_best:.4f} lift={lift:+.4f} [{best_config}]",
                  flush=True)

    _save_csv(all_rows, out_dir / "multidim_sweep.csv")

    # ══════════════════════════════════════════════════════════════════
    # ANALYSIS
    # ══════════════════════════════════════════════════════════════════
    if len(all_rows) > 10:
        print(f"\n{'='*80}")
        print("ANALYSIS: Which graph construction wins?")
        print(f"{'='*80}\n")

        # Per dataset: best graph method vs raw
        by_ds = defaultdict(list)
        for r in all_rows:
            by_ds[r["dataset"]].append(r)

        print(f"{'Dataset':<25} {'d':>4} {'raw_best':>9} {'graph_best':>10} "
              f"{'lift':>7} {'best_graph':>15} {'best_readout':>12}")
        print("-" * 90)

        wins_by_graph = defaultdict(int)
        wins_by_readout = defaultdict(int)
        lifts = []

        for ds in sorted(by_ds.keys()):
            rows_ds = by_ds[ds]
            raw_rows = [r for r in rows_ds if r["graph"] == "none"]
            graph_rows = [r for r in rows_ds if r["graph"] != "none"]
            if not raw_rows or not graph_rows:
                continue
            raw_best = max(r["acc"] for r in raw_rows)
            best_graph_row = max(graph_rows, key=lambda r: r["acc"])
            graph_best = best_graph_row["acc"]
            lift = graph_best - raw_best
            lifts.append(lift)
            d = raw_rows[0]["d"]
            wins_by_graph[best_graph_row["graph"]] += 1
            wins_by_readout[best_graph_row["readout"]] += 1
            print(f"{ds:<25} {d:>4} {raw_best:>9.4f} {graph_best:>10.4f} "
                  f"{lift:>+7.4f} {best_graph_row['graph']:>15} "
                  f"{best_graph_row['readout']:>12}")

        print(f"\nMean lift: {np.mean(lifts):+.4f}")
        print(f"Datasets where graph beats raw: {sum(1 for l in lifts if l > 0.005)}/{len(lifts)}")
        print(f"\nWins by graph type:")
        for g, c in sorted(wins_by_graph.items(), key=lambda x: -x[1]):
            print(f"  {g:<20} {c}")
        print(f"\nWins by readout:")
        for r, c in sorted(wins_by_readout.items(), key=lambda x: -x[1]):
            print(f"  {r:<20} {c}")

        # Per graph method: mean lift
        print(f"\nMean lift by graph method:")
        by_graph_method = defaultdict(list)
        for ds in by_ds:
            rows_ds = by_ds[ds]
            raw_best = max((r["acc"] for r in rows_ds if r["graph"] == "none"), default=0)
            for g_name in GRAPH_BUILDERS:
                g_rows = [r for r in rows_ds if r["graph"] == g_name]
                if g_rows:
                    g_best = max(r["acc"] for r in g_rows)
                    by_graph_method[g_name].append(g_best - raw_best)
        for g, lifts_g in sorted(by_graph_method.items(), key=lambda x: -np.mean(x[1])):
            pos = sum(1 for l in lifts_g if l > 0.005)
            print(f"  {g:<20} mean={np.mean(lifts_g):+.4f} "
                  f"pos={pos}/{len(lifts_g)} median={np.median(lifts_g):+.4f}")

    return all_rows


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--seeds", type=str, default="0,1")
    p.add_argument("--out", type=str, default="outputs/multidim_geometry")
    p.add_argument("--quick", action="store_true")
    p.add_argument("--only", type=str, default=None)
    args = p.parse_args()
    seeds = [int(s) for s in args.seeds.split(",")]
    out = Path(args.out)

    if args.quick:
        datasets = QUICK_DATASETS
    elif args.only == "existing":
        datasets = [d for d in ALL_DATASETS if d[0] not in
                     {"shuttle","magic","texture","phoneme","vehicle","ecoli",
                      "yeast","glass","vowel","isolet","mfeat_fourier",
                      "mfeat_karhunen","madelon","har","wall_robot","gas_drift",
                      "cifar100_resnet18","svhn_resnet18","stl10_resnet18",
                      "connect_4","balance_scale","steel_plates"}]
    else:
        datasets = ALL_DATASETS

    run_sweep(datasets, seeds, out)


if __name__ == "__main__":
    main()
