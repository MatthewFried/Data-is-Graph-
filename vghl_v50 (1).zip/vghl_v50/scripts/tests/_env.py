"""Shared test environment setup. Import FIRST in every test script.

Forces single-threaded execution for all numeric backends to prevent
deadlocks in repeated kNN / sklearn calls.
"""
import os

os.environ["OMP_NUM_THREADS"] = "1"
os.environ["MKL_NUM_THREADS"] = "1"
os.environ["OPENBLAS_NUM_THREADS"] = "1"
os.environ["NUMEXPR_NUM_THREADS"] = "1"

import sys
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "..", "src"))
