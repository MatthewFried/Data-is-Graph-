#!/usr/bin/env python3
"""Test: Batch Invariance.

Verifies that the same sample gets the same prediction regardless of
which other samples are in the batch. This is the fundamental correctness
test for the anchor-graph refactor.

Passes iff: predictions for a fixed set of test points are identical
across different batch compositions.
"""
import sys
import os

# Force single-thread to prevent deadlocks in repeated kNN calls
os.environ["OMP_NUM_THREADS"] = "1"
os.environ["MKL_NUM_THREADS"] = "1"
os.environ["OPENBLAS_NUM_THREADS"] = "1"
os.environ["NUMEXPR_NUM_THREADS"] = "1"

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "..", "src"))

import torch
import numpy as np
from vghl.utils.seed import set_seed
from vghl.models.graph_builder import GraphBuilderConfig
from vghl.models.propagation import PropagationConfig
from vghl.models.anchor_graph import AnchorGraphConfig
from vghl.models.geometric_machine import GeometricMachine


def test_batch_invariance(n_train=500, n_test=50, n_trials=5, seed=42):
    set_seed(seed)
    device = "cuda" if torch.cuda.is_available() else "cpu"

    # Generate synthetic data
    X_train = torch.randn(n_train, 2, device=device)
    y_train = (X_train[:, 0] > 0).long()
    X_test = torch.randn(n_test, 2, device=device)

    for gm_mode in ["transductive_full_graph", "inductive_anchor_graph"]:
        print(f"\n--- Testing mode: {gm_mode} ---")

        model = GeometricMachine(
            input_dim=2,
            n_classes=2,
            graph_cfg=GraphBuilderConfig(type="knn", k=8),
            prop_cfg=PropagationConfig(type="random_walk", steps=3),
            anchor_cfg=AnchorGraphConfig(mode=gm_mode, anchor_k=8),
        ).to(device)

        # Build graph once
        model.build_graph(X_train, labels=y_train)

        # Get reference predictions on test set
        model.eval()
        with torch.no_grad():
            ref_output = model(X_test, is_query=True)
            ref_logits = ref_output["logits"]

        # Re-run with different random contexts (should not matter)
        max_diff = 0.0
        for trial in range(n_trials):
            with torch.no_grad():
                output = model(X_test, is_query=True)
                logits = output["logits"]
            diff = (logits - ref_logits).abs().max().item()
            max_diff = max(max_diff, diff)
            print(f"  Trial {trial}: max logit diff = {diff:.2e}")

        if max_diff < 1e-5:
            print(f"  PASS: batch invariance holds (max_diff={max_diff:.2e})")
        else:
            print(f"  FAIL: predictions vary across runs (max_diff={max_diff:.2e})")
            return False

    print("\n=== ALL BATCH INVARIANCE TESTS PASSED ===")
    return True


if __name__ == "__main__":
    success = test_batch_invariance()
    sys.exit(0 if success else 1)
