#!/usr/bin/env python3
"""Test: Guarded Merge Preserves Behavior.

Builds a machine, computes embeddings/logits on a probe set, then:
  1. Proposes merges that meet behavioral distance threshold.
  2. Asserts merge only commits if Δlogits <= eps.
  3. Validates non-committing behavior when eps is tight.
"""
import os
import sys

os.environ["OMP_NUM_THREADS"] = "1"
os.environ["MKL_NUM_THREADS"] = "1"
os.environ["OPENBLAS_NUM_THREADS"] = "1"
os.environ["NUMEXPR_NUM_THREADS"] = "1"

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "..", "src"))

import torch
from vghl.utils.seed import set_seed
from vghl.models.graph_builder import GraphBuilderConfig, build_base_graph
from vghl.models.propagation import PropagationConfig, propagate
from vghl.models.merge import MergeConfig, compute_transition_signatures, find_merge_candidates, apply_merges
from vghl.search.minimize import (
    GuardedMergeConfig, compute_probe_signatures,
    compute_behavioral_distance, guarded_merge,
)


def test_guarded_merge_preserves_behavior(N=300, d=5, seed=42):
    set_seed(seed)
    device = "cpu"
    print(f"Guarded merge test: N={N}, d={d}, seed={seed}")

    # Create clustered data (3 clusters, merge should happen within clusters)
    centers = torch.tensor([[0, 0], [5, 0], [0, 5]], dtype=torch.float32)
    X_list = []
    for c in centers:
        X_list.append(c + torch.randn(N // 3, 2) * 0.3)
    X = torch.cat(X_list)
    N = X.shape[0]

    # Build graph
    graph = build_base_graph(X, GraphBuilderConfig(type="knn", k=8))
    ei, ew = graph["edge_index"], graph["edge_weight"]

    # Propagate to get embeddings
    h_before = propagate(X, ei, ew, N, PropagationConfig(type="random_walk", steps=3))

    # Simulate logits (random linear head)
    torch.manual_seed(seed)
    W = torch.randn(2, 3)
    logits_before = h_before @ W

    # ── Test 1: Loose eps → merges should commit ─────────────────
    print("\n  Test 1: Loose guard (eps=1.0)")
    cfg_loose = GuardedMergeConfig(
        enabled=True, tau=0.50, eps_emb=1.0, eps_logit=1.0,
        num_probes=4, metric="cosine",
    )
    new_ei, new_ew, compact, new_N, stats = guarded_merge(
        ei, ew, N, h_before, logits_before, cfg_loose,
    )
    print(f"    Proposed={stats['n_proposed']}, accepted={stats['n_accepted']}, "
          f"rejected={stats['n_rejected_guard']}")
    print(f"    N: {N} -> {new_N}")

    # With loose eps, at least some merges should be accepted
    assert stats['n_proposed'] > 0, "No merge candidates proposed"
    assert stats['n_accepted'] >= 0, "Negative accepted count"  # can be 0 if no similar pairs

    if stats['n_accepted'] > 0:
        assert new_N < N, f"Expected N to decrease: {N} -> {new_N}"
        print("    PASS: merges committed with loose guard")
    else:
        print("    INFO: no merges committed (insufficient similarity)")

    # ── Test 2: Tight eps → merges should be rejected ────────────
    print("\n  Test 2: Tight guard (eps=0.0001)")
    cfg_tight = GuardedMergeConfig(
        enabled=True, tau=0.50, eps_emb=0.0001, eps_logit=0.0001,
        num_probes=4, metric="cosine",
    )
    _, _, _, new_N_tight, stats_tight = guarded_merge(
        ei, ew, N, h_before, logits_before, cfg_tight,
    )
    print(f"    Proposed={stats_tight['n_proposed']}, accepted={stats_tight['n_accepted']}, "
          f"rejected={stats_tight['n_rejected_guard']}")

    # With extremely tight eps, most/all merges should be rejected by guard
    if stats_tight['n_proposed'] > 0:
        # Guard should reject more merges than loose version
        rejection_rate = stats_tight['n_rejected_guard'] / max(stats_tight['n_proposed'], 1)
        print(f"    Rejection rate: {rejection_rate:.2f}")
        # Tight eps should reject at least as many as loose eps accepted
        assert stats_tight['n_rejected_guard'] >= stats_tight['n_accepted'], (
            "Tight guard should reject more than it accepts"
        )
        print("    PASS: tight guard rejects merges")
    else:
        print("    INFO: no candidates to test guard")

    # ── Test 3: Disabled → no merges ─────────────────────────────
    print("\n  Test 3: Disabled guard")
    cfg_off = GuardedMergeConfig(enabled=False)
    _, _, _, new_N_off, stats_off = guarded_merge(
        ei, ew, N, h_before, logits_before, cfg_off,
    )
    assert new_N_off == N, "Disabled merge should not change N"
    assert stats_off['n_proposed'] == 0, "Disabled merge should propose nothing"
    print("    PASS: disabled guard does nothing")

    # ── Test 4: Probe signatures are non-trivial ─────────────────
    print("\n  Test 4: Probe signatures")
    sigs = compute_probe_signatures(ei, ew, N, num_probes=8)
    assert sigs.shape == (N, 8), f"Wrong shape: {sigs.shape}"
    assert not torch.isnan(sigs).any(), "NaN in signatures"
    assert sigs.abs().sum() > 0, "All-zero signatures"
    # Signatures should vary across nodes
    sig_std = sigs.std(dim=0).mean().item()
    print(f"    Signature std: {sig_std:.4f}")
    assert sig_std > 1e-6, f"Signatures are constant (std={sig_std})"
    print("    PASS: non-trivial signatures")

    print("\n=== GUARDED MERGE PRESERVATION TEST PASSED ===")
    return True


if __name__ == "__main__":
    success = test_guarded_merge_preserves_behavior()
    exit(0 if success else 1)
