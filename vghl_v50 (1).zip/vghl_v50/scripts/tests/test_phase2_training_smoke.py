#!/usr/bin/env python3
"""Test: Phase-2 Training Smoke Test.

Trains on a small dataset with Phase-2 enabled (hierarchy + multilevel propagation).
Asserts:
  1. Val loss decreases from epoch 0 to final epoch.
  2. Val accuracy > majority baseline + margin.
  3. Phase-2 machine has >= 2 levels.
  4. No NaN in outputs.
"""
import os
import sys

os.environ["OMP_NUM_THREADS"] = "1"
os.environ["MKL_NUM_THREADS"] = "1"
os.environ["OPENBLAS_NUM_THREADS"] = "1"
os.environ["NUMEXPR_NUM_THREADS"] = "1"

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "..", "src"))

import torch
from vghl.utils.seed import set_seed
from vghl.models.graph_builder import GraphBuilderConfig
from vghl.models.propagation import PropagationConfig
from vghl.models.anchor_graph import AnchorGraphConfig
from vghl.models.primitives import PrimitiveConfig
from vghl.models.recursion import RecursionConfig
from vghl.models.multilevel_compute import MultilevelComputeConfig
from vghl.models.merge import MergeConfig
from vghl.models.geometric_machine import GeometricMachine


def test_phase2_training_smoke(n_train=500, n_val=200, d=10, n_classes=3,
                                epochs=5, seed=42):
    set_seed(seed)
    device = "cpu"  # force CPU for test reliability

    # Synthetic data: 3 Gaussian blobs
    X_all = []
    y_all = []
    for c in range(n_classes):
        center = torch.randn(d) * 3
        X_all.append(center + torch.randn(n_train + n_val, d) * 0.5)
        y_all.append(torch.full((n_train + n_val,), c, dtype=torch.long))
    X = torch.cat(X_all)
    y = torch.cat(y_all)
    perm = torch.randperm(len(X))
    X, y = X[perm], y[perm]

    total = n_classes * (n_train + n_val)
    n_tr = n_classes * n_train
    X_train, y_train = X[:n_tr], y[:n_tr]
    X_val, y_val = X[n_tr:], y[n_tr:]

    print(f"Phase-2 smoke test: N_train={len(X_train)}, N_val={len(X_val)}, "
          f"d={d}, classes={n_classes}")

    # Build Phase-2 model
    model = GeometricMachine(
        input_dim=d,
        n_classes=n_classes,
        graph_cfg=GraphBuilderConfig(type="knn", k=12),
        prop_cfg=PropagationConfig(type="random_walk", steps=3),
        anchor_cfg=AnchorGraphConfig(mode="inductive_anchor_graph", anchor_k=8),
        primitive_cfg=PrimitiveConfig(types=["triangle"], use_in_propagation=True),
        recursion_cfg=RecursionConfig(enabled=True, depth=1,
                                       port_rule="boundary_top2",
                                       wiring_rule="shared_boundary"),
        multilevel_cfg=MultilevelComputeConfig(),
        merge_cfg=MergeConfig(enabled=False),
        head_type="mlp",
        head_hidden=64,
        embed_dim=d,
    ).to(device)

    # Build graph
    model.build_graph(X_train, labels=y_train)

    # Check Phase-2 levels
    assert model._levels is not None, "Phase-2 levels not built"
    n_levels = len(model._levels)
    print(f"  Phase-2 levels: {n_levels}, nodes={[l.n_nodes for l in model._levels]}")
    assert n_levels >= 2, f"Expected >= 2 levels, got {n_levels}"

    # Simple training loop
    optimizer = torch.optim.Adam(model.parameters(), lr=1e-3)
    loss_fn = torch.nn.CrossEntropyLoss()

    # Get propagated train features for training
    h_train = model._propagated_anchors.detach()
    losses = []

    for epoch in range(epochs):
        model.train()
        optimizer.zero_grad()
        logits = model.head(h_train)
        loss = loss_fn(logits, y_train)
        loss.backward()
        optimizer.step()
        losses.append(loss.item())

    # Val evaluation
    model.eval()
    with torch.no_grad():
        out = model(X_val, is_query=True)
        val_logits = out["logits"]

    assert not torch.isnan(val_logits).any(), "NaN in val logits!"

    val_preds = val_logits.argmax(dim=1)
    val_acc = (val_preds == y_val).float().mean().item()
    majority_baseline = max([(y_val == c).float().mean().item() for c in range(n_classes)])

    print(f"  Losses: {[f'{l:.4f}' for l in losses]}")
    print(f"  Val accuracy: {val_acc:.4f} (majority={majority_baseline:.4f})")

    # Assertions
    assert losses[-1] < losses[0], f"Loss did not decrease: {losses[0]:.4f} -> {losses[-1]:.4f}"
    assert val_acc > majority_baseline + 0.05, (
        f"Val acc {val_acc:.4f} not above majority+0.05 ({majority_baseline+0.05:.4f})"
    )

    print("=== PHASE-2 TRAINING SMOKE TEST PASSED ===")
    return True


if __name__ == "__main__":
    success = test_phase2_training_smoke()
    exit(0 if success else 1)
