#!/usr/bin/env python3
"""Test: Structural Edit Loop Improves (or Preserves) Score.

Runs the edit loop on a small manifold dataset and asserts:
  1. Best score >= initial score (edits don't make things worse).
  2. OR complexity decreases without large accuracy drop.
  3. Edit loop runs without crashes.
"""
import os
import sys

os.environ["OMP_NUM_THREADS"] = "1"
os.environ["MKL_NUM_THREADS"] = "1"
os.environ["OPENBLAS_NUM_THREADS"] = "1"
os.environ["NUMEXPR_NUM_THREADS"] = "1"

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "..", "src"))

import torch
from vghl.utils.seed import set_seed
from vghl.models.graph_builder import GraphBuilderConfig, build_base_graph
from vghl.models.propagation import PropagationConfig
from vghl.models.primitives import PrimitiveConfig, induce_primitives
from vghl.models.recursion import RecursionConfig, build_multilevel_graph
from vghl.models.multilevel_compute import MultilevelComputeConfig, multilevel_propagate
from vghl.models.merge import MergeConfig
from vghl.models.edit_loop import EditLoopConfig, run_edit_loop, score_machine


def test_search_improves_score(N=500, seed=42):
    set_seed(seed)
    device = "cpu"
    print(f"Edit loop score test: N={N}, seed={seed}")

    # Generate half-moons
    from sklearn.datasets import make_moons
    X_np, y_np = make_moons(n_samples=N, noise=0.15, random_state=seed)
    X = torch.tensor(X_np, dtype=torch.float32, device=device)
    y = torch.tensor(y_np, dtype=torch.long, device=device)

    # Build base graph
    graph_cfg = GraphBuilderConfig(type="knn", k=12)
    graph = build_base_graph(X, graph_cfg)
    ei, ew = graph["edge_index"], graph["edge_weight"]

    # Induce primitives
    prim_cfg = PrimitiveConfig(types=["triangle"], use_in_propagation=True)
    prims = induce_primitives(ei, X, prim_cfg)
    print(f"  Induced {len(prims)} primitives")

    assert len(prims) > 0, "No primitives induced"

    # Configs
    rec_cfg = RecursionConfig(enabled=True, depth=1,
                               port_rule="boundary_top2",
                               wiring_rule="shared_boundary")
    ml_cfg = MultilevelComputeConfig()
    prop_cfg = PropagationConfig(type="random_walk", steps=3)
    merge_cfg = MergeConfig(enabled=True, tau=0.90)

    # Build initial hierarchy for baseline score
    init_levels = build_multilevel_graph(X, ei, ew, prims, rec_cfg)
    init_h = multilevel_propagate(X, init_levels, prop_cfg, ml_cfg)
    init_score, init_details = score_machine(init_levels, 0.5)  # dummy acc
    print(f"  Initial: {len(init_levels)} levels, score={init_score:.4f}")

    # Run edit loop
    edit_cfg = EditLoopConfig(
        enabled=True,
        max_iterations=5,
        alpha_nodes=0.01,
        beta_edges=0.01,
        gamma_instability=0.1,
        try_edge_prune=True,
        edge_prune_percentile=0.93,
        try_primitive_prune=True,
        primitive_quality_step=0.05,
        try_merge=True,
    )

    best_levels, best_prims, log = run_edit_loop(
        z=X, edge_index=ei, edge_weight=ew,
        primitives=prims,
        recursion_cfg=rec_cfg,
        multilevel_cfg=ml_cfg,
        prop_cfg=prop_cfg,
        merge_cfg=merge_cfg,
        edit_cfg=edit_cfg,
        eval_fn=None,
    )

    final_score, final_details = score_machine(best_levels, 0.5)
    print(f"  Final: {len(best_levels)} levels, score={final_score:.4f}")
    print(f"  Log keys: {list(log.keys())}")

    # Assertions
    # Score should be >= initial (edits either improve or are rejected)
    assert final_score >= init_score - 0.01, (
        f"Final score {final_score:.4f} < initial {init_score:.4f} - 0.01"
    )

    # Total nodes/edges should be <= initial (complexity doesn't grow)
    init_V = init_details["total_nodes"]
    final_V = final_details["total_nodes"]
    init_E = init_details["total_edges"]
    final_E = final_details["total_edges"]
    print(f"  Complexity: V={init_V}->{final_V}, E={init_E}->{final_E}")

    # Edit loop produced log entries
    assert len(log) >= 1, "No log entries from edit loop"

    print("=== SEARCH IMPROVES SCORE TEST PASSED ===")
    return True


if __name__ == "__main__":
    success = test_search_improves_score()
    exit(0 if success else 1)
