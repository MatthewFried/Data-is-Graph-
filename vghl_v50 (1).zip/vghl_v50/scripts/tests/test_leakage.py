#!/usr/bin/env python3
"""Test: Label Leakage.

Verifies that val/test labels are never used in graph construction or pruning.
Tests by checking that label_consistency pruning only affects train nodes.
"""
import sys
import os

# Force single-thread to prevent deadlocks in repeated kNN calls
os.environ["OMP_NUM_THREADS"] = "1"
os.environ["MKL_NUM_THREADS"] = "1"
os.environ["OPENBLAS_NUM_THREADS"] = "1"
os.environ["NUMEXPR_NUM_THREADS"] = "1"

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "..", "src"))

import torch
from vghl.utils.seed import set_seed
from vghl.models.graph_builder import GraphBuilderConfig, build_base_graph
from vghl.models.pruning import PruningConfig, prune_graph


def test_label_leakage(n_train=300, n_val=100, seed=42):
    set_seed(seed)
    device = "cuda" if torch.cuda.is_available() else "cpu"
    print(f"Label leakage test: n_train={n_train}, n_val={n_val}")

    # Create data with known structure
    X_all = torch.randn(n_train + n_val, 2, device=device)
    y_all = (X_all[:, 0] > 0).long()

    # Build graph on all points
    graph = build_base_graph(X_all, GraphBuilderConfig(type="knn", k=8))

    # Create train mask: only first n_train are train
    train_mask = torch.zeros(n_train + n_val, dtype=torch.bool, device=device)
    train_mask[:n_train] = True

    # Run label_consistency pruning with train_mask
    cfg = PruningConfig(
        enabled=True,
        methods=["label_consistency"],
        label_agreement_min=0.5,
    )
    result = prune_graph(
        graph["edge_index"], graph["edge_weight"], X_all,
        cfg, labels=y_all,
        is_train_mask=train_mask,
    )

    node_mask = result["node_mask"]

    # Check: val/test nodes should NEVER be pruned by label_consistency
    val_nodes_pruned = (~node_mask[n_train:]).sum().item()
    train_nodes_pruned = (~node_mask[:n_train]).sum().item()

    print(f"  Train nodes pruned: {train_nodes_pruned}")
    print(f"  Val nodes pruned (should be 0): {val_nodes_pruned}")

    if val_nodes_pruned > 0:
        print("  FAIL: val/test labels leaked into pruning!")
        return False

    # Also verify: changing val labels should NOT change pruning result
    y_shuffled = y_all.clone()
    y_shuffled[n_train:] = torch.randint(0, 2, (n_val,), device=device)

    result2 = prune_graph(
        graph["edge_index"], graph["edge_weight"], X_all,
        cfg, labels=y_shuffled,
        is_train_mask=train_mask,
    )

    # Train node pruning should be similar (not identical because val labels
    # affect neighbor counts, but val nodes should still not be pruned)
    val_nodes_pruned_2 = (~result2["node_mask"][n_train:]).sum().item()
    if val_nodes_pruned_2 > 0:
        print("  FAIL: val nodes pruned even with shuffled labels!")
        return False

    print("=== LABEL LEAKAGE TEST PASSED ===")
    return True


if __name__ == "__main__":
    success = test_label_leakage()
    sys.exit(0 if success else 1)
