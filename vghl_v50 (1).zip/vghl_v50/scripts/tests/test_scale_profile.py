#!/usr/bin/env python3
"""Test: Scale Profile.

Verifies that graph construction + propagation complete without OOM
for increasing N. Logs runtime and peak memory.

Test sizes: 500, 2000, 5000, 10000
"""
import sys
import os

# Force single-thread to prevent deadlocks in repeated kNN calls
os.environ["OMP_NUM_THREADS"] = "1"
os.environ["MKL_NUM_THREADS"] = "1"
os.environ["OPENBLAS_NUM_THREADS"] = "1"
os.environ["NUMEXPR_NUM_THREADS"] = "1"

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "..", "src"))

import time
import torch
from vghl.utils.seed import set_seed
from vghl.models.graph_builder import GraphBuilderConfig, build_base_graph
from vghl.models.propagation import PropagationConfig, propagate


def test_scale_profile(
    sizes=(500, 2000, 5000, 10000),
    graph_types=("knn", "mutual_knn", "adaptive_radius"),
    operators=("random_walk", "ppr", "laplacian"),
    d=10,
    k=16,
    seed=42,
):
    set_seed(seed)
    device = "cuda" if torch.cuda.is_available() else "cpu"
    results = []

    print(f"Scale profile test on {device}, dim={d}, k={k}")
    print(f"{'N':>6} {'graph':>16} {'operator':>12} {'build_s':>8} {'prop_s':>8} {'edges':>8} {'status':>8}")
    print("-" * 80)

    for N in sizes:
        X = torch.randn(N, d, device=device)
        for gt in graph_types:
            for op in operators:
                status = "OK"
                build_t = prop_t = 0.0
                n_edges = 0

                try:
                    # Build graph
                    cfg = GraphBuilderConfig(type=gt, k=k)
                    t0 = time.perf_counter()
                    graph = build_base_graph(X, cfg)
                    build_t = time.perf_counter() - t0
                    n_edges = graph["edge_index"].shape[1]

                    # Propagate
                    pcfg = PropagationConfig(type=op, steps=5)
                    t0 = time.perf_counter()
                    h = propagate(X, graph["edge_index"], graph["edge_weight"], N, pcfg)
                    prop_t = time.perf_counter() - t0

                    # Verify output shape
                    assert h.shape == X.shape, f"Shape mismatch: {h.shape} vs {X.shape}"
                    assert not h.isnan().any(), "NaN in propagated features"

                except torch.cuda.OutOfMemoryError:
                    status = "OOM"
                    if device == "cuda":
                        torch.cuda.empty_cache()
                except Exception as e:
                    status = f"ERR"
                    print(f"  Error: {e}")

                print(f"{N:>6} {gt:>16} {op:>12} {build_t:>8.3f} {prop_t:>8.3f} {n_edges:>8} {status:>8}")
                results.append({
                    "N": N, "graph": gt, "operator": op,
                    "build_s": build_t, "prop_s": prop_t,
                    "n_edges": n_edges, "status": status,
                })

    # Summary
    failures = [r for r in results if r["status"] != "OK"]
    if failures:
        print(f"\n{len(failures)} FAILURES:")
        for f in failures:
            print(f"  N={f['N']}, {f['graph']}/{f['operator']}: {f['status']}")
        return False
    else:
        print("\n=== ALL SCALE TESTS PASSED ===")
        return True


if __name__ == "__main__":
    success = test_scale_profile()
    sys.exit(0 if success else 1)
