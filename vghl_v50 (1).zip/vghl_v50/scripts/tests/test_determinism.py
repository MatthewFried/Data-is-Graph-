#!/usr/bin/env python3
"""Test: Determinism.

Verifies that same seed produces identical graph structure and predictions.
"""
import sys
import os

# Force single-thread to prevent deadlocks in repeated kNN calls
os.environ["OMP_NUM_THREADS"] = "1"
os.environ["MKL_NUM_THREADS"] = "1"
os.environ["OPENBLAS_NUM_THREADS"] = "1"
os.environ["NUMEXPR_NUM_THREADS"] = "1"

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "..", "src"))

import torch
from vghl.utils.seed import set_seed
from vghl.models.graph_builder import GraphBuilderConfig, build_base_graph
from vghl.models.propagation import PropagationConfig, propagate


def test_determinism(n=1000, d=5, seed=42, n_trials=3):
    device = "cuda" if torch.cuda.is_available() else "cpu"
    print(f"Determinism test: N={n}, d={d}, seed={seed}, device={device}")

    ref_edges = None
    ref_h = None

    for trial in range(n_trials):
        set_seed(seed)
        X = torch.randn(n, d, device=device)

        graph = build_base_graph(X, GraphBuilderConfig(type="knn", k=16))
        h = propagate(X, graph["edge_index"], graph["edge_weight"], n,
                      PropagationConfig(type="random_walk", steps=5))

        ei = graph["edge_index"]
        ew = graph["edge_weight"]

        if ref_edges is None:
            ref_edges = (ei.clone(), ew.clone())
            ref_h = h.clone()
        else:
            # Check edge_index match
            ei_match = torch.equal(ei, ref_edges[0])
            ew_diff = (ew - ref_edges[1]).abs().max().item()
            h_diff = (h - ref_h).abs().max().item()

            print(f"  Trial {trial}: edges_match={ei_match}, weight_diff={ew_diff:.2e}, feat_diff={h_diff:.2e}")

            if not ei_match or ew_diff > 1e-6 or h_diff > 1e-5:
                print("  FAIL: non-deterministic results")
                return False

    print("=== DETERMINISM TEST PASSED ===")
    return True


if __name__ == "__main__":
    success = test_determinism()
    sys.exit(0 if success else 1)
