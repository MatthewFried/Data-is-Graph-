#!/usr/bin/env python3
"""Phase-2 Hierarchy Integrity Tests.

Tests:
  1. Every level-0 node has exactly one parent at level 1.
  2. Supernode membership sets do not overlap under greedy assignment.
  3. Ports are subset of members.
  4. Hierarchy produces valid predictions (no NaN, correct shape).
  5. Multilevel computation changes predictions vs flat propagation.
"""
import sys
import os

# Force single-thread to prevent deadlocks in repeated kNN calls
os.environ["OMP_NUM_THREADS"] = "1"
os.environ["MKL_NUM_THREADS"] = "1"
os.environ["OPENBLAS_NUM_THREADS"] = "1"
os.environ["NUMEXPR_NUM_THREADS"] = "1"

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "..", "src"))

import torch
from vghl.models.graph_builder import GraphBuilderConfig, build_base_graph
from vghl.models.propagation import PropagationConfig, propagate
from vghl.models.primitives import PrimitiveConfig, induce_primitives
from vghl.models.recursion import (
    RecursionConfig, build_multilevel_graph,
    contract_primitives, pool_to_supernodes, scatter_to_base,
)
from vghl.models.multilevel_compute import MultilevelComputeConfig, multilevel_propagate
from vghl.models.merge import MergeConfig
from vghl.models.geometric_machine import GeometricMachine
from vghl.models.anchor_graph import AnchorGraphConfig


def make_test_data(N=500, d=2, seed=42):
    """Create test dataset with two moons."""
    torch.manual_seed(seed)
    from sklearn.datasets import make_moons
    X, y = make_moons(n_samples=N, noise=0.1, random_state=seed)
    return torch.tensor(X, dtype=torch.float32), torch.tensor(y, dtype=torch.long)


def test_membership_coverage():
    """Every level-0 node maps to exactly one supernode."""
    X, y = make_test_data()
    N = X.shape[0]

    cfg = GraphBuilderConfig(type="knn", k=12)
    graph = build_base_graph(X, cfg)
    ei, ew = graph["edge_index"], graph["edge_weight"]

    prims = induce_primitives(ei, X, PrimitiveConfig(types=["triangle"], max_primitives_per_type=200))
    assert len(prims) > 0, "No primitives found"

    membership, port_indices, n_super = contract_primitives(prims, N, X, "boundary_top2", edge_index=ei)
    assert (membership >= 0).all(), "Some nodes have no parent"
    assert (membership < n_super).all(), "Membership out of range"
    assert membership.shape[0] == N, "Membership size mismatch"

    print(f"  PASS: all {N} nodes assigned to {n_super} supernodes")
    return True


def test_no_overlap():
    """Under greedy assignment, no node belongs to multiple primitives."""
    X, y = make_test_data()
    N = X.shape[0]

    cfg = GraphBuilderConfig(type="knn", k=12)
    graph = build_base_graph(X, cfg)
    ei = graph["edge_index"]

    prims = induce_primitives(ei, X, PrimitiveConfig(types=["triangle"], max_primitives_per_type=200))
    membership, _, n_super = contract_primitives(prims, N, X, "boundary_top2", edge_index=ei)

    # Each node should map to exactly one supernode
    for i in range(N):
        assert membership[i] >= 0, f"Node {i} unassigned"

    # Check uniqueness: membership is a function (each node → one supernode)
    # This is guaranteed by the (N,) tensor shape, but verify bincount
    counts = torch.bincount(membership, minlength=n_super)
    assert (counts >= 1).all(), "Some supernodes have no members"

    print(f"  PASS: greedy non-overlap verified, {n_super} supernodes")
    return True


def test_ports_subset_of_members():
    """Ports must be subset of their supernode's members."""
    X, y = make_test_data()
    N = X.shape[0]

    cfg = GraphBuilderConfig(type="knn", k=12)
    graph = build_base_graph(X, cfg)
    ei = graph["edge_index"]

    prims = induce_primitives(ei, X, PrimitiveConfig(types=["triangle"], max_primitives_per_type=200))
    membership, port_indices, n_super = contract_primitives(prims, N, X, "boundary_top2", edge_index=ei)

    for super_id in range(n_super):
        members = (membership == super_id).nonzero(as_tuple=True)[0].tolist()
        ports = port_indices[super_id][port_indices[super_id] >= 0].tolist()
        for p in ports:
            assert p in members, f"Port {p} not in members {members} of supernode {super_id}"

    print(f"  PASS: all ports are subsets of their supernode members")
    return True


def test_hierarchy_valid_predictions():
    """Phase-2 model produces valid predictions (no NaN, correct shape)."""
    X, y = make_test_data(N=300)
    N = X.shape[0]
    n_classes = 2

    model = GeometricMachine(
        input_dim=2,
        n_classes=n_classes,
        graph_cfg=GraphBuilderConfig(type="knn", k=12),
        prop_cfg=PropagationConfig(type="random_walk", steps=3),
        anchor_cfg=AnchorGraphConfig(mode="transductive_full_graph", anchor_k=8),
        primitive_cfg=PrimitiveConfig(
            types=["triangle"],
            max_primitives_per_type=100,
            use_in_propagation=True,
        ),
        recursion_cfg=RecursionConfig(enabled=True, depth=1,
                                       port_rule="boundary_top2",
                                       wiring_rule="shared_boundary"),
        multilevel_cfg=MultilevelComputeConfig(scheme="bottom_up_top_down", steps_per_level=2),
    )

    # Build graph (Phase 2 path)
    X_train = X[:200]
    X_test = X[200:]
    model.build_graph(X_train)

    # Check propagated anchors
    h = model.get_propagated_train_features()
    assert h is not None, "No propagated features"
    assert not torch.isnan(h).any(), "NaN in propagated features"
    assert h.shape == (200, 2), f"Wrong shape: {h.shape}"

    # Check query prediction
    out = model(X_test, is_query=True)
    logits = out["logits"]
    assert logits.shape == (100, n_classes), f"Wrong logit shape: {logits.shape}"
    assert not torch.isnan(logits).any(), "NaN in logits"

    print(f"  PASS: valid predictions, logits shape={logits.shape}")
    return True


def test_phase2_changes_predictions():
    """Phase-2 multilevel produces different predictions than Phase-1 flat."""
    X, y = make_test_data(N=300)

    # Phase 1 model
    model_p1 = GeometricMachine(
        input_dim=2, n_classes=2,
        graph_cfg=GraphBuilderConfig(type="knn", k=12),
        prop_cfg=PropagationConfig(type="random_walk", steps=3),
        anchor_cfg=AnchorGraphConfig(anchor_k=8),
    )
    model_p1.build_graph(X[:200])
    out_p1 = model_p1(X[200:], is_query=True)

    # Phase 2 model (same graph, but with hierarchy)
    model_p2 = GeometricMachine(
        input_dim=2, n_classes=2,
        graph_cfg=GraphBuilderConfig(type="knn", k=12),
        prop_cfg=PropagationConfig(type="random_walk", steps=3),
        anchor_cfg=AnchorGraphConfig(anchor_k=8),
        primitive_cfg=PrimitiveConfig(types=["triangle"], max_primitives_per_type=100,
                                       use_in_propagation=True),
        recursion_cfg=RecursionConfig(enabled=True, depth=1,
                                       wiring_rule="shared_boundary"),
        multilevel_cfg=MultilevelComputeConfig(steps_per_level=3),
    )
    model_p2.build_graph(X[:200])
    out_p2 = model_p2(X[200:], is_query=True)

    # Predictions should differ (different computation path)
    h1 = model_p1.get_propagated_train_features()
    h2 = model_p2.get_propagated_train_features()
    diff = (h1 - h2).abs().mean().item()

    # They won't be identical because multilevel adds hierarchical info
    print(f"  Feature diff (Phase1 vs Phase2): {diff:.6f}")
    assert model_p2._levels is not None, "Phase 2 should have levels"
    assert len(model_p2._levels) > 1, "Phase 2 should have >1 level"
    print(f"  PASS: Phase 2 built {len(model_p2._levels)} levels, features differ by {diff:.6f}")
    return True


if __name__ == "__main__":
    tests = [
        ("membership_coverage", test_membership_coverage),
        ("no_overlap", test_no_overlap),
        ("ports_subset", test_ports_subset_of_members),
        ("valid_predictions", test_hierarchy_valid_predictions),
        ("phase2_changes_predictions", test_phase2_changes_predictions),
    ]

    all_pass = True
    for name, fn in tests:
        print(f"\nTest: {name}")
        try:
            passed = fn()
            if not passed:
                all_pass = False
        except Exception as e:
            print(f"  FAIL: {e}")
            import traceback
            traceback.print_exc()
            all_pass = False

    print(f"\n{'='*60}")
    if all_pass:
        print("ALL PHASE-2 HIERARCHY TESTS PASSED")
    else:
        print("SOME TESTS FAILED")
        sys.exit(1)
