"""Test: edit loop acceptance score is non-decreasing over accepted edits.

This is the 'paper-grade invariant test' from the review checklist.
If the edit loop ever accepts an edit that decreases score, the test fails.
"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

import torch
import numpy as np
from vghl.models.edit_loop import (
    EditLoopConfig, score_machine, run_edit_loop,
)
from vghl.models.primitives import Primitive
from vghl.models.recursion import RecursionConfig, LevelGraph
from vghl.models.multilevel_compute import MultilevelComputeConfig
from vghl.models.propagation import PropagationConfig
from vghl.models.merge import MergeConfig


def test_edit_loop_monotone_score():
    """Score must be non-decreasing across accepted iterations."""
    np.random.seed(42)
    torch.manual_seed(42)

    N, d = 100, 8
    z = torch.randn(N, d)

    # Build a simple kNN graph
    from vghl.models.graph_builder import build_base_graph, GraphBuilderConfig
    gcfg = GraphBuilderConfig(type="knn", k=8)
    g = build_base_graph(z, gcfg)
    ei, ew = g["edge_index"], g["edge_weight"]

    # Create dummy primitives
    prims = [Primitive(center=z[i], radius=0.5, quality=0.5 + 0.5 * np.random.rand(),
                        node_indices=torch.tensor([i]))
             for i in range(min(N, 20))]

    rcfg = RecursionConfig(enabled=False)
    mcfg = MultilevelComputeConfig()
    pcfg = PropagationConfig(type="random_walk", steps=3)
    merge_cfg = MergeConfig(enabled=False)

    # eval_fn: deterministic ridge on random labels
    y_dummy = torch.randint(0, 3, (N,))

    def eval_fn(h, edge_index=None, edge_weight=None):
        from vghl.models.probe import ridge_eval
        # Split: first 70 train, rest val
        h_tr, h_val = h[:70], h[70:]
        y_tr, y_val = y_dummy[:70], y_dummy[70:]
        return ridge_eval(h_tr, y_tr, h_val, y_val, n_classes=3)

    ecfg = EditLoopConfig(
        enabled=True,
        max_iterations=5,
        try_edge_prune=True,
        try_primitive_prune=True,
        try_merge=False,
        min_improvement=0.0,  # accept ANY improvement (strict monotone)
        max_proposals=20,
    )

    _, _, _, _, log = run_edit_loop(
        z, ei, ew, prims,
        rcfg, mcfg, pcfg, merge_cfg, ecfg,
        eval_fn=eval_fn,
    )

    # Extract scores from iteration log
    scores = []
    for key in sorted(log.keys()):
        if key.startswith("iteration_") and isinstance(log[key], dict):
            scores.append(log[key]["score"])

    # Verify monotonicity
    print(f"Edit loop scores across iterations: {scores}")
    for i in range(1, len(scores)):
        assert scores[i] >= scores[i-1] - 1e-9, (
            f"Score decreased at iteration {i}: {scores[i-1]:.6f} -> {scores[i]:.6f}. "
            f"Edit loop accepted a negative-score edit!"
        )

    # Verify budget tracking
    assert "budget" in log
    budget = log["budget"]
    print(f"Budget: {budget['total_proposals']} proposals, "
          f"{budget['total_accepts']} accepts, "
          f"rate={budget['accept_rate']:.2f}")
    assert budget["total_accepts"] <= budget["total_proposals"]

    print("PASS: Edit loop score is non-decreasing over accepted edits")


if __name__ == "__main__":
    test_edit_loop_monotone_score()
