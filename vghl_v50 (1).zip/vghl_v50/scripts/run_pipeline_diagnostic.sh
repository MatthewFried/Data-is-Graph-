#!/bin/bash
# VGHL Pipeline Diagnostic: comprehensive bottleneck identification
# Tests PCA, readout heads, graph quality, test embedding, best combo
# across all 39 datasets × 2 seeds
set -e
export PYTHONUNBUFFERED=1
export OMP_NUM_THREADS=8
export MKL_NUM_THREADS=8
cd "$(dirname "$0")/.."
mkdir -p outputs/pipeline_diagnostic

echo "$(date) === PIPELINE DIAGNOSTIC START ==="

# 1. Graph quality (fast, no model training) — ~5 min
echo "$(date) === graph_quality ==="
python -u scripts/pipeline_diagnostic.py --only graph_quality --seeds 0,1

# 2. PCA pre-projection — ~20 min
echo "$(date) === pca ==="
python -u scripts/pipeline_diagnostic.py --only pca --seeds 0,1

# 3. Test embedding variants — ~15 min
echo "$(date) === test_embed ==="
python -u scripts/pipeline_diagnostic.py --only test_embed --seeds 0,1

# 4. Readout variants (MLP/SVM are slow) — ~45 min
echo "$(date) === readout ==="
python -u scripts/pipeline_diagnostic.py --only readout --seeds 0,1

# 5. Best combo (biggest sweep) — ~60 min
echo "$(date) === best_combo ==="
python -u scripts/pipeline_diagnostic.py --only best_combo --seeds 0,1

echo "$(date) === ALL DIAGNOSTICS COMPLETE ==="
echo "Results: outputs/pipeline_diagnostic/"
ls -la outputs/pipeline_diagnostic/
