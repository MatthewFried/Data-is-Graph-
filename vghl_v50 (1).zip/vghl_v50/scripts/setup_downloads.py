#!/usr/bin/env python3
"""Pre-download and validate every PyG dataset used by the v49 native-graph runs.

This is a fail-fast setup check: any missing dependency, failed download, malformed
split, or unusable GCN/GAT operator produces a non-zero exit status.
"""
import os
import sys

os.environ.setdefault("OMP_NUM_THREADS", "4")
ROOT = os.path.expanduser("~/.cache/vghl_pyg")


def _check_pyg_ops(torch):
    """Exercise the exact learned operators used later, not just imports."""
    from torch_geometric.nn import GATConv, GCNConv

    x = torch.randn(4, 3)
    ei = torch.tensor([[0, 1, 2, 3, 0, 2], [1, 0, 3, 2, 2, 0]], dtype=torch.long)
    with torch.no_grad():
        assert GCNConv(3, 2)(x, ei).shape == (4, 2)
        assert GATConv(3, 2, heads=2)(x, ei).shape == (4, 4)


def main():
    try:
        import torch
        import torch_geometric
        from torch_geometric.datasets import Actor, Amazon, Coauthor, Planetoid, WebKB
    except Exception as exc:
        print(
            "ERROR: the rebuttal runs require torch-geometric. Install the project "
            "with `python -m pip install -e \".[rebuttal]\"` (or install a PyG "
            "build compatible with your PyTorch version).",
            file=sys.stderr,
        )
        print(f"Import failure: {exc}", file=sys.stderr)
        return 2

    print(f"torch {torch.__version__} | torch_geometric {torch_geometric.__version__}")
    print(f"root: {ROOT}\n")

    failures = []
    try:
        _check_pyg_ops(torch)
        print("  OK torch_geometric GCNConv/GATConv smoke test")
    except Exception as exc:
        failures.append(("PyG operators", str(exc)))
        print(f"  FAIL PyG operators: {exc}")

    # 11 datasets: 3 Planetoid + 2 Amazon + 2 Coauthor + 3 WebKB + Actor.
    jobs = [
        ("Planetoid", Planetoid, ["Cora", "CiteSeer", "PubMed"]),
        ("Amazon", Amazon, ["Computers", "Photo"]),
        ("Coauthor", Coauthor, ["CS", "Physics"]),
        ("WebKB", WebKB, ["Texas", "Wisconsin", "Cornell"]),
        ("Actor", Actor, [None]),
    ]
    for label, cls, names in jobs:
        for name in names:
            nm = name or "Actor"
            try:
                ds = cls(ROOT, name) if name else cls(os.path.join(ROOT, "Actor"))
                d = ds[0]
                if d.x is None or d.y is None or d.edge_index is None:
                    raise RuntimeError("dataset lacks x, y, or edge_index")
                if d.edge_index.ndim != 2 or d.edge_index.shape[0] != 2:
                    raise RuntimeError(f"bad edge_index shape {tuple(d.edge_index.shape)}")
                if int(d.num_nodes) != int(d.x.shape[0]) or int(d.y.shape[0]) != int(d.num_nodes):
                    raise RuntimeError("x/y/node counts disagree")
                print(
                    f"  OK {label}/{nm:<10} N={d.num_nodes:<6} "
                    f"E={d.edge_index.shape[1]:<8} d={d.x.shape[1]:<6} "
                    f"classes={int(d.y.max()) + 1}"
                )
            except Exception as exc:
                failures.append((f"{label}/{nm}", str(exc)))
                print(f"  FAIL {label}/{nm}: {exc}")

    if failures:
        print("\nSetup failed; resolve every FAIL before launching experiments.", file=sys.stderr)
        for name, error in failures:
            print(f"  - {name}: {error}", file=sys.stderr)
        return 1

    print("\nAll 11 PyG datasets and the required GNN operators are ready.")
    print("Note: rebuttal_adult_diag.py uses sklearn/OpenML caches separately.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
