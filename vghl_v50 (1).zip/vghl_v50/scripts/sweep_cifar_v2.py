#!/usr/bin/env python3
"""CIFAR-10 ResNet-18: Comprehensive pipeline sweep.

The default pipeline (kNN graph → propagate → kNN-embed test → ridge)
gets 0.365 on CIFAR-10 vs 0.416 for raw features + ridge. The kNN
embedding step is lossy. This sweep tests every reasonable alternative.

Experiments:
  1. k × T grid (baseline reference)
  2. All propagation types: random_walk, ppr, heat, laplacian, gated, identity
  3. PPR alpha sweep (residual connection strength)
  4. Concat: [raw || propagated] features
  5. Raw test features: propagate train only, ridge predicts on raw test
  6. Label propagation: propagate one-hot labels, no ridge
  7. Cosine kNN: build graph from cosine similarity instead of L2
  8. PCA dim reduction before graph construction
  9. Ridge l2 sweep
 10. N scaling

Usage:
    python -u scripts/sweep_cifar_v2.py                    # all
    python -u scripts/sweep_cifar_v2.py --only prop_types  # just propagation types
"""
import os, sys, argparse, csv, time
import numpy as np
import torch
from pathlib import Path
from dataclasses import dataclass

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from vghl.data.loaders import build_datasets
from vghl.utils.config import ExperimentConfig
from vghl.models.graph_builder import build_base_graph, GraphBuilderConfig
from vghl.models.propagation import propagate, PropagationConfig
from vghl.models.probe import ridge_eval, embed_queries_via_knn, fit_ridge_classifier, predict_logits, accuracy
from vghl.models.knn_backend import knn, knn_to_edge_index


def _save_csv(rows, path):
    if not rows: return
    path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    keys = list(rows[0].keys())
    extra = sorted({k for r in rows for k in r.keys()} - set(keys))
    keys.extend(extra)
    tmp = str(path) + f".tmp.{os.getpid()}"
    with open(tmp, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=keys); w.writeheader()
        for r in rows: w.writerow({k: r.get(k, "") for k in keys})
        f.flush(); os.fsync(f.fileno())
    os.replace(tmp, str(path))
    print(f"  Saved: {path}")


def load_cifar(seed, n_train=40000, n_val=5000, n_test=10000):
    cfg = ExperimentConfig()
    cfg.data.dataset = "cifar10_resnet18"
    cfg.data.n_train = n_train
    cfg.data.n_val = n_val
    cfg.data.n_test = n_test
    cfg.seed = seed
    tr, va, te, meta = build_datasets(cfg)
    return tr.X, tr.y, va.X, va.y, te.X, te.y


def build_cosine_knn_graph(X, k):
    """Build kNN graph using cosine similarity instead of L2."""
    from sklearn.preprocessing import normalize
    X_np = X.detach().cpu().numpy().astype(np.float32)
    X_normed = normalize(X_np, norm='l2')
    X_normed_t = torch.tensor(X_normed, dtype=torch.float32)
    indices, distances = knn(X_normed_t, k)
    edge_index, edge_dist = knn_to_edge_index(indices, distances)
    # Convert L2 distance on unit sphere to cosine similarity weight
    # L2^2 = 2 - 2*cos(theta), so cos = 1 - L2^2/2
    cos_sim = 1.0 - (edge_dist ** 2) / 2.0
    edge_weight = cos_sim.clamp(min=0.0)
    return edge_index, edge_weight


def label_propagation(y_tr, edge_index, edge_weight, N, nc, T=5):
    """Pure label propagation: propagate one-hot labels, predict by argmax.
    Returns per-node predicted class (on train nodes)."""
    Y = torch.zeros(N, nc, dtype=torch.float32)
    Y.scatter_(1, y_tr.unsqueeze(1).long(), 1.0)
    pc = PropagationConfig(type="random_walk", steps=T)
    Y_prop = propagate(Y, edge_index, edge_weight, N, pc)
    return Y_prop.argmax(dim=1)


def label_propagation_inductive(X_tr, y_tr, X_te, edge_index, edge_weight, N, nc, k, T=5):
    """Inductive label propagation: propagate one-hot on train, kNN-embed for test."""
    Y = torch.zeros(N, nc, dtype=torch.float32)
    Y.scatter_(1, y_tr.unsqueeze(1).long(), 1.0)
    pc = PropagationConfig(type="random_walk", steps=T)
    Y_prop = propagate(Y, edge_index, edge_weight, N, pc)
    # Embed test via kNN of propagated label distributions
    Y_te = embed_queries_via_knn(Y_prop, X_tr, X_te, k=k)
    return (Y_te.argmax(dim=1) == torch.arange(nc).unsqueeze(0)).float(), Y_te.argmax(dim=1)


# ══════════════════════════════════════════════════════════════════════
# SWEEP 1: Propagation types × k × T
# ══════════════════════════════════════════════════════════════════════
def run_prop_types(seeds, out_dir, n_train=40000):
    print("\n" + "=" * 70)
    print(f"SWEEP: Propagation types (N={n_train})")
    print("=" * 70)
    rows = []

    k_values = [8, 16, 32, 64]
    T_values = [1, 2, 3, 5]

    configs = [
        ("random_walk", {}),
        ("ppr", {"alpha": 0.15}),
        ("ppr", {"alpha": 0.5}),
        ("ppr", {"alpha": 0.85}),
        ("heat", {"t": 0.5}),
        ("heat", {"t": 1.0}),
        ("heat", {"t": 2.0}),
        ("laplacian", {}),
        ("gated", {"gate_threshold": 0.3}),
        ("gated", {"gate_threshold": 0.5}),
        ("gated", {"gate_threshold": 0.7}),
        ("identity", {}),
    ]

    for seed in seeds:
        X_tr, y_tr, _, _, X_te, y_te = load_cifar(seed, n_train=n_train)
        N = len(X_tr)
        nc = max(int(y_tr.max()) + 1, int(y_te.max()) + 1)

        # No-graph baseline
        acc_ng = ridge_eval(X_tr, y_tr, X_te, y_te, n_classes=nc)
        rows.append({"seed": seed, "prop_type": "no_graph", "k": 0, "T": 0,
                      "params": "", "acc": acc_ng})
        print(f"  s{seed} no_graph: {acc_ng:.4f}")

        for k in k_values:
            k_eff = min(k, N - 1)
            gc = GraphBuilderConfig(type="knn", k=k_eff)
            g = build_base_graph(X_tr, gc)

            for prop_type, extra_params in configs:
                T_list = [0] if prop_type == "identity" else T_values
                for T in T_list:
                    pc = PropagationConfig(type=prop_type, steps=T, **extra_params)
                    try:
                        h = propagate(X_tr, g["edge_index"], g["edge_weight"], N, pc)
                        h_te = embed_queries_via_knn(h, X_tr, X_te, k=k_eff)
                        acc = ridge_eval(h, y_tr, h_te, y_te, n_classes=nc)
                    except Exception as e:
                        print(f"    ERROR {prop_type} k={k} T={T}: {e}")
                        acc = -1.0

                    param_str = ",".join(f"{pk}={pv}" for pk, pv in extra_params.items())
                    label = f"{prop_type}({param_str})" if param_str else prop_type
                    rows.append({
                        "seed": seed, "prop_type": label, "k": k, "T": T,
                        "params": param_str, "acc": acc,
                    })

                best_T_accs = [r["acc"] for r in rows
                               if r["seed"] == seed and r["k"] == k
                               and r["prop_type"].startswith(prop_type)
                               and r["acc"] > 0]
                if best_T_accs:
                    param_str = ",".join(f"{pk}={pv}" for pk, pv in extra_params.items())
                    label = f"{prop_type}({param_str})" if param_str else prop_type
            print(f"  s{seed} k={k}: done")

    _save_csv(rows, out_dir / "sweep_prop_types.csv")

    # Print best per prop type
    from collections import defaultdict
    by_type = defaultdict(list)
    for r in rows:
        if r["acc"] > 0:
            by_type[r["prop_type"]].append(r["acc"])
    print(f"\n{'Propagation':<30} {'mean':>7} {'max':>7}")
    print("-" * 46)
    for pt in sorted(by_type.keys(), key=lambda x: -max(by_type[x])):
        vals = by_type[pt]
        print(f"{pt:<30} {np.mean(vals):>7.4f} {np.max(vals):>7.4f}")

    return rows


# ══════════════════════════════════════════════════════════════════════
# SWEEP 2: Concat raw + propagated features
# ══════════════════════════════════════════════════════════════════════
def run_concat(seeds, out_dir, n_train=40000):
    print("\n" + "=" * 70)
    print(f"SWEEP: Concatenated [raw || propagated] features (N={n_train})")
    print("=" * 70)
    rows = []

    k_values = [8, 16, 32, 64]
    T_values = [1, 2, 3, 5]
    prop_configs = [
        ("random_walk", {}),
        ("ppr", {"alpha": 0.5}),
        ("ppr", {"alpha": 0.85}),
        ("laplacian", {}),
    ]

    for seed in seeds:
        X_tr, y_tr, _, _, X_te, y_te = load_cifar(seed, n_train=n_train)
        N = len(X_tr)
        nc = max(int(y_tr.max()) + 1, int(y_te.max()) + 1)

        acc_ng = ridge_eval(X_tr, y_tr, X_te, y_te, n_classes=nc)
        rows.append({"seed": seed, "mode": "raw_only", "k": 0, "T": 0,
                      "prop_type": "none", "acc": acc_ng, "dim": X_tr.shape[1]})

        for k in k_values:
            k_eff = min(k, N - 1)
            gc = GraphBuilderConfig(type="knn", k=k_eff)
            g = build_base_graph(X_tr, gc)

            for prop_type, extra in prop_configs:
                for T in T_values:
                    pc = PropagationConfig(type=prop_type, steps=T, **extra)
                    h = propagate(X_tr, g["edge_index"], g["edge_weight"], N, pc)
                    h_te = embed_queries_via_knn(h, X_tr, X_te, k=k_eff)

                    # Standard: propagated only
                    acc_prop = ridge_eval(h, y_tr, h_te, y_te, n_classes=nc)

                    # Concat: [raw || propagated] for train, [raw || knn_embed] for test
                    H_tr_cat = torch.cat([X_tr, h], dim=1)
                    H_te_cat = torch.cat([X_te, h_te], dim=1)
                    acc_cat = ridge_eval(H_tr_cat, y_tr, H_te_cat, y_te, n_classes=nc)

                    param_str = ",".join(f"{pk}={pv}" for pk, pv in extra.items())
                    label = f"{prop_type}({param_str})" if param_str else prop_type

                    rows.append({"seed": seed, "mode": "prop_only",
                                  "k": k, "T": T, "prop_type": label,
                                  "acc": acc_prop, "dim": h.shape[1]})
                    rows.append({"seed": seed, "mode": "concat",
                                  "k": k, "T": T, "prop_type": label,
                                  "acc": acc_cat, "dim": H_tr_cat.shape[1]})

            best_cat = max((r["acc"] for r in rows
                            if r["seed"] == seed and r["k"] == k and r["mode"] == "concat"), default=0)
            best_prop = max((r["acc"] for r in rows
                             if r["seed"] == seed and r["k"] == k and r["mode"] == "prop_only"), default=0)
            print(f"  s{seed} k={k}: concat={best_cat:.4f} prop={best_prop:.4f} ng={acc_ng:.4f}")

    _save_csv(rows, out_dir / "sweep_concat.csv")
    return rows


# ══════════════════════════════════════════════════════════════════════
# SWEEP 3: Raw test features (no kNN embedding for test)
# ══════════════════════════════════════════════════════════════════════
def run_raw_test(seeds, out_dir, n_train=40000):
    """Propagate train features, but use RAW test features for ridge.
    This avoids the lossy kNN embedding step for test data.
    Only works if propagated train and raw test live in same space (d_in == d_out)."""
    print("\n" + "=" * 70)
    print(f"SWEEP: Raw test features — skip kNN embed (N={n_train})")
    print("=" * 70)
    rows = []

    k_values = [8, 16, 32, 64]
    T_values = [1, 2, 3, 5]

    for seed in seeds:
        X_tr, y_tr, _, _, X_te, y_te = load_cifar(seed, n_train=n_train)
        N = len(X_tr)
        nc = max(int(y_tr.max()) + 1, int(y_te.max()) + 1)
        d = X_tr.shape[1]

        acc_ng = ridge_eval(X_tr, y_tr, X_te, y_te, n_classes=nc)
        rows.append({"seed": seed, "mode": "no_graph", "k": 0, "T": 0, "acc": acc_ng})

        for k in k_values:
            k_eff = min(k, N - 1)
            gc = GraphBuilderConfig(type="knn", k=k_eff)
            g = build_base_graph(X_tr, gc)

            for T in T_values:
                pc = PropagationConfig(type="random_walk", steps=T)
                h_tr = propagate(X_tr, g["edge_index"], g["edge_weight"], N, pc)

                # Mode A: standard (kNN embed test)
                h_te = embed_queries_via_knn(h_tr, X_tr, X_te, k=k_eff)
                acc_standard = ridge_eval(h_tr, y_tr, h_te, y_te, n_classes=nc)

                # Mode B: raw test — ridge fit on propagated train, predict on raw test
                # (dimensions match since propagation preserves dim)
                acc_raw_test = ridge_eval(h_tr, y_tr, X_te, y_te, n_classes=nc)

                # Mode C: concat train [raw||prop], raw test [raw||raw]
                H_tr_cat = torch.cat([X_tr, h_tr], dim=1)
                H_te_raw_cat = torch.cat([X_te, X_te], dim=1)
                acc_cat_raw = ridge_eval(H_tr_cat, y_tr, H_te_raw_cat, y_te, n_classes=nc)

                # Mode D: concat train [raw||prop], concat test [raw||knn_embed]
                H_te_cat = torch.cat([X_te, h_te], dim=1)
                acc_cat_embed = ridge_eval(H_tr_cat, y_tr, H_te_cat, y_te, n_classes=nc)

                for mode, acc in [("standard", acc_standard),
                                  ("raw_test", acc_raw_test),
                                  ("cat_raw_test", acc_cat_raw),
                                  ("cat_embed_test", acc_cat_embed)]:
                    rows.append({"seed": seed, "mode": mode,
                                  "k": k, "T": T, "acc": acc})

            bests = {}
            for r in rows:
                if r["seed"] == seed and r["k"] == k:
                    m = r["mode"]
                    bests[m] = max(bests.get(m, 0), r["acc"])
            print(f"  s{seed} k={k}: " + " ".join(f"{m}={v:.4f}" for m, v in sorted(bests.items())))

    _save_csv(rows, out_dir / "sweep_raw_test.csv")
    return rows


# ══════════════════════════════════════════════════════════════════════
# SWEEP 4: Label propagation (no ridge at all)
# ══════════════════════════════════════════════════════════════════════
def run_label_prop(seeds, out_dir, n_train=40000):
    print("\n" + "=" * 70)
    print(f"SWEEP: Label propagation — no ridge (N={n_train})")
    print("=" * 70)
    rows = []

    k_values = [4, 8, 16, 32, 64, 128]
    T_values = [1, 2, 3, 5, 10, 20]

    for seed in seeds:
        X_tr, y_tr, _, _, X_te, y_te = load_cifar(seed, n_train=n_train)
        N = len(X_tr)
        nc = max(int(y_tr.max()) + 1, int(y_te.max()) + 1)

        # kNN baseline (sklearn)
        from sklearn.neighbors import KNeighborsClassifier
        for k in k_values:
            k_eff = min(k, N - 1)
            knn_clf = KNeighborsClassifier(n_neighbors=k_eff, n_jobs=-1)
            knn_clf.fit(X_tr.numpy(), y_tr.numpy())
            acc_knn = float(knn_clf.score(X_te.numpy(), y_te.numpy()))
            rows.append({"seed": seed, "method": "knn", "k": k, "T": 0, "acc": acc_knn})
            if k == 16:
                print(f"  s{seed} kNN(k=16): {acc_knn:.4f}")

        for k in k_values:
            k_eff = min(k, N - 1)
            gc = GraphBuilderConfig(type="knn", k=k_eff)
            g = build_base_graph(X_tr, gc)

            for T in T_values:
                # Propagate one-hot labels on train graph
                Y = torch.zeros(N, nc, dtype=torch.float32)
                Y.scatter_(1, y_tr.unsqueeze(1).long(), 1.0)
                pc = PropagationConfig(type="random_walk", steps=T)
                Y_prop = propagate(Y, g["edge_index"], g["edge_weight"], N, pc)

                # Train accuracy (transductive on train)
                acc_train = (Y_prop.argmax(dim=1) == y_tr).float().mean().item()

                # Test: embed test via kNN into propagated label space
                Y_te_embed = embed_queries_via_knn(Y_prop, X_tr, X_te, k=k_eff)
                acc_test = (Y_te_embed.argmax(dim=1) == y_te).float().mean().item()

                rows.append({"seed": seed, "method": "label_prop",
                              "k": k, "T": T,
                              "acc": acc_test, "acc_train": acc_train})

            best = max(r["acc"] for r in rows
                       if r["seed"] == seed and r["k"] == k and r["method"] == "label_prop")
            print(f"  s{seed} LP k={k}: best_test={best:.4f}")

    _save_csv(rows, out_dir / "sweep_label_prop.csv")
    return rows


# ══════════════════════════════════════════════════════════════════════
# SWEEP 5: Cosine kNN graph
# ══════════════════════════════════════════════════════════════════════
def run_cosine_knn(seeds, out_dir, n_train=40000):
    print("\n" + "=" * 70)
    print(f"SWEEP: Cosine kNN graph (N={n_train})")
    print("=" * 70)
    rows = []

    k_values = [8, 16, 32, 64]
    T_values = [1, 2, 3, 5]

    for seed in seeds:
        X_tr, y_tr, _, _, X_te, y_te = load_cifar(seed, n_train=n_train)
        N = len(X_tr)
        nc = max(int(y_tr.max()) + 1, int(y_te.max()) + 1)

        for k in k_values:
            k_eff = min(k, N - 1)

            # L2 kNN (standard)
            gc = GraphBuilderConfig(type="knn", k=k_eff)
            g_l2 = build_base_graph(X_tr, gc)

            # Cosine kNN
            ei_cos, ew_cos = build_cosine_knn_graph(X_tr, k_eff)

            for T in T_values:
                pc = PropagationConfig(type="random_walk", steps=T)

                # L2
                h_l2 = propagate(X_tr, g_l2["edge_index"], g_l2["edge_weight"], N, pc)
                h_te_l2 = embed_queries_via_knn(h_l2, X_tr, X_te, k=k_eff)
                acc_l2 = ridge_eval(h_l2, y_tr, h_te_l2, y_te, n_classes=nc)

                # Cosine
                h_cos = propagate(X_tr, ei_cos, ew_cos, N, pc)
                h_te_cos = embed_queries_via_knn(h_cos, X_tr, X_te, k=k_eff)
                acc_cos = ridge_eval(h_cos, y_tr, h_te_cos, y_te, n_classes=nc)

                rows.append({"seed": seed, "metric": "L2", "k": k, "T": T, "acc": acc_l2})
                rows.append({"seed": seed, "metric": "cosine", "k": k, "T": T, "acc": acc_cos})

            best_l2 = max(r["acc"] for r in rows if r["seed"] == seed and r["k"] == k and r["metric"] == "L2")
            best_cos = max(r["acc"] for r in rows if r["seed"] == seed and r["k"] == k and r["metric"] == "cosine")
            print(f"  s{seed} k={k}: L2={best_l2:.4f} cos={best_cos:.4f}")

    _save_csv(rows, out_dir / "sweep_cosine.csv")
    return rows


# ══════════════════════════════════════════════════════════════════════
# SWEEP 6: PCA dim reduction
# ══════════════════════════════════════════════════════════════════════
def run_dim_reduction(seeds, out_dir, n_train=40000):
    print("\n" + "=" * 70)
    print(f"SWEEP: PCA dimensionality reduction (N={n_train})")
    print("=" * 70)
    from sklearn.decomposition import PCA
    from sklearn.preprocessing import StandardScaler
    rows = []

    dims = [16, 32, 64, 128, 256, 512]
    k_values = [8, 16, 32, 64]
    T_values = [1, 2, 3]

    for seed in seeds:
        X_tr, y_tr, _, _, X_te, y_te = load_cifar(seed, n_train=n_train)
        nc = max(int(y_tr.max()) + 1, int(y_te.max()) + 1)

        for d in dims:
            if d < 512:
                scaler = StandardScaler()
                X_tr_s = scaler.fit_transform(X_tr.numpy())
                X_te_s = scaler.transform(X_te.numpy())
                pca = PCA(n_components=d, random_state=seed)
                X_tr_d = torch.tensor(pca.fit_transform(X_tr_s), dtype=torch.float32)
                X_te_d = torch.tensor(pca.transform(X_te_s), dtype=torch.float32)
                var_exp = pca.explained_variance_ratio_.sum()
            else:
                X_tr_d, X_te_d = X_tr, X_te
                var_exp = 1.0

            N = len(X_tr_d)
            acc_ng = ridge_eval(X_tr_d, y_tr, X_te_d, y_te, n_classes=nc)
            rows.append({"seed": seed, "dim": d, "k": 0, "T": 0,
                          "acc": acc_ng, "mode": "no_graph", "var_explained": round(var_exp, 4)})

            for k in k_values:
                k_eff = min(k, N - 1)
                gc = GraphBuilderConfig(type="knn", k=k_eff)
                g = build_base_graph(X_tr_d, gc)

                for T in T_values:
                    pc = PropagationConfig(type="random_walk", steps=T)
                    h = propagate(X_tr_d, g["edge_index"], g["edge_weight"], N, pc)
                    h_te = embed_queries_via_knn(h, X_tr_d, X_te_d, k=k_eff)
                    acc = ridge_eval(h, y_tr, h_te, y_te, n_classes=nc)
                    rows.append({"seed": seed, "dim": d, "k": k, "T": T,
                                  "acc": acc, "mode": "vghl", "var_explained": round(var_exp, 4)})

            best_v = max((r["acc"] for r in rows
                          if r["seed"] == seed and r["dim"] == d and r["mode"] == "vghl"), default=0)
            print(f"  s{seed} d={d:>3}: ng={acc_ng:.4f} best_vghl={best_v:.4f} "
                  f"delta={best_v - acc_ng:+.4f} var={var_exp:.3f}")

    _save_csv(rows, out_dir / "sweep_dim.csv")
    return rows


# ══════════════════════════════════════════════════════════════════════
# SWEEP 7: Ridge l2
# ══════════════════════════════════════════════════════════════════════
def run_ridge_l2(seeds, out_dir, n_train=40000):
    print("\n" + "=" * 70)
    print(f"SWEEP: Ridge l2 regularization (N={n_train})")
    print("=" * 70)
    rows = []

    l2_values = [1e-4, 1e-3, 1e-2, 1e-1, 1.0, 10.0, 100.0]
    k_values = [16, 32]
    T_values = [1, 2, 5]

    for seed in seeds:
        X_tr, y_tr, _, _, X_te, y_te = load_cifar(seed, n_train=n_train)
        N = len(X_tr)
        nc = max(int(y_tr.max()) + 1, int(y_te.max()) + 1)

        for l2 in l2_values:
            acc_ng = ridge_eval(X_tr, y_tr, X_te, y_te, n_classes=nc, l2=l2)
            rows.append({"seed": seed, "l2": l2, "k": 0, "T": 0,
                          "acc": acc_ng, "mode": "no_graph"})

            for k in k_values:
                k_eff = min(k, N - 1)
                gc = GraphBuilderConfig(type="knn", k=k_eff)
                g = build_base_graph(X_tr, gc)
                for T in T_values:
                    pc = PropagationConfig(type="random_walk", steps=T)
                    h = propagate(X_tr, g["edge_index"], g["edge_weight"], N, pc)
                    h_te = embed_queries_via_knn(h, X_tr, X_te, k=k_eff)
                    acc = ridge_eval(h, y_tr, h_te, y_te, n_classes=nc, l2=l2)
                    rows.append({"seed": seed, "l2": l2, "k": k, "T": T,
                                  "acc": acc, "mode": "vghl"})

            best_v = max((r["acc"] for r in rows
                          if r["seed"] == seed and r["l2"] == l2 and r["mode"] == "vghl"), default=0)
            print(f"  s{seed} l2={l2:>8.4f}: ng={acc_ng:.4f} best_vghl={best_v:.4f}")

    _save_csv(rows, out_dir / "sweep_l2.csv")
    return rows


# ══════════════════════════════════════════════════════════════════════
# SWEEP 8: N scaling
# ══════════════════════════════════════════════════════════════════════
def run_n_scaling(seeds, out_dir):
    print("\n" + "=" * 70)
    print("SWEEP: N scaling")
    print("=" * 70)
    rows = []

    n_values = [500, 1000, 2000, 5000, 10000, 20000, 40000]
    k_values = [8, 16, 32]
    T_values = [1, 2, 3]

    for seed in seeds:
        for n_train in n_values:
            X_tr, y_tr, _, _, X_te, y_te = load_cifar(seed, n_train=n_train)
            N = len(X_tr)
            nc = max(int(y_tr.max()) + 1, int(y_te.max()) + 1)

            acc_ng = ridge_eval(X_tr, y_tr, X_te, y_te, n_classes=nc)
            rows.append({"seed": seed, "N": N, "k": 0, "T": 0,
                          "acc": acc_ng, "mode": "no_graph"})

            # kNN baseline
            from sklearn.neighbors import KNeighborsClassifier
            knn_clf = KNeighborsClassifier(n_neighbors=min(16, N - 1), n_jobs=-1)
            knn_clf.fit(X_tr.numpy(), y_tr.numpy())
            acc_knn = float(knn_clf.score(X_te.numpy(), y_te.numpy()))
            rows.append({"seed": seed, "N": N, "k": 16, "T": -1,
                          "acc": acc_knn, "mode": "knn"})

            for k in k_values:
                if k >= N: continue
                k_eff = min(k, N - 1)
                gc = GraphBuilderConfig(type="knn", k=k_eff)
                g = build_base_graph(X_tr, gc)
                for T in T_values:
                    pc = PropagationConfig(type="random_walk", steps=T)
                    h = propagate(X_tr, g["edge_index"], g["edge_weight"], N, pc)
                    h_te = embed_queries_via_knn(h, X_tr, X_te, k=k_eff)
                    acc = ridge_eval(h, y_tr, h_te, y_te, n_classes=nc)
                    rows.append({"seed": seed, "N": N, "k": k, "T": T,
                                  "acc": acc, "mode": "vghl"})

            best_v = max((r["acc"] for r in rows
                          if r["seed"] == seed and r["N"] == N and r["mode"] == "vghl"), default=0)
            print(f"  s{seed} N={N:>5}: ng={acc_ng:.4f} knn={acc_knn:.4f} "
                  f"best_vghl={best_v:.4f} Δ={best_v - acc_ng:+.4f}")

    _save_csv(rows, out_dir / "sweep_N.csv")
    return rows


# ══════════════════════════════════════════════════════════════════════
# MAIN
# ══════════════════════════════════════════════════════════════════════
def main():
    p = argparse.ArgumentParser()
    p.add_argument("--seeds", type=str, default="0,1")
    p.add_argument("--out", type=str, default="outputs/cifar_sweep_v2")
    p.add_argument("--only", type=str, default=None)
    p.add_argument("--n_train", type=int, default=40000)
    args = p.parse_args()
    seeds = [int(s) for s in args.seeds.split(",")]
    out = Path(args.out)
    only = (args.only or "all").lower()

    print("=" * 70)
    print(f"CIFAR-10 ResNet-18 COMPREHENSIVE SWEEP v2 (N={args.n_train}, seeds={seeds})")
    print("=" * 70)

    if only in ("all", "prop_types"):    run_prop_types(seeds, out, args.n_train)
    if only in ("all", "concat"):        run_concat(seeds, out, args.n_train)
    if only in ("all", "raw_test"):      run_raw_test(seeds, out, args.n_train)
    if only in ("all", "label_prop"):    run_label_prop(seeds, out, args.n_train)
    if only in ("all", "cosine_knn"):    run_cosine_knn(seeds, out, args.n_train)
    if only in ("all", "dim_reduction"): run_dim_reduction(seeds, out, args.n_train)
    if only in ("all", "ridge_l2"):      run_ridge_l2(seeds, out, args.n_train)
    if only in ("all", "n_scaling"):     run_n_scaling(seeds, out)

    print(f"\n{'='*70}")
    print("ALL SWEEPS DONE — check outputs/cifar_sweep_v2/")
    print(f"{'='*70}")


if __name__ == "__main__":
    main()
