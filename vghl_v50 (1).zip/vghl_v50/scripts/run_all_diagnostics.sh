#!/bin/bash
set -e
export PYTHONUNBUFFERED=1

# ══════════════════════════════════════════════════════════════
# VGHL Phase 2: Complete Diagnostic + Experiment Suite
# Run from vghl_v14/ directory
# ══════════════════════════════════════════════════════════════

DATASETS="sk_moons,breast_cancer,digits"
SEEDS="0,1,2"
SEEDS_FULL="0,1,2,3,4"
K=16

echo "══════════════════════════════════════════════════════════"
echo "  VGHL Phase 2 — Full Diagnostic Suite"
echo "  Datasets: $DATASETS"
echo "  Seeds:    $SEEDS (diagnostics) / $SEEDS_FULL (experiments)"
echo "══════════════════════════════════════════════════════════"

rm -rf outputs/

# ── Step 1: Baseline (does propagation help?) ──────────────
echo ""
echo "▶ Step 1: Raw vs Propagated baseline"
python scripts/diagnose_stability.py --only baseline \
  --datasets $DATASETS --seeds $SEEDS --k $K

# ── Step 2: Correlation (stability vs boundary) ───────────
echo ""
echo "▶ Step 2: Stability vs Boundary correlation"
python scripts/diagnose_stability.py --only corr \
  --datasets $DATASETS --seeds $SEEDS --k $K

# ── Step 3: Sigma sweep ───────────────────────────────────
echo ""
echo "▶ Step 3: Sigma sweep"
python scripts/diagnose_stability.py --only sigma \
  --datasets $DATASETS --seeds $SEEDS --k $K

# ── Step 4: Quadrant subsets (mechanism proof) ────────────
echo ""
echo "▶ Step 4: Quadrant subsets (stability × boundary)"
python scripts/diagnose_stability.py --only quadrant \
  --datasets $DATASETS --seeds $SEEDS --k $K

# ── Step 5: Prune comparison (what hurts to remove?) ─────
echo ""
echo "▶ Step 5: Boundary-prune vs interior-prune vs stability-prune"
python scripts/diagnose_stability.py --only prune \
  --datasets $DATASETS --seeds $SEEDS --k $K

# ── Step 6: Propagation ablation ─────────────────────────
echo ""
echo "▶ Step 6: Propagation step ablation"
python scripts/diagnose_stability.py --only prop \
  --datasets $DATASETS --seeds $SEEDS --k $K

# ── Step 7: Phase 2B — Stability subsets (full seeds) ────
echo ""
echo "▶ Step 7: Phase 2B — Stability subsets + trajectory"
python scripts/run_phase2_tests.py \
  --datasets $DATASETS --seeds $SEEDS_FULL --k_values $K

# ── Step 8: Phase 2C — Iterative refinement ──────────────
echo ""
echo "▶ Step 8: Phase 2C — Iterative refinement (with boundary retention)"
python scripts/refine_gm.py \
  --datasets $DATASETS --seeds $SEEDS_FULL --k_values $K \
  --refine_steps 12 --refine_frac 0.05

# ── Step 9: Phase 2D — Noise injection ───────────────────
echo ""
echo "▶ Step 9: Phase 2D — Noise injection (budget-controlled)"
python scripts/run_noise_injection_test.py \
  --datasets sk_moons,breast_cancer \
  --seeds $SEEDS_FULL --noise_fracs 0.05,0.1,0.2

# ── Step 10: Phase 2E — Transfer ─────────────────────────
echo ""
echo "▶ Step 10: Phase 2E — Transfer"
python scripts/transfer_gm.py \
  --pairs "sk_moons:sk_circles,breast_cancer:wine,digits:breast_cancer" \
  --seeds $SEEDS_FULL --k_base $K --k_attach 8

# ── Step 11: Phase 2F — Inductive control ────────────────
echo ""
echo "▶ Step 11: Phase 2F — Inductive control"
python scripts/inductive_control.py \
  --datasets sk_moons,breast_cancer \
  --seeds $SEEDS_FULL --k_values $K

# ══════════════════════════════════════════════════════════
# PHASE 3: Real-Data Experiments (Claims A, B, C)
# ══════════════════════════════════════════════════════════

echo ""
echo "═══════════════════════════════════════════════════════"
echo "  PHASE 3: Real-Data Experiments"
echo "═══════════════════════════════════════════════════════"

# ── Step 12: Claim A — Noise Identification ──────────────
echo ""
echo "▶ Step 12: Claim A — Noise identification on real data"
python -u scripts/run_real_experiments.py --only noise \
  --datasets breast_cancer,digits,mnist_embed,cifar10_pca \
  --seeds $SEEDS_FULL

# ── Step 13: Claim B — Geometric Universality ────────────
echo ""
echo "▶ Step 13: Claim B — Geometric universality"
python -u scripts/run_real_experiments.py --only geometry \
  --seeds $SEEDS_FULL

# ── Step 14: Claim C — Structural Signal ─────────────────
echo ""
echo "▶ Step 14: Claim C — Structural signal from propagation"
python -u scripts/run_real_experiments.py --only signal \
  --datasets breast_cancer,digits,mnist_embed,cifar10_pca \
  --seeds $SEEDS_FULL

echo ""
echo "══════════════════════════════════════════════════════════"
echo "  ALL DONE"
echo ""
echo "  Phase 2 Diagnostic outputs:"
echo "    outputs/diagnostics/raw_vs_propagated.csv"
echo "    outputs/diagnostics/correlation_table.csv"
echo "    outputs/diagnostics/sigma_sweep.csv"
echo "    outputs/diagnostics/quadrant_subsets.csv"
echo "    outputs/diagnostics/prune_comparison.csv"
echo "    outputs/diagnostics/prop_ablation.csv"
echo ""
echo "  Phase 2 Experiment outputs:"
echo "    outputs/phase2_tests/stability_subsets.csv"
echo "    outputs/phase2_tests/refinement_trajectory.csv"
echo "    outputs/refinement/refinement_curve.csv"
echo "    outputs/noise_injection/"
echo ""
echo "  Phase 3 Real-Data outputs (PAPER TABLES):"
echo "    outputs/real_experiments/claim_a_noise.csv"
echo "    outputs/real_experiments/claim_b_geometry.csv"
echo "    outputs/real_experiments/claim_c_signal.csv"
echo "══════════════════════════════════════════════════════════"
echo "    outputs/phase2_tests/stability_subsets.csv"
echo "    outputs/phase2_tests/refinement_trajectory.csv"
echo "    outputs/refinement/refinement_curve.csv"
echo "    outputs/noise_injection/"
echo "══════════════════════════════════════════════════════════"
