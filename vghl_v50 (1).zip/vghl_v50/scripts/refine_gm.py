#!/usr/bin/env python3
"""Optimization Convergence: Iterative structural refinement loop.

At each iteration:
  1. Build graph on current node set
  2. Propagate, train ridge readout, evaluate val accuracy
  3. Score nodes by stability (perturbation CV) or geometric heuristic
  4. Remove top frac% most unstable nodes
  5. Repeat

Control: identical loop but remove random nodes.

Demonstrates: structural edits improve the machine (analogous to gradient
descent in structure space). The expected result is accuracy rises then
falls — proving existence of an optimal computational geometry.

Usage:
    python scripts/refine_gm.py
    python scripts/refine_gm.py --datasets sk_moons,breast_cancer --seeds 0,1,2,3,4
    python scripts/refine_gm.py --refine_steps 15 --refine_frac 0.03
"""
import argparse
import sys
import os

os.environ["OMP_NUM_THREADS"] = os.environ.get("OMP_NUM_THREADS", "1")
os.environ["MKL_NUM_THREADS"] = os.environ.get("MKL_NUM_THREADS", "1")
os.environ["OPENBLAS_NUM_THREADS"] = os.environ.get("OPENBLAS_NUM_THREADS", "1")
os.environ["NUMEXPR_NUM_THREADS"] = os.environ.get("NUMEXPR_NUM_THREADS", "1")
os.environ["VECLIB_MAXIMUM_THREADS"] = os.environ.get("VECLIB_MAXIMUM_THREADS", "1")

import csv
import time
import statistics as stats_mod
import numpy as np
import torch
from pathlib import Path
from collections import defaultdict

torch.set_num_threads(1)

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from vghl.data.loaders import build_datasets
from vghl.utils.config import ExperimentConfig
from vghl.models.graph_builder import build_base_graph, GraphBuilderConfig
from vghl.models.propagation import propagate, PropagationConfig
from vghl.models.probe import ridge_eval, embed_queries_via_knn

DATASET_DEFAULTS = {
    # sklearn tabular
    "iris":              {"n_train": 0, "n_val": 0, "n_test": 0},
    "wine":              {"n_train": 0, "n_val": 0, "n_test": 0},
    "breast_cancer":     {"n_train": 0, "n_val": 0, "n_test": 0},
    "digits":            {"n_train": 0, "n_val": 0, "n_test": 0},
    "diabetes":          {"n_train": 0, "n_val": 0, "n_test": 0},
    "california_housing":{"n_train": 5000, "n_val": 1000, "n_test": 1000},
    # OpenML tabular
    "segment":           {"n_train": 0, "n_val": 0, "n_test": 0},
    "waveform":          {"n_train": 3000, "n_val": 500, "n_test": 500},
    "satellite":         {"n_train": 3000, "n_val": 500, "n_test": 500},
    "pendigits":         {"n_train": 5000, "n_val": 1000, "n_test": 1000},
    "optdigits":         {"n_train": 3000, "n_val": 500, "n_test": 500},
    "letter":            {"n_train": 5000, "n_val": 1000, "n_test": 1000},
    "covertype":         {"n_train": 5000, "n_val": 1000, "n_test": 1000},
    "adult":             {"n_train": 5000, "n_val": 1000, "n_test": 1000},
    # Embeddings
    "mnist_embed":       {"n_train": 5000, "n_val": 1000, "n_test": 1000},
    "fmnist_embed":      {"n_train": 5000, "n_val": 1000, "n_test": 1000},
    "cifar10_pca":       {"n_train": 5000, "n_val": 1000, "n_test": 1000},
    "newsgroups_embed":  {"n_train": 3000, "n_val": 500, "n_test": 500},
    "cifar10_resnet18":  {"n_train": 5000, "n_val": 1000, "n_test": 1000},
    "cora":              {"n_train": 0, "n_val": 0, "n_test": 0},
}


def load_dataset(name, seed, n_train=0, n_val=0, n_test=0):
    """Load dataset splits."""
    cfg = ExperimentConfig()
    cfg.data.dataset = name
    cfg.data.n_train = n_train
    cfg.data.n_val = n_val
    cfg.data.n_test = n_test
    cfg.seed = seed
    train_ds, val_ds, test_ds, meta = build_datasets(cfg)
    return train_ds.X, train_ds.y, val_ds.X, val_ds.y, test_ds.X, test_ds.y, meta


def compute_adaptive_sigma(X, graph_cfg):
    """Compute perturbation sigma scaled to dataset geometry."""
    graph = build_base_graph(X, graph_cfg)
    ei = graph["edge_index"]
    edge_dists = (X[ei[0]] - X[ei[1]]).norm(dim=1)
    return max(0.05 * edge_dists.median().item(), 1e-6)


def compute_node_instability(X, graph_cfg, n_trials=5, sigma=None, seed=0):
    """Compute per-node instability via neighbor-set Jaccard.

    If sigma is None, auto-scales to 5% of median edge distance.
    Returns instability = 1 - Jaccard (higher = more unstable = remove first).
    """
    from vghl.models.pruning import _build_neighbor_sets, _pairwise_jaccard
    rng = np.random.RandomState(seed)
    N = X.shape[0]
    d = X.shape[1]
    device = X.device

    if sigma is None:
        sigma = compute_adaptive_sigma(X, graph_cfg)

    boot_sets = []
    for t in range(n_trials):
        noise = torch.tensor(
            rng.randn(N, d).astype(np.float32) * sigma,
            device=device, dtype=X.dtype,
        )
        X_pert = X + noise
        graph = build_base_graph(X_pert, graph_cfg)
        ei = graph["edge_index"]
        boot_sets.append(_build_neighbor_sets(ei, N, device))

    jaccard = _pairwise_jaccard(boot_sets, N, device)
    return 1.0 - jaccard  # higher = more unstable


def evaluate_node_set(X_train, y_train, X_val, y_val,
                      node_mask, graph_cfg, prop_cfg):
    """Build graph on masked subset, propagate, ridge eval on val.

    Val points are embedded via kNN aggregation of propagated train
    embeddings (correct inductive protocol — no feature space mismatch).
    """
    X_sub = X_train[node_mask]
    y_sub = y_train[node_mask]
    N_sub = X_sub.shape[0]

    if N_sub < 5:
        return {"val_accuracy": 0.0, "n_nodes": N_sub, "n_edges": 0}

    n_classes = max(int(y_train.max()) + 1, int(y_sub.max()) + 1)
    graph = build_base_graph(X_sub, graph_cfg)
    ei = graph["edge_index"]
    ew = graph["edge_weight"]
    h = propagate(X_sub, ei, ew, N_sub, prop_cfg)

    # Embed val via kNN to propagated train embeddings
    k_embed = min(graph_cfg.k, N_sub)
    h_val = embed_queries_via_knn(h, X_sub, X_val, k=k_embed)

    acc = ridge_eval(h, y_sub, h_val, y_val, n_classes=n_classes)

    return {
        "val_accuracy": acc,
        "n_nodes": N_sub,
        "n_edges": ei.shape[1],
    }


def run_refinement(X_tr, y_tr, X_val, y_val, graph_cfg, prop_cfg,
                   refine_steps, refine_frac, mode, seed,
                   lambda_bnd=0.1):
    """Iterative refinement with accept/reject optimization protocol.

    Objective: J = val_accuracy - lambda * max(0, 0.5 - boundary_retention)
    Proposed edits accepted iff J_new >= J_old - tolerance.
    If mode contains 'sweep', runs unconditional pruning (no accept/reject).

    Args:
        mode: 'stability', 'random', 'stability_sweep', 'random_sweep'
        lambda_bnd: penalty weight for losing boundary nodes
    """
    N = X_tr.shape[0]
    rng = np.random.RandomState(seed)
    tolerance = 0.0  # strict: only accept if J_new >= J_old

    from vghl.models.knn_backend import KNNIndex
    k_bnd = max(graph_cfg.k * 8, 128)
    k_bnd = min(k_bnd, N - 1)
    X_cpu = X_tr.detach().cpu()
    y_cpu = y_tr.detach().cpu()
    bnd_index = KNNIndex(X_cpu)
    bnd_ind, _ = bnd_index.query(X_cpu, k_bnd + 1)
    bnd_ind = bnd_ind[:, 1:]
    neighbor_labels = y_cpu[torch.tensor(bnd_ind, dtype=torch.long)]
    boundary_score = (neighbor_labels != y_cpu.unsqueeze(1)).float().mean(dim=1)

    n_bnd_top = max(int(N * 0.2), 5)
    bnd_top_set = set(torch.argsort(boundary_score, descending=True)[:n_bnd_top].tolist())

    use_ar = "sweep" not in mode
    base_mode = mode.replace("_sweep", "")

    def _metrics(active_mask):
        n_a = int(active_mask.sum())
        if n_a < 5:
            return {
                "n_nodes": n_a, "n_edges": 0,
                "val_accuracy": 0.0,
                "fraction_remaining": n_a / N,
                "boundary_retention": 0.0,
                "mean_boundary_active": 0.0,
                "mean_val_anchor_dist": float('inf'),
                "p90_val_anchor_dist": float('inf'),
            }
        res = evaluate_node_set(X_tr, y_tr, X_val, y_val,
                                active_mask, graph_cfg, prop_cfg)
        a_set = set(active_mask.nonzero(as_tuple=True)[0].tolist())
        bnd_ret = len(bnd_top_set & a_set) / n_bnd_top
        X_a = X_tr[active_mask]
        ci = KNNIndex(X_a.detach().cpu())
        _, cd = ci.query(X_val.detach().cpu(), 1)
        return {
            "n_nodes": res["n_nodes"], "n_edges": res["n_edges"],
            "val_accuracy": res["val_accuracy"],
            "fraction_remaining": n_a / N,
            "boundary_retention": bnd_ret,
            "mean_boundary_active": boundary_score[active_mask].mean().item(),
            "mean_val_anchor_dist": float(cd.mean()),
            "p90_val_anchor_dist": float(np.percentile(cd, 90)),
        }

    def _J(m):
        return m["val_accuracy"] - lambda_bnd * max(0.0, 0.5 - m["boundary_retention"])

    active = torch.ones(N, dtype=torch.bool)
    records = []
    n_rejected = 0
    consec_rej = 0
    cur_frac = refine_frac
    prev_accepted = True  # step 0 is always "accepted" (initial state)

    for step in range(refine_steps + 1):
        n_active = int(active.sum())
        if n_active < 10:
            break

        m = _metrics(active)
        J = _J(m)
        records.append({
            "step": step, "mode": mode, **m,
            "objective_J": J, "accepted": prev_accepted,
            "n_rejected_total": n_rejected,
        })

        if step == refine_steps:
            break

        n_remove = max(int(n_active * cur_frac), 1)
        n_remove = min(n_remove, n_active - 10)
        if n_remove <= 0:
            break

        active_backup = active.clone()

        if base_mode == "stability":
            X_a = X_tr[active]
            instab = compute_node_instability(
                X_a, graph_cfg, n_trials=5, sigma=None,
                seed=seed + step * 100)
            k_top = min(n_remove, instab.shape[0])
            _, rm_local = torch.topk(instab, k_top)
        elif base_mode == "random":
            perm = torch.tensor(rng.permutation(n_active))
            rm_local = perm[:n_remove]
        else:
            raise ValueError(f"Unknown base mode: {base_mode}")

        ag = active.nonzero(as_tuple=True)[0]
        active[ag[rm_local]] = False

        if use_ar:
            m_new = _metrics(active)
            J_new = _J(m_new)
            if J_new >= J - tolerance:
                consec_rej = 0
                prev_accepted = True
            else:
                active = active_backup
                n_rejected += 1
                consec_rej += 1
                prev_accepted = False
                if consec_rej >= 3:
                    if cur_frac > 0.01:
                        cur_frac *= 0.5
                        consec_rej = 0
                    else:
                        break
        else:
            prev_accepted = True  # sweep mode: always accept

    return records


def main():
    p = argparse.ArgumentParser(description="Iterative refinement convergence")
    p.add_argument("--datasets", type=str, default="sk_moons,breast_cancer,digits")
    p.add_argument("--seeds", type=str, default="0,1,2,3,4")
    p.add_argument("--k_values", type=str, default="16")
    p.add_argument("--refine_steps", type=int, default=12,
                   help="Number of refinement iterations")
    p.add_argument("--refine_frac", type=float, default=0.05,
                   help="Fraction of nodes to remove per step")
    p.add_argument("--operator", type=str, default="random_walk")
    p.add_argument("--prop_steps", type=int, default=5)
    p.add_argument("--out", type=str, default="outputs/refinement")
    p.add_argument("--plot_only", action="store_true")

    args = p.parse_args()
    datasets = [d.strip() for d in args.datasets.split(",")]
    seeds = [int(s) for s in args.seeds.split(",")]
    k_values = [int(k) for k in args.k_values.split(",")]
    out_dir = Path(args.out)
    out_dir.mkdir(parents=True, exist_ok=True)

    print("=" * 70)
    print("ITERATIVE REFINEMENT CONVERGENCE")
    print(f"  Datasets:      {datasets}")
    print(f"  Seeds:         {seeds}")
    print(f"  k values:      {k_values}")
    print(f"  Refine steps:  {args.refine_steps}")
    print(f"  Refine frac:   {args.refine_frac}")
    print("=" * 70)

    if args.plot_only:
        all_rows = _load_csv(out_dir / "refinement_curve.csv")
    else:
        all_rows = []

        for dataset in datasets:
            dd = DATASET_DEFAULTS.get(dataset, {})
            n_train = dd.get("n_train", 0)
            n_val = dd.get("n_val", 0)
            n_test = dd.get("n_test", 0)

            for k in k_values:
                graph_cfg = GraphBuilderConfig(type="knn", k=k)
                prop_cfg = PropagationConfig(type=args.operator,
                                             steps=args.prop_steps)

                for seed in seeds:
                    for mode in ["stability", "random",
                                 "stability_sweep", "random_sweep"]:
                        tag = f"{dataset}_k{k}_{mode}_s{seed}"
                        print(f"\n[{tag}]", flush=True)

                        X_tr, y_tr, X_val, y_val, _, _, meta = load_dataset(
                            dataset, seed, n_train, n_val, n_test
                        )

                        t0 = time.time()
                        records = run_refinement(
                            X_tr, y_tr, X_val, y_val,
                            graph_cfg, prop_cfg,
                            args.refine_steps, args.refine_frac,
                            mode, seed,
                        )
                        elapsed = time.time() - t0

                        for rec in records:
                            rec["dataset"] = dataset
                            rec["k"] = k
                            rec["seed"] = seed
                            all_rows.append(rec)

                        # Print trajectory
                        for rec in records:
                            ar_flag = "✓" if rec.get("accepted", True) else "✗"
                            print(f"  step={rec['step']:2d} "
                                  f"nodes={rec['n_nodes']:5d} "
                                  f"acc={rec['val_accuracy']:.4f} "
                                  f"J={rec.get('objective_J',0):.4f} "
                                  f"bnd={rec.get('boundary_retention',0):.2f} "
                                  f"rej={rec.get('n_rejected_total',0)} {ar_flag}")
                        print(f"  [{elapsed:.1f}s]")

        # Save raw results (atomic write)
        if all_rows:
            csv_path = out_dir / "refinement_curve.csv"
            tmp = str(csv_path) + f".tmp.{os.getpid()}"
            with open(tmp, "w", newline="") as f:
                w = csv.DictWriter(f, fieldnames=all_rows[0].keys())
                w.writeheader()
                w.writerows(all_rows)
                f.flush(); os.fsync(f.fileno())
            os.replace(tmp, str(csv_path))
            print(f"\nResults: {csv_path}")

    # Analysis
    _print_summary(all_rows, out_dir)
    _generate_figure(all_rows, out_dir)


def _load_csv(path):
    """Load CSV rows with type coercion."""
    if not path.exists():
        return []
    with open(path) as f:
        rows = []
        for r in csv.DictReader(f):
            for k in ["step", "n_nodes", "n_edges", "k", "seed"]:
                if r.get(k):
                    try:
                        r[k] = int(r[k])
                    except ValueError:
                        pass
            for k in ["val_accuracy", "fraction_remaining"]:
                if r.get(k):
                    try:
                        r[k] = float(r[k])
                    except ValueError:
                        pass
            rows.append(r)
        return rows


def _print_summary(rows, out_dir):
    """Print summary: best step per dataset/mode."""
    if not rows:
        return

    print("\n" + "=" * 70)
    print("REFINEMENT SUMMARY")
    print("=" * 70)

    groups = defaultdict(lambda: defaultdict(list))
    for r in rows:
        key = (r["dataset"], r["k"], r["mode"], r["step"])
        groups[key]["acc"].append(float(r["val_accuracy"]))
        groups[key]["nodes"].append(int(r["n_nodes"]))

    # Find best step per dataset/mode
    dk_keys = sorted(set((r["dataset"], r["k"]) for r in rows))
    for ds, k in dk_keys:
        print(f"\n{ds} (k={k}):")
        for mode in ["stability", "random"]:
            best_acc = -1
            best_step = 0
            for step in range(100):
                key = (ds, k, mode, step)
                if key not in groups:
                    break
                mean_acc = stats_mod.mean(groups[key]["acc"])
                if mean_acc > best_acc:
                    best_acc = mean_acc
                    best_step = step
            key0 = (ds, k, mode, 0)
            if key0 in groups:
                start_acc = stats_mod.mean(groups[key0]["acc"])
                print(f"  {mode:12s}: start={start_acc:.4f} "
                      f"best={best_acc:.4f} (step {best_step}) "
                      f"Δ={best_acc - start_acc:+.4f}")


def _generate_figure(rows, out_dir):
    """Generate refinement trajectory figure."""
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except ImportError:
        print("matplotlib not installed, skipping figure")
        return

    out_dir = Path(out_dir)
    datasets = sorted(set(r["dataset"] for r in rows))
    k_use = max(set(int(r["k"]) for r in rows))
    n_ds = len(datasets)

    COLORS = {"stability": "#2563eb", "random": "#6b7280"}
    LABELS = {"stability": "Stability-guided", "random": "Random removal"}
    MARKERS = {"stability": "o", "random": "s"}

    fig, axes = plt.subplots(1, n_ds, figsize=(4.5 * n_ds, 3.5), squeeze=False)

    for i, ds in enumerate(datasets):
        ax = axes[0, i]
        for mode in ["stability", "random"]:
            # Group by step, compute mean±std
            step_data = defaultdict(list)
            frac_data = defaultdict(list)
            for r in rows:
                if r["dataset"] == ds and int(r["k"]) == k_use and r["mode"] == mode:
                    step_data[int(r["step"])].append(float(r["val_accuracy"]))
                    frac_data[int(r["step"])].append(float(r["fraction_remaining"]))

            steps = sorted(step_data.keys())
            means = [stats_mod.mean(step_data[s]) for s in steps]
            stds = [stats_mod.stdev(step_data[s]) if len(step_data[s]) > 1 else 0
                    for s in steps]
            fracs = [stats_mod.mean(frac_data[s]) for s in steps]

            ax.errorbar(fracs, means, yerr=stds,
                        label=LABELS[mode], color=COLORS[mode],
                        marker=MARKERS[mode], markersize=5,
                        linewidth=1.8, capsize=3, capthick=1.2)

        ds_label = ds.replace("_", " ").replace("sk ", "").title()
        if ds == "breast_cancer":
            ds_label = "Breast Cancer"
        ax.set_title(f"{ds_label} ($k$={k_use})", fontsize=13, fontweight="bold")
        ax.set_xlabel("Fraction remaining", fontsize=11)
        if i == 0:
            ax.set_ylabel("Val accuracy (ridge)", fontsize=11)
        ax.invert_xaxis()
        ax.grid(True, alpha=0.2)
        ax.tick_params(labelsize=10)

    handles, labels = axes[0, 0].get_legend_handles_labels()
    fig.legend(handles, labels, loc="upper center", ncol=2, fontsize=10,
               frameon=True, bbox_to_anchor=(0.5, 1.02))
    plt.tight_layout(rect=[0, 0, 1, 0.92])

    for ext in ["pdf", "png"]:
        fig.savefig(out_dir / f"refinement_curve.{ext}", dpi=300, bbox_inches="tight")
    print(f"Refinement figure: {out_dir / 'refinement_curve.pdf'}")
    plt.close(fig)


if __name__ == "__main__":
    main()
