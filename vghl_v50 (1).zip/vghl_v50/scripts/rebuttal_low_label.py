#!/usr/bin/env python3
"""Rebuttal Experiment A: low-label (semi-supervised) regime.

Purpose (AC priority 1): separate "geometry is where task-aligned signal is
accessible" from "the graph is a redundant re-encoding of X that strong raw
models already exploit."

In the full-label regime W = phi(X_train) is a deterministic function of the
same X the raw baseline sees, so no configuration can exceed a strong raw
model (data-processing). In the low-label regime the graph is built over ALL
training points (labeled + unlabeled) while raw-feature baselines see only
the labeled X. The graph is then NOT a re-encoding of the baseline's input.

Prediction (a priori, per dataset, from purity diagnostic):
  - high-purity datasets: full pipeline >> best raw-feature model at small L,
    and the advantage collapses under random-edge destruction (I1).
  - low-purity / low kNN-ridge-gap datasets (adult, covertype): no advantage.

Conditions per (dataset, seed, L labels/class):
  raw_ridge / raw_logreg / raw_rf / raw_knn : trained on labeled raw X only
  pipe_full     : kNN graph over ALL train X, P^tau X, ridge on labeled rows
  pipe_rand     : same but I1 random edges (independent src+dst, no self loops)
  noprop_attach : ridge on labeled raw rows, queries kNN-embedded over all X
                  (graph used only at attach time; the paper's No-Prop analog)
  noprop_raw    : ridge on labeled raw rows, tested on raw X_te directly
                  (no graph anywhere; clean no-graph condition -- the v44
                  noprop had a train-raw/test-attached representation
                  mismatch, both variants are now reported)
  lp_real       : label propagation (Zhu-Ghahramani, clamped) over the SAME
                  substrate W -- the classic low-label readout route of the
                  same geometry; test via identical raw-X kNN attach
  lp_rand       : label propagation over I1 random edges (collapse control)

Both ridge-on-P^tau-X and label diffusion are readouts of the same W; under
the chain, either route should exceed raw models where purity is high, and
label diffusion is the route adapted to the low-label regime. Label
propagation (lp_real vs best_raw, smallest L) is the PRIMARY preregistered
comparison; the feature route is secondary.

v45 protocol upgrades:
  - Labeled subsets are NESTED: one per-class permutation is drawn per
    (dataset, seed); L takes the first L indices per class, so the L=5 set
    is a subset of L=10 which is a subset of L=20.
  - The headline stratification is PREREGISTERED on the labeled-only
    diagnostic purity_excess > 0.10 (excess of labeled-subset kNN purity
    over the class-prior baseline sum p_c^2), a rule fixed before the full
    confirmatory run based on the pilot separation digits +0.38 vs adult
    -0.02. The oracle purity column remains in the CSV for analysis only.
  - Label propagation runs to convergence (max |dY| < 1e-6, cap 200 iters).
  - best_raw is an ORACLE ENVELOPE (per-seed max over four models selected
    with test knowledge); it is conservative AGAINST our claim. Individual
    baselines are all reported.

Usage:
  python -u scripts/rebuttal_low_label.py
  python -u scripts/rebuttal_low_label.py --datasets digits,optdigits --seeds 0,1,2
  python -u scripts/rebuttal_low_label.py --labels 5,10,20
"""
import os, sys
os.environ.setdefault("OMP_NUM_THREADS", "1")
os.environ.setdefault("MKL_NUM_THREADS", "1")
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")

import argparse
import numpy as np
import torch
from pathlib import Path
from collections import defaultdict

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))
sys.path.insert(0, os.path.dirname(__file__))

from run_real_experiments import (  # noqa: E402
    DATASETS, load_dataset, get_k, _save_csv,
)
from vghl.models.graph_builder import build_base_graph, GraphBuilderConfig  # noqa: E402
from vghl.models.propagation import propagate, PropagationConfig  # noqa: E402
from vghl.models.probe import ridge_eval, embed_queries_via_knn  # noqa: E402
from vghl.models.knn_backend import KNNIndex  # noqa: E402

DEFAULT_DATASETS = [
    # high purity (predicted win)
    "digits", "optdigits", "pendigits", "satellite", "segment", "letter",
    "mnist_embed", "fmnist_embed",
    # scope controls (predicted no win: kNN-ridge gap <= 0 or near-linear)
    "adult", "covertype",
]


def make_nested_selector(y: torch.Tensor, seed: int):
    """One per-class permutation per (dataset, seed); L takes the first L
    per class, so labeled sets are NESTED across label budgets."""
    rng = np.random.RandomState(seed * 1009)
    perms = {}
    for c in torch.unique(y).tolist():
        pool = torch.nonzero(y == c, as_tuple=False).flatten().numpy()
        perms[c] = rng.permutation(pool)

    def select(per_class: int) -> torch.Tensor:
        idx = []
        for c, perm in perms.items():
            idx.extend(perm[:min(per_class, len(perm))].tolist())
        mask = torch.zeros(len(y), dtype=torch.bool)
        mask[torch.tensor(sorted(idx), dtype=torch.long)] = True
        return mask

    return select


def select_labeled(y: torch.Tensor, per_class: int, seed: int) -> torch.Tensor:
    """Back-compat wrapper (nested)."""
    return make_nested_selector(y, seed)(per_class)


def make_random_edges(N: int, E: int, seed: int):
    """Protocol I1 (exactly as run_ablation): independent random src and dst,
    self-loops removed, uniform weights."""
    rng = np.random.RandomState(seed + 555)
    src = torch.tensor(rng.randint(0, N, E), dtype=torch.long)
    dst = torch.tensor(rng.randint(0, N, E), dtype=torch.long)
    valid = src != dst
    ei = torch.stack([src[valid], dst[valid]])
    ew = torch.ones(ei.shape[1])
    return ei, ew


def label_prop(y, lm, ei, ew, N, nc, max_iters=200, tol=1e-6):
    """Zhu-Ghahramani label propagation: Y <- D^-1 (A+I) Y, labeled rows
    clamped; iterated to convergence (max |dY| < tol) with an iteration cap.
    Note this aggregation (each node averages its out-neighbors) IS the
    documented row-normalized operator; it was correct in v44 as well."""
    from vghl.models.propagation import add_self_loops_sparse
    ei2, ew2 = add_self_loops_sparse(ei, ew, N)
    src, dst = ei2[0], ei2[1]
    deg = torch.zeros(N).scatter_add_(0, src, ew2).clamp(min=1e-12)
    Y0 = torch.zeros(N, nc)
    Y0[lm] = torch.nn.functional.one_hot(y[lm], nc).float()
    Y = Y0.clone()
    for _ in range(max_iters):
        msg = Y[dst] * ew2.unsqueeze(1)
        Y_new = torch.zeros(N, nc).index_add_(0, src, msg) / deg.unsqueeze(1)
        Y_new[lm] = Y0[lm]
        delta = (Y_new - Y).abs().max().item()
        Y = Y_new
        if delta < tol:
            break
    return Y


def knn_purity(X: torch.Tensor, y: torch.Tensor, k: int) -> float:
    """Dataset-level diagnostic: fraction of kNN neighbors sharing the query
    label. Uses ALL train labels -- an oracle dataset property used only for
    analysis stratification, never by any method. See purity_labeled for the
    version computable from the labeled subset alone."""
    index = KNNIndex(X.detach().cpu())
    ind, _ = index.query(X.detach().cpu(), min(k, len(X) - 1) + 1)
    ind = torch.tensor(ind[:, 1:], dtype=torch.long)
    return (y[ind] == y.unsqueeze(1)).float().mean().item()


def knn_purity_labeled(X: torch.Tensor, y: torch.Tensor,
                       lm: torch.Tensor, k: int = 5) -> float:
    """Purity estimated ONLY from the labeled subset (what a practitioner in
    the low-label regime could actually compute): for each labeled point,
    the share-label fraction among its nearest labeled neighbors."""
    Xl, yl = X[lm], y[lm]
    nl = len(Xl)
    if nl < 3:
        return float("nan")
    kk = min(k, nl - 1)
    index = KNNIndex(Xl.detach().cpu())
    ind, _ = index.query(Xl.detach().cpu(), kk + 1)
    ind = torch.tensor(ind[:, 1:], dtype=torch.long)
    return (yl[ind] == yl.unsqueeze(1)).float().mean().item()


def sklearn_baselines(Xl, yl, Xte, yte, n_classes, seed):
    """Strong raw-feature classifiers trained on the LABELED subset only."""
    from sklearn.linear_model import LogisticRegression
    from sklearn.ensemble import RandomForestClassifier
    from sklearn.neighbors import KNeighborsClassifier
    Xl_np, yl_np = Xl.numpy(), yl.numpy()
    Xte_np, yte_np = Xte.numpy(), yte.numpy()
    out = {}
    lr = LogisticRegression(max_iter=2000, C=1.0, random_state=seed)
    lr.fit(Xl_np, yl_np)
    out["raw_logreg"] = float((lr.predict(Xte_np) == yte_np).mean())
    rf = RandomForestClassifier(n_estimators=200, random_state=seed, n_jobs=1)
    rf.fit(Xl_np, yl_np)
    out["raw_rf"] = float((rf.predict(Xte_np) == yte_np).mean())
    kk = max(1, min(5, len(Xl_np) - 1))
    kn = KNeighborsClassifier(n_neighbors=kk)
    kn.fit(Xl_np, yl_np)
    out["raw_knn"] = float((kn.predict(Xte_np) == yte_np).mean())
    out["raw_ridge"] = ridge_eval(Xl, yl, Xte, yte, n_classes=n_classes)
    return out


def run(datasets, seeds, labels_per_class, tau, out_dir):
    out_dir = Path(out_dir)
    rows = []
    for ds in datasets:
        k = get_k(ds)
        for seed in seeds:
            try:
                X_tr, y_tr, X_val, y_val, X_te, y_te, meta = load_dataset(ds, seed)
            except Exception as e:
                print(f"  SKIP {ds} s{seed}: {e}", flush=True)
                continue
            N = len(X_tr)
            nc = max(int(y_tr.max()) + 1, int(y_te.max()) + 1)
            k_eff = min(k, N - 1)
            gc = GraphBuilderConfig(type="knn", k=k_eff)
            pc = PropagationConfig(type="random_walk", steps=tau)

            # Graph over ALL training points (labeled + unlabeled) -- built once
            g = build_base_graph(X_tr, gc)
            H_full = propagate(X_tr, g["edge_index"], g["edge_weight"], N, pc)
            ei_r, ew_r = make_random_edges(N, g["edge_index"].shape[1], seed)
            H_rand = propagate(X_tr, ei_r, ew_r, N, pc)

            # Test embeddings (inductive attach over ALL train points)
            Hte_full = embed_queries_via_knn(H_full, X_tr, X_te, k=k_eff)
            Hte_rand = embed_queries_via_knn(H_rand, X_tr, X_te, k=k_eff)
            Xte_att = embed_queries_via_knn(X_tr, X_tr, X_te, k=k_eff)

            purity = knn_purity(X_tr, y_tr, k_eff)

            selector = make_nested_selector(y_tr, seed)
            for L in labels_per_class:
                lm = selector(L)
                nl = int(lm.sum())
                if len(torch.unique(y_tr[lm])) < 2:
                    continue
                pl = knn_purity_labeled(X_tr, y_tr, lm)
                # Prior-matched baseline: expected share-label fraction under
                # label-independent geometry = sum of squared class freqs in
                # the labeled subset. The interpretable labeled-only
                # diagnostic is the EXCESS over this baseline (a raw
                # threshold would misread imbalanced/binary datasets).
                freqs = torch.bincount(y_tr[lm], minlength=nc).float()
                freqs = freqs / freqs.sum()
                prior = float((freqs ** 2).sum())
                r = {"dataset": ds, "seed": seed, "labels_per_class": L,
                     "n_labeled": nl, "N": N, "purity": purity,
                     "purity_labeled": pl, "purity_prior": prior,
                     "purity_excess": pl - prior}
                r.update(sklearn_baselines(X_tr[lm], y_tr[lm], X_te, y_te, nc, seed))
                r["pipe_full"] = ridge_eval(H_full[lm], y_tr[lm], Hte_full, y_te, n_classes=nc)
                r["pipe_rand"] = ridge_eval(H_rand[lm], y_tr[lm], Hte_rand, y_te, n_classes=nc)
                r["noprop_attach"] = ridge_eval(X_tr[lm], y_tr[lm], Xte_att, y_te, n_classes=nc)
                r["noprop_raw"] = ridge_eval(X_tr[lm], y_tr[lm], X_te, y_te, n_classes=nc)
                Yr = label_prop(y_tr, lm, g["edge_index"], g["edge_weight"], N, nc)
                Yte = embed_queries_via_knn(Yr, X_tr, X_te, k=k_eff)
                r["lp_real"] = (Yte.argmax(1) == y_te).float().mean().item()
                Yx = label_prop(y_tr, lm, ei_r, ew_r, N, nc)
                Yte_r = embed_queries_via_knn(Yx, X_tr, X_te, k=k_eff)
                r["lp_rand"] = (Yte_r.argmax(1) == y_te).float().mean().item()
                r["best_raw"] = max(r["raw_ridge"], r["raw_logreg"], r["raw_rf"], r["raw_knn"])
                r["lift_over_best_raw"] = r["pipe_full"] - r["best_raw"]
                r["lift_lp_over_best_raw"] = r["lp_real"] - r["best_raw"]
                r["collapse"] = r["pipe_full"] - r["pipe_rand"]
                r["collapse_lp"] = r["lp_real"] - r["lp_rand"]
                rows.append(r)
        print(f"  {ds}: done", flush=True)

    # Summary table
    hdr = (f"{'Dataset':<16} {'L':>3} {'excess':>7} {'best_raw':>8} "
           f"{'full':>6} {'rand':>6} {'nopA':>6} {'nopR':>6} {'lp':>6} "
           f"{'lp_rnd':>6} {'liftLP':>7} {'collLP':>7}")
    print("\n" + "=" * len(hdr)); print(hdr); print("-" * len(hdr))
    by = defaultdict(list)
    for r in rows:
        by[(r["dataset"], r["labels_per_class"])].append(r)
    for (ds, L), rs in sorted(by.items(), key=lambda t: (datasets.index(t[0][0]), t[0][1])):
        m = lambda f: np.mean([r[f] for r in rs])
        print(f"{ds:<16} {L:>3} {m('purity_excess'):>+7.2f} {m('best_raw'):>8.3f} "
              f"{m('pipe_full'):>6.3f} {m('pipe_rand'):>6.3f} {m('noprop_attach'):>6.3f} "
              f"{m('noprop_raw'):>6.3f} {m('lp_real'):>6.3f} {m('lp_rand'):>6.3f} "
              f"{m('lift_lp_over_best_raw'):>+7.3f} {m('collapse_lp'):>+7.3f}")
    _save_csv(rows, out_dir / "rebuttal_low_label.csv")

    # Headline (PREREGISTERED): predicted-win regime = mean purity_excess
    # (labeled-only diagnostic, smallest L) > 0.10, a rule fixed before the
    # confirmatory run. Primary comparison: lp_real vs best_raw at Lmin.
    from scipy import stats as sst
    Lmin = min(labels_per_class)
    exc = {d: np.mean([r["purity_excess"] for r in rows
                       if r["dataset"] == d and r["labels_per_class"] == Lmin])
           for d in {r["dataset"] for r in rows}}
    win = sorted([d for d, e in exc.items() if e > 0.10])
    ctrl = sorted([d for d, e in exc.items() if e <= 0.10])
    print(f"\nPreregistered regime rule (purity_excess > 0.10 at L={Lmin}):")
    print(f"  predicted-win: {win}")
    print(f"  predicted-no-win (scope controls): {ctrl}")
    for name, group in [("predicted-win", win), ("predicted-no-win", ctrl)]:
        if len(group) < 2:
            continue
        a = np.array([np.mean([r["lp_real"] for r in rows
                               if r["dataset"] == d and r["labels_per_class"] == Lmin])
                      for d in group])
        b = np.array([np.mean([r["best_raw"] for r in rows
                               if r["dataset"] == d and r["labels_per_class"] == Lmin])
                      for d in group])
        line = (f"  {name}: label-prop {a.mean():.3f} vs best-raw(oracle env.) "
                f"{b.mean():.3f}, mean lift {np.mean(a - b):+.3f}")
        if len(group) >= 3:
            t, p = sst.ttest_rel(a, b)
            line += f"  (paired t={t:.2f}, p={p:.2e}, n={len(group)})"
        print(line)
    print("  Prediction: positive lift in predicted-win, none in "
          "predicted-no-win; the interaction is the falsifiable claim.")
    return rows


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--datasets", type=str, default=None)
    p.add_argument("--seeds", type=str, default="0,1,2")
    p.add_argument("--labels", type=str, default="5,10,20")
    p.add_argument("--tau", type=int, default=5)
    p.add_argument("--out", type=str, default="outputs/rebuttal")
    a = p.parse_args()
    ds = a.datasets.split(",") if a.datasets else DEFAULT_DATASETS
    ds = [d for d in ds if d in DATASETS]
    seeds = [int(s) for s in a.seeds.split(",")]
    labels = [int(s) for s in a.labels.split(",")]
    run(ds, seeds, labels, a.tau, a.out)


if __name__ == "__main__":
    main()
