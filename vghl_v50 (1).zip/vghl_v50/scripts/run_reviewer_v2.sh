#!/bin/bash
# ══════════════════════════════════════════════════════════════════════
# VGHL v40: Run fixed reviewer experiments (#2 adversarial, #3 predictive, big CIFAR)
#
# Usage:
#   bash scripts/run_reviewer_v2.sh              # all three
#   bash scripts/run_reviewer_v2.sh adversarial  # just adversarial
#   bash scripts/run_reviewer_v2.sh predictive   # just predictive
#   bash scripts/run_reviewer_v2.sh big_cifar    # just big CIFAR
# ══════════════════════════════════════════════════════════════════════

set -e
export PYTHONUNBUFFERED=1
cd "$(dirname "$0")/.."

LOGDIR="outputs/logs"
mkdir -p "$LOGDIR"

MODE="${1:-all}"

run_step() {
    local NAME="$1"
    shift
    echo ""
    echo "$(date) === $NAME ==="
    local T0=$(date +%s)
    if "$@"; then
        local T1=$(date +%s)
        echo "$(date) DONE ($((T1 - T0))s)"
    else
        local T1=$(date +%s)
        echo "$(date) FAILED $NAME ($((T1 - T0))s)"
    fi
}

# ── Adversarial feature-bridge (20 datasets, 3 seeds) ────────────────
if [ "$MODE" = "all" ] || [ "$MODE" = "adversarial" ]; then
    run_step "adversarial_bridge" \
        python -u scripts/run_real_experiments.py \
            --only adversarial --seeds 0,1,2 \
            --threads 4
fi

# ── Predictive validity v2 (20 datasets, 3 seeds) ────────────────────
if [ "$MODE" = "all" ] || [ "$MODE" = "predictive" ]; then
    run_step "predictive_validity_v2" \
        python -u scripts/run_real_experiments.py \
            --only predictive --seeds 0,1,2 \
            --threads 4
fi

# ── Big CIFAR (N=40k, 2 seeds, relaxed threads) ──────────────────────
if [ "$MODE" = "all" ] || [ "$MODE" = "big_cifar" ]; then
    run_step "big_cifar" \
        python -u scripts/run_real_experiments.py \
            --only big_cifar --seeds 0,1 \
            --threads 8
fi

echo ""
echo "$(date) === ALL REVIEWER V2 EXPERIMENTS COMPLETE ==="
