#!/usr/bin/env python3
"""Learned operators (GCN, GAT, MLP) on native graphs: real vs destroyed.

Directly answers GMYt Q1: does the intervention signature persist for
learned message passing? Conditions per dataset (standard Planetoid
splits, row-normalized features): given graph, I1 random edges (same E),
symmetric degree-preserving rewire, plus a graph-free MLP on raw features
(also serves as an additional strong raw baseline for the ridge/LogReg/RF
set). Architectures: Kipf-default GCN (2 layers, hidden 16, dropout 0.5)
and GAT (8 heads x 8); Adam lr 0.01, weight decay 5e-4, 200 epochs, model
selected on validation accuracy. Requires torch_geometric.

Usage: python -u scripts/rebuttal_gcn_native.py --datasets cora,citeseer --seeds 0,1,2
"""
import os, sys
os.environ.setdefault("OMP_NUM_THREADS", "4")
import argparse
import random as pyrandom
import numpy as np
import torch
import torch.nn.functional as F

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))
sys.path.insert(0, os.path.dirname(__file__))

from rebuttal_native_graph import (  # noqa: E402
    load_native, symmetrize_dedup, make_random_edges, row_normalize,
)
from vghl.models.graph_builder import _apply_control  # noqa: E402
from run_real_experiments import _save_csv  # noqa: E402


def train_eval(model_name, X, y, ei, trm, vam, tem, nc, seed,
               device="cpu", epochs=200):
    """Train one readout and return test accuracy at best validation epoch."""
    from torch_geometric.nn import GCNConv, GATConv
    torch.manual_seed(seed); np.random.seed(seed); pyrandom.seed(seed)
    if device == "auto":
        device = "cuda" if torch.cuda.is_available() else "cpu"
    if str(device).startswith("cuda") and not torch.cuda.is_available():
        raise RuntimeError(f"requested {device}, but CUDA is unavailable")
    if str(device).startswith("cuda"):
        torch.cuda.manual_seed_all(seed)

    X = X.to(device); y = y.to(device); ei = ei.to(device)
    trm = trm.to(device); vam = vam.to(device); tem = tem.to(device)
    d = X.shape[1]

    class GCN(torch.nn.Module):
        def __init__(self):
            super().__init__()
            self.c1 = GCNConv(d, 16); self.c2 = GCNConv(16, nc)
        def forward(self, x, edge_index):
            x = F.relu(self.c1(x, edge_index))
            x = F.dropout(x, 0.5, self.training)
            return self.c2(x, edge_index)

    class GAT(torch.nn.Module):
        def __init__(self):
            super().__init__()
            self.c1 = GATConv(d, 8, heads=8, dropout=0.6)
            self.c2 = GATConv(64, nc, heads=1, concat=False, dropout=0.6)
        def forward(self, x, edge_index):
            x = F.dropout(x, 0.6, self.training)
            x = F.elu(self.c1(x, edge_index))
            x = F.dropout(x, 0.6, self.training)
            return self.c2(x, edge_index)

    class MLP(torch.nn.Module):
        def __init__(self):
            super().__init__()
            self.l1 = torch.nn.Linear(d, 64); self.l2 = torch.nn.Linear(64, nc)
        def forward(self, x, edge_index):
            del edge_index
            x = F.relu(self.l1(x))
            x = F.dropout(x, 0.5, self.training)
            return self.l2(x)

    factories = {"gcn": GCN, "gat": GAT, "mlp": MLP}
    if model_name not in factories:
        raise ValueError(f"unknown model {model_name!r}")
    model = factories[model_name]().to(device)
    opt = torch.optim.Adam(model.parameters(), lr=0.01, weight_decay=5e-4)
    best_val, best_test = -1.0, 0.0
    for _ in range(epochs):
        model.train(); opt.zero_grad(set_to_none=True)
        out = model(X, ei)
        loss = F.cross_entropy(out[trm], y[trm])
        loss.backward(); opt.step()
        model.eval()
        with torch.no_grad():
            pred = model(X, ei).argmax(1)
            va = (pred[vam] == y[vam]).float().mean().item()
            if va > best_val:
                best_val = va
                best_test = (pred[tem] == y[tem]).float().mean().item()
    return best_test


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--datasets", type=str, default="cora,citeseer")
    p.add_argument("--seeds", type=str, default="0,1,2")
    p.add_argument("--out", type=str, default="outputs/rebuttal")
    a = p.parse_args()
    seeds = [int(s) for s in a.seeds.split(",")]
    rows = []
    from pathlib import Path
    from collections import defaultdict
    for ds in a.datasets.split(","):
        X, y, ei_given, trm, vam, tem = load_native(ds)
        X = row_normalize(X)
        N = X.shape[0]; nc = int(y.max()) + 1
        ei_given = symmetrize_dedup(ei_given)
        E = ei_given.shape[1]
        for seed in seeds:
            torch.manual_seed(seed); pyrandom.seed(seed)
            conds = {
                "given": ei_given,
                "random_edges": make_random_edges(N, E, seed)[0],
                "degree_rewire": _apply_control(ei_given, torch.ones(E), N,
                                                "degree_preserving_rewire")[0],
            }
            r = {"dataset": ds, "seed": seed}
            r["mlp_raw"] = train_eval("mlp", X, y, ei_given, trm, vam, tem, nc, seed)
            for arch in ["gcn", "gat"]:
                for cname, ei in conds.items():
                    r[f"{arch}_{cname}"] = train_eval(arch, X, y, ei, trm, vam,
                                                      tem, nc, seed)
            rows.append(r)
            print(f"  {ds} s{seed}: " + " ".join(
                f"{k}={v:.3f}" for k, v in r.items()
                if k not in ("dataset", "seed")), flush=True)
    cols = [c for c in rows[0] if c not in ("dataset", "seed")]
    by = defaultdict(list)
    for r in rows:
        by[r["dataset"]].append(r)
    print("\n" + f"{'Dataset':<10} " + " ".join(f"{c:>16}" for c in cols))
    for ds, rs in by.items():
        vals = [f"{np.mean([r[c] for r in rs]):.3f}±{np.std([r[c] for r in rs]):.3f}"
                for c in cols]
        print(f"{ds:<10} " + " ".join(f"{v:>16}" for v in vals))
    _save_csv(rows, Path(a.out) / "rebuttal_gcn_native.csv")


if __name__ == "__main__":
    main()
