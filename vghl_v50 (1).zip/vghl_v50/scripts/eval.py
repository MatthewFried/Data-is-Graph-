#!/usr/bin/env python3
"""Evaluation CLI. Usage: python scripts/eval.py --ckpt outputs/run_name/best.pt --split test"""
import argparse, sys, os

os.environ.setdefault("OMP_NUM_THREADS", "1")
os.environ.setdefault("MKL_NUM_THREADS", "1")

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from vghl.utils.config import ExperimentConfig
from vghl.utils.seed import set_seed
from vghl.utils.logging import get_logger
from vghl.utils.io import load_checkpoint
from vghl.data.loaders import build_datasets, build_dataloaders
from vghl.models.vghl_model import build_model
from vghl.train.eval import evaluate_model

logger = get_logger("vghl.eval")


def main():
    p = argparse.ArgumentParser(description="VGHL Evaluation")
    p.add_argument("--ckpt", type=str, required=True, help="Checkpoint path")
    p.add_argument("--split", type=str, default="test", choices=["val", "test"])
    p.add_argument("--out", type=str, default=None, help="Output JSON path")
    p.add_argument("--device", type=str, default="auto")
    p.add_argument("--no_structural", action="store_true")
    args = p.parse_args()

    # Load config from checkpoint
    import torch
    state = torch.load(args.ckpt, map_location="cpu", weights_only=False)
    cfg = ExperimentConfig._from_dict(state["config"])
    if args.device != "auto":
        cfg.device = args.device
    device = cfg.resolve_device()

    set_seed(cfg.seed)

    # Data
    train_ds, val_ds, test_ds, meta = build_datasets(cfg)
    _, val_loader, test_loader = build_dataloaders(train_ds, val_ds, test_ds, cfg)
    loader = test_loader if args.split == "test" else val_loader

    input_dim = meta.get("d", train_ds.X.shape[1])
    n_classes = meta.get("n_classes", cfg.data.n_classes)

    # Determine model type from config name
    model_name = cfg.name.split("_")[0] if "_" in cfg.name else "vghl"
    if model_name not in ["vghl", "mlp", "point_gnn", "fixed_cluster_gnn"]:
        model_name = "vghl"

    model = build_model(model_name, input_dim, n_classes, cfg)
    model.load_state_dict(state["model_state_dict"])

    out_path = args.out or str(cfg.run_dir / f"eval_{args.split}.json")

    # Use saved epoch from checkpoint, or final epoch
    eval_epoch = state.get("epoch", cfg.train.epochs - 1)

    results = evaluate_model(
        model, loader, cfg, device, n_classes,
        save_path=out_path,
        compute_structural=(model_name == "vghl" and not args.no_structural),
        epoch=eval_epoch,
    )
    logger.info(f"Results saved to {out_path}")


if __name__ == "__main__":
    main()
