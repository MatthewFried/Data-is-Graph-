#!/usr/bin/env python3
"""Inductive Control: Proves pruning effects are not transductive leakage.

Builds graph on train only. Val/test points connect to train graph via
kNN-to-train. If pruning still improves accuracy under this protocol,
the effect is real, not caused by transductive information leakage.

Runs: baseline vs stability-pruned, inductive mode, multi-seed.

Usage:
    python scripts/inductive_control.py
    python scripts/inductive_control.py --datasets sk_moons,breast_cancer --seeds 0,1,2,3,4
"""
import argparse
import subprocess
import sys
import os
import json
import csv
import statistics as stats_mod
from pathlib import Path
from collections import defaultdict

os.environ.setdefault("OMP_NUM_THREADS", "1")
os.environ.setdefault("MKL_NUM_THREADS", "1")
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
os.environ.setdefault("NUMEXPR_NUM_THREADS", "1")


DATASET_DEFAULTS = {
    "sk_moons":      {"n_train": 5000, "n_val": 1000, "n_test": 1000, "epochs": 50},
    "sk_circles":    {"n_train": 5000, "n_val": 1000, "n_test": 1000, "epochs": 50},
    "breast_cancer": {"n_train": 0, "n_val": 0, "n_test": 0, "epochs": 80},
    "digits":        {"n_train": 0, "n_val": 0, "n_test": 0, "epochs": 80},
    "wine":          {"n_train": 0, "n_val": 0, "n_test": 0, "epochs": 80},
}

CONDITIONS = {
    "inductive_baseline": [],
    "inductive_prune_stab": [
        "--prune", "--prune_methods", "stability",
        "--prune_n_bootstrap", "5", "--prune_perturb_sigma", "0.01",
        "--prune_node_jaccard_min", "0.5",
    ],
    "inductive_prune_geo": [
        "--prune", "--prune_methods", "geometric",
    ],
    "transductive_baseline": [],
    "transductive_prune_stab": [
        "--prune", "--prune_methods", "stability",
        "--prune_n_bootstrap", "5", "--prune_perturb_sigma", "0.01",
        "--prune_node_jaccard_min", "0.5",
    ],
}


def run_single(dataset, k, seed, condition, out_dir, dd, quiet=True):
    """Run one train_gm.py experiment."""
    is_inductive = condition.startswith("inductive")
    name = f"{condition}_{dataset}_k{k}_s{seed}"
    run_dir = Path(out_dir) / name
    results_path = run_dir / "results.json"

    if results_path.exists():
        try:
            with open(results_path) as f:
                return json.load(f), name
        except Exception:
            pass

    cmd = [
        sys.executable, os.path.join(os.path.dirname(__file__), "train_gm.py"),
        "--dataset", dataset,
        "--graph_type", "knn", "--k", str(k),
        "--operator", "random_walk", "--prop_steps", "5",
        "--epochs", str(dd.get("epochs", 50)),
        "--head", "linear",
        "--seed", str(seed),
        "--name", name,
        "--out", str(out_dir),
    ]

    if dd.get("n_train", 0) > 0:
        cmd.extend(["--n_train", str(dd["n_train"])])
    if dd.get("n_val", 0) > 0:
        cmd.extend(["--n_val", str(dd["n_val"])])
    if dd.get("n_test", 0) > 0:
        cmd.extend(["--n_test", str(dd["n_test"])])
    if quiet:
        cmd.append("--quiet")

    # Set mode
    if is_inductive:
        cmd.extend(["--gm_mode", "inductive_anchor_graph",
                     "--anchor_k", "8", "--bipartite_steps", "1"])
    # else: default transductive_full_graph

    # Add condition-specific flags
    cmd.extend(CONDITIONS.get(condition, []))

    result = subprocess.run(cmd, capture_output=True, text=True)
    if result.returncode != 0:
        if result.stderr:
            lines = result.stderr.strip().split("\n")
            for line in lines[-3:]:
                print(f"    {line}")
        return None, name

    if results_path.exists():
        with open(results_path) as f:
            return json.load(f), name
    return None, name


def main():
    p = argparse.ArgumentParser(description="Inductive control experiment")
    p.add_argument("--datasets", type=str, default="sk_moons,breast_cancer")
    p.add_argument("--seeds", type=str, default="0,1,2,3,4")
    p.add_argument("--k_values", type=str, default="16")
    p.add_argument("--out", type=str, default="outputs/inductive_control")
    p.add_argument("--verbose", action="store_true")

    args = p.parse_args()
    datasets = [d.strip() for d in args.datasets.split(",")]
    seeds = [int(s) for s in args.seeds.split(",")]
    k_values = [int(k) for k in args.k_values.split(",")]
    out_dir = args.out

    conditions = list(CONDITIONS.keys())
    total = len(datasets) * len(k_values) * len(conditions) * len(seeds)
    done = 0

    print("=" * 70)
    print("INDUCTIVE CONTROL EXPERIMENT")
    print(f"  Datasets:   {datasets}")
    print(f"  Seeds:      {seeds}")
    print(f"  k values:   {k_values}")
    print(f"  Conditions: {conditions}")
    print(f"  Total runs: {total}")
    print("=" * 70)

    rows = []
    for dataset in datasets:
        dd = DATASET_DEFAULTS.get(dataset, {})
        for k in k_values:
            for condition in conditions:
                for seed in seeds:
                    done += 1
                    tag = f"{condition}_{dataset}_k{k}_s{seed}"
                    print(f"[{done}/{total}] {tag}", end=" ... ", flush=True)

                    res, name = run_single(
                        dataset, k, seed, condition, out_dir, dd,
                        quiet=not args.verbose,
                    )

                    if res is not None:
                        test = res.get("test", {})
                        machine = res.get("machine", {})
                        acc = test.get("test/accuracy", "")
                        row = {
                            "dataset": dataset, "k": k,
                            "condition": condition, "seed": seed,
                            "test_accuracy": acc,
                            "test_f1": test.get("test/f1", ""),
                            "n_nodes": machine.get("machine/n_nodes",
                                       machine.get("n_nodes", "")),
                            "n_edges": machine.get("machine/n_edges",
                                       machine.get("n_edges", "")),
                        }
                        rows.append(row)
                        print(f"acc={acc:.4f}" if isinstance(acc, float) else "?")
                    else:
                        print("FAILED")

    # Save
    if rows:
        csv_path = Path(out_dir) / "inductive_control.csv"
        with open(csv_path, "w", newline="") as f:
            w = csv.DictWriter(f, fieldnames=rows[0].keys())
            w.writeheader()
            w.writerows(rows)
        print(f"\nResults: {csv_path}")

    # Summary
    if rows:
        print("\n" + "=" * 80)
        print("INDUCTIVE CONTROL SUMMARY")
        print("=" * 80)

        groups = defaultdict(list)
        for r in rows:
            acc = r.get("test_accuracy")
            if acc == "" or acc is None:
                continue
            key = (r["dataset"], r["k"], r["condition"])
            groups[key].append(float(acc))

        print(f"{'Dataset':<16} {'k':>3} {'Condition':<30} {'Accuracy':>15}")
        print("-" * 70)

        summary_rows = []
        for (ds, k, cond), accs in sorted(groups.items()):
            mean = stats_mod.mean(accs)
            std = stats_mod.stdev(accs) if len(accs) > 1 else 0.0
            acc_str = f"{mean:.3f} ± {std:.3f}"
            print(f"{ds:<16} {k:>3} {cond:<30} {acc_str:>15}")
            summary_rows.append({
                "dataset": ds, "k": k, "condition": cond,
                "mean_acc": mean, "std_acc": std, "n": len(accs),
                "acc_str": acc_str,
            })

        # Key comparison: does pruning still help under inductive mode?
        print("\n── KEY COMPARISON ──")
        for ds in datasets:
            for k in k_values:
                ind_base = groups.get((ds, k, "inductive_baseline"), [])
                ind_prune = groups.get((ds, k, "inductive_prune_stab"), [])
                trans_base = groups.get((ds, k, "transductive_baseline"), [])
                trans_prune = groups.get((ds, k, "transductive_prune_stab"), [])

                if ind_base and ind_prune:
                    delta_ind = stats_mod.mean(ind_prune) - stats_mod.mean(ind_base)
                    print(f"{ds} k={k}: inductive pruning Δ = {delta_ind:+.4f} "
                          f"({'HELPS' if delta_ind > 0 else 'hurts'})")
                if trans_base and trans_prune:
                    delta_trans = stats_mod.mean(trans_prune) - stats_mod.mean(trans_base)
                    print(f"{ds} k={k}: transductive pruning Δ = {delta_trans:+.4f}")

        # LaTeX table
        _write_latex(summary_rows, Path(out_dir))

    print(f"\nAll outputs in: {out_dir}")


def _write_latex(summary, out_dir):
    """Write LaTeX table comparing inductive vs transductive."""
    if not summary:
        return
    lines = [
        r"\begin{table}[t]",
        r"\centering",
        r"\caption{Inductive control: pruning effects persist when graph is "
        r"built on train only (no transductive leakage).}",
        r"\label{tab:inductive}",
        r"\begin{tabular}{llcc}",
        r"\toprule",
        r"Dataset & Protocol & Baseline & Stability prune \\",
        r"\midrule",
    ]

    ds_list = sorted(set(s["dataset"] for s in summary))
    for ds in ds_list:
        ds_label = ds.replace("_", r"\_")
        if ds == "breast_cancer":
            ds_label = "Breast Cancer"
        elif ds == "sk_moons":
            ds_label = "Two Moons"

        for protocol in ["inductive", "transductive"]:
            base = [s for s in summary
                    if s["dataset"] == ds and s["condition"] == f"{protocol}_baseline"]
            prune = [s for s in summary
                     if s["dataset"] == ds and s["condition"] == f"{protocol}_prune_stab"]
            base_str = base[0]["acc_str"] if base else "-"
            prune_str = prune[0]["acc_str"] if prune else "-"
            lines.append(f"  {ds_label} & {protocol} & {base_str} & {prune_str}" + r" \\")

    lines.extend([r"\bottomrule", r"\end{tabular}", r"\end{table}"])

    tex_path = out_dir / "inductive_table.tex"
    with open(tex_path, "w") as f:
        f.write("\n".join(lines))
    print(f"LaTeX table: {tex_path}")


if __name__ == "__main__":
    main()
