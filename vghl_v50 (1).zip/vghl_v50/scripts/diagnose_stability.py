#!/usr/bin/env python3
"""Diagnostic: What does stability actually measure?

Computes boundary scores, correlates with stability, runs quadrant
subset tests, and measures coverage — to understand whether stability
identifies interior vs boundary nodes and what matters for accuracy.

Tests:
  1) Correlation: stability vs boundary (disagreement + entropy)
  2) Quadrant subsets: stable×interior, stable×boundary, etc.
  3) Boundary-prune vs interior-prune vs stability-prune
  4) Coverage diagnostics per subset
  5) Propagation step ablation on quadrants

Usage:
    python scripts/diagnose_stability.py
    python scripts/diagnose_stability.py --datasets sk_moons,breast_cancer,digits
"""
import argparse
import sys
import os

# Thread control MUST be before numpy/torch import
os.environ["OMP_NUM_THREADS"] = os.environ.get("OMP_NUM_THREADS", "1")
os.environ["MKL_NUM_THREADS"] = os.environ.get("MKL_NUM_THREADS", "1")
os.environ["OPENBLAS_NUM_THREADS"] = os.environ.get("OPENBLAS_NUM_THREADS", "1")
os.environ["NUMEXPR_NUM_THREADS"] = os.environ.get("NUMEXPR_NUM_THREADS", "1")
os.environ["VECLIB_MAXIMUM_THREADS"] = os.environ.get("VECLIB_MAXIMUM_THREADS", "1")

import csv
import time
import math
import numpy as np
import torch
from pathlib import Path
from collections import defaultdict

torch.set_num_threads(1)

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from vghl.data.loaders import build_datasets, PointDataset
from vghl.utils.config import ExperimentConfig
from vghl.models.graph_builder import build_base_graph, GraphBuilderConfig
from vghl.models.propagation import propagate, PropagationConfig
from vghl.models.probe import ridge_eval, embed_queries_via_knn

DATASET_DEFAULTS = {
    "sk_moons":       {"n_train": 5000, "n_val": 1000, "n_test": 1000},
    "sk_circles":     {"n_train": 5000, "n_val": 1000, "n_test": 1000},
    "breast_cancer":  {"n_train": 0, "n_val": 0, "n_test": 0},
    "digits":         {"n_train": 0, "n_val": 0, "n_test": 0},
    "wine":           {"n_train": 0, "n_val": 0, "n_test": 0},
    "ionosphere":     {"n_train": 0, "n_val": 0, "n_test": 0},
}


def load_dataset(dataset, seed, n_train, n_val, n_test):
    cfg = ExperimentConfig()
    cfg.data.dataset = dataset
    cfg.data.n_train = n_train
    cfg.data.n_val = n_val
    cfg.data.n_test = n_test
    cfg.seed = seed
    train_ds, val_ds, test_ds, meta = build_datasets(cfg)
    return train_ds.X, train_ds.y, val_ds.X, val_ds.y, test_ds.X, test_ds.y, meta


# ══════════════════════════════════════════════════════════════════════
# SCORING: boundary, stability, margin
# ══════════════════════════════════════════════════════════════════════

def compute_boundary_scores(X, y, k=16, k_boundary=None):
    """Compute per-node boundary scores.

    Uses k_boundary (default: max(k*8, 128)) for disagreement/entropy to
    ensure opposite-class neighbors are found even in well-separated datasets.
    For margin: uses per-class kNN index for exact nearest-opposite lookup.

    Returns dict with:
      disagreement: fraction of k_boundary neighbors with different label
      entropy: local label entropy over k_boundary neighbors
      margin: dist(nearest opposite-class) - dist(nearest same-class)
      opp_missing_rate: fraction of nodes with no opposite-class found
      k_boundary_used: actual k used
      disagree_nonzero_frac: fraction of nodes with any cross-class neighbor
    """
    from vghl.models.knn_backend import KNNIndex
    N = X.shape[0]
    n_classes = int(y.max()) + 1
    X_cpu = X.detach().cpu()

    # Large k for boundary detection
    if k_boundary is None:
        k_boundary = max(k * 8, 128)
    k_boundary = min(k_boundary, N - 1)

    index = KNNIndex(X_cpu)
    indices, distances = index.query(X_cpu, k_boundary + 1)
    indices = indices[:, 1:]    # remove self
    distances = distances[:, 1:]
    k_actual = indices.shape[1]

    indices_t = torch.tensor(indices, dtype=torch.long)
    distances_t = torch.tensor(distances, dtype=torch.float32)
    neighbor_labels = y[indices_t]  # (N, k_actual)

    # 1. Disagreement
    disagree = (neighbor_labels != y.unsqueeze(1)).float().mean(dim=1)

    # 2. Entropy
    entropy = torch.zeros(N)
    for c in range(n_classes):
        p_c = (neighbor_labels == c).float().mean(dim=1)
        log_p = torch.where(p_c > 0, torch.log(p_c + 1e-10), torch.zeros_like(p_c))
        entropy -= p_c * log_p

    # 3. Margin via per-class kNN (exact nearest opposite-class)
    margin = torch.zeros(N)
    opp_missing = 0

    class_knn = {}
    for c in range(n_classes):
        c_idx = (y == c).nonzero(as_tuple=True)[0]
        if len(c_idx) > 0:
            class_knn[c] = KNNIndex(X_cpu[c_idx])

    for i in range(N):
        own_c = y[i].item()
        # Nearest same-class from big neighbor list
        same_mask = neighbor_labels[i] == own_c
        d_same = distances_t[i][same_mask].min().item() if same_mask.any() else 0.0

        # Nearest opposite-class: query each other class's index
        d_opp = float('inf')
        xi = X_cpu[i:i+1]
        for c in range(n_classes):
            if c == own_c or c not in class_knn:
                continue
            _, d_c = class_knn[c].query(xi, 1)
            d_opp = min(d_opp, float(d_c[0, 0]))

        if d_opp == float('inf'):
            opp_missing += 1
            margin[i] = float('nan')  # censored: no opposite-class neighbor found
        else:
            margin[i] = d_opp - d_same

    return {
        "disagreement": disagree,
        "entropy": entropy,
        "margin": margin,
        "opp_missing_rate": opp_missing / N,
        "k_boundary_used": k_actual,
        "disagree_nonzero_frac": (disagree > 0).float().mean().item(),
    }


def compute_stability(X, graph_cfg, n_trials=5, sigma=None, seed=0):
    """Compute per-node stability with adaptive sigma."""
    from vghl.models.pruning import _build_neighbor_sets, _pairwise_jaccard
    rng = np.random.RandomState(seed)
    N = X.shape[0]
    d = X.shape[1]
    device = X.device

    if sigma is None:
        graph = build_base_graph(X, graph_cfg)
        ei = graph["edge_index"]
        edge_dists = (X[ei[0]] - X[ei[1]]).norm(dim=1)
        sigma = max(0.05 * edge_dists.median().item(), 1e-6)

    boot_sets = []
    for t in range(n_trials):
        noise = torch.tensor(
            rng.randn(N, d).astype(np.float32) * sigma,
            device=device, dtype=X.dtype,
        )
        graph = build_base_graph(X + noise, graph_cfg)
        boot_sets.append(_build_neighbor_sets(graph["edge_index"], N, device))

    stability = _pairwise_jaccard(boot_sets, N, device)
    return stability, sigma


def eval_subset(X_tr, y_tr, X_val, y_val, idx, graph_cfg, prop_cfg, k_embed=None):
    """Evaluate a subset by index tensor. Returns accuracy and coverage stats.

    k_embed defaults to graph_cfg.k so val embedding matches graph construction.
    """
    X_sub = X_tr[idx]
    y_sub = y_tr[idx]
    N_sub = len(idx)

    if N_sub < 5:
        return {"acc": 0.0, "n": N_sub, "mean_dist": 999, "p90_dist": 999}

    n_classes = max(int(y_tr.max()) + 1, int(y_sub.max()) + 1)
    graph = build_base_graph(X_sub, graph_cfg)
    h = propagate(X_sub, graph["edge_index"], graph["edge_weight"], N_sub, prop_cfg)

    k_e = min(graph_cfg.k if k_embed is None else k_embed, N_sub)
    h_val = embed_queries_via_knn(h, X_sub, X_val, k=k_e)
    acc = ridge_eval(h, y_sub, h_val, y_val, n_classes=n_classes)

    # Coverage: distance from val points to nearest subset anchor
    from vghl.models.knn_backend import KNNIndex
    knn = KNNIndex(X_sub.detach().cpu())
    _, dists = knn.query(X_val.detach().cpu(), 1)
    mean_dist = float(dists.mean())
    p90_dist = float(np.percentile(dists, 90))

    return {"acc": acc, "n": N_sub, "mean_dist": mean_dist, "p90_dist": p90_dist}


def spearman_corr(a, b):
    """Spearman rank correlation between two 1D tensors."""
    a_np = a.detach().cpu().numpy().astype(np.float64)
    b_np = b.detach().cpu().numpy().astype(np.float64)
    try:
        from scipy.stats import spearmanr
        rho, pval = spearmanr(a_np, b_np)
    except ImportError:
        # Manual fallback: rank-based Pearson
        def _rank(x):
            order = np.argsort(x)
            ranks = np.empty_like(order, dtype=np.float64)
            ranks[order] = np.arange(len(x), dtype=np.float64)
            return ranks
        ra, rb = _rank(a_np), _rank(b_np)
        n = len(ra)
        cov = np.mean(ra * rb) - np.mean(ra) * np.mean(rb)
        rho = cov / (np.std(ra) * np.std(rb) + 1e-12)
        pval = 0.0  # can't compute without scipy
    return rho, pval


def stratified_select(scores, y, n_select, top=True):
    """Select top/bottom nodes stratified by class."""
    classes = y.unique()
    counts = torch.bincount(y, minlength=int(classes.max()) + 1)
    total = y.shape[0]
    selected = []
    for c in classes:
        c_mask = (y == c)
        c_idx = c_mask.nonzero(as_tuple=True)[0]
        c_scores = scores[c_idx]
        n_c = max(int(n_select * counts[c].item() / total), 1)
        n_c = min(n_c, len(c_idx))
        if top:
            _, loc = torch.topk(c_scores, n_c)
        else:
            _, loc = torch.topk(c_scores, n_c, largest=False)
        selected.append(c_idx[loc])
    return torch.cat(selected)


# ══════════════════════════════════════════════════════════════════════
# TEST 1: Correlation table
# ══════════════════════════════════════════════════════════════════════

def run_correlation_analysis(datasets, seeds, k, out_dir, k_boundary=None):
    """Correlate stability with boundary scores."""
    print("\n" + "=" * 70)
    print("TEST 1: Stability vs Boundary Correlation")
    print("=" * 70)

    rows = []
    graph_cfg = GraphBuilderConfig(type="knn", k=k)

    for dataset in datasets:
        dd = DATASET_DEFAULTS.get(dataset, {})
        for seed in seeds:
            X_tr, y_tr, X_val, y_val, _, _, meta = load_dataset(
                dataset, seed, dd.get("n_train", 0),
                dd.get("n_val", 0), dd.get("n_test", 0),
            )
            N = len(X_tr)

            stability, sigma = compute_stability(X_tr, graph_cfg, seed=seed)
            boundary = compute_boundary_scores(X_tr, y_tr, k=k, k_boundary=k_boundary)

            # Log boundary diagnostics
            d_min = boundary["disagreement"].min().item()
            d_max = boundary["disagreement"].max().item()
            e_min = boundary["entropy"].min().item()
            e_max = boundary["entropy"].max().item()
            m_min = boundary["margin"].min().item()
            m_max = boundary["margin"].max().item()
            print(f"  [{dataset} s{seed}] k_bnd={boundary['k_boundary_used']} "
                  f"disagree_nonzero={boundary['disagree_nonzero_frac']:.2%} "
                  f"opp_missing={boundary['opp_missing_rate']:.2%}")
            print(f"    disagree=[{d_min:.4f},{d_max:.4f}] "
                  f"entropy=[{e_min:.4f},{e_max:.4f}] "
                  f"margin=[{m_min:.4f},{m_max:.4f}]")

            # Guard against constant arrays
            d_std = boundary["disagreement"].std().item()
            e_std = boundary["entropy"].std().item()
            m_std = boundary["margin"].std().item()

            if d_std < 1e-10:
                print(f"    ⚠ disagreement is constant — correlation undefined")
            if e_std < 1e-10:
                print(f"    ⚠ entropy is constant — correlation undefined")

            rho_disagree = rho_entropy = rho_margin = float('nan')
            p_disagree = p_entropy = p_margin = 1.0

            if d_std > 1e-10:
                rho_disagree, p_disagree = spearman_corr(stability, boundary["disagreement"])
            if e_std > 1e-10:
                rho_entropy, p_entropy = spearman_corr(stability, boundary["entropy"])
            if m_std > 1e-10:
                rho_margin, p_margin = spearman_corr(stability, boundary["margin"])

            # Quantile overlap
            n_q = max(int(N * 0.3), 5)
            unstable_idx = set(torch.argsort(stability)[:n_q].tolist())
            boundary_idx = set(torch.argsort(boundary["disagreement"], descending=True)[:n_q].tolist())
            overlap = len(unstable_idx & boundary_idx) / n_q

            row = {
                "dataset": dataset, "seed": seed, "N": N, "sigma": sigma,
                "k_boundary_used": boundary["k_boundary_used"],
                "disagree_nonzero_frac": boundary["disagree_nonzero_frac"],
                "opp_missing_rate": boundary["opp_missing_rate"],
                "rho_disagree": rho_disagree, "p_disagree": p_disagree,
                "rho_entropy": rho_entropy, "p_entropy": p_entropy,
                "rho_margin": rho_margin, "p_margin": p_margin,
                "unstable_boundary_overlap": overlap,
                "stab_mean": stability.mean().item(),
                "stab_std": stability.std().item(),
                "boundary_mean": boundary["disagreement"].mean().item(),
                "margin_mean": boundary["margin"].mean().item(),
                "margin_std": boundary["margin"].std().item(),
            }
            rows.append(row)

            def _fmt(v):
                return f"{v:+.3f}" if not math.isnan(v) else "NaN"
            print(f"  {dataset} s{seed}: ρ(s,disagree)={_fmt(rho_disagree)} "
                  f"ρ(s,entropy)={_fmt(rho_entropy)} ρ(s,margin)={_fmt(rho_margin)} "
                  f"overlap={overlap:.2f}")

    # Aggregate per dataset
    print(f"\n{'Dataset':<18} {'ρ(s,disagree)':>14} {'ρ(s,entropy)':>14} {'ρ(s,margin)':>12} {'overlap':>8}")
    print("-" * 70)
    by_ds = defaultdict(list)
    for r in rows:
        by_ds[r["dataset"]].append(r)
    for ds, rs in sorted(by_ds.items()):
        rd = np.nanmean([r["rho_disagree"] for r in rs])
        re = np.nanmean([r["rho_entropy"] for r in rs])
        rm = np.nanmean([r["rho_margin"] for r in rs])
        ov = np.nanmean([r["unstable_boundary_overlap"] for r in rs])
        def _f(v):
            return f"{v:>+14.3f}" if not np.isnan(v) else f"{'NaN':>14}"
        print(f"{ds:<18} {_f(rd)} {_f(re)} {_f(rm)[:12]:>12} {ov:>8.2f}")

    _save_csv(rows, out_dir / "correlation_table.csv")
    return rows


# ══════════════════════════════════════════════════════════════════════
# TEST 2: Quadrant subsets (stability × boundary)
# ══════════════════════════════════════════════════════════════════════

def run_quadrant_test(datasets, seeds, k, out_dir, frac=0.3, prop_steps=5,
                     k_boundary=None, target_frac=0.2):
    """4-quadrant test: stable×interior, stable×boundary, etc.

    Uses target_frac * N as subset size (NOT min of quadrant sizes).
    Uses k_boundary for boundary scoring (same as correlation test).
    Warns when boundary metric saturates.
    """
    print("\n" + "=" * 70)
    print("TEST 2: Quadrant Subsets (Stability × Boundary)")
    print(f"  target_frac={target_frac}, quantile_frac={frac}")
    print("=" * 70)

    rows = []
    graph_cfg = GraphBuilderConfig(type="knn", k=k)
    prop_cfg = PropagationConfig(type="random_walk", steps=prop_steps)

    MIN_SUBSET = 32  # minimum points for meaningful evaluation

    for dataset in datasets:
        dd = DATASET_DEFAULTS.get(dataset, {})
        for seed in seeds:
            X_tr, y_tr, X_val, y_val, _, _, meta = load_dataset(
                dataset, seed, dd.get("n_train", 0),
                dd.get("n_val", 0), dd.get("n_test", 0),
            )
            N = len(X_tr)
            n_classes = int(y_tr.max()) + 1
            n_target = max(int(N * target_frac), MIN_SUBSET)

            stability, _ = compute_stability(X_tr, graph_cfg, seed=seed)
            boundary = compute_boundary_scores(X_tr, y_tr, k=k, k_boundary=k_boundary)
            disagree = boundary["disagreement"]
            b_entropy = boundary["entropy"]
            b_margin = boundary["margin"]

            # Check boundary saturation
            bnd_nonzero = (disagree > 0).float().mean().item()
            bnd_std = disagree.std().item()
            boundary_informative = bnd_std > 1e-6 and bnd_nonzero > 0.05

            if not boundary_informative:
                print(f"\n  [{dataset} s{seed}] ⚠ BOUNDARY SATURATED "
                      f"(nonzero={bnd_nonzero:.1%}, std={bnd_std:.6f})")
                print(f"    → Using MARGIN for quadrant splits instead")
                # Fall back to margin for splitting
                split_score = b_margin
                split_name = "margin"
            else:
                split_score = disagree
                split_name = "disagree"

            # Quantile thresholds
            stab_hi = torch.quantile(stability, 1.0 - frac)
            stab_lo = torch.quantile(stability, frac)
            bnd_hi = torch.quantile(split_score, 1.0 - frac)
            bnd_lo = torch.quantile(split_score, frac)

            quadrants = {
                "stable_interior":  (stability >= stab_hi) & (split_score <= bnd_lo),
                "stable_boundary":  (stability >= stab_hi) & (split_score >= bnd_hi),
                "unstable_interior": (stability <= stab_lo) & (split_score <= bnd_lo),
                "unstable_boundary": (stability <= stab_lo) & (split_score >= bnd_hi),
            }

            rng = np.random.RandomState(seed)

            sizes_str = " | ".join(f"{q}={int(m.sum())}" for q, m in quadrants.items())
            print(f"\n  [{dataset} s{seed}] split={split_name} n_target={n_target} "
                  f"quadrants: {sizes_str}")

            def _make_row(qname, idx_tensor):
                """Evaluate a subset and build the full row dict."""
                n_use = len(idx_tensor)
                if n_use < 5:
                    return {"dataset": dataset, "seed": seed, "quadrant": qname,
                            "n": 0, "n_used": 0, "acc": 0,
                            "mean_dist": 999, "p90_dist": 999,
                            "mean_stability": 0, "mean_boundary": 0,
                            "mean_entropy": 0, "mean_margin": 0,
                            "class_counts": "", "boundary_informative": boundary_informative,
                            "split_metric": split_name, "too_small": True}

                res = eval_subset(X_tr, y_tr, X_val, y_val, idx_tensor,
                                  graph_cfg, prop_cfg)
                cc = torch.bincount(y_tr[idx_tensor], minlength=n_classes)
                too_small = n_use < MIN_SUBSET
                if too_small:
                    print(f"    ⚠ {qname}: n={n_use} < {MIN_SUBSET} — results unreliable")
                return {
                    "dataset": dataset, "seed": seed, "quadrant": qname,
                    **res,
                    "n_used": n_use,
                    "mean_stability": stability[idx_tensor].mean().item(),
                    "mean_boundary": disagree[idx_tensor].mean().item(),
                    "mean_entropy": b_entropy[idx_tensor].mean().item(),
                    "mean_margin": b_margin[idx_tensor].mean().item(),
                    "class_counts": ",".join(str(c.item()) for c in cc),
                    "boundary_informative": boundary_informative,
                    "split_metric": split_name,
                    "too_small": too_small,
                }

            for qname, qmask in quadrants.items():
                n_q = int(qmask.sum())
                if n_q < 5:
                    rows.append(_make_row(qname, torch.tensor([])))
                    continue

                q_idx = qmask.nonzero(as_tuple=True)[0]
                # Use min(n_target, quadrant_size) — NOT min across quadrants
                n_use = min(n_target, n_q)
                rng_q = np.random.RandomState(seed + hash(qname) % 10000)
                perm = rng_q.permutation(n_q)[:n_use]
                rows.append(_make_row(qname, q_idx[perm]))

            # Random baseline at n_target (full target size, not min_size)
            rand_idx = torch.tensor(rng.choice(N, n_target, replace=False))
            rows.append(_make_row("random", rand_idx))

            # Full
            rows.append(_make_row("full", torch.arange(N)))

    # Summary
    print(f"\n{'Dataset':<16} {'Quadrant':<22} {'n':>5} {'Acc':>7} {'Cov':>7} "
          f"{'Stab':>6} {'Bnd':>6} {'Margin':>7}")
    print("-" * 82)
    by_dq = defaultdict(list)
    for r in rows:
        by_dq[(r["dataset"], r["quadrant"])].append(r)
    for (ds, q), rs in sorted(by_dq.items()):
        valid = [r for r in rs if r.get("acc", 0) > 0]
        if not valid:
            continue
        accs = [r["acc"] for r in valid]
        ns = [r.get("n_used", r.get("n", 0)) for r in valid]
        dists = [r["mean_dist"] for r in valid if r.get("mean_dist", 999) < 900]
        stabs = [r.get("mean_stability", 0) for r in valid]
        bnds = [r.get("mean_boundary", 0) for r in valid]
        mrgs = [r.get("mean_margin", 0) for r in valid]
        flag = " ⚠" if any(r.get("too_small") for r in valid) else ""
        print(f"{ds:<16} {q:<22} {int(np.mean(ns)):>5} {np.mean(accs):>7.4f} "
              f"{np.mean(dists) if dists else 999:>7.3f} "
              f"{np.mean(stabs):>6.3f} {np.mean(bnds):>6.3f} "
              f"{np.mean(mrgs):>7.3f}{flag}")

    _save_csv(rows, out_dir / "quadrant_subsets.csv")
    return rows


# ══════════════════════════════════════════════════════════════════════
# TEST 3: Boundary-prune vs Interior-prune vs Stability-prune
# ══════════════════════════════════════════════════════════════════════

def run_prune_comparison(datasets, seeds, k, out_dir, prop_steps=5, k_boundary=None):
    """Compare what happens when you remove boundary vs interior vs unstable."""
    print("\n" + "=" * 70)
    print("TEST 3: Prune Comparison (boundary vs interior vs stability)")
    print("=" * 70)

    rows = []
    graph_cfg = GraphBuilderConfig(type="knn", k=k)
    prop_cfg = PropagationConfig(type="random_walk", steps=prop_steps)
    fractions_remove = [0.0, 0.05, 0.1, 0.15, 0.2, 0.3, 0.4]

    for dataset in datasets:
        dd = DATASET_DEFAULTS.get(dataset, {})
        for seed in seeds:
            X_tr, y_tr, X_val, y_val, _, _, meta = load_dataset(
                dataset, seed, dd.get("n_train", 0),
                dd.get("n_val", 0), dd.get("n_test", 0),
            )
            N = len(X_tr)

            stability, _ = compute_stability(X_tr, graph_cfg, seed=seed)
            boundary = compute_boundary_scores(X_tr, y_tr, k=k, k_boundary=k_boundary)
            disagree = boundary["disagreement"]

            # Sort orders
            stab_remove_order = torch.argsort(stability)       # least stable first
            bnd_remove_order = torch.argsort(disagree, descending=True)  # most boundary first
            int_remove_order = torch.argsort(disagree)          # most interior first
            rng = np.random.RandomState(seed)
            rand_order = torch.tensor(rng.permutation(N))

            orders = {
                "stability_prune": stab_remove_order,
                "boundary_prune": bnd_remove_order,
                "interior_prune": int_remove_order,
                "random_prune": rand_order,
            }

            print(f"\n  [{dataset} s{seed}]")

            for frac_rm in fractions_remove:
                n_remove = int(N * frac_rm)
                n_keep = N - n_remove
                if n_keep < 10:
                    break

                for oname, order in orders.items():
                    keep_idx = order[n_remove:]  # remove first n_remove
                    res = eval_subset(X_tr, y_tr, X_val, y_val, keep_idx,
                                      graph_cfg, prop_cfg)

                    # What fraction of boundary nodes are retained?
                    n_bnd_top = max(int(N * 0.3), 5)
                    bnd_top_set = set(torch.argsort(disagree, descending=True)[:n_bnd_top].tolist())
                    kept_set = set(keep_idx.tolist())
                    bnd_retention = len(bnd_top_set & kept_set) / n_bnd_top

                    # Stability + boundary of retained set
                    mean_stab_kept = stability[keep_idx].mean().item()
                    mean_bnd_kept = disagree[keep_idx].mean().item()

                    row = {
                        "dataset": dataset, "seed": seed,
                        "prune_mode": oname,
                        "frac_removed": frac_rm,
                        "n_kept": n_keep,
                        "acc": res["acc"],
                        "mean_dist": res["mean_dist"],
                        "boundary_retention": bnd_retention,
                        "mean_stab_retained": mean_stab_kept,
                        "mean_boundary_retained": mean_bnd_kept,
                    }
                    rows.append(row)

                # Print compact
                accs = {o: [r for r in rows if r["dataset"] == dataset
                            and r["seed"] == seed and r["prune_mode"] == o
                            and abs(r["frac_removed"] - frac_rm) < 0.001]
                        for o in orders}
                parts = []
                for o in ["stability_prune", "boundary_prune", "interior_prune", "random_prune"]:
                    if accs[o]:
                        parts.append(f"{o[:4]}={accs[o][-1]['acc']:.4f}")
                print(f"    rm={frac_rm:.0%}: {' '.join(parts)}")

    # Summary
    print(f"\n{'Dataset':<16} {'Mode':<18} {'rm%':>4} {'Acc':>8} {'BndRet':>7}")
    print("-" * 58)
    by_dpm = defaultdict(list)
    for r in rows:
        by_dpm[(r["dataset"], r["prune_mode"], r["frac_removed"])].append(r)
    for (ds, pm, fr), rs in sorted(by_dpm.items()):
        accs = [r["acc"] for r in rs]
        brs = [r["boundary_retention"] for r in rs]
        print(f"{ds:<16} {pm:<18} {fr:>4.0%} {np.mean(accs):>8.4f} {np.mean(brs):>7.2f}")

    _save_csv(rows, out_dir / "prune_comparison.csv")
    return rows


# ══════════════════════════════════════════════════════════════════════
# TEST 4: Propagation step ablation
# ══════════════════════════════════════════════════════════════════════

def run_prop_ablation(datasets, seeds, k, out_dir, k_boundary=None):
    """How does propagation depth affect boundary vs stable subsets?"""
    print("\n" + "=" * 70)
    print("TEST 4: Propagation Step Ablation")
    print("=" * 70)

    rows = []
    graph_cfg = GraphBuilderConfig(type="knn", k=k)
    prop_steps_list = [0, 1, 3, 5, 10]

    for dataset in datasets:
        dd = DATASET_DEFAULTS.get(dataset, {})
        for seed in seeds:
            X_tr, y_tr, X_val, y_val, _, _, meta = load_dataset(
                dataset, seed, dd.get("n_train", 0),
                dd.get("n_val", 0), dd.get("n_test", 0),
            )
            N = len(X_tr)

            stability, _ = compute_stability(X_tr, graph_cfg, seed=seed)
            boundary = compute_boundary_scores(X_tr, y_tr, k=k, k_boundary=k_boundary)
            disagree = boundary["disagreement"]

            n_sel = max(int(N * 0.3), 10)
            subsets = {
                "top_stable": stratified_select(stability, y_tr, n_sel, top=True),
                "top_boundary": stratified_select(disagree, y_tr, n_sel, top=True),
                "full": torch.arange(N),
            }
            rng = np.random.RandomState(seed)
            subsets["random"] = torch.tensor(rng.choice(N, n_sel, replace=False))

            for T in prop_steps_list:
                prop_cfg = PropagationConfig(type="random_walk", steps=T)
                for sname, idx in subsets.items():
                    res = eval_subset(X_tr, y_tr, X_val, y_val, idx,
                                      graph_cfg, prop_cfg)
                    rows.append({
                        "dataset": dataset, "seed": seed,
                        "prop_steps": T, "subset": sname,
                        "acc": res["acc"], "n": res["n"],
                    })

                parts = []
                for sn in ["top_stable", "top_boundary", "random", "full"]:
                    r = [r for r in rows if r["dataset"] == dataset
                         and r["seed"] == seed and r["prop_steps"] == T
                         and r["subset"] == sn]
                    if r:
                        parts.append(f"{sn[:5]}={r[-1]['acc']:.4f}")
                print(f"  [{dataset} s{seed} T={T}] {' '.join(parts)}")

    _save_csv(rows, out_dir / "prop_ablation.csv")
    return rows


# ══════════════════════════════════════════════════════════════════════
# TEST 5: Sigma sweep (is auto-sigma right?)
# ══════════════════════════════════════════════════════════════════════

def run_sigma_sweep(datasets, seeds, k, out_dir, prop_steps=5):
    """Sweep sigma to understand stability sensitivity."""
    print("\n" + "=" * 70)
    print("TEST 5: Sigma Sweep")
    print("=" * 70)

    rows = []
    graph_cfg = GraphBuilderConfig(type="knn", k=k)
    prop_cfg = PropagationConfig(type="random_walk", steps=prop_steps)

    for dataset in datasets:
        dd = DATASET_DEFAULTS.get(dataset, {})
        for seed in seeds:
            X_tr, y_tr, X_val, y_val, _, _, meta = load_dataset(
                dataset, seed, dd.get("n_train", 0),
                dd.get("n_val", 0), dd.get("n_test", 0),
            )
            N = len(X_tr)

            # Get auto sigma for reference
            graph = build_base_graph(X_tr, graph_cfg)
            ei = graph["edge_index"]
            edge_dists = (X_tr[ei[0]] - X_tr[ei[1]]).norm(dim=1)
            median_dist = edge_dists.median().item()
            feat_std = X_tr.std(dim=0).mean().item()

            # Sweep: fractions of median edge distance
            sigma_fracs = [0.01, 0.02, 0.05, 0.1, 0.2, 0.5]
            sigmas = [f * median_dist for f in sigma_fracs]

            print(f"\n  [{dataset} s{seed}] median_edge={median_dist:.4f} feat_std={feat_std:.4f}")

            for sf, sigma in zip(sigma_fracs, sigmas):
                stability, _ = compute_stability(X_tr, graph_cfg, sigma=sigma, seed=seed)

                s_mean = stability.mean().item()
                s_std = stability.std().item()
                s_spread = stability.max().item() - stability.min().item()

                # Quick subset test: top 20% stable vs random vs bottom 20%
                n_sel = max(int(N * 0.2), 10)
                top_idx = stratified_select(stability, y_tr, n_sel, top=True)
                bot_idx = stratified_select(stability, y_tr, n_sel, top=False)
                rng = np.random.RandomState(seed)
                rand_idx = torch.tensor(rng.choice(N, n_sel, replace=False))

                acc_top = eval_subset(X_tr, y_tr, X_val, y_val, top_idx,
                                      graph_cfg, prop_cfg)["acc"]
                acc_bot = eval_subset(X_tr, y_tr, X_val, y_val, bot_idx,
                                      graph_cfg, prop_cfg)["acc"]
                acc_rand = eval_subset(X_tr, y_tr, X_val, y_val, rand_idx,
                                       graph_cfg, prop_cfg)["acc"]

                row = {
                    "dataset": dataset, "seed": seed,
                    "sigma_frac": sf, "sigma": sigma,
                    "stab_mean": s_mean, "stab_std": s_std, "stab_spread": s_spread,
                    "acc_top": acc_top, "acc_bottom": acc_bot, "acc_random": acc_rand,
                    "delta_top_rand": acc_top - acc_rand,
                    "delta_top_bot": acc_top - acc_bot,
                }
                rows.append(row)

                print(f"    σ={sf:.0%}×med ({sigma:.4f}): "
                      f"spread={s_spread:.3f} "
                      f"top={acc_top:.4f} rand={acc_rand:.4f} bot={acc_bot:.4f} "
                      f"Δ(top-rand)={acc_top-acc_rand:+.4f}")

    # Summary: best sigma per dataset
    print(f"\n{'Dataset':<16} {'Best σ_frac':>10} {'Spread':>8} {'Δ(top-rand)':>12}")
    print("-" * 50)
    by_ds = defaultdict(list)
    for r in rows:
        by_ds[r["dataset"]].append(r)
    for ds, rs in sorted(by_ds.items()):
        # Average delta per sigma_frac
        by_sf = defaultdict(list)
        for r in rs:
            by_sf[r["sigma_frac"]].append(r["delta_top_rand"])
        best_sf = max(by_sf.keys(), key=lambda sf: np.mean(by_sf[sf]))
        best_delta = np.mean(by_sf[best_sf])
        best_spread = np.mean([r["stab_spread"] for r in rs if r["sigma_frac"] == best_sf])
        print(f"{ds:<16} {best_sf:>10.0%} {best_spread:>8.3f} {best_delta:>+12.4f}")

    _save_csv(rows, out_dir / "sigma_sweep.csv")
    return rows


# ══════════════════════════════════════════════════════════════════════
# TEST 6: Raw vs propagated baseline (does propagation help at all?)
# ══════════════════════════════════════════════════════════════════════

def run_raw_vs_propagated(datasets, seeds, k, out_dir):
    """Baseline: ridge on raw features vs propagated, full vs subsets."""
    print("\n" + "=" * 70)
    print("TEST 6: Raw vs Propagated Baseline")
    print("=" * 70)

    rows = []
    graph_cfg = GraphBuilderConfig(type="knn", k=k)

    for dataset in datasets:
        dd = DATASET_DEFAULTS.get(dataset, {})
        for seed in seeds:
            X_tr, y_tr, X_val, y_val, _, _, meta = load_dataset(
                dataset, seed, dd.get("n_train", 0),
                dd.get("n_val", 0), dd.get("n_test", 0),
            )
            N = len(X_tr)
            n_classes = int(y_tr.max()) + 1

            # 1. Raw features, no propagation
            acc_raw = ridge_eval(X_tr, y_tr, X_val, y_val, n_classes=n_classes)

            # 2. Propagated features, full graph
            for T in [1, 3, 5, 10]:
                prop_cfg = PropagationConfig(type="random_walk", steps=T)
                graph = build_base_graph(X_tr, graph_cfg)
                h = propagate(X_tr, graph["edge_index"], graph["edge_weight"], N, prop_cfg)
                h_val = embed_queries_via_knn(h, X_tr, X_val, k=min(k, N))
                acc_prop = ridge_eval(h, y_tr, h_val, y_val, n_classes=n_classes)

                rows.append({
                    "dataset": dataset, "seed": seed,
                    "mode": f"propagated_T{T}", "acc": acc_prop,
                    "delta_vs_raw": acc_prop - acc_raw,
                })

            rows.append({
                "dataset": dataset, "seed": seed,
                "mode": "raw", "acc": acc_raw, "delta_vs_raw": 0.0,
            })

            print(f"  [{dataset} s{seed}] raw={acc_raw:.4f} " +
                  " ".join(f"T{r['mode'].split('T')[-1]}={r['acc']:.4f}"
                           for r in rows[-5:-1]))

    _save_csv(rows, out_dir / "raw_vs_propagated.csv")
    return rows


# ══════════════════════════════════════════════════════════════════════
# Utilities
# ══════════════════════════════════════════════════════════════════════

def _save_csv(rows, path):
    if not rows:
        return
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=rows[0].keys())
        writer.writeheader()
        writer.writerows(rows)
    print(f"  Saved: {path}")


def main():
    p = argparse.ArgumentParser(description="Stability Diagnostics")
    p.add_argument("--datasets", type=str, default="sk_moons,breast_cancer,digits")
    p.add_argument("--seeds", type=str, default="0,1,2")
    p.add_argument("--k", type=int, default=16)
    p.add_argument("--k_boundary", type=int, default=None,
                   help="k for boundary scoring (default: max(k*8, 128))")
    p.add_argument("--out", type=str, default="outputs/diagnostics")
    p.add_argument("--skip_corr", action="store_true")
    p.add_argument("--skip_quadrant", action="store_true")
    p.add_argument("--skip_prune", action="store_true")
    p.add_argument("--skip_prop", action="store_true")
    p.add_argument("--skip_sigma", action="store_true")
    p.add_argument("--skip_baseline", action="store_true")
    p.add_argument("--only", type=str, default=None,
                   help="Run ONLY this test: corr,quadrant,prune,prop,sigma,baseline")

    args = p.parse_args()
    datasets = [d.strip() for d in args.datasets.split(",")]
    seeds = [int(s) for s in args.seeds.split(",")]
    out = Path(args.out)

    print("=" * 70)
    print("STABILITY DIAGNOSTICS — Understanding What Matters")
    print(f"  Datasets:    {datasets}")
    print(f"  Seeds:       {seeds}")
    print(f"  k:           {args.k}")
    print(f"  k_boundary:  {args.k_boundary or 'auto (max(k*8,128))'}")
    print("-" * 70)
    print("DEFINITIONS:")
    print("  s_i  = stability: mean pairwise Jaccard of kNN neighbor sets under perturbation")
    print("  b_i  = disagreement: frac of k_boundary neighbors with different label")
    print("  H_i  = entropy: local label entropy over k_boundary neighbors")
    print("  m_i  = margin: dist(nearest_opp_class) - dist(nearest_same_class)")
    print("  cov  = coverage: mean dist from val points to nearest anchor in subset")
    print("=" * 70)

    # If --only is set, skip everything except that test
    run_all = args.only is None
    only = (args.only or "").lower()

    if (run_all and not args.skip_baseline) or only == "baseline":
        run_raw_vs_propagated(datasets, seeds, args.k, out)

    if (run_all and not args.skip_corr) or only == "corr":
        run_correlation_analysis(datasets, seeds, args.k, out,
                                 k_boundary=args.k_boundary)

    if (run_all and not args.skip_sigma) or only == "sigma":
        run_sigma_sweep(datasets, seeds, args.k, out)

    if (run_all and not args.skip_quadrant) or only == "quadrant":
        run_quadrant_test(datasets, seeds, args.k, out,
                         k_boundary=args.k_boundary)

    if (run_all and not args.skip_prune) or only == "prune":
        run_prune_comparison(datasets, seeds, args.k, out,
                             k_boundary=args.k_boundary)

    if (run_all and not args.skip_prop) or only == "prop":
        run_prop_ablation(datasets, seeds, args.k, out,
                          k_boundary=args.k_boundary)

    print(f"\n{'='*70}")
    print(f"All diagnostics saved to: {out}/")
    print(f"CSV files: correlation_table.csv, quadrant_subsets.csv,")
    print(f"           prune_comparison.csv, prop_ablation.csv,")
    print(f"           sigma_sweep.csv, raw_vs_propagated.csv")
    print(f"{'='*70}")


if __name__ == "__main__":
    main()
