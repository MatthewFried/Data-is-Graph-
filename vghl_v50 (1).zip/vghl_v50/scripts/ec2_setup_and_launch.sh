#!/bin/bash
# ══════════════════════════════════════════════════════════════════════
# VGHL EC2 Setup + Launch
# ══════════════════════════════════════════════════════════════════════
#
# EC2 Recommendation:
#   c6i.8xlarge  — 32 vCPU, 64 GB RAM, ~$1.36/hr (best value)
#   c6i.12xlarge — 48 vCPU, 96 GB RAM, ~$2.04/hr (if budget allows)
#   c6i.16xlarge — 64 vCPU, 128 GB RAM, ~$2.72/hr (overkill but fast)
#
#   NO GPU needed. This is all CPU: kNN, ridge regression, numpy.
#   More cores = more nohup jobs run simultaneously.
#
# Step 1: Launch EC2, SSH in
# Step 2: Upload vghl_v37.zip, run this script
# Step 3: All experiments launch as nohup background jobs
# Step 4: Check outputs/ in the morning
#
# Usage:
#   bash scripts/ec2_setup_and_launch.sh
#
# ══════════════════════════════════════════════════════════════════════

set -e
cd "$(dirname "$0")/.."
PROJECT_ROOT="$(pwd)"

echo "══════════════════════════════════════════════════════════════════════"
echo "  VGHL EC2 SETUP"
echo "  Project: $PROJECT_ROOT"
echo "══════════════════════════════════════════════════════════════════════"

# ── Step 1: Install dependencies ──────────────────────────────────────
echo ""
echo "▶ Installing Python dependencies..."
pip install --break-system-packages -q \
    torch torchvision numpy scipy scikit-learn 2>/dev/null || \
pip install -q torch torchvision numpy scipy scikit-learn

# Verify
python -c "import torch; import sklearn; print(f'torch={torch.__version__} sklearn={sklearn.__version__}')"

# ── Step 2: Cache ALL datasets (needs internet) ──────────────────────
echo ""
echo "▶ Caching all datasets..."
python -c "
import warnings; warnings.filterwarnings('ignore')
from sklearn.datasets import fetch_openml, fetch_20newsgroups
from torchvision import datasets
import os
root = os.path.expanduser('~/.cache/vghl_data')
os.makedirs(root, exist_ok=True)
print('  MNIST...'); datasets.MNIST(root, download=True)
print('  FashionMNIST...'); datasets.FashionMNIST(root, download=True)
print('  CIFAR-10...'); datasets.CIFAR10(root, download=True)
print('  20newsgroups train...'); fetch_20newsgroups(subset='train', remove=('headers','footers','quotes'))
print('  20newsgroups test...'); fetch_20newsgroups(subset='test', remove=('headers','footers','quotes'))
print('  adult (OpenML 1590)...'); fetch_openml(data_id=1590, as_frame=False, parser='liac-arff')
print('  heart (OpenML)...'); fetch_openml(name='heart-statlog', version=1, as_frame=False, parser='liac-arff')
print('  ✓ ALL DATASETS CACHED')
"

# ── Step 3: Quick smoke test ──────────────────────────────────────────
echo ""
echo "▶ Smoke test (single dataset, single seed)..."
python -u scripts/run_real_experiments.py --only geometry \
    --datasets breast_cancer --seeds 0 \
    --out outputs/smoke_test 2>&1 | tail -5

if [ $? -eq 0 ]; then
    echo "  ✓ Smoke test passed"
else
    echo "  ✗ Smoke test FAILED — fix before launching"
    exit 1
fi

# ── Step 4: Create output dirs ────────────────────────────────────────
mkdir -p outputs/logs
mkdir -p outputs/real_experiments
mkdir -p outputs/refinement
mkdir -p outputs/transfer
mkdir -p outputs/noise_injection

echo ""
echo "══════════════════════════════════════════════════════════════════════"
echo "  SETUP COMPLETE — Ready to launch experiments"
echo ""
echo "  Now paste the nohup commands from scripts/launch_all.sh"
echo "  or run: bash scripts/launch_all.sh"
echo "══════════════════════════════════════════════════════════════════════"
