#!/usr/bin/env python3
"""Rebuttal Experiment D: the mechanism as a quantitative, label-free predictor.

Response to GMYt's "the inversion is a known property of the operator":
if random-walk contraction is the classical mechanism, then it makes a
quantitative prediction that can FAIL: per-dataset collapse magnitude should
be predicted by a substrate statistic computed WITHOUT labels and WITHOUT
any training or readout. This script computes, for every dataset:

  retention(G) = ||C P^tau X||_F / ||C X||_F     (C = column-centering)

a norm-ratio retention statistic (not guaranteed to lie in [0,1] in
general) that is a pure function of (graph, features): no labels, no
classifier. v45: the predictor's randomized graph uses an INDEPENDENT null
draw (seed offset 7777) from the accuracy intervention's draw (offset 555),
removing the mechanical coupling of sharing one random graph between
predictor and outcome. Predictions tested:

  P1: collapse := acc(full) - acc(random_edges) correlates strongly
      (Spearman) with retention(real) - retention(random) across datasets.
  P2: eigenvector-label alignment R^2 (top-8) drops on destroyed graphs
      on every dataset (extends paper Table 2 from 5 to all datasets).

A refuter for the account: a dataset with high retention gap but no
collapse, or low retention gap with large collapse (rank-order violation
driving Spearman below ~0.7).

Usage:
  python -u scripts/rebuttal_spectral_predictor.py
  python -u scripts/rebuttal_spectral_predictor.py --datasets digits,iris --seeds 0,1
"""
import os, sys
os.environ.setdefault("OMP_NUM_THREADS", "1")
os.environ.setdefault("MKL_NUM_THREADS", "1")

import argparse
import numpy as np
import torch
from pathlib import Path
from collections import defaultdict

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))
sys.path.insert(0, os.path.dirname(__file__))

from run_real_experiments import (  # noqa: E402
    DATASETS, load_dataset, get_k, _save_csv, eval_pipeline, eval_pipeline_edges,
)
from vghl.models.graph_builder import build_base_graph, GraphBuilderConfig  # noqa: E402
from vghl.models.propagation import propagate, PropagationConfig  # noqa: E402

DEFAULT_DATASETS = [d for d in DATASETS if d != "cora"]  # cora: phi fails a priori


def make_random_edges(N, E, seed):
    rng = np.random.RandomState(seed + 555)
    src = torch.tensor(rng.randint(0, N, E), dtype=torch.long)
    dst = torch.tensor(rng.randint(0, N, E), dtype=torch.long)
    valid = src != dst
    return torch.stack([src[valid], dst[valid]]), torch.ones(int(valid.sum()))


def retention(X, ei, ew, tau):
    """Label-free: fraction of (centered) feature variance surviving P^tau."""
    N = X.shape[0]
    H = propagate(X, ei, ew, N, PropagationConfig(type="random_walk", steps=tau))
    Xc = X - X.mean(dim=0, keepdim=True)
    Hc = H - H.mean(dim=0, keepdim=True)
    return (Hc.norm() / Xc.norm().clamp(min=1e-12)).item()


def eig_label_r2(X, y, ei, ew, n_modes=8, iters=300, seed=0):
    """R^2 of centered one-hot labels regressed on the dominant n_modes-dim
    invariant subspace of the symmetric normalized operator
    S = D^-1/2 (A+I) D^-1/2 (same spectrum as the random walk).

    Computed by orthogonal (subspace) iteration rather than ARPACK: the top
    eigenvalues of these kNN operators are extremely clustered (gaps ~1e-4),
    which stalls Lanczos, while the *span* -- the only thing R^2 depends on
    -- converges under subspace iteration regardless of within-cluster
    rotation. This span is exactly the mode set propagation preserves.
    """
    import scipy.sparse as sp
    N = X.shape[0]
    src_i, dst_i = ei[0].numpy(), ei[1].numpy()
    w = ew.numpy().astype(np.float64)
    A = sp.coo_matrix((w, (src_i, dst_i)), shape=(N, N))
    A = (A + A.T) * 0.5
    A = A + sp.eye(N)
    deg = np.asarray(A.sum(axis=1)).flatten().clip(min=1e-12)
    Dm = sp.diags(deg ** -0.5)
    S = (Dm @ A @ Dm).tocsr()

    k = min(n_modes, N - 2)
    rng = np.random.RandomState(seed)
    Q, _ = np.linalg.qr(rng.randn(N, k))
    prev = None
    for _ in range(iters):
        Q, R = np.linalg.qr(S @ Q)
        ritz = np.sort(np.abs(np.diag(R)))[::-1]
        if prev is not None and np.max(np.abs(ritz - prev)) < 1e-8:
            break
        prev = ritz

    nc = int(y.max()) + 1
    Y = np.zeros((N, nc)); Y[np.arange(N), y.numpy()] = 1.0
    Yc = Y - Y.mean(axis=0, keepdims=True)
    beta, *_ = np.linalg.lstsq(Q, Yc, rcond=None)
    resid = Yc - Q @ beta
    ss_tot = (Yc ** 2).sum()
    return float(1 - (resid ** 2).sum() / max(ss_tot, 1e-12))


def run(datasets, seeds, tau, out_dir):
    out_dir = Path(out_dir)
    rows = []
    for ds in datasets:
        k = get_k(ds)
        for seed in seeds:
            try:
                X_tr, y_tr, X_val, y_val, X_te, y_te, _ = load_dataset(ds, seed)
            except Exception as e:
                print(f"  SKIP {ds} s{seed}: {e}", flush=True)
                continue
            N = len(X_tr)
            k_eff = min(k, N - 1)
            gc = GraphBuilderConfig(type="knn", k=k_eff)
            pc = PropagationConfig(type="random_walk", steps=tau)
            g = build_base_graph(X_tr, gc)
            ei, ew = g["edge_index"], g["edge_weight"]
            # outcome intervention draw
            ei_r, ew_r = make_random_edges(N, ei.shape[1], seed)
            # INDEPENDENT null draw for the predictor
            ei_p, ew_p = make_random_edges(N, ei.shape[1], seed + 7222)

            acc_full, _ = eval_pipeline(X_tr, y_tr, X_te, y_te, gc, pc)
            acc_rand, _ = eval_pipeline_edges(X_tr, y_tr, X_te, y_te, ei_r, ew_r, gc, pc)

            rows.append({
                "dataset": ds, "seed": seed, "N": N,
                "acc_full": acc_full, "acc_random": acc_rand,
                "collapse": acc_full - acc_rand,
                "retention_real": retention(X_tr, ei, ew, tau),
                "retention_random": retention(X_tr, ei_p, ew_p, tau),
                "r2_real": eig_label_r2(X_tr, y_tr, ei, ew),
                "r2_random": eig_label_r2(X_tr, y_tr, ei_p, ew_p),
            })
        print(f"  {ds}: done", flush=True)

    by = defaultdict(list)
    for r in rows:
        by[r["dataset"]].append(r)
    agg = []
    for ds, rs in by.items():
        m = lambda f: float(np.mean([r[f] for r in rs]))
        agg.append({"dataset": ds, **{f: m(f) for f in
                    ["collapse", "retention_real", "retention_random",
                     "r2_real", "r2_random", "acc_full", "acc_random"]}})

    hdr = (f"{'Dataset':<20} {'collapse':>9} {'ret_real':>9} {'ret_rand':>9} "
           f"{'R2_real':>8} {'R2_rand':>8}")
    print("\n" + hdr); print("-" * len(hdr))
    for a in sorted(agg, key=lambda r: -r["collapse"]):
        print(f"{a['dataset']:<20} {a['collapse']:>+9.3f} {a['retention_real']:>9.3f} "
              f"{a['retention_random']:>9.3f} {a['r2_real']:>8.3f} {a['r2_random']:>8.3f}")

    from scipy import stats as sst
    c = np.array([a["collapse"] for a in agg])
    gap = np.array([a["retention_real"] - a["retention_random"] for a in agg])
    r2g = np.array([a["r2_real"] - a["r2_random"] for a in agg])
    rho1 = sst.spearmanr(gap, c)
    rho2 = sst.spearmanr(r2g, c)
    print(f"\nP1  Spearman(retention gap [label-free, readout-free], collapse) = "
          f"{rho1.statistic:.3f} (p={rho1.pvalue:.2e}, n={len(c)})")
    print(f"P2  Spearman(R2 alignment gap [uses labels],          collapse) = "
          f"{rho2.statistic:.3f} (p={rho2.pvalue:.2e})")
    if len(c) >= 4:
        lodo = [sst.spearmanr(np.delete(gap, i), np.delete(c, i)).statistic
                for i in range(len(c))]
        print(f"P1  leave-one-dataset-out range: [{min(lodo):.3f}, {max(lodo):.3f}]")
    print("Refuter check (pre-specified before the full-roster run): the "
          "account fails if Spearman(P1) < 0.7 on the full roster, or any "
          "dataset shows a high retention gap with no collapse (inspect table).")
    print("Interpret only on the full dataset roster: the correlation needs "
          "the low-collapse datasets for variance.")
    _save_csv(rows, out_dir / "rebuttal_spectral_predictor.csv")
    return rows


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--datasets", type=str, default=None)
    p.add_argument("--seeds", type=str, default="0,1,2")
    p.add_argument("--tau", type=int, default=5)
    p.add_argument("--out", type=str, default="outputs/rebuttal")
    a = p.parse_args()
    ds = a.datasets.split(",") if a.datasets else DEFAULT_DATASETS
    ds = [d for d in ds if d in DATASETS]
    run(ds, [int(s) for s in a.seeds.split(",")], a.tau, a.out)


if __name__ == "__main__":
    main()
