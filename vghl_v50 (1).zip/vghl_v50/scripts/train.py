#!/usr/bin/env python3
"""VGHL Training CLI v2. All CLI args override config file values."""
import argparse, sys, os

# Thread guards to prevent OpenMP/MKL deadlocks on WSL/Linux (before any imports)
os.environ.setdefault("OMP_NUM_THREADS", "1")
os.environ.setdefault("MKL_NUM_THREADS", "1")

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))
from vghl.utils.config import ExperimentConfig
from vghl.utils.seed import set_seed
from vghl.utils.logging import get_logger
from vghl.data.loaders import build_datasets, build_dataloaders
from vghl.models.vghl_model import build_model
from vghl.train.trainer import Trainer
from vghl.train.eval import evaluate_model
logger = get_logger("vghl.main")

def parse_args():
    p = argparse.ArgumentParser(description="VGHL Training v2")
    # Meta
    p.add_argument("--config", type=str, default=None)
    p.add_argument("--name", type=str, default=None)
    p.add_argument("--seed", type=int, default=None)
    p.add_argument("--out", type=str, default=None)
    p.add_argument("--device", type=str, default=None)
    p.add_argument("--model", type=str, default=None, choices=["vghl","mlp","point_gnn","fixed_cluster_gnn"])
    # Data
    p.add_argument("--dataset", type=str, default=None)
    p.add_argument("--n_train", type=int, default=None)
    p.add_argument("--n_val", type=int, default=None)
    p.add_argument("--n_test", type=int, default=None)
    p.add_argument("--d", type=int, default=None)
    p.add_argument("--noise_sigma", type=float, default=None)
    p.add_argument("--label_noise", type=float, default=None)
    p.add_argument("--n_classes", type=int, default=None)
    p.add_argument("--grid_size", type=int, default=None)
    # Embed
    p.add_argument("--embed", type=str, default=None, choices=["identity","mlp"])
    p.add_argument("--embed_dim", type=int, default=None)
    # Partition
    p.add_argument("--m", type=int, default=None)
    p.add_argument("--L", type=int, default=None)
    p.add_argument("--temps", type=str, default=None)
    p.add_argument("--temp_mode", type=str, default=None, choices=["fixed","learnable","anneal"])
    p.add_argument("--temp_anneal_start", type=float, default=None)
    p.add_argument("--temp_anneal_end", type=float, default=None)
    p.add_argument("--temp_anneal_epochs", type=int, default=None)
    p.add_argument("--distance", type=str, default=None)
    p.add_argument("--init_sites", type=str, default=None)
    # Point graph (NEW)
    p.add_argument("--point_graph", action="store_true", default=None, dest="point_graph_enabled")
    p.add_argument("--no_point_graph", action="store_false", dest="point_graph_enabled")
    p.add_argument("--point_k", type=int, default=None)
    p.add_argument("--point_mp_layers", type=int, default=None)
    p.add_argument("--point_gnn_type", type=str, default=None, choices=["gcn","sage","gat"])
    p.add_argument("--modulate_edges", action="store_true", default=None, dest="modulate_edges")
    p.add_argument("--no_modulate_edges", action="store_false", dest="modulate_edges")
    # Boundary (NEW)
    p.add_argument("--boundary_mode", type=str, default=None, choices=["none","entropy","margin"])
    p.add_argument("--boundary_threshold", type=float, default=None)
    p.add_argument("--boundary_frac", type=float, default=None)
    p.add_argument("--lambda_boundary", type=float, default=None)
    p.add_argument("--boundary_loss", type=str, default=None, choices=["consistency","contrastive","laplacian"])
    p.add_argument("--ii_weight", type=float, default=None, help="interior-interior edge weight")
    p.add_argument("--bb_weight", type=float, default=None, help="boundary-boundary edge weight")
    p.add_argument("--bi_weight", type=float, default=None, help="boundary-interior edge weight")
    # Confidence (noise suppression)
    p.add_argument("--confidence_mode", type=str, default=None, choices=["none","entropy","drift","entropy+drift"])
    p.add_argument("--confidence_scales", type=str, default=None, help="comma list or 'all'")
    p.add_argument("--confidence_beta_entropy", type=float, default=None)
    p.add_argument("--confidence_beta_drift", type=float, default=None)
    p.add_argument("--confidence_alpha_min", type=float, default=None)
    p.add_argument("--confidence_warmup", type=int, default=None)
    p.add_argument("--confidence_detach", action="store_true", default=None)
    p.add_argument("--confidence_apply_pullback", action="store_true", default=None)
    p.add_argument("--confidence_apply_pooling", action="store_true", default=None)
    p.add_argument("--no_confidence_apply_pooling", action="store_false", dest="confidence_apply_pooling")
    p.add_argument("--confidence_apply_task_loss", action="store_true", default=None)
    p.add_argument("--no_confidence_apply_task_loss", action="store_false", dest="confidence_apply_task_loss")
    p.add_argument("--confidence_task_scale", type=int, default=None)
    # Noise (perturbation system)
    p.add_argument("--noise_enabled", action="store_true", default=None)
    p.add_argument("--no_noise", action="store_false", dest="noise_enabled")
    p.add_argument("--pert_sigma", type=float, default=None)
    p.add_argument("--noise_schedule", type=str, default=None, choices=["constant","linear_anneal","cosine"])
    p.add_argument("--noise_samples", type=int, default=None)
    p.add_argument("--noise_per_point_mode", type=str, default=None, choices=["global","boundary_weighted"])
    p.add_argument("--noise_boundary_kappa", type=float, default=None)
    p.add_argument("--sigma_boundary_cap", type=float, default=None)
    p.add_argument("--kappa_warmup", type=int, default=None)
    p.add_argument("--sigma_warmup", type=int, default=None)
    p.add_argument("--boundary_mask_mode", type=str, default=None, choices=["threshold","quantile","topk"])
    p.add_argument("--boundary_quantile", type=float, default=None)
    p.add_argument("--boundary_topk_frac", type=float, default=None)
    # Stability
    p.add_argument("--stability_enabled", action="store_true", default=None)
    p.add_argument("--no_stability", action="store_false", dest="stability_enabled")
    p.add_argument("--stability_target", type=str, default=None, choices=["clean","mean_perturbed","teacher_clean"])
    p.add_argument("--stability_divergence", type=str, default=None, choices=["l1","l2","kl"])
    p.add_argument("--stability_scales", type=str, default=None)
    p.add_argument("--stability_weight", type=float, default=None)
    p.add_argument("--stability_warmup", type=int, default=None)
    # Anti-uniform assignment
    p.add_argument("--lambda_assign_entropy", type=float, default=None)
    p.add_argument("--lambda_assign_sharp", type=float, default=None)
    # Geometry regularizers
    p.add_argument("--lambda_conn", type=float, default=None)
    p.add_argument("--conn_epsilon", type=float, default=None)
    p.add_argument("--lambda_lap_smooth", type=float, default=None)
    # EMA teacher
    p.add_argument("--ema_enabled", action="store_true", default=None)
    p.add_argument("--no_ema", action="store_false", dest="ema_enabled")
    p.add_argument("--ema_decay", type=float, default=None)
    # Region graph
    p.add_argument("--region_graph", type=str, default=None, choices=["coact","site_knn","both","boundary_mass","soft_kernel"])
    p.add_argument("--region_k", type=int, default=None)
    p.add_argument("--graph_refresh", type=str, default=None)
    p.add_argument("--pool_mode", type=str, default=None, choices=["soft","top1","topk"])
    p.add_argument("--min_degree", type=int, default=None)
    # GNN
    p.add_argument("--gnn_type", type=str, default=None, choices=["gcn","sage","gat"])
    p.add_argument("--gnn_layers", type=int, default=None)
    p.add_argument("--gat_heads", type=int, default=None)
    p.add_argument("--edge_mask", action="store_true", default=None)
    p.add_argument("--no_edge_mask", action="store_false", dest="edge_mask")
    p.add_argument("--consensus_gate", action="store_true", default=None)
    p.add_argument("--no_consensus_gate", action="store_false", dest="consensus_gate")
    p.add_argument("--consensus_tau", type=float, default=None)
    # Losses
    p.add_argument("--lambda_balance", type=float, default=None)
    p.add_argument("--lambda_stab", type=float, default=None)
    p.add_argument("--stab_scales", type=str, default=None)
    p.add_argument("--stab_noise_sigma", type=float, default=None)
    p.add_argument("--lambda_ent", type=float, default=None)
    p.add_argument("--lambda_smooth", type=float, default=None)
    p.add_argument("--lambda_cut", type=float, default=None)
    p.add_argument("--lambda_edge_l1", type=float, default=None)
    p.add_argument("--lambda_within_label", type=float, default=None)
    # Training
    p.add_argument("--epochs", type=int, default=None)
    p.add_argument("--batch_size", type=int, default=None)
    p.add_argument("--lr", type=float, default=None)
    p.add_argument("--weight_decay", type=float, default=None)
    p.add_argument("--optimizer", type=str, default=None, choices=["adam","adamw","sgd"])
    p.add_argument("--scheduler", type=str, default=None, choices=["none","cosine","step","plateau"])
    p.add_argument("--grad_clip", type=float, default=None)
    p.add_argument("--early_stop_patience", type=int, default=None)
    # Performance (NEW)
    p.add_argument("--amp", action="store_true", default=None)
    p.add_argument("--no_amp", action="store_false", dest="amp")
    p.add_argument("--accum_steps", type=int, default=None)
    p.add_argument("--torch_compile", action="store_true", default=None)
    p.add_argument("--num_workers", type=int, default=None)
    p.add_argument("--torch_threads", type=int, default=None, help="Set torch.set_num_threads")
    p.add_argument("--max_steps", type=int, default=None, help="Stop after N train batches (for smoke tests)")
    p.add_argument("--no_init_sites", action="store_true", help="Skip site initialization")
    p.add_argument("--profile", action="store_true", help="Print timing breakdown per epoch")
    # Logging
    p.add_argument("--no_tb", action="store_true")
    p.add_argument("--no_plots", action="store_true")
    p.add_argument("--quiet", action="store_true")
    p.add_argument("--save_artifacts", action="store_true", default=None)
    return p.parse_args()

def apply_cli(cfg, args):
    model_name = args.model or "vghl"
    # Simple top-level
    for attr in ["name","seed","device"]:
        v = getattr(args, attr, None)
        if v is not None: setattr(cfg, attr, v)
    if args.out is not None: cfg.out_dir = args.out
    # Data
    for attr in ["dataset","n_train","n_val","n_test","d","noise_sigma","label_noise","n_classes","grid_size"]:
        v = getattr(args, attr, None)
        if v is not None: setattr(cfg.data, attr, v)
    # Embed
    if args.embed is not None: cfg.embed.mode = args.embed
    if args.embed_dim is not None: cfg.embed.embed_dim = args.embed_dim
    # Partition
    if args.m is not None: cfg.partition.m = args.m
    if args.L is not None: cfg.partition.L = args.L
    if args.temps is not None: cfg.partition.temps = [float(x) for x in args.temps.split(",")]
    if args.temp_mode is not None: cfg.partition.temp_mode = args.temp_mode
    if args.temp_anneal_start is not None: cfg.partition.temp_anneal_start = args.temp_anneal_start
    if args.temp_anneal_end is not None: cfg.partition.temp_anneal_end = args.temp_anneal_end
    if args.temp_anneal_epochs is not None: cfg.partition.temp_anneal_epochs = args.temp_anneal_epochs
    if args.distance is not None: cfg.partition.distance = args.distance
    if args.init_sites is not None: cfg.partition.init_sites = args.init_sites
    # Point graph
    if args.point_graph_enabled is not None: cfg.point_graph.enabled = args.point_graph_enabled
    if args.point_k is not None: cfg.point_graph.k = args.point_k
    if args.point_mp_layers is not None: cfg.point_graph.layers = args.point_mp_layers
    if args.point_gnn_type is not None: cfg.point_graph.type = args.point_gnn_type
    if args.modulate_edges is not None: cfg.point_graph.modulate_edges = args.modulate_edges
    # Boundary
    if args.boundary_mode is not None: cfg.boundary.mode = args.boundary_mode
    if args.boundary_threshold is not None: cfg.boundary.threshold = args.boundary_threshold
    if args.boundary_frac is not None: cfg.boundary.frac = args.boundary_frac
    if args.lambda_boundary is not None: cfg.boundary.lambda_boundary = args.lambda_boundary
    if args.boundary_loss is not None: cfg.boundary.boundary_loss = args.boundary_loss
    if args.ii_weight is not None: cfg.boundary.interior_interior_weight = args.ii_weight
    if args.bb_weight is not None: cfg.boundary.boundary_boundary_weight = args.bb_weight
    if args.bi_weight is not None: cfg.boundary.boundary_interior_weight = args.bi_weight
    # Confidence
    if args.confidence_mode is not None: cfg.confidence.mode = args.confidence_mode
    if args.confidence_scales is not None: cfg.confidence.scales = args.confidence_scales
    if args.confidence_beta_entropy is not None: cfg.confidence.beta_entropy = args.confidence_beta_entropy
    if args.confidence_beta_drift is not None: cfg.confidence.beta_drift = args.confidence_beta_drift
    if args.confidence_alpha_min is not None: cfg.confidence.alpha_min = args.confidence_alpha_min
    if args.confidence_warmup is not None: cfg.confidence.warmup_epochs = args.confidence_warmup
    if args.confidence_detach is not None: cfg.confidence.detach = args.confidence_detach
    if args.confidence_apply_pullback is not None: cfg.confidence.apply_pullback = args.confidence_apply_pullback
    if args.confidence_apply_pooling is not None: cfg.confidence.apply_pooling = args.confidence_apply_pooling
    if args.confidence_apply_task_loss is not None: cfg.confidence.apply_task_loss = args.confidence_apply_task_loss
    if args.confidence_task_scale is not None: cfg.confidence.task_scale = args.confidence_task_scale
    # Noise
    if args.noise_enabled is not None: cfg.noise.enabled = args.noise_enabled
    if args.pert_sigma is not None: cfg.noise.sigma = args.pert_sigma
    if args.noise_schedule is not None: cfg.noise.schedule = args.noise_schedule
    if args.noise_samples is not None: cfg.noise.samples = args.noise_samples
    if args.noise_per_point_mode is not None: cfg.noise.per_point_mode = args.noise_per_point_mode
    if args.noise_boundary_kappa is not None: cfg.noise.boundary_kappa = args.noise_boundary_kappa
    if args.sigma_boundary_cap is not None: cfg.noise.sigma_boundary_cap = args.sigma_boundary_cap
    if args.kappa_warmup is not None: cfg.noise.kappa_warmup_epochs = args.kappa_warmup
    if args.sigma_warmup is not None: cfg.noise.sigma_warmup_epochs = args.sigma_warmup
    if args.boundary_mask_mode is not None: cfg.noise.boundary_mask_mode = args.boundary_mask_mode
    if args.boundary_quantile is not None: cfg.noise.boundary_quantile = args.boundary_quantile
    if args.boundary_topk_frac is not None: cfg.noise.boundary_topk_frac = args.boundary_topk_frac
    # Stability
    if args.stability_enabled is not None: cfg.stability.enabled = args.stability_enabled
    if args.stability_target is not None: cfg.stability.target = args.stability_target
    if args.stability_divergence is not None: cfg.stability.divergence = args.stability_divergence
    if args.stability_scales is not None: cfg.stability.scales = args.stability_scales
    if args.stability_weight is not None: cfg.stability.weight = args.stability_weight
    if args.stability_warmup is not None: cfg.stability.warmup_epochs = args.stability_warmup
    # Anti-uniform
    if args.lambda_assign_entropy is not None: cfg.loss.lambda_assign_entropy = args.lambda_assign_entropy
    if args.lambda_assign_sharp is not None: cfg.loss.lambda_assign_sharp = args.lambda_assign_sharp
    # EMA teacher
    if args.ema_enabled is not None: cfg.ema_teacher.enabled = args.ema_enabled
    if args.ema_decay is not None: cfg.ema_teacher.decay = args.ema_decay
    # Region graph
    if args.region_graph is not None: cfg.region_graph.method = args.region_graph
    if args.region_k is not None: cfg.region_graph.K = args.region_k
    if args.graph_refresh is not None: cfg.region_graph.graph_refresh = args.graph_refresh
    if args.pool_mode is not None: cfg.region_graph.pool_mode = args.pool_mode
    if args.min_degree is not None: cfg.region_graph.min_degree = args.min_degree
    # Geometry regularizers
    if args.lambda_conn is not None: cfg.loss.lambda_conn = args.lambda_conn
    if args.conn_epsilon is not None: cfg.loss.conn_epsilon = args.conn_epsilon
    if args.lambda_lap_smooth is not None: cfg.loss.lambda_lap_smooth = args.lambda_lap_smooth
    # GNN
    if args.gnn_type is not None: cfg.gnn.type = args.gnn_type
    if args.gnn_layers is not None: cfg.gnn.layers = args.gnn_layers
    if args.gat_heads is not None: cfg.gnn.gat_heads = args.gat_heads
    if args.edge_mask is not None: cfg.gnn.edge_mask = args.edge_mask
    if args.consensus_gate is not None: cfg.gnn.consensus_gate = args.consensus_gate
    if args.consensus_tau is not None: cfg.gnn.consensus_tau = args.consensus_tau
    # Losses
    for attr in ["lambda_balance","lambda_stab","stab_noise_sigma","lambda_ent","lambda_smooth",
                 "lambda_cut","lambda_edge_l1","lambda_within_label"]:
        v = getattr(args, attr, None)
        if v is not None: setattr(cfg.loss, attr, v)
    if args.stab_scales is not None: cfg.loss.stab_scales = args.stab_scales
    # Training
    for attr in ["epochs","batch_size","lr","weight_decay","optimizer","scheduler","grad_clip","early_stop_patience"]:
        v = getattr(args, attr, None)
        if v is not None: setattr(cfg.train, attr, v)
    # Performance
    if args.amp is not None: cfg.train.amp = args.amp
    if args.accum_steps is not None: cfg.train.accum_steps = args.accum_steps
    if args.torch_compile is not None: cfg.train.torch_compile = args.torch_compile
    if args.num_workers is not None: cfg.num_workers = args.num_workers
    # Logging
    if args.no_tb: cfg.log.tensorboard = False
    if args.no_plots: cfg.log.save_plots = False
    if args.quiet: cfg.log.verbose = False
    if args.save_artifacts is not None: cfg.log.save_artifacts = args.save_artifacts
    # Auto-name
    if cfg.name == "default" and args.name is None:
        pg = "pg" if cfg.point_graph.enabled else "nopg"
        cfg.name = f"{model_name}_{cfg.data.dataset}_m{cfg.partition.m}_L{cfg.partition.L}_{pg}_s{cfg.seed}"
    return cfg, model_name

def main():
    args = parse_args()
    cfg = ExperimentConfig.load(args.config) if args.config else ExperimentConfig()
    cfg, model_name = apply_cli(cfg, args)

    # Thread control
    if args.torch_threads is not None:
        import torch
        torch.set_num_threads(args.torch_threads)

    set_seed(cfg.seed)
    device = cfg.resolve_device()
    logger.info(f"Config: {cfg.name} | Device: {device}")
    cfg.save()

    train_ds, val_ds, test_ds, meta = build_datasets(cfg)
    train_loader, val_loader, test_loader = build_dataloaders(train_ds, val_ds, test_ds, cfg)
    input_dim = meta.get("d", train_ds.X.shape[1])
    n_classes = meta.get("n_classes", cfg.data.n_classes)
    logger.info(f"Data: {len(train_ds)} train | dim={input_dim}, classes={n_classes}")

    model = build_model(model_name, input_dim, n_classes, cfg).to(device)
    if hasattr(model, "init_sites") and not args.no_init_sites:
        logger.info(f"Initializing sites ({cfg.partition.init_sites})...")
        model.init_sites(train_loader, device)

    trainer = Trainer(model, cfg, train_loader, val_loader, test_loader, n_classes, device)
    trainer.max_steps = args.max_steps  # None means unlimited
    trainer.profile = getattr(args, "profile", False)
    train_results = trainer.train()
    logger.info(f"Done. Best epoch: {train_results['best_epoch']}")

    logger.info("Final test eval...")
    best_epoch = train_results.get("best_epoch", cfg.train.epochs - 1)
    evaluate_model(model, test_loader, cfg, device, n_classes,
                   save_path=str(cfg.run_dir / "eval.json"),
                   compute_structural=(model_name in ("vghl", "fixed_cluster_gnn")),
                   epoch=best_epoch)
    logger.info(f"Outputs: {cfg.run_dir}")

if __name__ == "__main__":
    main()
