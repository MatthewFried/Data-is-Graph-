#!/bin/bash
# VGHL Meta-Analysis: When does geometry help?
# Runs all datasets with meta-feature computation + correlation analysis
set -e
export PYTHONUNBUFFERED=1
export OMP_NUM_THREADS=8
export MKL_NUM_THREADS=8
cd "$(dirname "$0")/.."
mkdir -p outputs/meta_analysis

echo "$(date) === META-ANALYSIS START ==="

# Phase 1: Existing 20 datasets (fast, ~15 min)
echo "$(date) === Phase 1: existing datasets ==="
python -u scripts/meta_analysis.py --only existing --seeds 0,1,2

# Phase 2: New OpenML datasets (may need network for first download)
echo "$(date) === Phase 2: new OpenML datasets ==="
python -u scripts/meta_analysis.py --only new_openml --seeds 0,1,2

# Phase 3: Large embedding datasets (CIFAR-100, SVHN, STL-10 — needs GPU for extraction)
echo "$(date) === Phase 3: large embedding datasets ==="
python -u scripts/meta_analysis.py --only large_embed --seeds 0,1,2

# Phase 4: Full combined analysis
echo "$(date) === Phase 4: full combined ==="
python -u scripts/meta_analysis.py --only all --seeds 0,1,2

echo "$(date) === META-ANALYSIS COMPLETE ==="
echo "Results: outputs/meta_analysis/meta_analysis.csv"
