#!/usr/bin/env python3
"""Geometric Machine Sweep Runner.

Runs Phase 1 coarse exploration: sweep graph constructors × operators × datasets.
Collects all results into a single CSV for analysis.

Usage:
    python scripts/sweep_gm.py --sweep experiments/configs/gm_sweeps/phase1_moons.yaml
    python scripts/sweep_gm.py --sweep experiments/configs/gm_sweeps/phase1_moons.yaml --dry_run
    python scripts/sweep_gm.py --auto_phase1 --datasets sk_moons,sk_circles --epochs 50
"""
import argparse
import sys
import os
import yaml
import subprocess
import time
import json
import csv
import statistics
from pathlib import Path
from itertools import product

os.environ.setdefault("OMP_NUM_THREADS", "1")
os.environ.setdefault("MKL_NUM_THREADS", "1")

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))
from vghl.utils.logging import get_logger

logger = get_logger("vghl.gm_sweep")


# ── Phase 1: All graph types × operators ─────────────────────────────

GRAPH_TYPES = ["knn", "mutual_knn", "epsilon", "adaptive_radius", "mst_shortcuts", "gabriel", "hybrid"]
OPERATORS = ["identity", "random_walk", "ppr", "heat", "laplacian", "gated"]
K_VALUES = [4, 8, 16, 32]
PROP_STEPS = [1, 3, 5, 10]


def generate_phase1_runs(datasets, seeds=None, epochs=50, k_values=None, operators=None,
                          graph_types=None, prop_steps=None, controls=None):
    """Generate Phase 1 sweep: coarse exploration of geometry × operator.

    If controls is provided, each (graph_type, operator, k, steps) combo
    is run with each control mode to produce ablation pairs.
    """
    if seeds is None:
        seeds = [0]
    if k_values is None:
        k_values = [8, 16]
    if operators is None:
        operators = OPERATORS
    if graph_types is None:
        graph_types = GRAPH_TYPES
    if prop_steps is None:
        prop_steps = [3, 5]
    if controls is None:
        controls = ["none"]

    runs = []
    for dataset in datasets:
        for graph_type in graph_types:
            for operator in operators:
                for k in k_values:
                    for steps in prop_steps:
                        for control in controls:
                            for seed in seeds:
                                ctrl_tag = f"_{control}" if control != "none" else ""
                                name = f"gm_{dataset}_{graph_type}_{operator}_k{k}_T{steps}{ctrl_tag}_s{seed}"
                                runs.append({
                                    "name": name,
                                    "args": {
                                        "--dataset": dataset,
                                        "--graph_type": graph_type,
                                        "--operator": operator,
                                        "--k": str(k),
                                        "--prop_steps": str(steps),
                                        "--control": control,
                                        "--seed": str(seed),
                                        "--epochs": str(epochs),
                                        "--head": "linear",
                                    },
                                })
    return runs


def run_sweep(runs, out_dir, dry_run=False, quiet=False):
    """Execute sweep runs and collect results."""
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    results_csv = out_dir / "sweep_results.csv"

    csv_fields = [
        "name", "status", "time_s",
        "dataset", "graph_type", "operator", "k", "prop_steps", "seed",
        "test_accuracy", "test_f1", "test_loss",
        "val_accuracy", "val_loss",
        "best_epoch",
        # Machine metrics
        "n_edges", "density", "deg_mean", "deg_std",
        "n_components", "largest_component_frac",
        "clustering_coeff", "n_triangles",
        "spectral_gap", "lambda2",
    ]

    csv_file = open(results_csv, "w", newline="")
    writer = csv.DictWriter(csv_file, fieldnames=csv_fields, extrasaction="ignore")
    writer.writeheader()

    logger.info(f"Sweep: {len(runs)} runs → {out_dir}")

    for i, run in enumerate(runs):
        name = run["name"]
        run_args = run["args"]

        cmd = [sys.executable, os.path.join(os.path.dirname(__file__), "train_gm.py")]
        cmd.extend(["--name", name, "--out", str(out_dir)])
        if quiet:
            cmd.append("--quiet")

        for flag, val in run_args.items():
            if val is True:
                cmd.append(flag)
            elif val is not False:
                cmd.extend([flag, str(val)])

        logger.info(f"[{i+1}/{len(runs)}] {name}")

        if dry_run:
            logger.info(f"  CMD: {' '.join(cmd)}")
            continue

        t0 = time.time()
        result = subprocess.run(cmd, capture_output=True, text=True)
        elapsed = time.time() - t0
        status = "OK" if result.returncode == 0 else f"FAIL({result.returncode})"

        # Collect results
        row = {
            "name": name,
            "status": status,
            "time_s": f"{elapsed:.1f}",
            "dataset": run_args.get("--dataset", ""),
            "graph_type": run_args.get("--graph_type", ""),
            "operator": run_args.get("--operator", ""),
            "k": run_args.get("--k", ""),
            "prop_steps": run_args.get("--prop_steps", ""),
            "seed": run_args.get("--seed", ""),
        }

        # Load results JSON if available
        results_path = out_dir / name / "results.json"
        if results_path.exists():
            try:
                with open(results_path) as f:
                    res = json.load(f)
                test = res.get("test", {})
                row["test_accuracy"] = test.get("test/accuracy", "")
                row["test_f1"] = test.get("test/f1", "")
                row["test_loss"] = test.get("test/loss", "")
                row["best_epoch"] = res.get("best_epoch", "")
                row["val_accuracy"] = ""
                row["val_loss"] = res.get("best_val_loss", "")

                machine = res.get("machine", {})
                for mk in ["n_edges", "density", "deg_mean", "deg_std",
                           "n_components", "largest_component_frac",
                           "clustering_coeff", "n_triangles",
                           "spectral_gap", "lambda2"]:
                    row[mk] = machine.get(f"machine/{mk}", "")
            except Exception as e:
                logger.warning(f"  Failed to load results: {e}")

        writer.writerow(row)
        csv_file.flush()

        if status != "OK":
            logger.warning(f"  {status}: {result.stderr[-200:] if result.stderr else 'no stderr'}")
        else:
            acc = row.get("test_accuracy", "?")
            logger.info(f"  {status} [{elapsed:.1f}s] acc={acc}")

    csv_file.close()
    logger.info(f"Results: {results_csv}")

    # Build aggregate.csv: flatten all results.json into one CSV
    if not dry_run:
        aggregate_results(out_dir)

    return str(results_csv)


def aggregate_results(out_dir: Path):
    """Read every run's results.json + config.yaml and write aggregate.csv."""
    out_dir = Path(out_dir)
    all_rows = []
    for run_dir in sorted(out_dir.iterdir()):
        if not run_dir.is_dir():
            continue
        results_path = run_dir / "results.json"
        config_path = run_dir / "config.yaml"
        if not results_path.exists():
            continue

        try:
            with open(results_path) as f:
                res = json.load(f)
            cfg = {}
            if config_path.exists():
                with open(config_path) as f:
                    cfg = yaml.safe_load(f) or {}

            row = {"name": run_dir.name}

            # Config fields
            data_cfg = cfg.get("data", {})
            gb_cfg = cfg.get("graph_builder", {})
            op_cfg = cfg.get("operator", {})
            row["dataset"] = data_cfg.get("dataset", "")
            row["n_train"] = data_cfg.get("n_train", "")
            row["n_classes"] = data_cfg.get("n_classes", "")
            row["graph_type"] = gb_cfg.get("type", "")
            row["k"] = gb_cfg.get("k", "")
            row["control"] = gb_cfg.get("control", "none")
            row["operator"] = op_cfg.get("type", "")
            row["prop_steps"] = op_cfg.get("steps", "")
            row["head_type"] = cfg.get("head", {}).get("type", "")
            row["seed"] = cfg.get("seed", "")

            # Test metrics
            test = res.get("test", {})
            for k, v in test.items():
                row[k.replace("/", "_")] = v

            # Val
            row["best_epoch"] = res.get("best_epoch", "")
            row["best_val_loss"] = res.get("best_val_loss", "")

            # Machine metrics
            machine = res.get("machine", {})
            for k, v in machine.items():
                row[k.replace("machine/", "")] = v

            all_rows.append(row)
        except Exception as e:
            logger.warning(f"Failed to read {run_dir.name}: {e}")

    if not all_rows:
        logger.warning("No results to aggregate")
        return

    # Collect all keys (union)
    all_keys = []
    seen = set()
    for row in all_rows:
        for k in row:
            if k not in seen:
                all_keys.append(k)
                seen.add(k)

    agg_path = out_dir / "aggregate.csv"
    with open(agg_path, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=all_keys, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(all_rows)

    logger.info(f"Aggregate: {agg_path} ({len(all_rows)} runs)")

    # Multi-seed summary: group by config (excluding seed), compute mean/std
    try:
        from collections import defaultdict
        groups = defaultdict(list)
        for row in all_rows:
            # Config key = everything except seed and name
            key_parts = []
            for k in ["dataset", "graph_type", "operator", "k", "prop_steps", "control"]:
                key_parts.append(f"{k}={row.get(k, '')}")
            config_key = "|".join(key_parts)
            groups[config_key].append(row)

        summary_rows = []
        metric_keys = [k for k in all_keys if any(
            m in k for m in ["accuracy", "loss", "acc", "f1"]
        ) and k not in ["train_acc"]]

        for config_key, rows_g in groups.items():
            if len(rows_g) < 2:
                continue
            summary = {"config": config_key, "n_seeds": len(rows_g)}
            # Copy config fields from first row
            for k in ["dataset", "graph_type", "operator", "k", "prop_steps", "control"]:
                summary[k] = rows_g[0].get(k, "")
            # Compute mean/std for numeric metrics
            for mk in metric_keys:
                vals = []
                for r in rows_g:
                    v = r.get(mk)
                    if v is not None and v != "":
                        try:
                            vals.append(float(v))
                        except (ValueError, TypeError):
                            pass
                if vals:
                    summary[f"{mk}_mean"] = round(statistics.mean(vals), 5)
                    summary[f"{mk}_std"] = round(statistics.stdev(vals), 5) if len(vals) > 1 else 0.0
            summary_rows.append(summary)

        if summary_rows:
            summary_keys = []
            seen_s = set()
            for row in summary_rows:
                for k in row:
                    if k not in seen_s:
                        summary_keys.append(k)
                        seen_s.add(k)
            summary_path = out_dir / "summary_by_config.csv"
            with open(summary_path, "w", newline="") as f:
                writer = csv.DictWriter(f, fieldnames=summary_keys, extrasaction="ignore")
                writer.writeheader()
                writer.writerows(summary_rows)
            logger.info(f"Summary: {summary_path} ({len(summary_rows)} configs)")
    except Exception as e:
        logger.warning(f"Could not generate multi-seed summary: {e}")


def main():
    p = argparse.ArgumentParser(description="Geometric Machine Sweep")
    p.add_argument("--sweep", type=str, default=None, help="Sweep YAML file")
    p.add_argument("--dry_run", action="store_true")
    p.add_argument("--out", type=str, default="outputs/gm_sweep")
    p.add_argument("--quiet", action="store_true")

    # Auto Phase 1
    p.add_argument("--auto_phase1", action="store_true",
                    help="Auto-generate Phase 1 sweep")
    p.add_argument("--datasets", type=str, default="sk_moons",
                    help="Comma-separated datasets for auto sweep")
    p.add_argument("--epochs", type=int, default=50)
    p.add_argument("--seeds", type=str, default="0,1,2",
                    help="Comma-separated seeds (default: 3 seeds for statistical validity)")
    p.add_argument("--k_values", type=str, default="8,16",
                    help="Comma-separated k values")
    p.add_argument("--graph_types", type=str, default=None,
                    help="Comma-separated graph types (default: all)")
    p.add_argument("--operators", type=str, default=None,
                    help="Comma-separated operators (default: all)")
    p.add_argument("--steps", type=str, default="3,5",
                    help="Comma-separated prop steps")
    p.add_argument("--controls", type=str, default="none",
                    help="Comma-separated control modes (none,random_destination,degree_preserving_rewire)")

    args = p.parse_args()

    if args.auto_phase1:
        datasets = [d.strip() for d in args.datasets.split(",")]
        seeds = [int(s) for s in args.seeds.split(",")]
        k_values = [int(k) for k in args.k_values.split(",")]
        graph_types = [g.strip() for g in args.graph_types.split(",")] if args.graph_types else None
        operators = [o.strip() for o in args.operators.split(",")] if args.operators else None
        prop_steps = [int(s) for s in args.steps.split(",")]
        controls = [c.strip() for c in args.controls.split(",")]

        runs = generate_phase1_runs(
            datasets, seeds=seeds, epochs=args.epochs,
            k_values=k_values, operators=operators,
            graph_types=graph_types, prop_steps=prop_steps,
            controls=controls,
        )
        run_sweep(runs, args.out, dry_run=args.dry_run, quiet=args.quiet)
        return

    if args.sweep:
        with open(args.sweep) as f:
            sweep_cfg = yaml.safe_load(f)

        runs = sweep_cfg.get("runs", [])
        # Convert YAML format to internal format
        formatted_runs = []
        for run in runs:
            name = run.get("name", "unnamed")
            run_args = {}
            for k, v in run.get("args", {}).items():
                if not k.startswith("--"):
                    k = f"--{k}"
                run_args[k] = str(v) if not isinstance(v, bool) else v
            formatted_runs.append({"name": name, "args": run_args})

        run_sweep(formatted_runs, args.out, dry_run=args.dry_run, quiet=args.quiet)
        return

    logger.error("Specify --sweep <file> or --auto_phase1")


if __name__ == "__main__":
    main()
