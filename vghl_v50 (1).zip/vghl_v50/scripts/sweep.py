#!/usr/bin/env python3
"""Sweep runner: runs multiple experiments from a YAML sweep file.

Usage:
    python scripts/sweep.py --sweep experiments/configs/ablations/sweep_partition.yaml
    python scripts/sweep.py --sweep experiments/configs/ablations/sweep_partition.yaml --dry_run

Sweep YAML format:
    base_config: experiments/configs/base.yaml  # optional base
    runs:
      - name: vghl_m16
        overrides:
          partition.m: 16
      - name: vghl_m32
        overrides:
          partition.m: 32
"""
import argparse
import sys
import os
import yaml
import subprocess
import time
from pathlib import Path

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))
from vghl.utils.logging import get_logger

logger = get_logger("vghl.sweep")


def override_to_cli_arg(key: str, value) -> list:
    """Convert a dotted override key to CLI argument."""
    # Map dotted config paths to CLI args
    mapping = {
        "data.dataset": "--dataset",
        "data.n_train": "--n_train",
        "data.noise_sigma": "--noise_sigma",
        "data.label_noise": "--label_noise",
        "data.n_classes": "--n_classes",
        "data.grid_size": "--grid_size",
        "embed.mode": "--embed",
        "embed.embed_dim": "--embed_dim",
        "partition.m": "--m",
        "partition.L": "--L",
        "partition.temps": "--temps",
        "partition.temp_mode": "--temp_mode",
        "partition.temp_anneal_start": "--temp_anneal_start",
        "partition.temp_anneal_end": "--temp_anneal_end",
        "partition.temp_anneal_epochs": "--temp_anneal_epochs",
        "partition.distance": "--distance",
        "partition.init_sites": "--init_sites",
        "point_graph.enabled": "--point_graph",
        "point_graph.k": "--point_k",
        "point_graph.layers": "--point_mp_layers",
        "point_graph.type": "--point_gnn_type",
        "point_graph.modulate_edges": "--modulate_edges",
        "boundary.mode": "--boundary_mode",
        "boundary.threshold": "--boundary_threshold",
        "boundary.frac": "--boundary_frac",
        "boundary.lambda_boundary": "--lambda_boundary",
        "boundary.boundary_loss": "--boundary_loss",
        "boundary.interior_interior_weight": "--ii_weight",
        "boundary.boundary_boundary_weight": "--bb_weight",
        "boundary.boundary_interior_weight": "--bi_weight",
        "confidence.mode": "--confidence_mode",
        "confidence.scales": "--confidence_scales",
        "confidence.beta_entropy": "--confidence_beta_entropy",
        "confidence.beta_drift": "--confidence_beta_drift",
        "confidence.alpha_min": "--confidence_alpha_min",
        "confidence.warmup_epochs": "--confidence_warmup",
        "confidence.detach": "--confidence_detach",
        "confidence.apply_pooling": "--confidence_apply_pooling",
        "confidence.apply_pullback": "--confidence_apply_pullback",
        "confidence.apply_task_loss": "--confidence_apply_task_loss",
        "confidence.task_scale": "--confidence_task_scale",
        "noise.enabled": "--noise_enabled",
        "noise.sigma": "--pert_sigma",
        "noise.schedule": "--noise_schedule",
        "noise.samples": "--noise_samples",
        "noise.per_point_mode": "--noise_per_point_mode",
        "noise.boundary_kappa": "--noise_boundary_kappa",
        "noise.sigma_boundary_cap": "--sigma_boundary_cap",
        "noise.kappa_warmup_epochs": "--kappa_warmup",
        "noise.sigma_warmup_epochs": "--sigma_warmup",
        "noise.boundary_mask_mode": "--boundary_mask_mode",
        "noise.boundary_quantile": "--boundary_quantile",
        "noise.boundary_topk_frac": "--boundary_topk_frac",
        "stability.enabled": "--stability_enabled",
        "stability.target": "--stability_target",
        "stability.divergence": "--stability_divergence",
        "stability.scales": "--stability_scales",
        "stability.weight": "--stability_weight",
        "stability.warmup_epochs": "--stability_warmup",
        "loss.lambda_assign_entropy": "--lambda_assign_entropy",
        "loss.lambda_assign_sharp": "--lambda_assign_sharp",
        "ema_teacher.enabled": "--ema_enabled",
        "ema_teacher.decay": "--ema_decay",
        "region_graph.method": "--region_graph",
        "region_graph.min_degree": "--min_degree",
        "loss.lambda_conn": "--lambda_conn",
        "loss.conn_epsilon": "--conn_epsilon",
        "loss.lambda_lap_smooth": "--lambda_lap_smooth",
        "region_graph.K": "--region_k",
        "region_graph.graph_refresh": "--graph_refresh",
        "region_graph.pool_mode": "--pool_mode",
        "gnn.type": "--gnn_type",
        "gnn.layers": "--gnn_layers",
        "gnn.edge_mask": "--edge_mask",
        "gnn.consensus_gate": "--consensus_gate",
        "gnn.consensus_tau": "--consensus_tau",
        "gnn.gat_heads": "--gat_heads",
        "loss.lambda_balance": "--lambda_balance",
        "loss.lambda_stab": "--lambda_stab",
        "loss.stab_scales": "--stab_scales",
        "loss.stab_noise_sigma": "--stab_noise_sigma",
        "loss.lambda_ent": "--lambda_ent",
        "loss.lambda_smooth": "--lambda_smooth",
        "loss.lambda_cut": "--lambda_cut",
        "loss.lambda_edge_l1": "--lambda_edge_l1",
        "loss.lambda_within_label": "--lambda_within_label",
        "train.epochs": "--epochs",
        "train.batch_size": "--batch_size",
        "train.lr": "--lr",
        "train.optimizer": "--optimizer",
        "train.scheduler": "--scheduler",
        "train.grad_clip": "--grad_clip",
    }

    cli_key = mapping.get(key)
    if cli_key is None:
        logger.warning(f"Unknown override key: {key}, skipping")
        return []

    if isinstance(value, bool):
        if value:
            return [cli_key]
        else:
            # Map to --no_X flags
            neg_map = {
                "--edge_mask": "--no_edge_mask",
                "--consensus_gate": "--no_consensus_gate",
                "--point_graph": "--no_point_graph",
                "--modulate_edges": "--no_modulate_edges",
                "--noise_enabled": "--no_noise",
                "--stability_enabled": "--no_stability",
                "--ema_enabled": "--no_ema",
                "--confidence_apply_pooling": "--no_confidence_apply_pooling",
                "--confidence_apply_task_loss": "--no_confidence_apply_task_loss",
            }
            if cli_key in neg_map:
                return [neg_map[cli_key]]
            return []
    elif isinstance(value, list):
        return [cli_key, ",".join(str(x) for x in value)]
    else:
        return [cli_key, str(value)]


def main():
    p = argparse.ArgumentParser(description="VGHL Sweep Runner")
    p.add_argument("--sweep", type=str, required=True, help="Sweep YAML file")
    p.add_argument("--dry_run", action="store_true", help="Print commands without running")
    p.add_argument("--out", type=str, default="outputs", help="Base output directory")
    args = p.parse_args()

    with open(args.sweep) as f:
        sweep = yaml.safe_load(f)

    base_config = sweep.get("base_config")
    runs = sweep.get("runs", [])

    logger.info(f"Sweep: {len(runs)} runs")

    results = []
    for i, run in enumerate(runs):
        name = run.get("name", f"run_{i}")
        model = run.get("model", "vghl")
        seed = run.get("seed", 0)
        overrides = run.get("overrides", {})

        cmd = [sys.executable, os.path.join(os.path.dirname(__file__), "train.py")]
        if base_config:
            cmd.extend(["--config", base_config])
        cmd.extend(["--name", name, "--model", model, "--seed", str(seed), "--out", args.out])

        for key, value in overrides.items():
            cmd.extend(override_to_cli_arg(key, value))

        logger.info(f"[{i+1}/{len(runs)}] {name}: {' '.join(cmd)}")

        if args.dry_run:
            continue

        t0 = time.time()
        result = subprocess.run(cmd, capture_output=False)
        elapsed = time.time() - t0

        status = "OK" if result.returncode == 0 else f"FAILED (code {result.returncode})"
        logger.info(f"[{i+1}/{len(runs)}] {name}: {status} ({elapsed:.1f}s)")
        results.append({"name": name, "status": status, "time": elapsed})

    # Summary
    logger.info("=" * 60)
    logger.info("SWEEP SUMMARY")
    for r in results:
        logger.info(f"  {r['name']}: {r['status']} ({r['time']:.1f}s)")


if __name__ == "__main__":
    main()
