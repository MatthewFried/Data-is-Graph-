#!/bin/bash
# CIFAR-10 ResNet-18 comprehensive pipeline sweep
# Tests all reasonable combinations: propagation types, concat, raw test,
# label propagation, cosine kNN, PCA, ridge l2, N scaling
set -e
export PYTHONUNBUFFERED=1
export OMP_NUM_THREADS=8
export MKL_NUM_THREADS=8
cd "$(dirname "$0")/.."
mkdir -p outputs/cifar_sweep_v2

echo "$(date) === CIFAR COMPREHENSIVE SWEEP v2 ==="

# Most diagnostic first: raw_test tells us if kNN embedding is the bottleneck
echo "$(date) === raw_test ==="
python -u scripts/sweep_cifar_v2.py --only raw_test --seeds 0,1

# Concat: does adding raw features help?
echo "$(date) === concat ==="
python -u scripts/sweep_cifar_v2.py --only concat --seeds 0,1

# Label propagation: pure geometry test, no ridge
echo "$(date) === label_prop ==="
python -u scripts/sweep_cifar_v2.py --only label_prop --seeds 0,1

# All propagation types (biggest sweep)
echo "$(date) === prop_types ==="
python -u scripts/sweep_cifar_v2.py --only prop_types --seeds 0,1

# Cosine kNN
echo "$(date) === cosine_knn ==="
python -u scripts/sweep_cifar_v2.py --only cosine_knn --seeds 0,1

# PCA
echo "$(date) === dim_reduction ==="
python -u scripts/sweep_cifar_v2.py --only dim_reduction --seeds 0,1

# Ridge l2
echo "$(date) === ridge_l2 ==="
python -u scripts/sweep_cifar_v2.py --only ridge_l2 --seeds 0,1

# N scaling
echo "$(date) === n_scaling ==="
python -u scripts/sweep_cifar_v2.py --only n_scaling --seeds 0,1

echo "$(date) === ALL SWEEPS COMPLETE ==="
echo "Results: outputs/cifar_sweep_v2/"
ls -la outputs/cifar_sweep_v2/
