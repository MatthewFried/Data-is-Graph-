#!/usr/bin/env python3
"""Phase 2 Tests: Stability Identification + Iterative Refinement Trajectory.

Test 3 — Stability Identification:
  Build graph, compute per-node stability score, then compare performance
  of subgraphs built from: top-20% stable, random, bottom-20% unstable nodes.
  If stable > random > unstable, pruning identifies computational noise.

Test 4 — Iterative Refinement Trajectory:
  Progressively prune 10%, 20%, 30%, ... of nodes by instability score.
  Plot accuracy at each stage. Expected: accuracy rises then falls,
  proving existence of optimal computational geometry.

Usage:
    python scripts/run_phase2_tests.py
    python scripts/run_phase2_tests.py --datasets sk_moons,breast_cancer --seeds 0,1,2
    python scripts/run_phase2_tests.py --plot_only
"""
import argparse
import sys
import os
import csv
import time
import statistics as stats_mod
import numpy as np
import torch
from pathlib import Path
from collections import defaultdict

os.environ.setdefault("OMP_NUM_THREADS", "1")
os.environ.setdefault("MKL_NUM_THREADS", "1")
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
os.environ.setdefault("NUMEXPR_NUM_THREADS", "1")

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from vghl.data.loaders import build_datasets, PointDataset
from vghl.utils.config import ExperimentConfig
from vghl.models.graph_builder import build_base_graph, GraphBuilderConfig
from vghl.models.propagation import propagate, PropagationConfig
from vghl.models.probe import ridge_eval, embed_queries_via_knn


DATASET_DEFAULTS = {
    "sk_moons":       {"n_train": 5000, "n_val": 1000, "n_test": 1000},
    "sk_circles":     {"n_train": 5000, "n_val": 1000, "n_test": 1000},
    "breast_cancer":  {"n_train": 0, "n_val": 0, "n_test": 0},
    "digits":         {"n_train": 0, "n_val": 0, "n_test": 0},
    "wine":           {"n_train": 0, "n_val": 0, "n_test": 0},
    "ionosphere":     {"n_train": 0, "n_val": 0, "n_test": 0},
    "sonar":          {"n_train": 0, "n_val": 0, "n_test": 0},
    "vehicle":        {"n_train": 0, "n_val": 0, "n_test": 0},
}


def load_dataset(dataset, seed, n_train, n_val, n_test):
    """Load dataset splits."""
    cfg = ExperimentConfig()
    cfg.data.dataset = dataset
    cfg.data.n_train = n_train
    cfg.data.n_val = n_val
    cfg.data.n_test = n_test
    cfg.seed = seed
    train_ds, val_ds, test_ds, meta = build_datasets(cfg)
    return train_ds.X, train_ds.y, val_ds.X, val_ds.y, test_ds.X, test_ds.y, meta


def compute_adaptive_sigma(X, graph_cfg):
    """Compute perturbation sigma scaled to dataset geometry.

    sigma = 0.05 * median kNN edge distance. This ensures perturbations
    are meaningful relative to the actual point spacing.
    """
    graph = build_base_graph(X, graph_cfg)
    ei = graph["edge_index"]
    edge_dists = (X[ei[0]] - X[ei[1]]).norm(dim=1)
    median_dist = edge_dists.median().item()
    sigma = 0.05 * median_dist
    return max(sigma, 1e-6)


def compute_node_stability(X, graph_cfg, n_trials=5, sigma=None, seed=0):
    """Compute per-node stability via mean pairwise Jaccard of neighbor sets.

    If sigma is None, automatically scales to 5% of median edge distance.
    Returns stability scores (higher = more stable).
    Also returns stats dict with distribution info for diagnostics.
    """
    from vghl.models.pruning import _build_neighbor_sets, _pairwise_jaccard
    rng = np.random.RandomState(seed)
    N = X.shape[0]
    d = X.shape[1]
    device = X.device

    if sigma is None:
        sigma = compute_adaptive_sigma(X, graph_cfg)

    boot_sets = []
    for t in range(n_trials):
        noise = torch.tensor(
            rng.randn(N, d).astype(np.float32) * sigma,
            device=device, dtype=X.dtype,
        )
        X_pert = X + noise
        graph = build_base_graph(X_pert, graph_cfg)
        ei = graph["edge_index"]
        boot_sets.append(_build_neighbor_sets(ei, N, device))

    stability = _pairwise_jaccard(boot_sets, N, device)
    return stability, sigma


def eval_subgraph(X_train, y_train, X_val, y_val, node_mask,
                  graph_cfg, prop_cfg):
    """Build graph from subset of nodes, propagate, evaluate with ridge.

    Val points are embedded via kNN aggregation of propagated train
    embeddings (correct inductive protocol).
    """
    X_sub = X_train[node_mask]
    y_sub = y_train[node_mask]
    N_sub = X_sub.shape[0]

    if N_sub < 5:
        return {"val_accuracy": 0.0, "n_nodes": N_sub, "n_edges": 0}

    n_classes = max(int(y_train.max()) + 1, int(y_sub.max()) + 1)

    # Build graph on subset
    graph = build_base_graph(X_sub, graph_cfg)
    ei = graph["edge_index"]
    ew = graph["edge_weight"]

    # Propagate
    h = propagate(X_sub, ei, ew, N_sub, prop_cfg)

    # Embed val via kNN to propagated train embeddings
    k_embed = min(graph_cfg.k, N_sub)
    h_val = embed_queries_via_knn(h, X_sub, X_val, k=k_embed)

    # Ridge: fit on propagated subset, predict on embedded val
    acc = ridge_eval(h, y_sub, h_val, y_val, n_classes=n_classes)

    return {
        "val_accuracy": acc,
        "n_nodes": N_sub,
        "n_edges": ei.shape[1],
    }


# ══════════════════════════════════════════════════════════════════════
# TEST 3: Stability Node Subsets
# ══════════════════════════════════════════════════════════════════════

def stratified_top_k(stability, y, n_select, top=True):
    """Select top (or bottom) n_select nodes, stratified by class.

    Ensures each class contributes proportionally, preventing class skew
    from dominating the subset selection.
    """
    classes = y.unique()
    class_counts = torch.bincount(y, minlength=int(classes.max()) + 1)
    total = y.shape[0]
    selected = []

    for c in classes:
        c_mask = (y == c)
        c_idx = c_mask.nonzero(as_tuple=True)[0]
        c_stab = stability[c_idx]
        n_c = max(int(n_select * class_counts[c].item() / total), 1)
        n_c = min(n_c, len(c_idx))

        if top:
            _, top_local = torch.topk(c_stab, n_c)
        else:
            _, top_local = torch.topk(c_stab, n_c, largest=False)
        selected.append(c_idx[top_local])

    return torch.cat(selected)


def run_stability_subsets(datasets, seeds, k_values, out_dir,
                          top_frac=0.2, operator="random_walk", prop_steps=5,
                          stab_sigma=None, stab_trials=5, stratified=True):
    """Test 3: Compare stable vs random vs unstable node subsets.

    With diagnostics: stability distribution stats, embedding coverage,
    and adaptive sigma.
    """
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    rows = []
    for dataset in datasets:
        dd = DATASET_DEFAULTS.get(dataset, {})
        n_train = dd.get("n_train", 0)
        n_val = dd.get("n_val", 0)
        n_test = dd.get("n_test", 0)

        for k in k_values:
            graph_cfg = GraphBuilderConfig(type="knn", k=k)
            prop_cfg = PropagationConfig(type=operator, steps=prop_steps)

            for seed in seeds:
                tag = f"{dataset}_k{k}_s{seed}"
                print(f"\n[Test 3: {tag}]", flush=True)

                X_tr, y_tr, X_val, y_val, _, _, meta = load_dataset(
                    dataset, seed, n_train, n_val, n_test
                )
                N = len(X_tr)

                # Compute stability with adaptive sigma
                t0 = time.time()
                stability, sigma_used = compute_node_stability(
                    X_tr, graph_cfg, n_trials=stab_trials,
                    sigma=stab_sigma, seed=seed,
                )
                elapsed = time.time() - t0

                # Diagnostics
                s_mean = stability.mean().item()
                s_std = stability.std().item()
                s_min = stability.min().item()
                s_max = stability.max().item()
                s_spread = s_max - s_min
                print(f"  Stability: σ={sigma_used:.4f} "
                      f"mean={s_mean:.3f} std={s_std:.3f} "
                      f"range=[{s_min:.3f},{s_max:.3f}] spread={s_spread:.3f} "
                      f"({elapsed:.1f}s)")

                if s_spread < 0.01:
                    print(f"  ⚠ WARNING: stability spread < 0.01 — "
                          f"perturbation too weak or dataset too uniform")

                n_top = max(int(N * top_frac), 5)
                n_bottom = n_top
                rng = np.random.RandomState(seed)

                if stratified:
                    top_idx = stratified_top_k(stability, y_tr, n_top, top=True)
                    bottom_idx = stratified_top_k(stability, y_tr, n_bottom, top=False)
                else:
                    sorted_idx = torch.argsort(stability, descending=True)
                    top_idx = sorted_idx[:n_top]
                    bottom_idx = sorted_idx[-n_bottom:]

                subsets = {
                    "top_stable": top_idx,
                    "bottom_unstable": bottom_idx,
                    "random": torch.tensor(rng.choice(N, n_top, replace=False)),
                    "full": torch.arange(N),
                }

                for subset_name, idx in subsets.items():
                    mask = torch.zeros(N, dtype=torch.bool)
                    mask[idx] = True
                    result = eval_subgraph(
                        X_tr, y_tr, X_val, y_val, mask, graph_cfg, prop_cfg
                    )

                    # Class balance diagnostic
                    n_classes = int(y_tr.max()) + 1
                    class_dist = torch.bincount(y_tr[mask], minlength=n_classes)
                    class_str = ",".join(str(c.item()) for c in class_dist)

                    # Mean stability of selected nodes
                    mean_stab_sel = stability[mask].mean().item()

                    row = {
                        "dataset": dataset, "k": k, "seed": seed,
                        "subset": subset_name,
                        "n_nodes": result["n_nodes"],
                        "n_edges": result["n_edges"],
                        "val_accuracy": result["val_accuracy"],
                        "sigma_used": sigma_used,
                        "stab_mean": s_mean,
                        "stab_std": s_std,
                        "stab_spread": s_spread,
                        "mean_stab_selected": mean_stab_sel,
                        "class_counts": class_str,
                        "stratified": stratified,
                    }
                    rows.append(row)
                    print(f"  {subset_name:20s}: acc={result['val_accuracy']:.4f} "
                          f"({result['n_nodes']} nodes, {result['n_edges']} edges) "
                          f"mean_stab={mean_stab_sel:.3f} classes=[{class_str}]")

    if rows:
        csv_path = out_dir / "stability_subsets.csv"
        with open(csv_path, "w", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=rows[0].keys())
            writer.writeheader()
            writer.writerows(rows)
        print(f"\nStability subsets: {csv_path}")

    return rows


# ══════════════════════════════════════════════════════════════════════
# TEST 4: Iterative Refinement Trajectory
# ══════════════════════════════════════════════════════════════════════

def run_refinement_trajectory(datasets, seeds, k_values, out_dir,
                               fractions=None, operator="random_walk", prop_steps=5,
                               stab_sigma=None, stab_trials=5, stratified=True):
    """Test 4: Progressive pruning by stability score."""
    if fractions is None:
        fractions = [1.0, 0.9, 0.8, 0.7, 0.6, 0.5, 0.4, 0.3, 0.2]

    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    rows = []
    for dataset in datasets:
        dd = DATASET_DEFAULTS.get(dataset, {})
        n_train = dd.get("n_train", 0)
        n_val = dd.get("n_val", 0)
        n_test = dd.get("n_test", 0)

        for k in k_values:
            graph_cfg = GraphBuilderConfig(type="knn", k=k)
            prop_cfg = PropagationConfig(type=operator, steps=prop_steps)

            for seed in seeds:
                tag = f"{dataset}_k{k}_s{seed}"
                print(f"\n[Test 4: {tag}]", flush=True)

                X_tr, y_tr, X_val, y_val, _, _, meta = load_dataset(
                    dataset, seed, n_train, n_val, n_test
                )
                N = len(X_tr)

                # Compute stability once with adaptive sigma
                stability, sigma_used = compute_node_stability(
                    X_tr, graph_cfg, n_trials=stab_trials,
                    sigma=stab_sigma, seed=seed,
                )
                print(f"  σ={sigma_used:.4f} stab_range="
                      f"[{stability.min():.3f},{stability.max():.3f}]")
                sorted_idx = torch.argsort(stability, descending=True)

                rng = np.random.RandomState(seed)

                for frac in fractions:
                    n_keep = max(int(N * frac), 5)

                    # Structural: keep most stable (stratified)
                    if stratified:
                        stable_idx = stratified_top_k(stability, y_tr, n_keep, top=True)
                    else:
                        stable_idx = sorted_idx[:n_keep]
                    stable_mask = torch.zeros(N, dtype=torch.bool)
                    stable_mask[stable_idx] = True
                    res_stable = eval_subgraph(
                        X_tr, y_tr, X_val, y_val, stable_mask, graph_cfg, prop_cfg
                    )

                    # Random baseline
                    rand_idx = torch.tensor(rng.choice(N, n_keep, replace=False))
                    rand_mask = torch.zeros(N, dtype=torch.bool)
                    rand_mask[rand_idx] = True
                    res_random = eval_subgraph(
                        X_tr, y_tr, X_val, y_val, rand_mask, graph_cfg, prop_cfg
                    )

                    # Structural diagnostics
                    mean_stab_kept = stability[stable_mask].mean().item()
                    mean_stab_rand = stability[rand_mask].mean().item()

                    for mode, res, ms in [("structural", res_stable, mean_stab_kept),
                                          ("random", res_random, mean_stab_rand)]:
                        row = {
                            "dataset": dataset, "k": k, "seed": seed,
                            "fraction": frac, "mode": mode,
                            "n_nodes": res["n_nodes"],
                            "n_edges": res["n_edges"],
                            "val_accuracy": res["val_accuracy"],
                            "mean_stab_retained": ms,
                            "sigma_used": sigma_used,
                        }
                        rows.append(row)

                    delta = res_stable['val_accuracy'] - res_random['val_accuracy']
                    print(f"  frac={frac:.1f}: structural={res_stable['val_accuracy']:.4f} "
                          f"random={res_random['val_accuracy']:.4f} "
                          f"(Δ={delta:+.4f}) "
                          f"stab_kept={mean_stab_kept:.3f}")

    if rows:
        csv_path = out_dir / "refinement_trajectory.csv"
        with open(csv_path, "w", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=rows[0].keys())
            writer.writeheader()
            writer.writerows(rows)
        print(f"\nRefinement trajectory: {csv_path}")

    return rows


# ══════════════════════════════════════════════════════════════════════
# Summary & Figures
# ══════════════════════════════════════════════════════════════════════

def summarize_stability_subsets(rows):
    """Compute mean ± std for stability subset test."""
    groups = defaultdict(list)
    for r in rows:
        key = (r["dataset"], r["k"], r["subset"])
        groups[key].append(float(r["val_accuracy"]))

    summary = []
    for (ds, k, subset), accs in sorted(groups.items()):
        mean = stats_mod.mean(accs)
        std = stats_mod.stdev(accs) if len(accs) > 1 else 0.0
        summary.append({
            "dataset": ds, "k": k, "subset": subset,
            "mean_acc": mean, "std_acc": std, "n": len(accs),
            "acc_str": f"{mean:.3f} ± {std:.3f}",
        })
    return summary


def summarize_trajectory(rows):
    """Compute mean ± std for refinement trajectory."""
    groups = defaultdict(list)
    for r in rows:
        key = (r["dataset"], r["k"], r["mode"], float(r["fraction"]))
        groups[key].append(float(r["val_accuracy"]))

    summary = []
    for (ds, k, mode, frac), accs in sorted(groups.items()):
        mean = stats_mod.mean(accs)
        std = stats_mod.stdev(accs) if len(accs) > 1 else 0.0
        summary.append({
            "dataset": ds, "k": k, "mode": mode, "fraction": frac,
            "mean_acc": mean, "std_acc": std, "n": len(accs),
        })
    return summary


def generate_figures(stability_summary, trajectory_summary, out_dir):
    """Generate publication figures for Tests 3 and 4."""
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
        import matplotlib.ticker as ticker
    except ImportError:
        print("matplotlib not installed, skipping figures")
        return

    out_dir = Path(out_dir)

    # ── Test 3 Figure: Stability Subsets Bar Chart ──
    datasets = sorted(set(s["dataset"] for s in stability_summary))
    if datasets:
        k_use = sorted(set(s["k"] for s in stability_summary))[-1]

        COLORS = {
            "full": "#6b7280",
            "top_stable": "#2563eb",
            "random": "#f59e0b",
            "bottom_unstable": "#dc2626",
        }
        LABELS = {
            "full": "Full graph",
            "top_stable": "Top 20% stable",
            "random": "Random 20%",
            "bottom_unstable": "Bottom 20% unstable",
        }

        fig, ax = plt.subplots(figsize=(3.5 * len(datasets), 4))
        x = np.arange(len(datasets))
        bar_w = 0.2

        for j, subset in enumerate(["full", "top_stable", "random", "bottom_unstable"]):
            means, stds = [], []
            for ds in datasets:
                match = [s for s in stability_summary
                         if s["dataset"] == ds and s["k"] == k_use and s["subset"] == subset]
                if match:
                    means.append(match[0]["mean_acc"])
                    stds.append(match[0]["std_acc"])
                else:
                    means.append(0)
                    stds.append(0)

            ax.bar(x + j * bar_w, means, bar_w, yerr=stds,
                   label=LABELS[subset], color=COLORS[subset],
                   capsize=3, alpha=0.85)

        ds_labels = []
        for ds in datasets:
            label = ds.replace("_", " ").replace("sk ", "").title()
            if ds == "breast_cancer":
                label = "Breast Cancer"
            ds_labels.append(label)

        ax.set_xticks(x + 1.5 * bar_w)
        ax.set_xticklabels(ds_labels, fontsize=10)
        ax.set_ylabel("Val accuracy (ridge)", fontsize=11)
        ax.legend(fontsize=8, frameon=True, loc="lower right")
        ax.grid(True, axis="y", alpha=0.2)
        ax.set_title(f"Test 3: Stable vs Unstable Node Subsets ($k$={k_use})",
                     fontsize=13, fontweight="bold")
        plt.tight_layout()

        for ext in ["pdf", "png"]:
            fig.savefig(out_dir / f"stability_subsets.{ext}", dpi=300, bbox_inches="tight")
        print(f"Stability figure: {out_dir / 'stability_subsets.pdf'}")
        plt.close(fig)

    # ── Test 4 Figure: Refinement Trajectory ──
    datasets_t = sorted(set(s["dataset"] for s in trajectory_summary))
    if datasets_t:
        k_use = sorted(set(s["k"] for s in trajectory_summary))[-1]
        n_ds = len(datasets_t)

        COLORS = {"structural": "#2563eb", "random": "#6b7280"}
        LABELS = {"structural": "Stability-guided", "random": "Random"}
        MARKERS = {"structural": "o", "random": "s"}

        fig, axes = plt.subplots(1, n_ds, figsize=(4.5 * n_ds, 3.5), squeeze=False)

        for i, ds in enumerate(datasets_t):
            ax = axes[0, i]
            for mode in ["structural", "random"]:
                data = sorted(
                    [s for s in trajectory_summary
                     if s["dataset"] == ds and s["k"] == k_use and s["mode"] == mode],
                    key=lambda s: s["fraction"],
                )
                if not data:
                    continue
                fracs = [s["fraction"] for s in data]
                means = [s["mean_acc"] for s in data]
                stds = [s["std_acc"] for s in data]

                ax.errorbar(fracs, means, yerr=stds,
                            label=LABELS[mode], color=COLORS[mode],
                            marker=MARKERS[mode], markersize=6,
                            linewidth=1.8, capsize=3, capthick=1.2)

            ds_label = ds.replace("_", " ").replace("sk ", "").title()
            if ds == "breast_cancer":
                ds_label = "Breast Cancer"
            ax.set_title(f"{ds_label} ($k$={k_use})", fontsize=13, fontweight="bold")
            ax.set_xlabel("Retention fraction", fontsize=11)
            if i == 0:
                ax.set_ylabel("Val accuracy (ridge)", fontsize=11)
            ax.set_xlim(0.15, 1.05)
            ax.grid(True, alpha=0.2)
            ax.tick_params(labelsize=10)

        handles, labels = axes[0, 0].get_legend_handles_labels()
        fig.legend(handles, labels, loc="upper center", ncol=2, fontsize=10,
                   frameon=True, bbox_to_anchor=(0.5, 1.02))
        plt.tight_layout(rect=[0, 0, 1, 0.92])

        for ext in ["pdf", "png"]:
            fig.savefig(out_dir / f"refinement_trajectory.{ext}", dpi=300, bbox_inches="tight")
        print(f"Trajectory figure: {out_dir / 'refinement_trajectory.pdf'}")
        plt.close(fig)


def main():
    p = argparse.ArgumentParser(description="Phase 2 Tests: stability + refinement")
    p.add_argument("--datasets", type=str, default="sk_moons,breast_cancer,digits")
    p.add_argument("--seeds", type=str, default="0,1,2,3,4")
    p.add_argument("--k_values", type=str, default="16")
    p.add_argument("--top_frac", type=float, default=0.2,
                   help="Fraction for top/bottom stability subsets")
    p.add_argument("--operator", type=str, default="random_walk")
    p.add_argument("--prop_steps", type=int, default=5)
    p.add_argument("--out", type=str, default="outputs/phase2_tests")
    p.add_argument("--plot_only", action="store_true")
    p.add_argument("--skip_test3", action="store_true")
    p.add_argument("--skip_test4", action="store_true")
    p.add_argument("--stab_sigma", type=float, default=None,
                   help="Perturbation sigma. None=auto (5%% median edge dist)")
    p.add_argument("--stab_trials", type=int, default=5,
                   help="Number of bootstrap trials for stability")
    p.add_argument("--no_stratify", action="store_true",
                   help="Disable class-stratified subset selection")

    args = p.parse_args()
    datasets = [d.strip() for d in args.datasets.split(",")]
    seeds = [int(s) for s in args.seeds.split(",")]
    k_values = [int(k) for k in args.k_values.split(",")]
    out_dir = Path(args.out)

    print("=" * 70)
    print("PHASE 2 TESTS: Stability Identification + Refinement Trajectory")
    print(f"  Datasets:    {datasets}")
    print(f"  Seeds:       {seeds}")
    print(f"  k values:    {k_values}")
    print(f"  Top frac:    {args.top_frac}")
    print(f"  Stab sigma:  {args.stab_sigma or 'auto (5% median edge dist)'}")
    print(f"  Stab trials: {args.stab_trials}")
    print(f"  Stratified:  {not args.no_stratify}")
    print("=" * 70)

    stratified = not args.no_stratify

    if args.plot_only:
        # Load existing
        stab_rows = []
        traj_rows = []
        stab_path = out_dir / "stability_subsets.csv"
        traj_path = out_dir / "refinement_trajectory.csv"
        if stab_path.exists():
            with open(stab_path) as f:
                stab_rows = list(csv.DictReader(f))
        if traj_path.exists():
            with open(traj_path) as f:
                traj_rows = list(csv.DictReader(f))
    else:
        # Run tests
        stab_rows = []
        traj_rows = []

        if not args.skip_test3:
            print("\n══ TEST 3: Stability Node Subsets ══")
            stab_rows = run_stability_subsets(
                datasets, seeds, k_values, out_dir,
                top_frac=args.top_frac,
                operator=args.operator, prop_steps=args.prop_steps,
                stab_sigma=args.stab_sigma, stab_trials=args.stab_trials,
                stratified=stratified,
            )

        if not args.skip_test4:
            print("\n══ TEST 4: Iterative Refinement Trajectory ══")
            traj_rows = run_refinement_trajectory(
                datasets, seeds, k_values, out_dir,
                operator=args.operator, prop_steps=args.prop_steps,
                stab_sigma=args.stab_sigma, stab_trials=args.stab_trials,
                stratified=stratified,
            )

    # Summarize
    stab_summary = summarize_stability_subsets(stab_rows) if stab_rows else []
    traj_summary = summarize_trajectory(traj_rows) if traj_rows else []

    if stab_summary:
        print("\n" + "=" * 70)
        print("TEST 3 SUMMARY: Stability Subsets")
        print("=" * 70)
        print(f"{'Dataset':<18} {'k':>3} {'Subset':<22} {'Accuracy':>15}")
        print("-" * 65)
        for s in stab_summary:
            print(f"{s['dataset']:<18} {s['k']:>3} {s['subset']:<22} {s['acc_str']:>15}")

    if traj_summary:
        print("\n" + "=" * 70)
        print("TEST 4 SUMMARY: Refinement Trajectory")
        print("=" * 70)
        print(f"{'Dataset':<18} {'k':>3} {'Mode':<14} {'Frac':>5} {'Accuracy':>12}")
        print("-" * 60)
        for s in traj_summary:
            print(f"{s['dataset']:<18} {s['k']:>3} {s['mode']:<14} "
                  f"{s['fraction']:>5.1f} {s['mean_acc']:>8.4f} ± {s['std_acc']:.4f}")

    # Figures
    generate_figures(stab_summary, traj_summary, out_dir)

    print(f"\nAll outputs in: {out_dir}")


if __name__ == "__main__":
    main()
