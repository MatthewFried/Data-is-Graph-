#!/usr/bin/env python3
"""Rebuttal Experiment C: formal equivalence analysis for Full vs No-Prop.

AC priority 3 / GMYt Q2b: "statistically tied" requires an equivalence test,
not a non-significant difference. This script runs paired TOST at several
margins on the per-dataset Full vs No-Prop differences from ablation.csv
(the per-seed output of `run_real_experiments.py --only ablation`), plus a
Wilcoxon test, a bootstrap CI, and a normal-approximation posterior
P(|delta| < margin) (ROPE-style).

Honesty requirements baked in: the margin is post hoc, so we report a
sensitivity sweep (0.5pp, 1pp, 2.5pp) rather than a single chosen margin;
2.5pp is defensible as the measured hyperparameter noise floor (paper
Appendix I: mean accuracy range 0.025 across fixed configurations).

Usage:
  python -u scripts/rebuttal_tost.py --csv outputs/real_experiments/ablation.csv
  python -u scripts/rebuttal_tost.py --csv ablation.csv --col_a full_vghl --col_b no_propagation
"""
import argparse
import numpy as np
import pandas as pd
from scipy import stats


def tost_paired(diff: np.ndarray, margin: float):
    """Two one-sided tests on paired differences. Equivalence is concluded
    at level alpha=0.05 iff both one-sided p-values are < 0.05, equivalently
    the 90% CI of the mean difference lies inside (-margin, +margin)."""
    n = len(diff)
    m, sd = diff.mean(), diff.std(ddof=1)
    se = sd / np.sqrt(n)
    if not np.isfinite(se) or se == 0:
        # Degenerate: all paired differences identical
        inside = abs(m) < margin
        return (0.0 if inside else 1.0), (m, m)
    t_lo = (m + margin) / se          # H0: mean <= -margin
    t_hi = (m - margin) / se          # H0: mean >= +margin
    p_lo = 1 - stats.t.cdf(t_lo, n - 1)
    p_hi = stats.t.cdf(t_hi, n - 1)
    p_tost = max(p_lo, p_hi)
    ci90 = stats.t.interval(0.90, n - 1, loc=m, scale=se)
    return p_tost, ci90


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--csv", type=str, required=True,
                   help="ablation.csv with per-seed rows")
    p.add_argument("--col_a", type=str, default="full_vghl")
    p.add_argument("--col_b", type=str, default="no_propagation")
    p.add_argument("--margins", type=str, default="0.005,0.01,0.025")
    a = p.parse_args()

    df = pd.read_csv(a.csv)
    need = {"dataset", a.col_a, a.col_b}
    missing = need - set(df.columns)
    if missing:
        raise SystemExit(f"CSV missing columns: {missing}")

    g = df.groupby("dataset")[[a.col_a, a.col_b]].mean()
    # guard against unmatched seed sets producing NaN means
    g = g.dropna()
    diff = (g[a.col_a] - g[a.col_b]).values
    n = len(diff)
    if n < 2:
        raise SystemExit(f"Need >=2 datasets with complete pairs, got {n}.")
    m, sd = diff.mean(), diff.std(ddof=1)
    se = sd / np.sqrt(n)

    print(f"Paired per-dataset differences: {a.col_a} - {a.col_b}")
    print(f"  n datasets = {n}")
    print(f"  mean diff  = {m:+.4f}   sd = {sd:.4f}   se = {se:.4f}")
    for ds, d in zip(g.index, diff):
        print(f"    {ds:<20} {d:+.4f}")

    t, pval = stats.ttest_rel(g[a.col_a], g[a.col_b])
    try:
        w = stats.wilcoxon(g[a.col_a], g[a.col_b])
        wtxt = f"W={w.statistic:.1f} p={w.pvalue:.3f}"
    except ValueError:
        wtxt = "n/a (zero differences)"
    print(f"\n  Difference tests (NOT equivalence): paired t={t:.2f} p={pval:.3f}; "
          f"Wilcoxon {wtxt}")

    rng = np.random.RandomState(0)
    boots = np.array([diff[rng.randint(0, n, n)].mean() for _ in range(20000)])
    lo, hi = np.percentile(boots, [2.5, 97.5])
    print(f"  Bootstrap 95% CI of mean diff: [{lo:+.4f}, {hi:+.4f}]")

    print("\n  TOST equivalence (margin sensitivity, alpha=0.05):")
    print(f"  {'margin':>8} {'p_TOST':>10} {'90% CI':>24} {'equivalent?':>12} "
          f"{'P(|d|<margin)':>15}")
    for margin in [float(s) for s in a.margins.split(",")]:
        p_tost, ci90 = tost_paired(diff, margin)
        # ROPE-style posterior: t posterior for the mean under flat prior
        if se > 0 and np.isfinite(se):
            post = stats.t(df=n - 1, loc=m, scale=se)
            p_rope = post.cdf(margin) - post.cdf(-margin)
        else:
            p_rope = 1.0 if abs(m) < margin else 0.0
        eq = "YES" if p_tost < 0.05 else "no"
        ci_txt = f"[{ci90[0]:+.4f}, {ci90[1]:+.4f}]"
        print(f"  {margin:>8.3f} {p_tost:>10.4f} {ci_txt:>24} "
              f"{eq:>12} {p_rope:>15.3f}")

    print("\n  Heterogeneity (TOST here concerns the MEAN difference only; "
          "it does not establish per-dataset equivalence):")
    print(f"    per-dataset diff range: [{diff.min():+.4f}, {diff.max():+.4f}]")
    for margin in [float(s) for s in a.margins.split(",")]:
        n_out = int((np.abs(diff) > margin).sum())
        print(f"    |diff| > {margin:.3f} on {n_out}/{n} datasets")
    if n >= 4:
        lodo = [np.delete(diff, i).mean() for i in range(n)]
        print(f"    leave-one-dataset-out mean range: "
              f"[{min(lodo):+.4f}, {max(lodo):+.4f}]")

    print("\n  Reporting language (restricted):")
    print("  - Passing TOST at margin d supports only: 'the mean per-dataset "
          "difference lies within +/-d (margin selected post hoc; "
          "sensitivity reported; per-dataset spread reported above).'")
    print("  - It does NOT establish that the two conditions are equivalent "
          "on every dataset.")
    print("  - If TOST fails at all margins: 'Full and No-Prop differ by "
          f"{m*100:+.1f}pp on average; we do not claim formal equivalence.'")


if __name__ == "__main__":
    main()
