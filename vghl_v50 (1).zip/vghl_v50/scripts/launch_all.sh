#!/bin/bash
# ══════════════════════════════════════════════════════════════════════
# LAUNCH ALL — paste this whole block or run: bash scripts/launch_all.sh
#
# Each line is independent. They all run simultaneously as background
# jobs. On a 32-core machine, all ~25 jobs run at once.
#
# Monitor: tail -f outputs/logs/*.log
# Check:   ls -la outputs/real_experiments/  outputs/transfer/  etc.
# Status:  jobs -l   OR   ps aux | grep python
# ══════════════════════════════════════════════════════════════════════

cd "$(dirname "$0")/.."
mkdir -p outputs/logs

SEEDS="0,1,2,3,4"
export PYTHONUNBUFFERED=1
export OMP_NUM_THREADS=2
export MKL_NUM_THREADS=2

echo "Launching all experiments as nohup background jobs..."
echo "Monitor: tail -f outputs/logs/*.log"
echo ""

# ══════════════════════════════════════════════════════════════════════
# CLAIM A: Noise Identification — split by dataset for parallelism
# ══════════════════════════════════════════════════════════════════════
nohup python -u scripts/run_real_experiments.py --only noise --datasets breast_cancer   --seeds $SEEDS --out outputs/real_experiments/a_breast_cancer   > outputs/logs/a_breast_cancer.log 2>&1 &
nohup python -u scripts/run_real_experiments.py --only noise --datasets wine            --seeds $SEEDS --out outputs/real_experiments/a_wine            > outputs/logs/a_wine.log 2>&1 &
nohup python -u scripts/run_real_experiments.py --only noise --datasets heart           --seeds $SEEDS --out outputs/real_experiments/a_heart           > outputs/logs/a_heart.log 2>&1 &
nohup python -u scripts/run_real_experiments.py --only noise --datasets digits          --seeds $SEEDS --out outputs/real_experiments/a_digits          > outputs/logs/a_digits.log 2>&1 &
nohup python -u scripts/run_real_experiments.py --only noise --datasets adult           --seeds $SEEDS --out outputs/real_experiments/a_adult           > outputs/logs/a_adult.log 2>&1 &
nohup python -u scripts/run_real_experiments.py --only noise --datasets mnist_embed     --seeds $SEEDS --out outputs/real_experiments/a_mnist_embed     > outputs/logs/a_mnist_embed.log 2>&1 &
nohup python -u scripts/run_real_experiments.py --only noise --datasets fmnist_embed    --seeds $SEEDS --out outputs/real_experiments/a_fmnist_embed    > outputs/logs/a_fmnist_embed.log 2>&1 &
nohup python -u scripts/run_real_experiments.py --only noise --datasets cifar10_pca     --seeds $SEEDS --out outputs/real_experiments/a_cifar10_pca     > outputs/logs/a_cifar10_pca.log 2>&1 &
nohup python -u scripts/run_real_experiments.py --only noise --datasets newsgroups_embed --seeds $SEEDS --out outputs/real_experiments/a_newsgroups     > outputs/logs/a_newsgroups.log 2>&1 &

# ══════════════════════════════════════════════════════════════════════
# CLAIM B: Geometric Universality — all datasets in one (fast per dataset)
# ══════════════════════════════════════════════════════════════════════
nohup python -u scripts/run_real_experiments.py --only geometry --datasets breast_cancer,wine,heart,digits,adult --seeds $SEEDS --out outputs/real_experiments/b_tabular > outputs/logs/b_tabular.log 2>&1 &
nohup python -u scripts/run_real_experiments.py --only geometry --datasets mnist_embed,fmnist_embed,cifar10_pca,newsgroups_embed --seeds $SEEDS --out outputs/real_experiments/b_embed > outputs/logs/b_embed.log 2>&1 &

# ══════════════════════════════════════════════════════════════════════
# CLAIM C: Structural Signal — split by dataset (edge survival is slow)
# ══════════════════════════════════════════════════════════════════════
nohup python -u scripts/run_real_experiments.py --only signal --datasets breast_cancer  --seeds $SEEDS --out outputs/real_experiments/c_breast_cancer  > outputs/logs/c_breast_cancer.log 2>&1 &
nohup python -u scripts/run_real_experiments.py --only signal --datasets wine           --seeds $SEEDS --out outputs/real_experiments/c_wine           > outputs/logs/c_wine.log 2>&1 &
nohup python -u scripts/run_real_experiments.py --only signal --datasets heart          --seeds $SEEDS --out outputs/real_experiments/c_heart          > outputs/logs/c_heart.log 2>&1 &
nohup python -u scripts/run_real_experiments.py --only signal --datasets digits         --seeds $SEEDS --out outputs/real_experiments/c_digits         > outputs/logs/c_digits.log 2>&1 &
nohup python -u scripts/run_real_experiments.py --only signal --datasets adult          --seeds $SEEDS --out outputs/real_experiments/c_adult          > outputs/logs/c_adult.log 2>&1 &
nohup python -u scripts/run_real_experiments.py --only signal --datasets mnist_embed    --seeds $SEEDS --out outputs/real_experiments/c_mnist_embed    > outputs/logs/c_mnist_embed.log 2>&1 &
nohup python -u scripts/run_real_experiments.py --only signal --datasets fmnist_embed   --seeds $SEEDS --out outputs/real_experiments/c_fmnist_embed   > outputs/logs/c_fmnist_embed.log 2>&1 &
nohup python -u scripts/run_real_experiments.py --only signal --datasets cifar10_pca    --seeds $SEEDS --out outputs/real_experiments/c_cifar10_pca    > outputs/logs/c_cifar10_pca.log 2>&1 &
nohup python -u scripts/run_real_experiments.py --only signal --datasets newsgroups_embed --seeds $SEEDS --out outputs/real_experiments/c_newsgroups   > outputs/logs/c_newsgroups.log 2>&1 &

# ══════════════════════════════════════════════════════════════════════
# CLAIM D: Stability Predicts Reliability — all datasets together (fast)
# ══════════════════════════════════════════════════════════════════════
nohup python -u scripts/run_real_experiments.py --only reliability --datasets breast_cancer,wine,heart,digits,adult,mnist_embed,fmnist_embed,cifar10_pca,newsgroups_embed --seeds $SEEDS --out outputs/real_experiments/d_all > outputs/logs/d_reliability.log 2>&1 &

# ══════════════════════════════════════════════════════════════════════
# CLAIM E: Representation Quality — one job (compares all reps)
# ══════════════════════════════════════════════════════════════════════
nohup python -u scripts/run_real_experiments.py --only representation --seeds $SEEDS --out outputs/real_experiments/e_repr > outputs/logs/e_representation.log 2>&1 &

# ══════════════════════════════════════════════════════════════════════
# REFINEMENT: Accept/reject on multiple datasets
# ══════════════════════════════════════════════════════════════════════
nohup python -u scripts/refine_gm.py --datasets breast_cancer,wine,digits       --seeds $SEEDS --refine_steps 15 --out outputs/refinement/tabular  > outputs/logs/refine_tabular.log 2>&1 &
nohup python -u scripts/refine_gm.py --datasets mnist_embed,fmnist_embed        --seeds $SEEDS --refine_steps 15 --out outputs/refinement/embed    > outputs/logs/refine_embed.log 2>&1 &
nohup python -u scripts/refine_gm.py --datasets cifar10_pca                     --seeds $SEEDS --refine_steps 15 --out outputs/refinement/cifar    > outputs/logs/refine_cifar.log 2>&1 &

# ══════════════════════════════════════════════════════════════════════
# TRANSFER: 10 pairs — same-domain + cross-domain
# Split into batches so they don't compete for memory
# ══════════════════════════════════════════════════════════════════════
# Same-domain transfers (should work)
nohup python -u scripts/transfer_gm.py --pairs "mnist_embed:fmnist_embed,fmnist_embed:mnist_embed"   --seeds $SEEDS --out outputs/transfer/img_img    > outputs/logs/transfer_img_img.log 2>&1 &
nohup python -u scripts/transfer_gm.py --pairs "breast_cancer:wine,wine:breast_cancer"               --seeds $SEEDS --out outputs/transfer/tab_tab    > outputs/logs/transfer_tab_tab.log 2>&1 &
nohup python -u scripts/transfer_gm.py --pairs "digits:breast_cancer"                                --seeds $SEEDS --out outputs/transfer/tab_tab2   > outputs/logs/transfer_tab_tab2.log 2>&1 &

# Cross-domain transfers (stress test — discover what breaks)
nohup python -u scripts/transfer_gm.py --pairs "mnist_embed:newsgroups_embed"                        --seeds $SEEDS --out outputs/transfer/img_text   > outputs/logs/transfer_img_text.log 2>&1 &
nohup python -u scripts/transfer_gm.py --pairs "mnist_embed:cifar10_pca"                             --seeds $SEEDS --out outputs/transfer/mnist_cif  > outputs/logs/transfer_mnist_cif.log 2>&1 &
nohup python -u scripts/transfer_gm.py --pairs "breast_cancer:digits"                                --seeds $SEEDS --out outputs/transfer/bc_dig     > outputs/logs/transfer_bc_dig.log 2>&1 &
nohup python -u scripts/transfer_gm.py --pairs "digits:mnist_embed"                                  --seeds $SEEDS --out outputs/transfer/dig_mnist  > outputs/logs/transfer_dig_mnist.log 2>&1 &
nohup python -u scripts/transfer_gm.py --pairs "newsgroups_embed:cifar10_pca"                        --seeds $SEEDS --out outputs/transfer/text_cif   > outputs/logs/transfer_text_cif.log 2>&1 &

# ══════════════════════════════════════════════════════════════════════
# NOISE INJECTION: Legacy script, all 3 modes, multiple datasets
# ══════════════════════════════════════════════════════════════════════
nohup python -u scripts/run_noise_injection_test.py --datasets breast_cancer,digits      --seeds $SEEDS --noise_fracs "0.05,0.1,0.2" --noise_modes "random_points,label_flip,boundary_noise" --out outputs/noise_injection/tabular  > outputs/logs/noise_tabular.log 2>&1 &
nohup python -u scripts/run_noise_injection_test.py --datasets wine                      --seeds $SEEDS --noise_fracs "0.05,0.1,0.2" --noise_modes "random_points,label_flip,boundary_noise" --out outputs/noise_injection/wine     > outputs/logs/noise_wine.log 2>&1 &

# ══════════════════════════════════════════════════════════════════════

N_JOBS=$(jobs -p | wc -l)
echo ""
echo "══════════════════════════════════════════════════════════════════════"
echo "  LAUNCHED $N_JOBS background jobs"
echo "  Time: $(date)"
echo ""
echo "  Monitor:"
echo "    tail -f outputs/logs/a_mnist_embed.log   # watch one job"
echo "    ls outputs/logs/*.log | xargs wc -l      # check progress"
echo "    ps aux | grep python | wc -l             # count running"
echo "    grep '✓\|ERROR\|Traceback' outputs/logs/*.log  # check status"
echo ""
echo "  When all done (ps shows no python):"
echo "    python scripts/merge_results.py          # merge split CSVs"
echo "══════════════════════════════════════════════════════════════════════"
