#!/bin/bash
# CIFAR-10 ResNet-18 hyperparameter sweep
# Run the most important sweep first (k×T), then others in parallel
set -e
export PYTHONUNBUFFERED=1
cd "$(dirname "$0")/.."
mkdir -p outputs/cifar_sweep outputs/logs

echo "$(date) === CIFAR SWEEP START ==="

# Sweep 1: k × T grid (most important — run first)
echo "$(date) === k×T sweep ==="
python -u scripts/sweep_big_cifar.py --only kt_sweep --seeds 0,1 --n_train 40000
echo "$(date) === k×T DONE ==="

# Sweep 2: N scaling (does geometry help at smaller N?)
echo "$(date) === N scaling ==="
python -u scripts/sweep_big_cifar.py --only n_scaling --seeds 0,1
echo "$(date) === N scaling DONE ==="

# Sweep 3: Dim reduction (PCA on ResNet features)
echo "$(date) === dim reduction ==="
python -u scripts/sweep_big_cifar.py --only dim_reduction --seeds 0,1 --n_train 40000
echo "$(date) === dim reduction DONE ==="

# Sweep 4: Ridge regularization
echo "$(date) === ridge alpha ==="
python -u scripts/sweep_big_cifar.py --only ridge_l2 --seeds 0,1 --n_train 40000
echo "$(date) === ridge alpha DONE ==="

echo "$(date) === ALL CIFAR SWEEPS COMPLETE ==="
echo "Results in outputs/cifar_sweep/"
