#!/bin/bash
# Multidimensional Geometry Sweep
# Tests 10 graph construction methods × 3 propagations × 3 readouts
# across all 39 datasets
set -e
export PYTHONUNBUFFERED=1
export OMP_NUM_THREADS=8
export MKL_NUM_THREADS=8
cd "$(dirname "$0")/.."
mkdir -p outputs/multidim_geometry

# Install umap if not present (for UMAP graph construction)
pip install umap-learn --break-system-packages -q 2>/dev/null || true

echo "$(date) === MULTIDIM GEOMETRY SWEEP START ==="

# Quick test first (9 datasets, ~15 min)
echo "$(date) === Quick test ==="
python -u scripts/multidim_geometry.py --quick --seeds 0

# If quick succeeds, full sweep (all 39 datasets, ~3-4 hours)
echo "$(date) === Full sweep ==="
python -u scripts/multidim_geometry.py --seeds 0,1

echo "$(date) === MULTIDIM GEOMETRY SWEEP COMPLETE ==="
ls -la outputs/multidim_geometry/
