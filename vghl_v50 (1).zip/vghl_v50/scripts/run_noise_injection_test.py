#!/usr/bin/env python3
"""Noise Injection Test: Does pruning identify noise?

Injects controlled noise into training data, then tests whether pruning
preferentially removes the injected noise points. This turns "pruning helps"
into "pruning identifies noise" — a much stronger claim.

Two noise modes:
  1. Random points: inject uniform random points into the feature space
  2. Label noise: flip labels of a fraction of training points

For each mode, we measure:
  - Accuracy with vs without pruning (pruning should help more under noise)
  - For random-point injection: what fraction of pruned nodes were noise
    (should be >> the noise injection rate)

Usage:
    python scripts/run_noise_injection_test.py

    # Quick test
    python scripts/run_noise_injection_test.py --seeds 0,1,2 --noise_fracs 0.1

    # Different dataset
    python scripts/run_noise_injection_test.py --datasets sk_moons,breast_cancer
"""
import argparse
import sys
import os
import csv
import time
import statistics
import numpy as np
import torch
from pathlib import Path
from collections import defaultdict

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))
from vghl.utils.repro import enforce_reproducibility
enforce_reproducibility(seed=0)


from vghl.data.loaders import build_datasets, build_dataloaders, PointDataset
from vghl.utils.config import ExperimentConfig
from vghl.models.graph_builder import build_base_graph, GraphBuilderConfig
from vghl.models.pruning import prune_graph, PruningConfig


DATASET_DEFAULTS = {
    "sk_moons":       {"n_train": 5000, "n_val": 1000, "n_test": 1000, "epochs": 50},
    "sk_circles":     {"n_train": 5000, "n_val": 1000, "n_test": 1000, "epochs": 50},
    "breast_cancer":  {"n_train": 0, "n_val": 0, "n_test": 0, "epochs": 80},
    "digits":         {"n_train": 0, "n_val": 0, "n_test": 0, "epochs": 80},
}


def inject_random_points(X_train, y_train, noise_frac, seed):
    """Inject uniform random points into feature space.

    Returns X_noisy, y_noisy, is_noise_mask (bool tensor, True = injected noise).
    """
    rng = np.random.RandomState(seed)
    n_orig = len(X_train)
    n_noise = int(n_orig * noise_frac)

    # Random points in the bounding box of the original data (with 10% margin)
    X_np = X_train.detach().cpu().numpy()
    lo = X_np.min(axis=0) - 0.1 * (X_np.max(axis=0) - X_np.min(axis=0))
    hi = X_np.max(axis=0) + 0.1 * (X_np.max(axis=0) - X_np.min(axis=0))

    X_noise = rng.uniform(lo, hi, size=(n_noise, X_np.shape[1])).astype(np.float32)
    # Random labels
    n_classes = len(torch.unique(y_train))
    y_noise = torch.tensor(rng.randint(0, n_classes, n_noise), dtype=torch.long)

    X_noisy = torch.cat([X_train, torch.tensor(X_noise)], dim=0)
    y_noisy = torch.cat([y_train, y_noise], dim=0)

    is_noise = torch.zeros(len(X_noisy), dtype=torch.bool)
    is_noise[n_orig:] = True

    # Shuffle so noise isn't just at the end
    perm = torch.randperm(len(X_noisy), generator=torch.Generator().manual_seed(seed))
    X_noisy = X_noisy[perm]
    y_noisy = y_noisy[perm]
    is_noise = is_noise[perm]

    return X_noisy, y_noisy, is_noise


def inject_label_noise(X_train, y_train, noise_frac, seed):
    """Flip labels of a fraction of training points.

    Returns X (unchanged), y_noisy, is_noise_mask (bool tensor, True = flipped).
    """
    rng = np.random.RandomState(seed)
    n = len(y_train)
    n_flip = int(n * noise_frac)

    flip_idx = rng.choice(n, n_flip, replace=False)
    n_classes = len(torch.unique(y_train))

    y_noisy = y_train.clone()
    for i in flip_idx:
        # Flip to a different class
        orig = y_noisy[i].item()
        new_label = rng.randint(0, n_classes - 1)
        if new_label >= orig:
            new_label += 1
        y_noisy[i] = new_label

    is_noise = torch.zeros(n, dtype=torch.bool)
    is_noise[flip_idx] = True

    return X_train.clone(), y_noisy, is_noise


def inject_boundary_noise(X_train, y_train, noise_frac, seed):
    """Add noisy points near class boundaries with ambiguous labels.

    Finds boundary points (nearest to opposite class), perturbs them,
    assigns random labels. Tests whether pruning identifies structurally
    ambiguous injections, not just feature outliers.

    Returns X_noisy, y_noisy, is_noise_mask.
    """
    from vghl.models.knn_backend import KNNIndex
    rng = np.random.RandomState(seed)
    n_orig = len(X_train)
    n_noise = int(n_orig * noise_frac)
    n_classes = int(y_train.max()) + 1

    # Find boundary points: those closest to opposite-class neighbors
    X_cpu = X_train.detach().cpu()
    y_cpu = y_train.detach().cpu()
    # Per-class: find nearest opposite for each point
    margin = torch.full((n_orig,), float('inf'))
    for c in range(n_classes):
        opp_mask = (y_cpu != c)
        own_mask = (y_cpu == c)
        if opp_mask.sum() == 0 or own_mask.sum() == 0:
            continue
        opp_idx = opp_mask.nonzero(as_tuple=True)[0]
        own_idx = own_mask.nonzero(as_tuple=True)[0]
        opp_knn = KNNIndex(X_cpu[opp_idx])
        _, dists = opp_knn.query(X_cpu[own_idx], 1)
        margin[own_idx] = torch.tensor(dists[:, 0], dtype=torch.float32)

    # Select points with smallest margin (closest to boundary)
    n_source = min(n_noise * 3, n_orig)
    _, bnd_idx = torch.topk(margin, n_source, largest=False)
    chosen = bnd_idx[rng.choice(len(bnd_idx), n_noise, replace=False)]

    # Perturb these points slightly
    X_np = X_train[chosen].detach().cpu().numpy()
    sigma = np.std(X_train.detach().cpu().numpy(), axis=0) * 0.05
    X_noise = (X_np + rng.randn(*X_np.shape) * sigma).astype(np.float32)
    y_noise = torch.tensor(rng.randint(0, n_classes, n_noise), dtype=torch.long)

    X_noisy = torch.cat([X_train, torch.tensor(X_noise)], dim=0)
    y_noisy = torch.cat([y_train, y_noise], dim=0)
    is_noise = torch.zeros(len(X_noisy), dtype=torch.bool)
    is_noise[n_orig:] = True

    perm = torch.randperm(len(X_noisy), generator=torch.Generator().manual_seed(seed))
    return X_noisy[perm], y_noisy[perm], is_noise[perm]


def run_pruning_analysis(X_train, y_train, is_noise, graph_cfg, prune_cfg, seed):
    """Build graph, prune, and check which nodes were removed.

    Returns dict with:
      - n_original, n_pruned, n_removed
      - noise_in_original, noise_in_removed
      - removal_precision (fraction of removed nodes that were noise)
      - removal_recall (fraction of noise nodes that were removed)
    """
    # Build graph
    graph = build_base_graph(X_train, graph_cfg)
    edge_index = graph["edge_index"]
    edge_weight = graph["edge_weight"]
    N = X_train.shape[0]

    # Prune
    train_mask = torch.ones(N, dtype=torch.bool)
    pruned = prune_graph(
        edge_index, edge_weight, X_train,
        prune_cfg, labels=y_train,
        graph_builder_fn=lambda pts: build_base_graph(pts, graph_cfg),
        is_train_mask=train_mask,
    )

    node_mask = pruned.get("node_mask")
    if node_mask is None or node_mask.all():
        # No nodes removed — edge-only pruning
        n_edges_before = edge_index.shape[1]
        n_edges_after = pruned["edge_index"].shape[1]
        return {
            "n_original": N,
            "n_pruned": N,
            "n_removed": 0,
            "noise_in_original": int(is_noise.sum()),
            "noise_in_removed": 0,
            "removal_precision": 0.0,
            "removal_recall": 0.0,
            "edges_before": n_edges_before,
            "edges_after": n_edges_after,
            "node_pruning": False,
        }

    removed_mask = ~node_mask
    n_removed = int(removed_mask.sum())
    noise_in_removed = int((removed_mask & is_noise).sum())
    noise_in_original = int(is_noise.sum())
    clean_in_removed = n_removed - noise_in_removed

    # Precision: of removed nodes, what fraction were noise?
    precision = noise_in_removed / max(n_removed, 1)
    # Recall: of noise nodes, what fraction were removed?
    recall = noise_in_removed / max(noise_in_original, 1)

    return {
        "n_original": N,
        "n_pruned": int(node_mask.sum()),
        "n_removed": n_removed,
        "noise_in_original": noise_in_original,
        "noise_in_removed": noise_in_removed,
        "clean_in_removed": clean_in_removed,
        "removal_precision": precision,
        "removal_recall": recall,
        "edges_before": edge_index.shape[1],
        "edges_after": pruned["edge_index"].shape[1],
        "node_pruning": True,
    }




def load_dataset(dataset, seed, n_train, n_val, n_test):
    """Load dataset using VGHL data pipeline."""
    cfg = ExperimentConfig()
    cfg.data.dataset = dataset
    cfg.data.n_train = n_train
    cfg.data.n_val = n_val
    cfg.data.n_test = n_test
    cfg.seed = seed
    train_ds, val_ds, test_ds, meta = build_datasets(cfg)
    return train_ds.X, train_ds.y, val_ds.X, val_ds.y, test_ds.X, test_ds.y, meta


def main():
    p = argparse.ArgumentParser(description="Noise injection test for pruning")
    p.add_argument("--datasets", type=str, default="sk_moons,breast_cancer")
    p.add_argument("--seeds", type=str, default="0,1,2,3,4")
    p.add_argument("--k_values", type=str, default="16")
    p.add_argument("--noise_fracs", type=str, default="0.05,0.1,0.2",
                   help="Comma-separated noise fractions to test")
    p.add_argument("--noise_modes", type=str, default="random_points,label_flip,boundary_noise",
                   help="Comma-separated: random_points, label_flip, boundary_noise")
    p.add_argument("--out", type=str, default="outputs/noise_injection")
    p.add_argument("--verbose", action="store_true")

    args = p.parse_args()
    datasets = [d.strip() for d in args.datasets.split(",")]
    seeds = [int(s) for s in args.seeds.split(",")]
    k_values = [int(k) for k in args.k_values.split(",")]
    noise_fracs = [float(f) for f in args.noise_fracs.split(",")]
    noise_modes = [m.strip() for m in args.noise_modes.split(",")]
    out_dir = Path(args.out)
    out_dir.mkdir(parents=True, exist_ok=True)

    print("=" * 70)
    print("NOISE INJECTION TEST")
    print(f"  Datasets:     {datasets}")
    print(f"  Seeds:        {seeds}")
    print(f"  k values:     {k_values}")
    print(f"  Noise fracs:  {noise_fracs}")
    print(f"  Noise modes:  {noise_modes}")
    print("=" * 70)

    all_rows = []

    for dataset in datasets:
        dd = DATASET_DEFAULTS.get(dataset, {})
        n_train = dd.get("n_train", 5000)
        n_val = dd.get("n_val", 1000)
        n_test = dd.get("n_test", 1000)

        for k in k_values:
            for noise_frac in noise_fracs:
                for noise_mode in noise_modes:
                    for seed in seeds:
                        tag = f"{dataset}_{noise_mode}_f{noise_frac}_k{k}_s{seed}"
                        print(f"\n[{tag}]", flush=True)

                        # Load clean data
                        X_tr, y_tr, X_val, y_val, X_te, y_te, meta = load_dataset(
                            dataset, seed, n_train, n_val, n_test
                        )

                        # Inject noise
                        if noise_mode == "random_points":
                            X_noisy, y_noisy, is_noise = inject_random_points(
                                X_tr, y_tr, noise_frac, seed
                            )
                        elif noise_mode == "label_flip":
                            X_noisy, y_noisy, is_noise = inject_label_noise(
                                X_tr, y_tr, noise_frac, seed
                            )
                        elif noise_mode == "boundary_noise":
                            X_noisy, y_noisy, is_noise = inject_boundary_noise(
                                X_tr, y_tr, noise_frac, seed
                            )
                        else:
                            raise ValueError(f"Unknown noise mode: {noise_mode}")

                        print(f"  Injected: {int(is_noise.sum())}/{len(X_noisy)} "
                              f"noise points ({noise_mode})")

                        # Run pruning analysis (direct, no training)
                        graph_cfg = GraphBuilderConfig(type="knn", k=k)

                        # ── Accuracy comparison: no-prune, structured-prune, random-prune ──
                        from vghl.models.propagation import propagate, PropagationConfig
                        from vghl.models.probe import ridge_eval, embed_queries_via_knn
                        prop_cfg = PropagationConfig(type="random_walk", steps=5)
                        n_classes = int(max(y_noisy.max(), y_val.max())) + 1

                        # 1. No pruning on noisy data
                        graph_noisy = build_base_graph(X_noisy, graph_cfg)
                        h_noisy = propagate(X_noisy, graph_noisy["edge_index"],
                                            graph_noisy["edge_weight"],
                                            len(X_noisy), prop_cfg)
                        # Embed val via kNN to propagated noisy train
                        h_val_emb = embed_queries_via_knn(h_noisy, X_noisy, X_val, k=k)
                        acc_noprune = ridge_eval(h_noisy, y_noisy, h_val_emb, y_val,
                                                 n_classes)
                        print(f"  No prune on noisy: acc={acc_noprune:.4f}")

                        for prune_method, prune_label in [
                            ("geometric", "geo"),
                            ("stability", "stab"),
                        ]:
                            # Adaptive sigma for stability pruning
                            if prune_method == "stability":
                                edge_dists = (X_noisy[graph_noisy["edge_index"][0]] -
                                              X_noisy[graph_noisy["edge_index"][1]]).norm(dim=1)
                                sigma_adaptive = max(0.05 * edge_dists.median().item(), 1e-6)
                                # Quantile-based: target removal rate = noise_frac * 2
                                # (expect to remove ~2x noise fraction to catch noise + margin)
                                target_removal = min(noise_frac * 2.0, 0.4)
                                # We'll compute Jaccard then threshold at quantile
                                # Use node_jaccard_min=0.0 to disable threshold pruning,
                                # then apply quantile post-hoc
                                prune_cfg = PruningConfig(
                                    enabled=True,
                                    methods=[prune_method],
                                    n_bootstrap=5,
                                    perturb_sigma=sigma_adaptive,
                                    node_jaccard_min=0.0,  # disable: we'll do quantile below
                                    edge_survival_threshold=0.5,
                                )
                                print(f"  stab σ={sigma_adaptive:.4f} "
                                      f"target_rm={target_removal:.0%}")
                            else:
                                sigma_adaptive = 0.0
                                target_removal = 0.0
                                prune_cfg = PruningConfig(
                                    enabled=True,
                                    methods=[prune_method],
                                )

                            analysis = run_pruning_analysis(
                                X_noisy, y_noisy, is_noise,
                                graph_cfg, prune_cfg, seed,
                            )

                            # 2. Accuracy after structured pruning
                            # Always compute — even for edge-only pruning
                            N_noisy = len(X_noisy)
                            pruned_result = prune_graph(
                                graph_noisy["edge_index"],
                                graph_noisy["edge_weight"],
                                X_noisy,
                                prune_cfg, labels=y_noisy,
                                graph_builder_fn=lambda pts: build_base_graph(pts, graph_cfg),
                                is_train_mask=torch.ones(N_noisy, dtype=torch.bool),
                            )
                            node_mask = pruned_result.get("node_mask")
                            pruned_ei = pruned_result["edge_index"]
                            pruned_ew = pruned_result["edge_weight"]

                            # For stability: apply quantile-based node removal
                            # instead of fixed threshold
                            if (prune_method == "stability"
                                    and target_removal > 0
                                    and "mean_jaccard" in pruned_result.get("stats", {})):
                                # Re-compute Jaccard to get per-node scores
                                # (prune_graph already computed it but only stored stats)
                                # We need to re-run just the Jaccard part
                                from vghl.models.pruning import (
                                    _build_neighbor_sets, _pairwise_jaccard,
                                )
                                boot_sets = []
                                rng_stab = np.random.RandomState(seed + 7777)
                                N_n = len(X_noisy)
                                for _b in range(5):
                                    noise_stab = torch.randn_like(X_noisy) * sigma_adaptive
                                    g_pert = build_base_graph(X_noisy + noise_stab, graph_cfg)
                                    boot_sets.append(
                                        _build_neighbor_sets(g_pert["edge_index"], N_n, X_noisy.device)
                                    )
                                node_jaccard = _pairwise_jaccard(boot_sets, N_n, X_noisy.device)
                                # Remove bottom target_removal fraction by Jaccard
                                n_remove = int(N_n * target_removal)
                                n_remove = min(n_remove, N_n - 10)
                                if n_remove > 0:
                                    _, worst_idx = torch.topk(node_jaccard, n_remove, largest=False)
                                    node_mask = torch.ones(N_n, dtype=torch.bool, device=X_noisy.device)
                                    node_mask[worst_idx] = False
                                    # Recompute edges for kept nodes
                                    src_ok = node_mask[graph_noisy["edge_index"][0]]
                                    dst_ok = node_mask[graph_noisy["edge_index"][1]]
                                    kept_edge_mask = src_ok & dst_ok
                                    # Remap node indices
                                    remap = torch.cumsum(node_mask.long(), dim=0) - 1
                                    pruned_ei = remap[graph_noisy["edge_index"][:, kept_edge_mask]]
                                    pruned_ew = graph_noisy["edge_weight"][kept_edge_mask]

                                    jac_kept = node_jaccard[node_mask].mean().item()
                                    jac_removed = node_jaccard[~node_mask].mean().item()
                                    print(f"    quantile prune: removed {n_remove}/{N_n}, "
                                          f"Jaccard kept={jac_kept:.3f} removed={jac_removed:.3f}")

                                    # Update analysis stats
                                    analysis["n_removed"] = n_remove
                                    analysis["node_pruning"] = True
                                    # Recompute precision/recall with new mask
                                    removed_mask = ~node_mask
                                    n_noise = int(is_noise.sum())
                                    if n_noise > 0 and n_remove > 0:
                                        noise_removed = int((removed_mask & is_noise).sum())
                                        analysis["removal_precision"] = noise_removed / n_remove
                                        analysis["removal_recall"] = noise_removed / n_noise
                                    else:
                                        analysis["removal_precision"] = 0.0
                                        analysis["removal_recall"] = 0.0

                            has_node_removal = (node_mask is not None
                                                and not node_mask.all())

                            if has_node_removal:
                                X_kept = X_noisy[node_mask]
                                y_kept = y_noisy[node_mask]
                            else:
                                X_kept = X_noisy
                                y_kept = y_noisy
                            N_kept = X_kept.shape[0]

                            # Propagate on pruned structure
                            if has_node_removal:
                                g_kept = build_base_graph(X_kept, graph_cfg)
                                h_kept = propagate(X_kept, g_kept["edge_index"],
                                                   g_kept["edge_weight"],
                                                   N_kept, prop_cfg)
                            else:
                                # Edge-only pruning: use pruned edges
                                h_kept = propagate(X_kept, pruned_ei, pruned_ew,
                                                   N_kept, prop_cfg)

                            h_val_pruned = embed_queries_via_knn(
                                h_kept, X_kept, X_val, k=min(k, N_kept))
                            acc_pruned = ridge_eval(h_kept, y_kept,
                                                    h_val_pruned, y_val, n_classes)

                            # 3. Random deletion (matched fraction)
                            acc_random = acc_noprune  # default for edge-only
                            if has_node_removal:
                                n_keep = int(node_mask.sum())
                                rng_rand = np.random.RandomState(seed + 999)
                                rand_idx = torch.tensor(
                                    rng_rand.choice(N_noisy, n_keep, replace=False))
                                X_rand = X_noisy[rand_idx]
                                y_rand = y_noisy[rand_idx]
                                g_rand = build_base_graph(X_rand, graph_cfg)
                                h_rand = propagate(X_rand, g_rand["edge_index"],
                                                   g_rand["edge_weight"],
                                                   n_keep, prop_cfg)
                                h_val_rand = embed_queries_via_knn(
                                    h_rand, X_rand, X_val, k=min(k, n_keep))
                                acc_random = ridge_eval(h_rand, y_rand,
                                                        h_val_rand, y_val, n_classes)

                            # For label_flip: also report edge-disagreement reduction
                            edge_disagree_reduction = 0.0
                            if noise_mode == "label_flip":
                                orig_ei = graph_noisy["edge_index"]
                                orig_disagree = (y_noisy[orig_ei[0]] != y_noisy[orig_ei[1]]).float().mean().item()
                                if pruned_ei.numel() > 0:
                                    if has_node_removal:
                                        kept_disagree = (y_kept[pruned_ei[0]] != y_kept[pruned_ei[1]]).float().mean().item()
                                    else:
                                        kept_disagree = (y_noisy[pruned_ei[0]] != y_noisy[pruned_ei[1]]).float().mean().item()
                                else:
                                    kept_disagree = 0.0
                                edge_disagree_reduction = orig_disagree - kept_disagree

                            # Class-conditional removal rates
                            n_classes_noisy = int(y_noisy.max()) + 1
                            class_removal_rates = {}
                            if has_node_removal and node_mask is not None:
                                removed_mask = ~node_mask
                                for c in range(n_classes_noisy):
                                    c_mask = (y_noisy == c)
                                    c_total = int(c_mask.sum())
                                    c_removed = int((removed_mask & c_mask).sum())
                                    class_removal_rates[f"rm_rate_c{c}"] = (
                                        c_removed / c_total if c_total > 0 else 0.0)

                            row = {
                                "dataset": dataset, "k": k,
                                "noise_mode": noise_mode,
                                "noise_frac": noise_frac,
                                "prune_method": prune_method,
                                "seed": seed,
                                "sigma_used": sigma_adaptive,
                                "target_removal": target_removal,
                                "acc_no_prune": acc_noprune,
                                "acc_structured_prune": acc_pruned,
                                "acc_random_prune": acc_random,
                                "edge_disagree_reduction": edge_disagree_reduction,
                                **analysis,
                                **class_removal_rates,
                            }
                            all_rows.append(row)

                            if analysis["node_pruning"] and analysis["n_removed"] > 0:
                                print(f"  {prune_label}: removed {analysis['n_removed']} nodes, "
                                      f"precision={analysis['removal_precision']:.3f}, "
                                      f"recall={analysis['removal_recall']:.3f}, "
                                      f"acc_prune={acc_pruned:.4f}, "
                                      f"acc_random={acc_random:.4f}")
                            else:
                                print(f"  {prune_label}: edge-only pruning "
                                      f"({analysis['edges_before']}→{analysis['edges_after']} edges), "
                                      f"acc_prune={acc_pruned:.4f}"
                                      + (f", edge_disagree_Δ={edge_disagree_reduction:+.4f}"
                                         if noise_mode == "label_flip" else ""))

                        # (accuracy comparison integrated above via ridge)

    # Write results
    if all_rows:
        csv_path = out_dir / "noise_injection_results.csv"
        # Build fieldnames as union of all keys (handles varying rm_rate_c* columns)
        preferred = [
            "dataset", "k", "noise_mode", "noise_frac", "prune_method", "seed",
            "sigma_used", "target_removal",
            "acc_no_prune", "acc_structured_prune", "acc_random_prune",
            "edge_disagree_reduction",
            "n_original", "n_pruned", "n_removed",
            "noise_in_original", "noise_in_removed",
            "removal_precision", "removal_recall",
            "edges_before", "edges_after", "node_pruning",
        ]
        all_keys = {k for row in all_rows for k in row.keys()}
        extras = sorted(all_keys - set(preferred))
        fieldnames = [c for c in preferred if c in all_keys] + extras
        with open(csv_path, "w", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames,
                                    extrasaction="ignore")
            writer.writeheader()
            for row in all_rows:
                writer.writerow({k: row.get(k, "") for k in fieldnames})
        print(f"\nResults: {csv_path}")

    # Compute and print summary
    if all_rows:
        print("\n" + "=" * 90)
        print("NOISE INJECTION SUMMARY")
        print("=" * 90)

        groups = defaultdict(list)
        for r in all_rows:
            key = (r["dataset"], r["noise_mode"], r["noise_frac"], r["prune_method"])
            groups[key].append(r)

        print(f"{'Dataset':<16} {'Mode':<14} {'Frac':>5} {'Prune':<8} "
              f"{'Removed':>8} {'Precision':>10} {'Recall':>8} "
              f"{'NoP':>6} {'Struc':>6} {'Rand':>6}")
        print("-" * 100)

        summary_rows = []
        for (ds, mode, frac, prune), runs in sorted(groups.items()):
            precisions = [r["removal_precision"] for r in runs if r["node_pruning"]]
            recalls = [r["removal_recall"] for r in runs if r["node_pruning"]]
            removed = [r["n_removed"] for r in runs if r["node_pruning"]]
            acc_nop = [r.get("acc_no_prune", 0) for r in runs
                       if r.get("acc_no_prune") is not None]
            acc_str = [r.get("acc_structured_prune", 0) for r in runs
                       if r.get("acc_structured_prune") is not None]
            acc_rnd = [r.get("acc_random_prune", 0) for r in runs
                       if r.get("acc_random_prune") is not None]

            if precisions:
                mean_prec = statistics.mean(precisions)
                std_prec = statistics.stdev(precisions) if len(precisions) > 1 else 0
                mean_rec = statistics.mean(recalls)
                std_rec = statistics.stdev(recalls) if len(recalls) > 1 else 0
                mean_rem = statistics.mean(removed)
                m_nop = statistics.mean(acc_nop) if acc_nop else 0
                m_str = statistics.mean(acc_str) if acc_str else 0
                m_rnd = statistics.mean(acc_rnd) if acc_rnd else 0

                print(f"{ds:<16} {mode:<14} {frac:>5.2f} {prune:<8} "
                      f"{mean_rem:>8.0f} "
                      f"{mean_prec:>6.3f}±{std_prec:.3f} "
                      f"{mean_rec:>4.3f}±{std_rec:.3f} "
                      f"{m_nop:>6.3f} {m_str:>6.3f} {m_rnd:>6.3f}")

                summary_rows.append({
                    "dataset": ds, "noise_mode": mode, "noise_frac": frac,
                    "prune_method": prune, "n_seeds": len(precisions),
                    "mean_removed": mean_rem,
                    "mean_precision": mean_prec, "std_precision": std_prec,
                    "mean_recall": mean_rec, "std_recall": std_rec,
                    "mean_acc_no_prune": m_nop,
                    "mean_acc_structured": m_str,
                    "mean_acc_random": m_rnd,
                })
            else:
                n_edge_runs = len([r for r in runs if not r["node_pruning"]])
                if n_edge_runs > 0:
                    edges_b = statistics.mean([r["edges_before"] for r in runs])
                    edges_a = statistics.mean([r["edges_after"] for r in runs])
                    print(f"{ds:<16} {mode:<14} {frac:>5.2f} {prune:<8} "
                          f"{'edge-only':>8} "
                          f"{'N/A':>10} {'N/A':>8}  "
                          f"(edges: {edges_b:.0f}→{edges_a:.0f})")

        if summary_rows:
            summary_path = out_dir / "noise_injection_summary.csv"
            all_skeys = sorted({k for row in summary_rows for k in row.keys()})
            with open(summary_path, "w", newline="") as f:
                writer = csv.DictWriter(f, fieldnames=all_skeys)
                writer.writeheader()
                for row in summary_rows:
                    writer.writerow({k: row.get(k, "") for k in all_skeys})
            print(f"\nSummary: {summary_path}")

        # Key interpretation
        print("\n" + "=" * 70)
        print("INTERPRETATION GUIDE")
        print("=" * 70)
        print("Precision > noise_frac → pruning preferentially targets noise")
        print("  e.g., if noise_frac=0.10 and precision=0.35,")
        print("  then 35% of removed nodes were noise (vs 10% by chance)")
        print("Recall > 0 → pruning actually catches some noise")
        print("  Higher recall = more noise removed")
        print()

    print(f"All outputs in: {out_dir}")


if __name__ == "__main__":
    main()
