#!/usr/bin/env python3
"""CIFAR-10 ResNet-18 Large-Scale Sweep.

The N=40k run showed full_vghl (0.364) < no_graph (0.416), meaning
propagation hurts with default params. But random edges collapse to
0.100 (chance), so geometry IS causal — we just need to find the
right operating point.

Hypotheses to test:
  1. T is too high — over-smoothing kills discriminative signal
  2. k is wrong — too small = fragile, too large = dilutes classes
  3. Need weighted propagation (distance-weighted, not uniform)
  4. Sigma (kernel width) matters — adaptive vs fixed
  5. Dimensionality: PCA pre-reduction of ResNet features might help
  6. Ridge alpha tuning for high-dim propagated features
  7. N scaling: maybe geometry helps more at moderate N

Usage:
    python -u scripts/sweep_big_cifar.py
    python -u scripts/sweep_big_cifar.py --only kT_sweep
    python -u scripts/sweep_big_cifar.py --only dim_reduction
    python -u scripts/sweep_big_cifar.py --only n_scaling
    python -u scripts/sweep_big_cifar.py --only propagation_types
    python -u scripts/sweep_big_cifar.py --only ridge_l2
    python -u scripts/sweep_big_cifar.py --only combined_best
"""
import os, sys, argparse, csv, time
import numpy as np
import torch
from pathlib import Path
from collections import defaultdict

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from vghl.data.loaders import build_datasets, PointDataset
from vghl.utils.config import ExperimentConfig
from vghl.models.graph_builder import build_base_graph, GraphBuilderConfig
from vghl.models.propagation import propagate, PropagationConfig
from vghl.models.probe import ridge_eval, embed_queries_via_knn

def _save_csv(rows, path):
    if not rows: return
    path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    keys = list(rows[0].keys())
    extra = sorted({k for r in rows for k in r.keys()} - set(keys))
    keys.extend(extra)
    tmp = str(path) + f".tmp.{os.getpid()}"
    with open(tmp, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=keys); w.writeheader()
        for r in rows: w.writerow({k: r.get(k, "") for k in keys})
        f.flush(); os.fsync(f.fileno())
    os.replace(tmp, str(path))
    print(f"  Saved: {path}")


def load_cifar(seed, n_train=40000, n_val=5000, n_test=10000):
    cfg = ExperimentConfig()
    cfg.data.dataset = "cifar10_resnet18"
    cfg.data.n_train = n_train
    cfg.data.n_val = n_val
    cfg.data.n_test = n_test
    cfg.seed = seed
    tr, va, te, meta = build_datasets(cfg)
    return tr.X, tr.y, va.X, va.y, te.X, te.y


def eval_full(X_tr, y_tr, X_te, y_te, k, T, ridge_l2=1e-2):
    """Full pipeline with configurable params. Returns acc and timing."""
    N = len(X_tr)
    nc = max(int(y_tr.max()) + 1, int(y_te.max()) + 1)
    k_eff = min(k, N - 1)
    gc = GraphBuilderConfig(type="knn", k=k_eff)
    pc = PropagationConfig(type="random_walk", steps=T)

    t0 = time.time()
    g = build_base_graph(X_tr, gc)
    h = propagate(X_tr, g["edge_index"], g["edge_weight"], N, pc)
    h_te = embed_queries_via_knn(h, X_tr, X_te, k=k_eff)
    acc = ridge_eval(h, y_tr, h_te, y_te, n_classes=nc, l2=ridge_l2)
    elapsed = time.time() - t0
    return acc, elapsed


def eval_no_graph(X_tr, y_tr, X_te, y_te, ridge_l2=1e-2):
    nc = max(int(y_tr.max()) + 1, int(y_te.max()) + 1)
    return ridge_eval(X_tr, y_tr, X_te, y_te, n_classes=nc, l2=ridge_l2)


# ══════════════════════════════════════════════════════════════════════
# SWEEP 1: k × T grid (the most important one)
# ══════════════════════════════════════════════════════════════════════
def run_kT_sweep(seeds, out_dir, n_train=40000):
    print("\n" + "=" * 70)
    print(f"SWEEP 1: k × T grid (N={n_train})")
    print("=" * 70)
    k_values = [4, 8, 16, 32, 64, 128, 256]
    T_values = [0, 1, 2, 3, 5, 10]
    rows = []

    for seed in seeds:
        X_tr, y_tr, _, _, X_te, y_te = load_cifar(seed, n_train=n_train)
        N = len(X_tr)

        # Baseline: no graph
        acc_ng = eval_no_graph(X_tr, y_tr, X_te, y_te)
        rows.append({"seed": seed, "k": 0, "T": 0, "acc": acc_ng,
                      "time_s": 0, "N": N, "condition": "no_graph"})
        print(f"  s{seed} no_graph: {acc_ng:.4f}")

        for k in k_values:
            for T in T_values:
                acc, elapsed = eval_full(X_tr, y_tr, X_te, y_te, k, T)
                rows.append({"seed": seed, "k": k, "T": T, "acc": acc,
                              "time_s": round(elapsed, 2), "N": N,
                              "condition": f"k{k}_T{T}"})
                print(f"  s{seed} k={k:>3} T={T:>2}: {acc:.4f} ({elapsed:.1f}s)")

    _save_csv(rows, out_dir / "sweep_kT.csv")

    # Print summary: mean acc per (k, T)
    print(f"\n{'k':>5}", end="")
    for T in T_values:
        print(f"  T={T:>2}", end="")
    print(f"  {'best_T':>6}")
    print("-" * (8 + 7 * len(T_values) + 8))
    by_kT = defaultdict(list)
    for r in rows:
        if r["condition"] != "no_graph":
            by_kT[(r["k"], r["T"])].append(r["acc"])
    ng_mean = np.mean([r["acc"] for r in rows if r["condition"] == "no_graph"])
    print(f"{'ng':>5}", end="")
    for T in T_values:
        print(f"  {ng_mean:.4f}", end="")
    print()
    for k in k_values:
        print(f"{k:>5}", end="")
        best_T, best_acc = 0, 0
        for T in T_values:
            m = np.mean(by_kT.get((k, T), [0]))
            print(f"  {m:.4f}", end="")
            if m > best_acc:
                best_acc = m
                best_T = T
        marker = " ✓" if best_acc > ng_mean else ""
        print(f"  T={best_T:>2}{marker}")

    return rows


# ══════════════════════════════════════════════════════════════════════
# SWEEP 2: Dimensionality reduction (PCA on ResNet features)
# ══════════════════════════════════════════════════════════════════════
def run_dim_reduction(seeds, out_dir, n_train=40000):
    print("\n" + "=" * 70)
    print(f"SWEEP 2: PCA dimensionality reduction (N={n_train})")
    print("=" * 70)
    from sklearn.decomposition import PCA
    from sklearn.preprocessing import StandardScaler

    dims = [32, 64, 128, 256, 512]  # 512 = no reduction
    k_values = [16, 32, 64]
    T_values = [1, 2, 3, 5]
    rows = []

    for seed in seeds:
        X_tr, y_tr, _, _, X_te, y_te = load_cifar(seed, n_train=n_train)

        for d in dims:
            if d < 512:
                scaler = StandardScaler()
                X_tr_s = scaler.fit_transform(X_tr.numpy())
                X_te_s = scaler.transform(X_te.numpy())
                pca = PCA(n_components=d, random_state=seed)
                X_tr_d = torch.tensor(pca.fit_transform(X_tr_s), dtype=torch.float32)
                X_te_d = torch.tensor(pca.transform(X_te_s), dtype=torch.float32)
                var_explained = pca.explained_variance_ratio_.sum()
            else:
                X_tr_d, X_te_d = X_tr, X_te
                var_explained = 1.0

            # No graph baseline for this dim
            acc_ng = eval_no_graph(X_tr_d, y_tr, X_te_d, y_te)
            rows.append({"seed": seed, "dim": d, "k": 0, "T": 0,
                          "acc": acc_ng, "var_explained": round(var_explained, 4),
                          "condition": "no_graph"})

            for k in k_values:
                for T in T_values:
                    acc, elapsed = eval_full(X_tr_d, y_tr, X_te_d, y_te, k, T)
                    rows.append({"seed": seed, "dim": d, "k": k, "T": T,
                                  "acc": acc, "var_explained": round(var_explained, 4),
                                  "time_s": round(elapsed, 2),
                                  "condition": f"d{d}_k{k}_T{T}"})

            print(f"  s{seed} d={d}: no_graph={acc_ng:.4f}, "
                  f"best_prop={max(r['acc'] for r in rows if r['seed']==seed and r['dim']==d and r['condition']!='no_graph'):.4f}, "
                  f"var={var_explained:.3f}")

    _save_csv(rows, out_dir / "sweep_dim.csv")
    return rows


# ══════════════════════════════════════════════════════════════════════
# SWEEP 3: N scaling — does geometry help more at smaller N?
# ══════════════════════════════════════════════════════════════════════
def run_n_scaling(seeds, out_dir):
    print("\n" + "=" * 70)
    print("SWEEP 3: N scaling (where does geometry start helping?)")
    print("=" * 70)
    n_values = [500, 1000, 2000, 5000, 10000, 20000, 40000]
    # Use a few good (k, T) combos
    configs = [(16, 1), (16, 2), (32, 1), (32, 2), (64, 1)]
    rows = []

    for seed in seeds:
        for n_train in n_values:
            try:
                X_tr, y_tr, _, _, X_te, y_te = load_cifar(seed, n_train=n_train)
            except Exception as e:
                print(f"  SKIP N={n_train} s{seed}: {e}"); continue
            N = len(X_tr)

            acc_ng = eval_no_graph(X_tr, y_tr, X_te, y_te)
            rows.append({"seed": seed, "N": N, "k": 0, "T": 0,
                          "acc": acc_ng, "condition": "no_graph"})

            # kNN baseline
            from sklearn.neighbors import KNeighborsClassifier
            knn = KNeighborsClassifier(n_neighbors=min(16, N - 1), n_jobs=-1)
            knn.fit(X_tr.numpy(), y_tr.numpy())
            acc_knn = float(knn.score(X_te.numpy(), y_te.numpy()))
            rows.append({"seed": seed, "N": N, "k": 16, "T": -1,
                          "acc": acc_knn, "condition": "knn_baseline"})

            for k, T in configs:
                if k >= N: continue
                acc, elapsed = eval_full(X_tr, y_tr, X_te, y_te, k, T)
                rows.append({"seed": seed, "N": N, "k": k, "T": T,
                              "acc": acc, "time_s": round(elapsed, 2),
                              "condition": f"k{k}_T{T}"})

            best_vghl = max(r["acc"] for r in rows
                            if r["seed"] == seed and r["N"] == N
                            and r["condition"] not in ("no_graph", "knn_baseline"))
            print(f"  s{seed} N={N:>5}: no_graph={acc_ng:.4f} kNN={acc_knn:.4f} "
                  f"best_vghl={best_vghl:.4f} delta={best_vghl - acc_ng:+.4f}")

    _save_csv(rows, out_dir / "sweep_N.csv")
    return rows


# ══════════════════════════════════════════════════════════════════════
# SWEEP 4: Ridge alpha (regularization matters for propagated features)
# ══════════════════════════════════════════════════════════════════════
def run_ridge_l2(seeds, out_dir, n_train=40000):
    print("\n" + "=" * 70)
    print(f"SWEEP 4: Ridge alpha (N={n_train})")
    print("=" * 70)
    alphas = [0.001, 0.01, 0.1, 1.0, 10.0, 100.0]
    configs = [(16, 1), (32, 1), (32, 2), (64, 1)]
    rows = []

    for seed in seeds:
        X_tr, y_tr, _, _, X_te, y_te = load_cifar(seed, n_train=n_train)
        N = len(X_tr)
        nc = max(int(y_tr.max()) + 1, int(y_te.max()) + 1)

        for alpha in alphas:
            # No graph with this alpha
            acc_ng = eval_no_graph(X_tr, y_tr, X_te, y_te, ridge_l2=alpha)
            rows.append({"seed": seed, "k": 0, "T": 0, "alpha": alpha,
                          "acc": acc_ng, "condition": "no_graph"})

            for k, T in configs:
                acc, _ = eval_full(X_tr, y_tr, X_te, y_te, k, T,
                                   ridge_l2=alpha)
                rows.append({"seed": seed, "k": k, "T": T, "alpha": alpha,
                              "acc": acc, "condition": f"k{k}_T{T}"})

            best = max(r["acc"] for r in rows
                       if r["seed"] == seed and r["alpha"] == alpha
                       and r["condition"] != "no_graph")
            print(f"  s{seed} α={alpha:>6.3f}: no_graph={acc_ng:.4f} best_vghl={best:.4f}")

    _save_csv(rows, out_dir / "sweep_alpha.csv")
    return rows


# ══════════════════════════════════════════════════════════════════════
# SWEEP 5: Combined best — take winners from above, run ablation
# ══════════════════════════════════════════════════════════════════════
def run_combined_best(seeds, out_dir, n_train=40000):
    """After running other sweeps, manually set best params here and
    run the full ablation (real vs random vs rewired vs pruned)."""
    print("\n" + "=" * 70)
    print(f"SWEEP 5: Combined best params — full ablation (N={n_train})")
    print("=" * 70)
    from sklearn.neighbors import KNeighborsClassifier

    # === SET THESE AFTER REVIEWING SWEEP RESULTS ===
    best_configs = [
        {"k": 16, "T": 1, "label": "k16_T1"},
        {"k": 32, "T": 1, "label": "k32_T1"},
        {"k": 32, "T": 2, "label": "k32_T2"},
        {"k": 64, "T": 1, "label": "k64_T1"},
        {"k": 64, "T": 2, "label": "k64_T2"},
    ]
    rows = []

    for seed in seeds:
        X_tr, y_tr, _, _, X_te, y_te = load_cifar(seed, n_train=n_train)
        N = len(X_tr)
        nc = max(int(y_tr.max()) + 1, int(y_te.max()) + 1)

        # Baselines
        acc_ng = eval_no_graph(X_tr, y_tr, X_te, y_te)
        knn_clf = KNeighborsClassifier(n_neighbors=32, n_jobs=-1)
        knn_clf.fit(X_tr.numpy(), y_tr.numpy())
        acc_knn = float(knn_clf.score(X_te.numpy(), y_te.numpy()))

        for cfg in best_configs:
            k, T, label = cfg["k"], cfg["T"], cfg["label"]
            gc = GraphBuilderConfig(type="knn", k=min(k, N - 1))
            pc = PropagationConfig(type="random_walk", steps=T)

            # Full
            acc_full, _ = eval_full(X_tr, y_tr, X_te, y_te, k, T)

            # Random edges
            g = build_base_graph(X_tr, gc)
            ei = g["edge_index"]
            E = ei.shape[1]
            rng = np.random.RandomState(seed + 555)
            rs = torch.tensor(rng.randint(0, N, E), dtype=torch.long)
            rd = torch.tensor(rng.randint(0, N, E), dtype=torch.long)
            valid = rs != rd
            ei_r = torch.stack([rs[valid], rd[valid]])
            ew_r = torch.ones(ei_r.shape[1])
            h_rand = propagate(X_tr, ei_r, ew_r, N, pc)
            h_te_rand = embed_queries_via_knn(h_rand, X_tr, X_te, k=min(k, N - 1))
            acc_rand = ridge_eval(h_rand, y_tr, h_te_rand, y_te, n_classes=nc)

            rows.append({
                "seed": seed, "config": label, "N": N,
                "acc_no_graph": acc_ng, "acc_knn": acc_knn,
                "acc_full": acc_full, "acc_random": acc_rand,
                "delta_vs_ng": acc_full - acc_ng,
                "collapse": acc_full - acc_rand,
            })
            print(f"  s{seed} {label}: full={acc_full:.4f} ng={acc_ng:.4f} "
                  f"rand={acc_rand:.4f} Δng={acc_full - acc_ng:+.4f} "
                  f"collapse={acc_full - acc_rand:+.4f}")

    _save_csv(rows, out_dir / "sweep_combined.csv")
    return rows


# ══════════════════════════════════════════════════════════════════════
# MAIN
# ══════════════════════════════════════════════════════════════════════
def main():
    p = argparse.ArgumentParser(description="CIFAR-10 ResNet-18 Large-Scale Sweep")
    p.add_argument("--seeds", type=str, default="0,1")
    p.add_argument("--out", type=str, default="outputs/cifar_sweep")
    p.add_argument("--only", type=str, default=None)
    p.add_argument("--n_train", type=int, default=40000)
    args = p.parse_args()
    seeds = [int(s) for s in args.seeds.split(",")]
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    only = (args.only or "all").lower()

    print("=" * 70)
    print(f"CIFAR-10 ResNet-18 SWEEP (N={args.n_train}, seeds={seeds})")
    print("=" * 70)

    if only in ("all", "kt_sweep"):       run_kT_sweep(seeds, out, args.n_train)
    if only in ("all", "dim_reduction"):   run_dim_reduction(seeds, out, args.n_train)
    if only in ("all", "n_scaling"):       run_n_scaling(seeds, out)
    if only in ("all", "ridge_l2"):     run_ridge_l2(seeds, out, args.n_train)
    if only in ("all", "combined_best"):   run_combined_best(seeds, out, args.n_train)

    print(f"\n{'='*70}")
    print("ALL SWEEPS DONE")
    print(f"{'='*70}")


if __name__ == "__main__":
    main()
