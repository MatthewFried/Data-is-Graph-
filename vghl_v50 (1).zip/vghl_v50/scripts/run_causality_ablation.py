#!/usr/bin/env python3
"""Causality Ablation for Paper: geometry vs destroyed-geometry controls.

Runs the full ablation:
  - Multiple datasets (sk_moons, breast_cancer, etc.)
  - Multiple seeds (0-4) for mean ± std
  - Multiple k values (4, 8, 16, 32) for connectivity sweep
  - All three conditions: none, degree_preserving_rewire, random_destination

Produces:
  1. results CSV with all runs
  2. LaTeX-ready summary table (mean ± std per dataset × condition)
  3. Publication figure: test accuracy vs k for real vs controls

Usage:
    # Full ablation (recommended)
    python scripts/run_causality_ablation.py

    # Quick test (fewer seeds/k values)
    python scripts/run_causality_ablation.py --seeds 0,1,2 --k_values 8,16

    # Add extra datasets
    python scripts/run_causality_ablation.py --datasets sk_moons,breast_cancer,sk_circles

    # Just regenerate figures from existing results
    python scripts/run_causality_ablation.py --plot_only
"""
import argparse
import subprocess
import sys
import os
import json
import csv
import time
from pathlib import Path
from collections import defaultdict

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))
from vghl.utils.repro import enforce_reproducibility
enforce_reproducibility(seed=0)



# ── Configuration ─────────────────────────────────────────────────────

CONTROLS = ["none", "degree_preserving_rewire", "random_destination"]
CONTROL_LABELS = {
    "none": "Real geometry",
    "degree_preserving_rewire": "Degree-preserving rewire",
    "random_destination": "Random destination",
}
# Short labels for figure legend
CONTROL_SHORT = {
    "none": "Real geometry",
    "degree_preserving_rewire": "Degree-pres. rewire",
    "random_destination": "Random dest.",
}

# Per-dataset defaults (n_train, n_val, n_test, epochs, operator, prop_steps)
DATASET_DEFAULTS = {
    "sk_moons":       {"n_train": 5000, "n_val": 1000, "n_test": 1000, "epochs": 50},
    "sk_circles":     {"n_train": 5000, "n_val": 1000, "n_test": 1000, "epochs": 50},
    "breast_cancer":  {"n_train": 0, "n_val": 0, "n_test": 0, "epochs": 80},
    "wine":           {"n_train": 0, "n_val": 0, "n_test": 0, "epochs": 80},
    "digits":         {"n_train": 0, "n_val": 0, "n_test": 0, "epochs": 80},
}


def run_single(dataset, k, control, seed, out_dir, epochs, n_train, n_val, n_test,
               operator="random_walk", prop_steps=5, quiet=True):
    """Run a single train_gm.py experiment. Returns results dict or None."""
    ctrl_tag = control if control != "none" else "real"
    name = f"causal_{dataset}_{ctrl_tag}_k{k}_s{seed}"
    run_dir = Path(out_dir) / name

    # Skip if already done
    results_path = run_dir / "results.json"
    if results_path.exists():
        try:
            with open(results_path) as f:
                return json.load(f)
        except Exception:
            pass  # re-run if corrupt

    cmd = [
        sys.executable, os.path.join(os.path.dirname(__file__), "train_gm.py"),
        "--dataset", dataset,
        "--graph_type", "knn", "--k", str(k),
        "--operator", operator, "--prop_steps", str(prop_steps),
        "--control", control,
        "--epochs", str(epochs),
        "--head", "linear",
        "--seed", str(seed),
        "--name", name,
        "--out", str(out_dir),
    ]
    # For tabular datasets with 0, don't pass n_train etc (use defaults)
    if n_train > 0:
        cmd.extend(["--n_train", str(n_train)])
    if n_val > 0:
        cmd.extend(["--n_val", str(n_val)])
    if n_test > 0:
        cmd.extend(["--n_test", str(n_test)])
    if quiet:
        cmd.append("--quiet")

    result = subprocess.run(cmd, capture_output=True, text=True)
    if result.returncode != 0:
        print(f"  FAILED: {name}")
        if result.stderr:
            print(f"    {result.stderr[-300:]}")
        return None

    if results_path.exists():
        with open(results_path) as f:
            return json.load(f)
    return None


def run_ablation(datasets, seeds, k_values, out_dir, operator="random_walk",
                 prop_steps=5, quiet=True):
    """Run full causality ablation grid."""
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    rows = []
    total = len(datasets) * len(k_values) * len(CONTROLS) * len(seeds)
    done = 0

    for dataset in datasets:
        dd = DATASET_DEFAULTS.get(dataset, {})
        epochs = dd.get("epochs", 50)
        n_train = dd.get("n_train", 5000)
        n_val = dd.get("n_val", 1000)
        n_test = dd.get("n_test", 1000)

        for k in k_values:
            for control in CONTROLS:
                for seed in seeds:
                    done += 1
                    ctrl_tag = control if control != "none" else "real"
                    name = f"causal_{dataset}_{ctrl_tag}_k{k}_s{seed}"
                    print(f"[{done}/{total}] {name}", end=" ... ", flush=True)

                    t0 = time.time()
                    res = run_single(
                        dataset, k, control, seed, out_dir, epochs,
                        n_train, n_val, n_test, operator, prop_steps, quiet,
                    )
                    elapsed = time.time() - t0

                    if res is not None:
                        test = res.get("test", {})
                        machine = res.get("machine", {})
                        row = {
                            "dataset": dataset,
                            "k": k,
                            "control": control,
                            "control_label": CONTROL_LABELS[control],
                            "seed": seed,
                            "test_accuracy": test.get("test/accuracy", ""),
                            "test_f1": test.get("test/f1", ""),
                            "test_loss": test.get("test/loss", ""),
                            "best_epoch": res.get("best_epoch", ""),
                            "n_edges": machine.get("machine/n_edges",
                                       machine.get("n_edges", "")),
                            "edge_dist_mean": machine.get("machine/edge_dist_mean",
                                              machine.get("edge_dist_mean", "")),
                        }
                        rows.append(row)
                        acc = row["test_accuracy"]
                        print(f"acc={acc:.4f} [{elapsed:.1f}s]")
                    else:
                        print(f"FAILED [{elapsed:.1f}s]")

    # Write CSV
    if rows:
        csv_path = out_dir / "causality_ablation.csv"
        with open(csv_path, "w", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=rows[0].keys())
            writer.writeheader()
            writer.writerows(rows)
        print(f"\nResults: {csv_path}")

    return rows


def compute_summary(rows):
    """Group by (dataset, k, control), compute mean ± std."""
    import statistics

    groups = defaultdict(list)
    for r in rows:
        acc = r.get("test_accuracy")
        if acc == "" or acc is None:
            continue
        key = (r["dataset"], r["k"], r["control"])
        groups[key].append(float(acc))

    summary = []
    for (dataset, k, control), accs in sorted(groups.items()):
        mean_acc = statistics.mean(accs)
        std_acc = statistics.stdev(accs) if len(accs) > 1 else 0.0
        summary.append({
            "dataset": dataset,
            "k": k,
            "control": control,
            "control_label": CONTROL_LABELS[control],
            "n_seeds": len(accs),
            "mean_acc": mean_acc,
            "std_acc": std_acc,
            "acc_str": f"{mean_acc:.3f} ± {std_acc:.3f}",
        })

    return summary


def write_latex_table(summary, out_dir):
    """Write LaTeX-ready table: datasets as rows, conditions as columns.

    Groups by dataset, uses the 'main' k value (k=16 or most common),
    shows mean ± std for each condition.
    """
    out_dir = Path(out_dir)

    # Find best k per dataset (highest real-geometry accuracy)
    best_k = {}
    for s in summary:
        if s["control"] == "none":
            ds = s["dataset"]
            if ds not in best_k or s["mean_acc"] > best_k[ds][1]:
                best_k[ds] = (s["k"], s["mean_acc"])

    lines = []
    lines.append(r"\begin{table}[t]")
    lines.append(r"\centering")
    lines.append(r"\caption{Causality ablation: test accuracy (mean $\pm$ std over 5 seeds). "
                 r"Controls destroy geometry while preserving degree structure.}")
    lines.append(r"\label{tab:causality}")
    lines.append(r"\begin{tabular}{lccc}")
    lines.append(r"\toprule")
    lines.append(r"Dataset & Real geometry & Degree-pres.\ rewire & Random dest.\ \\")
    lines.append(r"\midrule")

    datasets_seen = []
    for s in summary:
        ds = s["dataset"]
        if ds not in [x[0] for x in datasets_seen]:
            bk = best_k.get(ds, (16, 0))[0]
            datasets_seen.append((ds, bk))

    for ds, bk in datasets_seen:
        vals = {}
        for s in summary:
            if s["dataset"] == ds and s["k"] == bk:
                vals[s["control"]] = s["acc_str"]
        if len(vals) < 3:
            continue
        ds_label = ds.replace("_", r"\_").replace("sk_", "").capitalize()
        if ds == "breast_cancer":
            ds_label = "Breast Cancer"
        elif ds == "sk_moons":
            ds_label = "Two Moons"
        elif ds == "sk_circles":
            ds_label = "Circles"
        elif ds == "wine":
            ds_label = "Wine"
        elif ds == "digits":
            ds_label = "Digits"
        lines.append(
            f"  {ds_label} ($k$={bk}) & "
            f"\\textbf{{{vals.get('none', '-')}}} & "
            f"{vals.get('degree_preserving_rewire', '-')} & "
            f"{vals.get('random_destination', '-')} \\\\"
        )

    lines.append(r"\bottomrule")
    lines.append(r"\end{tabular}")
    lines.append(r"\end{table}")

    tex_path = out_dir / "causality_table.tex"
    with open(tex_path, "w") as f:
        f.write("\n".join(lines))
    print(f"LaTeX table: {tex_path}")


def generate_figure(summary, out_dir):
    """Generate publication figure: test accuracy vs k, real vs controls.

    One subplot per dataset. Uses matplotlib with clean styling.
    """
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
        import matplotlib.ticker as ticker
    except ImportError:
        print("matplotlib not installed, skipping figure generation")
        print("  Install with: pip install matplotlib")
        return

    out_dir = Path(out_dir)

    datasets = sorted(set(s["dataset"] for s in summary))
    n_ds = len(datasets)

    # Colors and markers
    COLORS = {
        "none": "#2563eb",  # blue
        "degree_preserving_rewire": "#dc2626",  # red
        "random_destination": "#f59e0b",  # amber
    }
    MARKERS = {
        "none": "o",
        "degree_preserving_rewire": "s",
        "random_destination": "D",
    }

    fig, axes = plt.subplots(1, n_ds, figsize=(4.5 * n_ds, 3.5), squeeze=False)

    for i, dataset in enumerate(datasets):
        ax = axes[0, i]
        ds_data = [s for s in summary if s["dataset"] == dataset]

        for control in CONTROLS:
            ctrl_data = sorted(
                [s for s in ds_data if s["control"] == control],
                key=lambda s: s["k"],
            )
            if not ctrl_data:
                continue

            ks = [s["k"] for s in ctrl_data]
            means = [s["mean_acc"] for s in ctrl_data]
            stds = [s["std_acc"] for s in ctrl_data]

            ax.errorbar(
                ks, means, yerr=stds,
                label=CONTROL_SHORT[control],
                color=COLORS[control],
                marker=MARKERS[control],
                markersize=6,
                linewidth=1.8,
                capsize=3,
                capthick=1.2,
            )

        # Chance line
        # Determine n_classes from accuracy of worst control
        ax.axhline(y=0.5, color="gray", linestyle=":", linewidth=0.8, alpha=0.6)

        # Formatting
        ds_label = dataset.replace("_", " ").replace("sk ", "").title()
        if dataset == "breast_cancer":
            ds_label = "Breast Cancer"
        ax.set_title(ds_label, fontsize=13, fontweight="bold")
        ax.set_xlabel("$k$ (neighbors)", fontsize=11)
        if i == 0:
            ax.set_ylabel("Test accuracy", fontsize=11)
        ax.set_xscale("log", base=2)
        ax.xaxis.set_major_formatter(ticker.ScalarFormatter())
        ax.xaxis.set_minor_formatter(ticker.NullFormatter())
        ax.set_xticks([k for k in sorted(set(s["k"] for s in ds_data))])
        ax.set_ylim(0.35, 1.02)
        ax.grid(True, alpha=0.2)
        ax.tick_params(labelsize=10)

    # Single legend at top
    handles, labels = axes[0, 0].get_legend_handles_labels()
    fig.legend(
        handles, labels, loc="upper center",
        ncol=3, fontsize=10, frameon=True,
        bbox_to_anchor=(0.5, 1.02),
    )

    plt.tight_layout(rect=[0, 0, 1, 0.92])

    # Save as both PDF and PNG
    for ext in ["pdf", "png"]:
        fig_path = out_dir / f"causality_ablation.{ext}"
        fig.savefig(fig_path, dpi=300, bbox_inches="tight")
    print(f"Figure: {out_dir / 'causality_ablation.pdf'}")
    plt.close(fig)


def load_existing_results(out_dir):
    """Load results from existing causality_ablation.csv."""
    csv_path = Path(out_dir) / "causality_ablation.csv"
    if not csv_path.exists():
        print(f"No existing results at {csv_path}")
        return []
    rows = []
    with open(csv_path) as f:
        reader = csv.DictReader(f)
        for row in reader:
            # Convert numeric fields
            for k in ["k", "seed"]:
                if row.get(k):
                    row[k] = int(row[k])
            for k in ["test_accuracy", "test_f1", "test_loss"]:
                if row.get(k):
                    try:
                        row[k] = float(row[k])
                    except ValueError:
                        pass
            rows.append(row)
    print(f"Loaded {len(rows)} existing results from {csv_path}")
    return rows


def main():
    p = argparse.ArgumentParser(
        description="Causality ablation for paper: real geometry vs destroyed-geometry controls"
    )
    p.add_argument("--datasets", type=str, default="sk_moons,breast_cancer,digits,wine",
                   help="Comma-separated datasets")
    p.add_argument("--seeds", type=str, default="0,1,2,3,4",
                   help="Comma-separated seeds (default: 0,1,2,3,4)")
    p.add_argument("--k_values", type=str, default="4,8,16,32",
                   help="Comma-separated k values (default: 4,8,16,32)")
    p.add_argument("--operator", type=str, default="random_walk")
    p.add_argument("--prop_steps", type=int, default=5)
    p.add_argument("--out", type=str, default="outputs/causality_ablation",
                   help="Output directory")
    p.add_argument("--plot_only", action="store_true",
                   help="Skip runs, just regenerate figures from existing CSV")
    p.add_argument("--verbose", action="store_true",
                   help="Show per-epoch output from train_gm")

    args = p.parse_args()

    datasets = [d.strip() for d in args.datasets.split(",")]
    seeds = [int(s) for s in args.seeds.split(",")]
    k_values = [int(k) for k in args.k_values.split(",")]
    out_dir = args.out

    print("=" * 60)
    print("CAUSALITY ABLATION")
    print(f"  Datasets:  {datasets}")
    print(f"  Seeds:     {seeds}")
    print(f"  k values:  {k_values}")
    print(f"  Controls:  {list(CONTROL_LABELS.values())}")
    print(f"  Operator:  {args.operator} (T={args.prop_steps})")
    print(f"  Output:    {out_dir}")
    n_runs = len(datasets) * len(k_values) * len(CONTROLS) * len(seeds)
    print(f"  Total runs: {n_runs}")
    print("=" * 60)

    if args.plot_only:
        rows = load_existing_results(out_dir)
    else:
        rows = run_ablation(
            datasets, seeds, k_values, out_dir,
            operator=args.operator, prop_steps=args.prop_steps,
            quiet=not args.verbose,
        )

    if not rows:
        print("No results to summarize")
        return

    # Summary statistics
    summary = compute_summary(rows)

    # Print summary table
    print("\n" + "=" * 80)
    print("SUMMARY: Test Accuracy (mean ± std)")
    print("=" * 80)
    print(f"{'Dataset':<20} {'k':>3} {'Condition':<28} {'Accuracy':>15} {'n':>3}")
    print("-" * 80)
    for s in summary:
        print(f"{s['dataset']:<20} {s['k']:>3} {s['control_label']:<28} {s['acc_str']:>15} {s['n_seeds']:>3}")
    print("=" * 80)

    # Write summary CSV
    summary_path = Path(out_dir) / "causality_summary.csv"
    with open(summary_path, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=summary[0].keys())
        writer.writeheader()
        writer.writerows(summary)
    print(f"\nSummary CSV: {summary_path}")

    # LaTeX table
    write_latex_table(summary, out_dir)

    # Figure
    generate_figure(summary, out_dir)

    print("\nDone! Files in:", out_dir)


if __name__ == "__main__":
    main()
