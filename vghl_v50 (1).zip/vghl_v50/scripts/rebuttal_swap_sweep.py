#!/usr/bin/env python3
"""Null ladder for the rewiring control: how much of the rewired-vs-random
gap is mixing depth vs symmetry class vs degree sequence?

Cells per dataset: rewire at 2x/10x/50x |E_und| swaps (symmetric,
degree-preserving, runtime-asserted) and a symmetric ER null (symmetric,
matched density, degrees NOT preserved). Interpretation:
  rewire(50x) ~ random(directed I1)  -> submitted Table 6 value reflected
                                        thorough mixing; only the operation
                                        description needed correcting
  rewire plateau ~ symER             -> gap is symmetry class, not degrees;
                                        claim: neither degree sequence nor
                                        symmetry class nor density explains
                                        the real graph's performance
  rewire plateau > symER             -> configuration model retains residual
                                        structure worth naming

Usage: python -u scripts/rebuttal_swap_sweep.py [--datasets ...] [--seeds 0,1,2]
"""
import os, sys
os.environ.setdefault("OMP_NUM_THREADS", "1")
import argparse
import numpy as np
import torch

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))
sys.path.insert(0, os.path.dirname(__file__))

from run_real_experiments import (  # noqa: E402
    DATASETS, load_dataset, get_k, eval_pipeline_edges,
    _degree_preserving_rewire, _save_csv,
)
from vghl.models.graph_builder import build_base_graph, GraphBuilderConfig  # noqa: E402
from vghl.models.propagation import PropagationConfig  # noqa: E402

DEFAULT = ["digits", "optdigits", "pendigits", "satellite",
           "mnist_embed", "wine", "segment", "letter"]


def sym_er(N, E_und, seed):
    """Symmetric ER null: E_und undirected edges, both directions emitted,
    no duplicates, no self loops."""
    rng = np.random.RandomState(seed + 999)
    edges = set()
    while len(edges) < E_und:
        a, b = rng.randint(0, N, 2)
        if a != b:
            edges.add((min(a, b), max(a, b)))
    u = torch.tensor([e[0] for e in edges])
    v = torch.tensor([e[1] for e in edges])
    return torch.cat([torch.stack([u, v]), torch.stack([v, u])], dim=1)


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--datasets", type=str, default=None)
    p.add_argument("--seeds", type=str, default="0,1,2")
    p.add_argument("--out", type=str, default="outputs/rebuttal")
    a = p.parse_args()
    datasets = [d for d in (a.datasets.split(",") if a.datasets else DEFAULT)
                if d in DATASETS]
    seeds = [int(s) for s in a.seeds.split(",")]
    rows = []
    from pathlib import Path
    for ds in datasets:
        X, y, _, _, Xte, yte, _ = load_dataset(ds, 0)
        N = len(X)
        k = min(get_k(ds), N - 1)
        gc = GraphBuilderConfig(type="knn", k=k)
        pc = PropagationConfig(type="random_walk", steps=5)
        g = build_base_graph(X, gc)
        ei = g["edge_index"]
        E_und = int((ei[0] < ei[1]).sum())
        out = [f"{ds:<14}"]
        for mult in [2, 10, 50]:
            accs = []
            for seed in seeds:
                ei_r, diag = _degree_preserving_rewire(ei, N, mult * E_und, seed)
                assert diag["degree_vector_unchanged"] and diag["reciprocity"] == 1.0
                acc, _ = eval_pipeline_edges(X, y, Xte, yte, ei_r,
                                             torch.ones(ei_r.shape[1]), gc, pc)
                accs.append(acc)
                rows.append({"dataset": ds, "seed": seed, "cell": f"rewire_{mult}x",
                             "acc": acc, "overlap": diag["orig_edge_overlap"],
                             "swaps_done": diag["swaps_done"]})
            out.append(f"rw{mult}x:{np.mean(accs):.3f}")
        accs = []
        for seed in seeds:
            ei_e = sym_er(N, E_und, seed)
            acc, _ = eval_pipeline_edges(X, y, Xte, yte, ei_e,
                                         torch.ones(ei_e.shape[1]), gc, pc)
            accs.append(acc)
            rows.append({"dataset": ds, "seed": seed, "cell": "sym_er",
                         "acc": acc, "overlap": 0.0, "swaps_done": 0})
        out.append(f"symER:{np.mean(accs):.3f}")
        print("  ".join(out), flush=True)
    _save_csv(rows, Path(a.out) / "rebuttal_swap_sweep.csv")


if __name__ == "__main__":
    main()
