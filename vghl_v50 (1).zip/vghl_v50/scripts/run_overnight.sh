#!/bin/bash
# ══════════════════════════════════════════════════════════════════════
# VGHL Overnight Runner — COMPREHENSIVE Discovery Suite
# ══════════════════════════════════════════════════════════════════════
#
# Goal: Cast a wide net. We don't know what will work yet.
# Run everything on everything. In the morning, look at the CSVs
# and discover which claims hold and where the boundary is.
#
# Estimated time:
#   quick  — ~30 min  (3 datasets, 3 seeds, core claims only)
#   medium — ~2 hours (core datasets, all claims)
#   full   — ~6-10 hours (all datasets, all claims, all transfer pairs)
#
# Usage:
#   bash scripts/run_overnight.sh           # full
#   bash scripts/run_overnight.sh quick     # validation
#   bash scripts/run_overnight.sh medium    # balanced
#
# ══════════════════════════════════════════════════════════════════════

set -e
export PYTHONUNBUFFERED=1
export OMP_NUM_THREADS=4
export MKL_NUM_THREADS=4

cd "$(dirname "$0")/.."
LOGDIR="outputs/logs"
mkdir -p "$LOGDIR"

TIMESTAMP=$(date +%Y%m%d_%H%M%S)
LOGFILE="$LOGDIR/overnight_${TIMESTAMP}.log"
exec > >(tee -a "$LOGFILE") 2>&1

MODE="${1:-full}"

echo "══════════════════════════════════════════════════════════════════════"
echo "  VGHL COMPREHENSIVE DISCOVERY SUITE"
echo "  Started: $(date)"
echo "  Mode: $MODE"
echo "  Log: $LOGFILE"
echo "══════════════════════════════════════════════════════════════════════"

# ── Dataset groups ────────────────────────────────────────────────────
DS_TAB="breast_cancer,wine,heart,digits,adult"
DS_EMB="mnist_embed,fmnist_embed,cifar10_pca,newsgroups_embed"
DS_ALL="$DS_TAB,$DS_EMB"

# Transfer pairs: MANY combinations to discover what transfers
TRANSFER_SAME="mnist_embed:fmnist_embed,fmnist_embed:mnist_embed,breast_cancer:wine,wine:breast_cancer,digits:breast_cancer"
TRANSFER_CROSS="mnist_embed:newsgroups_embed,mnist_embed:cifar10_pca,breast_cancer:digits,digits:mnist_embed,newsgroups_embed:cifar10_pca"
TRANSFER_ALL="$TRANSFER_SAME,$TRANSFER_CROSS"

if [ "$MODE" = "quick" ]; then
    SEEDS="0,1,2"
    DS_ALL="breast_cancer,digits,mnist_embed"
    DS_TAB="breast_cancer,digits"
    DS_EMB="mnist_embed"
    TRANSFER_ALL="mnist_embed:fmnist_embed,breast_cancer:wine"
    REFINE_DS="breast_cancer,digits,mnist_embed"
    NOISE_DS="breast_cancer,digits"
elif [ "$MODE" = "medium" ]; then
    SEEDS="0,1,2,3,4"
    DS_ALL="breast_cancer,wine,digits,mnist_embed,fmnist_embed,cifar10_pca"
    DS_TAB="breast_cancer,wine,digits"
    DS_EMB="mnist_embed,fmnist_embed,cifar10_pca"
    TRANSFER_ALL="$TRANSFER_SAME"
    REFINE_DS="breast_cancer,digits,mnist_embed,cifar10_pca"
    NOISE_DS="breast_cancer,digits,mnist_embed"
else  # full
    SEEDS="0,1,2,3,4"
    REFINE_DS="breast_cancer,wine,digits,mnist_embed,fmnist_embed,cifar10_pca"
    NOISE_DS="breast_cancer,digits,wine,mnist_embed"
fi

echo "  Seeds: $SEEDS"
echo "  All datasets: $DS_ALL"
echo "  Transfer pairs: $TRANSFER_ALL"
echo ""

run_step() {
    local STEP="$1"
    shift
    echo ""
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    echo "  STEP: $STEP"
    echo "  Time: $(date)"
    echo "  Cmd:  $@"
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    local T0=$(date +%s)
    if "$@"; then
        local T1=$(date +%s)
        echo "  ✓ $STEP — $(( T1 - T0 ))s"
    else
        local T1=$(date +%s)
        echo "  ✗ $STEP FAILED — $(( T1 - T0 ))s (continuing...)"
    fi
}

# ══════════════════════════════════════════════════════════════════════
# 1. CLAIM A: Noise Identification — ALL datasets
# ══════════════════════════════════════════════════════════════════════
run_step "Claim A — Noise ID (ALL datasets)" \
    python -u scripts/run_real_experiments.py --only noise \
        --datasets "$DS_ALL" --seeds "$SEEDS"

# ══════════════════════════════════════════════════════════════════════
# 2. CLAIM B: Geometric Universality — ALL datasets
# ══════════════════════════════════════════════════════════════════════
run_step "Claim B — Universality (ALL datasets)" \
    python -u scripts/run_real_experiments.py --only geometry \
        --datasets "$DS_ALL" --seeds "$SEEDS"

# ══════════════════════════════════════════════════════════════════════
# 3. CLAIM C: Structural Signal — ALL datasets
# ══════════════════════════════════════════════════════════════════════
run_step "Claim C — Signal ablation (ALL datasets)" \
    python -u scripts/run_real_experiments.py --only signal \
        --datasets "$DS_ALL" --seeds "$SEEDS"

# ══════════════════════════════════════════════════════════════════════
# 4. CLAIM D: Stability Predicts Reliability — ALL datasets
# ══════════════════════════════════════════════════════════════════════
run_step "Claim D — Reliability quantiles (ALL datasets)" \
    python -u scripts/run_real_experiments.py --only reliability \
        --datasets "$DS_ALL" --seeds "$SEEDS"

# ══════════════════════════════════════════════════════════════════════
# 5. CLAIM E: Representation Quality — all reps
# ══════════════════════════════════════════════════════════════════════
run_step "Claim E — Representation quality (all reps)" \
    python -u scripts/run_real_experiments.py --only representation \
        --seeds "$SEEDS"

# ══════════════════════════════════════════════════════════════════════
# 6. REFINEMENT: Accept/reject on MANY datasets
# ══════════════════════════════════════════════════════════════════════
run_step "Refinement — Accept/reject convergence" \
    python -u scripts/refine_gm.py \
        --datasets "$REFINE_DS" \
        --seeds "$SEEDS" --refine_steps 15 --refine_frac 0.05

# ══════════════════════════════════════════════════════════════════════
# 7. TRANSFER: 10 pairs — same-domain + cross-domain
# ══════════════════════════════════════════════════════════════════════
run_step "Transfer — ALL pairs" \
    python -u scripts/transfer_gm.py \
        --pairs "$TRANSFER_ALL" \
        --seeds "$SEEDS"

# ══════════════════════════════════════════════════════════════════════
# 8. NOISE INJECTION: All 3 modes, many datasets
# ══════════════════════════════════════════════════════════════════════
run_step "Noise injection — 3 modes, multiple datasets" \
    python -u scripts/run_noise_injection_test.py \
        --datasets "$NOISE_DS" \
        --seeds "$SEEDS" --noise_fracs "0.05,0.1,0.2" \
        --noise_modes "random_points,label_flip,boundary_noise"

# ══════════════════════════════════════════════════════════════════════
echo ""
echo "══════════════════════════════════════════════════════════════════════"
echo "  DONE — $(date)"
echo "  Log: $LOGFILE"
echo ""
echo "  OUTPUTS:"
echo "    outputs/real_experiments/claim_a_noise.csv"
echo "    outputs/real_experiments/claim_b_geometry.csv"
echo "    outputs/real_experiments/claim_c_signal.csv"
echo "    outputs/real_experiments/claim_d_reliability.csv"
echo "    outputs/real_experiments/claim_e_representation.csv"
echo "    outputs/refinement/refinement_curve.csv"
echo "    outputs/transfer/transfer_results.csv"
echo "    outputs/noise_injection/noise_injection_results.csv"
echo ""
echo "  WHAT TO CHECK:"
echo "    1. claim_a: Where does edge P/R beat LOF/kNN?"
echo "    2. claim_c: Does Δ(full-destroyed) >> 0 everywhere?"
echo "    3. claim_c: Is Δ(edge-rand) > Δ(node-rand)?"
echo "    4. claim_d: Is Q5 acc >> Q1 acc?"
echo "    5. claim_e: Is PCA stability > raw stability?"
echo "    6. transfer: Which A→B pairs have transfer_real > random_attach?"
echo "    7. ALL: Where do tabular and embedding results diverge?"
echo "══════════════════════════════════════════════════════════════════════"
