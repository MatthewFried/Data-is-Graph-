#!/usr/bin/env python3
"""Merge split experiment CSVs into unified paper-ready files.

Since launch_all.sh runs one dataset per nohup job, each writes its own
CSV. This script merges them into single files per claim.

Usage:
    python scripts/merge_results.py
    python scripts/merge_results.py --base outputs  # custom base dir

Produces:
    outputs/merged/claim_a_noise_ALL.csv
    outputs/merged/claim_b_geometry_ALL.csv
    outputs/merged/claim_c_signal_ALL.csv
    outputs/merged/claim_d_reliability_ALL.csv
    outputs/merged/claim_e_representation_ALL.csv
    outputs/merged/refinement_ALL.csv
    outputs/merged/transfer_ALL.csv
    outputs/merged/noise_injection_ALL.csv
"""
import csv
import sys
import os
from pathlib import Path
from collections import defaultdict

def merge_csvs(pattern_dirs, filename_pattern, output_path):
    """Find all CSVs matching pattern, merge into one."""
    all_rows = []
    all_keys = set()
    files_found = []

    for d in pattern_dirs:
        d = Path(d)
        if not d.exists():
            continue
        for f in sorted(d.glob("**/*.csv")):
            if filename_pattern and filename_pattern not in f.name:
                continue
            files_found.append(str(f))
            with open(f, "r") as fh:
                reader = csv.DictReader(fh)
                for row in reader:
                    all_rows.append(row)
                    all_keys.update(row.keys())

    if not all_rows:
        return 0, []

    # Stable column ordering
    all_keys = sorted(all_keys)
    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    with open(output_path, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=all_keys)
        w.writeheader()
        for row in all_rows:
            w.writerow({k: row.get(k, "") for k in all_keys})

    return len(all_rows), files_found


def main():
    base = Path(sys.argv[1]) if len(sys.argv) > 1 else Path("outputs")
    out = base / "merged"
    out.mkdir(parents=True, exist_ok=True)

    print("=" * 70)
    print("MERGING EXPERIMENT RESULTS")
    print(f"  Base: {base}")
    print(f"  Output: {out}")
    print("=" * 70)

    merges = [
        # (search dirs, filename filter, output name)
        (
            [base / "real_experiments" / d for d in
             ["a_breast_cancer", "a_wine", "a_heart", "a_digits", "a_adult",
              "a_mnist_embed", "a_fmnist_embed", "a_cifar10_pca", "a_newsgroups",
              "real_experiments"]],
            "claim_a",
            out / "claim_a_noise_ALL.csv",
        ),
        (
            [base / "real_experiments" / d for d in
             ["b_tabular", "b_embed", "real_experiments"]],
            "claim_b",
            out / "claim_b_geometry_ALL.csv",
        ),
        (
            [base / "real_experiments" / d for d in
             ["c_breast_cancer", "c_wine", "c_heart", "c_digits", "c_adult",
              "c_mnist_embed", "c_fmnist_embed", "c_cifar10_pca", "c_newsgroups",
              "real_experiments"]],
            "claim_c",
            out / "claim_c_signal_ALL.csv",
        ),
        (
            [base / "real_experiments" / d for d in
             ["d_all", "real_experiments"]],
            "claim_d",
            out / "claim_d_reliability_ALL.csv",
        ),
        (
            [base / "real_experiments" / d for d in
             ["e_repr", "real_experiments"]],
            "claim_e",
            out / "claim_e_representation_ALL.csv",
        ),
        (
            [base / "refinement" / d for d in
             ["tabular", "embed", "cifar", "refinement"]],
            "refinement",
            out / "refinement_ALL.csv",
        ),
        (
            [base / "transfer" / d for d in
             ["img_img", "tab_tab", "tab_tab2", "img_text", "mnist_cif",
              "bc_dig", "dig_mnist", "text_cif", "transfer"]],
            "transfer",
            out / "transfer_ALL.csv",
        ),
        (
            [base / "noise_injection" / d for d in
             ["tabular", "wine", "noise_injection"]],
            "noise_injection",
            out / "noise_injection_ALL.csv",
        ),
    ]

    for search_dirs, pattern, output_path in merges:
        n_rows, files = merge_csvs(search_dirs, pattern, output_path)
        if n_rows > 0:
            print(f"  ✓ {output_path.name}: {n_rows} rows from {len(files)} files")
        else:
            print(f"  - {output_path.name}: no data found")

    print(f"\n{'='*70}")
    print(f"  Merged files in: {out}/")
    print(f"  Share these CSVs for analysis.")
    print(f"{'='*70}")


if __name__ == "__main__":
    main()
