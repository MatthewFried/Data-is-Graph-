#!/usr/bin/env python3
"""Phase-2 Machine Discovery: end-to-end DATA → GRAPH → NN pipeline.

Protocol:
  1. Load dataset + optional feature extractor.
  2. Build initial graph from geometry.
  3. Run machine discovery search loop (grammar sweep + structural edits).
  4. Evaluate best machine.
  5. Save artifacts (graphs, mappings, summary JSON).

Usage:
  python scripts/run_phase2_discovery.py --dataset sk_moons --search
  python scripts/run_phase2_discovery.py --dataset wine --search --K_grammars 4
  python scripts/run_phase2_discovery.py --dataset cifar10_pca --n_train 2000
"""
import os
os.environ["OMP_NUM_THREADS"] = "1"
os.environ["MKL_NUM_THREADS"] = "1"
os.environ["OPENBLAS_NUM_THREADS"] = "1"
os.environ["NUMEXPR_NUM_THREADS"] = "1"

import sys
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

import argparse
import logging
import time
import torch
import numpy as np

from vghl.utils.seed import set_seed
from vghl.models.graph_builder import GraphBuilderConfig, build_base_graph
from vghl.models.propagation import PropagationConfig, propagate
from vghl.models.anchor_graph import AnchorGraphConfig
from vghl.models.primitives import PrimitiveConfig, induce_primitives
from vghl.models.recursion import RecursionConfig, build_multilevel_graph
from vghl.models.multilevel_compute import MultilevelComputeConfig, multilevel_propagate
from vghl.models.merge import MergeConfig
from vghl.models.head import PredictionHead
from vghl.models.edit_loop import EditLoopConfig, run_edit_loop, score_machine
from vghl.logging.run_summary import (
    create_summary, add_machine_info, add_score, save_summary,
)

logging.basicConfig(level=logging.INFO, format="%(name)s | %(message)s")
logger = logging.getLogger("discovery")


def load_dataset(args):
    """Load dataset and return X_train, y_train, X_val, y_val, X_test, y_test, meta."""
    ds = args.dataset

    if ds in ("wine", "breast_cancer"):
        from vghl.data.tabular import _load_sklearn, split_tabular
        X, y, meta = _load_sklearn(ds, args.seed)
        X_tr, y_tr, X_val, y_val, X_te, y_te = split_tabular(X, y)
        return X_tr, y_tr, X_val, y_val, X_te, y_te, meta

    if ds == "cifar10_pca":
        from vghl.data.cifar10_features import load_cifar10_features
        X_tr, y_tr, X_te, y_te, meta = load_cifar10_features(
            "pca_50", args.seed, n_train=args.n_train, n_test=args.n_test,
        )
        n_val = len(X_tr) // 5
        return X_tr[n_val:], y_tr[n_val:], X_tr[:n_val], y_tr[:n_val], X_te, y_te, meta

    if ds.startswith("sk_"):
        from sklearn.datasets import make_moons, make_circles
        n = args.n_train + args.n_val + args.n_test
        if ds == "sk_moons":
            X_np, y_np = make_moons(n_samples=n, noise=0.1, random_state=args.seed)
        elif ds == "sk_circles":
            X_np, y_np = make_circles(n_samples=n, noise=0.05, random_state=args.seed, factor=0.5)
        else:
            raise ValueError(f"Unknown sklearn dataset: {ds}")
        X = torch.tensor(X_np, dtype=torch.float32)
        y = torch.tensor(y_np, dtype=torch.long)
        perm = torch.randperm(len(X), generator=torch.Generator().manual_seed(args.seed))
        X, y = X[perm], y[perm]
        n1, n2 = args.n_train, args.n_train + args.n_val
        meta = {"n_classes": int(y.max().item() + 1), "input_dim": X.shape[1], "dataset": ds}
        return X[:n1], y[:n1], X[n1:n2], y[n1:n2], X[n2:], y[n2:], meta

    if ds in ("mnist", "fashion_mnist"):
        from vghl.data.loaders import _load_mnist
        fashion = ds == "fashion_mnist"
        X_tr, y_tr = _load_mnist(train=True, fashion=fashion)
        X_te, y_te = _load_mnist(train=False, fashion=fashion)
        perm = torch.randperm(len(X_tr), generator=torch.Generator().manual_seed(args.seed))
        X_tr, y_tr = X_tr[perm], y_tr[perm]
        if args.n_train > 0:
            X_tr, y_tr = X_tr[:args.n_train], y_tr[:args.n_train]
        if args.n_test > 0:
            X_te, y_te = X_te[:args.n_test], y_te[:args.n_test]
        n_val = min(500, len(X_tr) // 5)
        meta = {"n_classes": 10, "input_dim": 784, "dataset": ds}
        return X_tr[n_val:], y_tr[n_val:], X_tr[:n_val], y_tr[:n_val], X_te, y_te, meta

    raise ValueError(f"Unknown dataset: {ds}")


def run_discovery(args):
    set_seed(args.seed)
    t0 = time.time()
    device = "cpu"

    # ── Load data ─────────────────────────────────────────────────
    X_train, y_train, X_val, y_val, X_test, y_test, meta = load_dataset(args)
    n_classes = meta["n_classes"]
    input_dim = meta["input_dim"]
    logger.info(f"Dataset: {args.dataset}, train={len(X_train)}, val={len(X_val)}, "
                f"test={len(X_test)}, d={input_dim}, classes={n_classes}")

    summary = create_summary(args.dataset, args.seed)

    # ── Build base graph ──────────────────────────────────────────
    graph_cfg = GraphBuilderConfig(type="knn", k=args.k)
    graph = build_base_graph(X_train, graph_cfg)
    ei, ew = graph["edge_index"], graph["edge_weight"]
    N = X_train.shape[0]
    logger.info(f"Base graph: N={N}, E={ei.shape[1]}")

    # ── Grammar configs to sweep ──────────────────────────────────
    prim_types_grid = [["triangle"], ["star"], ["triangle", "star"]]
    port_grid = ["boundary_top2", "medoid"]
    wiring_grid = ["shared_boundary", "port_knn"]

    if not args.search:
        # Single run with defaults
        prim_types_grid = [["triangle"]]
        port_grid = ["boundary_top2"]
        wiring_grid = ["shared_boundary"]

    best_score = -float("inf")
    best_levels = None
    best_prims = None
    best_h = None
    best_label = ""

    for prim_types in prim_types_grid:
        for port_rule in port_grid:
            for wiring_rule in wiring_grid:
                label = f"{','.join(prim_types)}/{port_rule}/{wiring_rule}"
                try:
                    prim_cfg = PrimitiveConfig(types=prim_types, use_in_propagation=True)
                    prims = induce_primitives(ei, X_train, prim_cfg)
                    if len(prims) == 0:
                        logger.info(f"  {label}: 0 primitives, skip")
                        continue

                    rec_cfg = RecursionConfig(
                        enabled=True, depth=args.depth,
                        port_rule=port_rule, wiring_rule=wiring_rule,
                    )
                    levels = build_multilevel_graph(X_train, ei, ew, prims, rec_cfg)

                    prop_cfg = PropagationConfig(type="random_walk", steps=args.prop_steps)
                    ml_cfg = MultilevelComputeConfig()
                    h = multilevel_propagate(X_train, levels, prop_cfg, ml_cfg)

                    # Quick head training to get val score
                    from vghl.utils.config import HeadConfig
                    head_cfg = HeadConfig(hidden_sizes=[64], dropout=0.0)
                    head = PredictionHead(input_dim, n_classes, head_cfg)
                    opt = torch.optim.Adam(head.parameters(), lr=1e-3)
                    loss_fn = torch.nn.CrossEntropyLoss()
                    for _ in range(args.head_epochs):
                        opt.zero_grad()
                        loss = loss_fn(head(h.detach()), y_train)
                        loss.backward()
                        opt.step()

                    # Score
                    with torch.no_grad():
                        train_logits = head(h.detach())
                        acc = (train_logits.argmax(1) == y_train).float().mean().item()

                    sc, det = score_machine(levels, acc, alpha=0.01, beta=0.01, gamma=0.1)
                    logger.info(f"  {label}: prims={len(prims)}, levels={len(levels)}, "
                                f"acc={acc:.4f}, score={sc:.4f}")

                    if sc > best_score:
                        best_score, best_levels, best_prims, best_h = sc, levels, prims, h
                        best_label = label

                except Exception as e:
                    logger.warning(f"  {label}: FAILED — {e}")

    if best_levels is None:
        logger.error("All grammar configs failed!")
        return

    logger.info(f"\nBest grammar: {best_label}, score={best_score:.4f}")

    # ── Edit loop refinement ──────────────────────────────────────
    if args.search:
        logger.info("Running edit loop refinement...")
        edit_cfg = EditLoopConfig(
            enabled=True, max_iterations=args.M_edits,
            try_edge_prune=True, try_primitive_prune=True, try_merge=True,
        )
        merge_cfg = MergeConfig(enabled=True, tau=0.90)
        prop_cfg = PropagationConfig(type="random_walk", steps=args.prop_steps)
        ml_cfg = MultilevelComputeConfig()
        rec_cfg = RecursionConfig(enabled=True, depth=args.depth,
                                   port_rule=best_label.split("/")[1],
                                   wiring_rule=best_label.split("/")[2])

        refined_levels, refined_prims, edit_log = run_edit_loop(
            z=X_train, edge_index=ei, edge_weight=ew,
            primitives=best_prims,
            recursion_cfg=rec_cfg, multilevel_cfg=ml_cfg,
            prop_cfg=prop_cfg, merge_cfg=merge_cfg,
            edit_cfg=edit_cfg,
        )
        refined_h = multilevel_propagate(X_train, refined_levels, prop_cfg, ml_cfg)
        ref_sc, ref_det = score_machine(refined_levels, best_score)  # reuse best acc as proxy
        logger.info(f"Refined: {len(refined_levels)} levels, score={ref_sc:.4f}")
        logger.info(f"Edit log: {list(edit_log.keys())}")

        if ref_sc >= best_score:
            best_levels, best_prims, best_h = refined_levels, refined_prims, refined_h
            best_score = ref_sc

    # ── Final summary ─────────────────────────────────────────────
    add_machine_info(summary, best_levels, best_prims)
    _, final_det = score_machine(best_levels, 0.0)
    add_score(summary, {
        "total": best_score,
        "acc": best_score,  # proxy
        "total_nodes": final_det["total_nodes"],
        "total_edges": final_det["total_edges"],
    })

    out_dir = os.path.join("experiments", "discovery_runs")
    path = save_summary(summary, out_dir)
    logger.info(f"Summary: {path}")
    logger.info(f"Wall time: {time.time() - t0:.1f}s")
    logger.info("=== DISCOVERY COMPLETE ===")


def main():
    p = argparse.ArgumentParser(description="Phase-2 Machine Discovery")
    p.add_argument("--dataset", type=str, default="sk_moons")
    p.add_argument("--seed", type=int, default=42)
    p.add_argument("--k", type=int, default=12)
    p.add_argument("--depth", type=int, default=1)
    p.add_argument("--prop_steps", type=int, default=3)
    p.add_argument("--head_epochs", type=int, default=5)
    p.add_argument("--n_train", type=int, default=1000)
    p.add_argument("--n_val", type=int, default=300)
    p.add_argument("--n_test", type=int, default=300)
    p.add_argument("--search", action="store_true", help="Enable discovery search loop")
    p.add_argument("--K_grammars", type=int, default=6)
    p.add_argument("--M_edits", type=int, default=10)
    run_discovery(p.parse_args())


if __name__ == "__main__":
    main()
