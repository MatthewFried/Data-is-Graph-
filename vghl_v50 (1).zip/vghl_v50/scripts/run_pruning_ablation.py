#!/usr/bin/env python3
"""Pruning & Compression Ablation for Paper.

Runs the full structural refinement ablation:
  - Multiple datasets (sk_moons, breast_cancer, sk_circles)
  - Multiple seeds (0-4) for mean ± std
  - Multiple k values (8, 16) for connectivity sensitivity
  - Four conditions: baseline, geometric prune, stability prune
  - Compression curves (structural vs random deletion) at best k

Produces:
  1. pruning_ablation.csv — all individual run results
  2. pruning_summary.csv — mean ± std grouped by (dataset, k, condition)
  3. pruning_table.tex — LaTeX table for paper
  4. compression_curves.csv — all compression curve data across seeds
  5. compression_curves.pdf — publication figure
  6. pruning_accuracy.pdf — accuracy comparison figure

Usage:
    # Full ablation (recommended)
    python scripts/run_pruning_ablation.py

    # Quick test
    python scripts/run_pruning_ablation.py --seeds 0,1,2 --k_values 16

    # Just regenerate figures from existing results
    python scripts/run_pruning_ablation.py --plot_only

    # Add datasets
    python scripts/run_pruning_ablation.py --datasets sk_moons,breast_cancer,sk_circles,wine
"""
import argparse
import subprocess
import sys
import os
import json
import csv
import time
from pathlib import Path
from collections import defaultdict

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))
from vghl.utils.repro import enforce_reproducibility
enforce_reproducibility(seed=0)



# ── Configuration ─────────────────────────────────────────────────────

CONDITIONS = {
    "baseline": {},
    "prune_geo": {"--prune": True, "--prune_methods": "geometric"},
    "prune_stab": {
        "--prune": True, "--prune_methods": "stability",
        "--prune_n_bootstrap": "5", "--prune_perturb_sigma": "0.01",
        "--prune_node_jaccard_min": "0.5",
    },
}

CONDITION_LABELS = {
    "baseline": "No pruning",
    "prune_geo": "Geometric pruning",
    "prune_stab": "Stability pruning",
}

COMPRESSION_FRACTIONS = [1.0, 0.8, 0.6, 0.4, 0.2, 0.1]

DATASET_DEFAULTS = {
    "sk_moons":       {"n_train": 5000, "n_val": 1000, "n_test": 1000, "epochs": 50},
    "sk_circles":     {"n_train": 5000, "n_val": 1000, "n_test": 1000, "epochs": 50},
    "breast_cancer":  {"n_train": 0, "n_val": 0, "n_test": 0, "epochs": 80},
    "wine":           {"n_train": 0, "n_val": 0, "n_test": 0, "epochs": 80},
    "digits":         {"n_train": 0, "n_val": 0, "n_test": 0, "epochs": 80},
}


def run_single(dataset, k, condition, seed, out_dir, epochs, n_train, n_val, n_test,
               operator="random_walk", prop_steps=5, quiet=True,
               compression_fractions=None):
    """Run a single train_gm.py experiment."""
    name = f"prune_{dataset}_{condition}_k{k}_s{seed}"
    run_dir = Path(out_dir) / name

    results_path = run_dir / "results.json"
    if results_path.exists():
        try:
            with open(results_path) as f:
                return json.load(f), name
        except Exception:
            pass

    cmd = [
        sys.executable, os.path.join(os.path.dirname(__file__), "train_gm.py"),
        "--dataset", dataset,
        "--graph_type", "knn", "--k", str(k),
        "--operator", operator, "--prop_steps", str(prop_steps),
        "--control", "none",
        "--epochs", str(epochs),
        "--head", "linear",
        "--seed", str(seed),
        "--name", name,
        "--out", str(out_dir),
    ]
    if n_train > 0:
        cmd.extend(["--n_train", str(n_train)])
    if n_val > 0:
        cmd.extend(["--n_val", str(n_val)])
    if n_test > 0:
        cmd.extend(["--n_test", str(n_test)])
    if quiet:
        cmd.append("--quiet")

    # Add condition-specific flags
    cond_flags = CONDITIONS.get(condition, {})
    for flag, val in cond_flags.items():
        if val is True:
            cmd.append(flag)
        elif val is not False:
            cmd.extend([flag, str(val)])

    # Add compression fractions if requested
    if compression_fractions:
        cmd.extend(["--compression_fractions",
                     ",".join(str(f) for f in compression_fractions)])

    result = subprocess.run(cmd, capture_output=True, text=True)
    if result.returncode != 0:
        print(f"  FAILED: {name}")
        if result.stderr:
            # Print last few lines of error
            lines = result.stderr.strip().split("\n")
            for line in lines[-5:]:
                print(f"    {line}")
        return None, name

    if results_path.exists():
        with open(results_path) as f:
            return json.load(f), name
    return None, name


def run_pruning_ablation(datasets, seeds, k_values, out_dir, operator="random_walk",
                         prop_steps=5, quiet=True):
    """Run pruning ablation: baseline vs geometric vs stability pruning."""
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    rows = []
    conditions = list(CONDITIONS.keys())
    total = len(datasets) * len(k_values) * len(conditions) * len(seeds)
    done = 0

    for dataset in datasets:
        dd = DATASET_DEFAULTS.get(dataset, {})
        epochs = dd.get("epochs", 50)
        n_train = dd.get("n_train", 5000)
        n_val = dd.get("n_val", 1000)
        n_test = dd.get("n_test", 1000)

        for k in k_values:
            for condition in conditions:
                for seed in seeds:
                    done += 1
                    name = f"prune_{dataset}_{condition}_k{k}_s{seed}"
                    print(f"[{done}/{total}] {name}", end=" ... ", flush=True)

                    t0 = time.time()
                    res, _ = run_single(
                        dataset, k, condition, seed, out_dir, epochs,
                        n_train, n_val, n_test, operator, prop_steps, quiet,
                    )
                    elapsed = time.time() - t0

                    if res is not None:
                        test = res.get("test", {})
                        machine = res.get("machine", {})
                        row = {
                            "dataset": dataset,
                            "k": k,
                            "condition": condition,
                            "condition_label": CONDITION_LABELS[condition],
                            "seed": seed,
                            "test_accuracy": test.get("test/accuracy", ""),
                            "test_f1": test.get("test/f1", ""),
                            "test_loss": test.get("test/loss", ""),
                            "best_epoch": res.get("best_epoch", ""),
                            "n_nodes": machine.get("machine/n_nodes",
                                       machine.get("n_nodes", "")),
                            "n_edges": machine.get("machine/n_edges",
                                       machine.get("n_edges", "")),
                            "isolated_nodes": machine.get("machine/isolated_nodes",
                                              machine.get("isolated_nodes", "")),
                            "deg_mean": machine.get("machine/deg_mean",
                                        machine.get("deg_mean", "")),
                        }
                        rows.append(row)
                        acc = row["test_accuracy"]
                        nodes = row["n_nodes"]
                        edges = row["n_edges"]
                        print(f"acc={acc:.4f} nodes={nodes} edges={edges} [{elapsed:.1f}s]"
                              if isinstance(acc, float) else f"[{elapsed:.1f}s]")
                    else:
                        print(f"FAILED [{elapsed:.1f}s]")

    if rows:
        csv_path = out_dir / "pruning_ablation.csv"
        with open(csv_path, "w", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=rows[0].keys())
            writer.writeheader()
            writer.writerows(rows)
        print(f"\nPruning results: {csv_path}")

    return rows


def run_compression_curves(datasets, seeds, k_values, out_dir, operator="random_walk",
                           prop_steps=5, quiet=True):
    """Run compression curves for each dataset at best k."""
    out_dir = Path(out_dir)
    all_comp_rows = []
    total = len(datasets) * len(seeds) * len(k_values)
    done = 0

    for dataset in datasets:
        dd = DATASET_DEFAULTS.get(dataset, {})
        epochs = min(dd.get("epochs", 50), 30)  # shorter for compression
        n_train = dd.get("n_train", 5000)
        n_val = dd.get("n_val", 1000)
        n_test = dd.get("n_test", 1000)

        for k in k_values:
            for seed in seeds:
                done += 1
                name = f"compress_{dataset}_k{k}_s{seed}"
                print(f"[{done}/{total}] {name}", end=" ... ", flush=True)

                t0 = time.time()
                res, _ = run_single(
                    dataset, k, "baseline", seed, out_dir, epochs,
                    n_train, n_val, n_test, operator, prop_steps, quiet,
                    compression_fractions=COMPRESSION_FRACTIONS,
                )
                elapsed = time.time() - t0

                # Read compression CSV
                comp_csv = out_dir / name / "compression.csv"
                if comp_csv.exists():
                    with open(comp_csv) as f:
                        for row in csv.DictReader(f):
                            row["dataset"] = dataset
                            row["k"] = k
                            row["seed"] = seed
                            all_comp_rows.append(row)
                    print(f"OK [{elapsed:.1f}s]")
                else:
                    print(f"NO CSV [{elapsed:.1f}s]")

    if all_comp_rows:
        csv_path = out_dir / "compression_curves.csv"
        with open(csv_path, "w", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=all_comp_rows[0].keys())
            writer.writeheader()
            writer.writerows(all_comp_rows)
        print(f"\nCompression curves: {csv_path}")

    return all_comp_rows


def compute_summary(rows):
    """Group by (dataset, k, condition), compute mean ± std."""
    import statistics
    groups = defaultdict(list)
    edge_groups = defaultdict(list)
    node_groups = defaultdict(list)
    for r in rows:
        acc = r.get("test_accuracy")
        if acc == "" or acc is None:
            continue
        key = (r["dataset"], r["k"], r["condition"])
        groups[key].append(float(acc))
        for field, grp in [("n_edges", edge_groups), ("n_nodes", node_groups)]:
            val = r.get(field)
            if val != "" and val is not None:
                try:
                    grp[key].append(float(val))
                except (ValueError, TypeError):
                    pass

    summary = []
    for (dataset, k, condition), accs in sorted(groups.items()):
        mean_acc = statistics.mean(accs)
        std_acc = statistics.stdev(accs) if len(accs) > 1 else 0.0
        edges = edge_groups.get((dataset, k, condition), [])
        nodes = node_groups.get((dataset, k, condition), [])
        mean_edges = statistics.mean(edges) if edges else 0
        mean_nodes = statistics.mean(nodes) if nodes else 0
        summary.append({
            "dataset": dataset, "k": k,
            "condition": condition,
            "condition_label": CONDITION_LABELS.get(condition, condition),
            "n_seeds": len(accs),
            "mean_acc": mean_acc, "std_acc": std_acc,
            "acc_str": f"{mean_acc:.3f} ± {std_acc:.3f}",
            "mean_nodes": int(mean_nodes),
            "mean_edges": int(mean_edges),
        })
    return summary


def compute_compression_summary(comp_rows):
    """Group compression data by (dataset, k, mode, fraction), compute mean ± std."""
    import statistics
    groups = defaultdict(list)
    for r in comp_rows:
        try:
            acc = float(r["ridge_val_acc"])
        except (ValueError, KeyError):
            continue
        key = (r["dataset"], int(r["k"]), r["mode"], float(r["fraction"]))
        groups[key].append(acc)

    summary = []
    for (dataset, k, mode, frac), accs in sorted(groups.items()):
        mean_acc = statistics.mean(accs)
        std_acc = statistics.stdev(accs) if len(accs) > 1 else 0.0
        summary.append({
            "dataset": dataset, "k": k, "mode": mode, "fraction": frac,
            "n_seeds": len(accs),
            "mean_acc": mean_acc, "std_acc": std_acc,
        })
    return summary


def write_latex_table(summary, out_dir):
    """Write LaTeX table: datasets × conditions, showing acc and edge count."""
    out_dir = Path(out_dir)
    lines = []
    lines.append(r"\begin{table}[t]")
    lines.append(r"\centering")
    lines.append(r"\caption{Structural pruning ablation: test accuracy (mean $\pm$ std over 5 seeds) "
                 r"with graph size (nodes/edges). Pruning reduces graph size while "
                 r"preserving or improving accuracy.}")
    lines.append(r"\label{tab:pruning}")
    lines.append(r"\begin{tabular}{llccc}")
    lines.append(r"\toprule")
    lines.append(r"Dataset & $k$ & No pruning & Geometric & Stability \\")
    lines.append(r"\midrule")

    # Group by (dataset, k)
    dk_pairs = sorted(set((s["dataset"], s["k"]) for s in summary))
    for dataset, k in dk_pairs:
        vals = {}
        for s in summary:
            if s["dataset"] == dataset and s["k"] == k:
                vals[s["condition"]] = (s["acc_str"], s["mean_nodes"], s["mean_edges"])

        ds_label = dataset.replace("_", r"\_").replace(r"sk\_", "")
        if dataset == "breast_cancer":
            ds_label = "Breast Cancer"
        elif dataset == "sk_moons":
            ds_label = "Two Moons"
        elif dataset == "sk_circles":
            ds_label = "Circles"
        elif dataset == "wine":
            ds_label = "Wine"
        elif dataset == "digits":
            ds_label = "Digits"

        # Find best condition
        best_cond = max(vals.keys(),
                        key=lambda c: float(vals[c][0].split(" ± ")[0]) if c in vals else 0)

        parts = [f"  {ds_label} & {k}"]
        for cond in ["baseline", "prune_geo", "prune_stab"]:
            if cond in vals:
                acc_str, nodes, edges = vals[cond]
                cell = f"{acc_str} ({nodes:,}/{edges:,})"
                if cond == best_cond and cond != "baseline":
                    cell = r"\textbf{" + cell + "}"
                parts.append(cell)
            else:
                parts.append("-")
        lines.append(" & ".join(parts) + r" \\")

    lines.append(r"\bottomrule")
    lines.append(r"\end{tabular}")
    lines.append(r"\end{table}")

    tex_path = out_dir / "pruning_table.tex"
    with open(tex_path, "w") as f:
        f.write("\n".join(lines))
    print(f"LaTeX table: {tex_path}")


def generate_compression_figure(comp_summary, out_dir):
    """Generate compression curve figure: accuracy vs retention fraction."""
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except ImportError:
        print("matplotlib not installed, skipping figure")
        return

    out_dir = Path(out_dir)
    datasets = sorted(set(s["dataset"] for s in comp_summary))
    k_values = sorted(set(s["k"] for s in comp_summary))
    # Use first k only for simplicity
    k = k_values[0] if k_values else 16
    n_ds = len(datasets)

    COLORS = {"random": "#6b7280", "pruning": "#2563eb"}
    MARKERS = {"random": "o", "pruning": "s"}
    LABELS = {"random": "Random deletion", "pruning": "Structural deletion"}

    fig, axes = plt.subplots(1, n_ds, figsize=(4.5 * n_ds, 3.5), squeeze=False)

    for i, dataset in enumerate(datasets):
        ax = axes[0, i]
        for mode in ["random", "pruning"]:
            data = sorted(
                [s for s in comp_summary
                 if s["dataset"] == dataset and s["k"] == k and s["mode"] == mode],
                key=lambda s: s["fraction"],
            )
            if not data:
                continue
            fracs = [s["fraction"] for s in data]
            means = [s["mean_acc"] for s in data]
            stds = [s["std_acc"] for s in data]
            ax.errorbar(
                fracs, means, yerr=stds,
                label=LABELS[mode], color=COLORS[mode],
                marker=MARKERS[mode], markersize=6,
                linewidth=1.8, capsize=3, capthick=1.2,
            )

        ds_label = dataset.replace("_", " ").replace("sk ", "").title()
        if dataset == "breast_cancer":
            ds_label = "Breast Cancer"
        ax.set_title(f"{ds_label} ($k$={k})", fontsize=13, fontweight="bold")
        ax.set_xlabel("Retention fraction", fontsize=11)
        if i == 0:
            ax.set_ylabel("Ridge val accuracy", fontsize=11)
        ax.set_xlim(0.05, 1.05)
        ax.grid(True, alpha=0.2)
        ax.tick_params(labelsize=10)

    handles, labels = axes[0, 0].get_legend_handles_labels()
    fig.legend(handles, labels, loc="upper center", ncol=2, fontsize=10,
               frameon=True, bbox_to_anchor=(0.5, 1.02))
    plt.tight_layout(rect=[0, 0, 1, 0.92])

    for ext in ["pdf", "png"]:
        fig.savefig(out_dir / f"compression_curves.{ext}", dpi=300, bbox_inches="tight")
    print(f"Compression figure: {out_dir / 'compression_curves.pdf'}")
    plt.close(fig)


def generate_pruning_figure(summary, out_dir):
    """Generate bar chart comparing pruning conditions."""
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
        import numpy as np
    except ImportError:
        print("matplotlib not installed, skipping figure")
        return

    out_dir = Path(out_dir)
    datasets = sorted(set(s["dataset"] for s in summary))
    # Use k=16 (or first available)
    k_pref = 16

    COLORS = {"baseline": "#6b7280", "prune_geo": "#2563eb", "prune_stab": "#059669"}

    dk_pairs = []
    for ds in datasets:
        available_k = sorted(set(s["k"] for s in summary if s["dataset"] == ds))
        k_use = k_pref if k_pref in available_k else available_k[0]
        dk_pairs.append((ds, k_use))

    n_groups = len(dk_pairs)
    n_conds = 3
    bar_width = 0.25

    fig, ax = plt.subplots(figsize=(3.5 * n_groups, 4))

    x = np.arange(n_groups)
    for j, cond in enumerate(["baseline", "prune_geo", "prune_stab"]):
        means, stds = [], []
        for ds, k in dk_pairs:
            match = [s for s in summary
                     if s["dataset"] == ds and s["k"] == k and s["condition"] == cond]
            if match:
                means.append(match[0]["mean_acc"])
                stds.append(match[0]["std_acc"])
            else:
                means.append(0)
                stds.append(0)

        ax.bar(x + j * bar_width, means, bar_width, yerr=stds,
               label=CONDITION_LABELS[cond], color=COLORS[cond],
               capsize=3, alpha=0.85)

    ds_labels = []
    for ds, k in dk_pairs:
        label = ds.replace("_", " ").replace("sk ", "").title()
        if ds == "breast_cancer":
            label = "Breast Cancer"
        ds_labels.append(f"{label}\n($k$={k})")

    ax.set_xticks(x + bar_width)
    ax.set_xticklabels(ds_labels, fontsize=10)
    ax.set_ylabel("Test accuracy", fontsize=11)
    ax.legend(fontsize=9, frameon=True)
    ax.grid(True, axis="y", alpha=0.2)
    ax.set_title("Structural Pruning Ablation", fontsize=13, fontweight="bold")
    plt.tight_layout()

    for ext in ["pdf", "png"]:
        fig.savefig(out_dir / f"pruning_accuracy.{ext}", dpi=300, bbox_inches="tight")
    print(f"Pruning figure: {out_dir / 'pruning_accuracy.pdf'}")
    plt.close(fig)


def load_existing(out_dir, filename):
    """Load existing CSV results."""
    path = Path(out_dir) / filename
    if not path.exists():
        return []
    rows = []
    with open(path) as f:
        for row in csv.DictReader(f):
            for k in ["k", "seed"]:
                if row.get(k):
                    try:
                        row[k] = int(row[k])
                    except ValueError:
                        pass
            for k in ["test_accuracy", "test_f1", "test_loss", "n_edges",
                       "ridge_val_acc", "fraction"]:
                if row.get(k):
                    try:
                        row[k] = float(row[k])
                    except (ValueError, TypeError):
                        pass
            rows.append(row)
    print(f"Loaded {len(rows)} rows from {path}")
    return rows


def main():
    p = argparse.ArgumentParser(
        description="Pruning & compression ablation for paper"
    )
    p.add_argument("--datasets", type=str, default="sk_moons,breast_cancer,sk_circles,digits,wine",
                   help="Comma-separated datasets")
    p.add_argument("--seeds", type=str, default="0,1,2,3,4",
                   help="Comma-separated seeds")
    p.add_argument("--k_values", type=str, default="8,16",
                   help="Comma-separated k values")
    p.add_argument("--operator", type=str, default="random_walk")
    p.add_argument("--prop_steps", type=int, default=5)
    p.add_argument("--out", type=str, default="outputs/pruning_ablation")
    p.add_argument("--plot_only", action="store_true")
    p.add_argument("--skip_compression", action="store_true",
                   help="Skip compression curves (faster)")
    p.add_argument("--verbose", action="store_true")

    args = p.parse_args()
    datasets = [d.strip() for d in args.datasets.split(",")]
    seeds = [int(s) for s in args.seeds.split(",")]
    k_values = [int(k) for k in args.k_values.split(",")]
    out_dir = args.out

    n_prune = len(datasets) * len(k_values) * len(CONDITIONS) * len(seeds)
    n_comp = len(datasets) * len(k_values) * len(seeds) if not args.skip_compression else 0

    print("=" * 60)
    print("PRUNING & COMPRESSION ABLATION")
    print(f"  Datasets:    {datasets}")
    print(f"  Seeds:       {seeds}")
    print(f"  k values:    {k_values}")
    print(f"  Conditions:  {list(CONDITION_LABELS.values())}")
    print(f"  Output:      {out_dir}")
    print(f"  Pruning runs:      {n_prune}")
    print(f"  Compression runs:  {n_comp}")
    print(f"  Total runs:        {n_prune + n_comp}")
    print("=" * 60)

    if args.plot_only:
        rows = load_existing(out_dir, "pruning_ablation.csv")
        comp_rows = load_existing(out_dir, "compression_curves.csv")
    else:
        # Phase A: Pruning ablation
        print("\n── PHASE A: Pruning Ablation ──")
        rows = run_pruning_ablation(
            datasets, seeds, k_values, out_dir,
            operator=args.operator, prop_steps=args.prop_steps,
            quiet=not args.verbose,
        )

        # Phase B: Compression curves
        comp_rows = []
        if not args.skip_compression:
            print("\n── PHASE B: Compression Curves ──")
            comp_rows = run_compression_curves(
                datasets, seeds, k_values, out_dir,
                operator=args.operator, prop_steps=args.prop_steps,
                quiet=not args.verbose,
            )

    # ── Analysis ──
    print("\n── ANALYSIS ──")

    if rows:
        summary = compute_summary(rows)

        # Print table
        print("\n" + "=" * 90)
        print("PRUNING SUMMARY: Test Accuracy (mean ± std)")
        print("=" * 90)
        print(f"{'Dataset':<18} {'k':>3} {'Condition':<22} {'Accuracy':>15} {'Nodes':>6} {'Edges':>8} {'n':>3}")
        print("-" * 90)
        for s in summary:
            print(f"{s['dataset']:<18} {s['k']:>3} {s['condition_label']:<22} "
                  f"{s['acc_str']:>15} {s['mean_nodes']:>6} {s['mean_edges']:>8} {s['n_seeds']:>3}")
        print("=" * 90)

        summary_path = Path(out_dir) / "pruning_summary.csv"
        with open(summary_path, "w", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=summary[0].keys())
            writer.writeheader()
            writer.writerows(summary)

        write_latex_table(summary, out_dir)
        generate_pruning_figure(summary, out_dir)

    if comp_rows:
        comp_summary = compute_compression_summary(comp_rows)
        if comp_summary:
            print("\nCOMPRESSION CURVE SUMMARY:")
            print(f"{'Dataset':<18} {'k':>3} {'Mode':<10} {'Frac':>5} {'Accuracy':>12}")
            print("-" * 55)
            for s in comp_summary:
                print(f"{s['dataset']:<18} {s['k']:>3} {s['mode']:<10} "
                      f"{s['fraction']:>5.1f} {s['mean_acc']:>8.4f} ± {s['std_acc']:.4f}")

            generate_compression_figure(comp_summary, out_dir)

    print(f"\nAll outputs in: {out_dir}")


if __name__ == "__main__":
    main()
