#!/usr/bin/env python3
"""Nested, exact-density endpoint-redirection curves on supplied graphs.

For each canonical undirected edge, one endpoint is selected uniformly at
random as the retained anchor and the other endpoint is replaced by a unique,
non-self endpoint. Replacement edges are generated once per (dataset, seed),
are disjoint from the original graph, and are applied in one fixed random
order. Therefore:
  * p=0 is exactly the original graph,
  * the number of undirected edges is constant at every dose,
  * exactly k/E_und original edges have been replaced at dose k, and
  * p=1 has zero retained original edges.

This removes the node-ID confound in the old implementation, which always kept
the numerically smaller endpoint.
"""
import argparse
import os
import sys
from pathlib import Path

os.environ.setdefault("OMP_NUM_THREADS", "4")

import numpy as np
import torch

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))
sys.path.insert(0, os.path.dirname(__file__))

from rebuttal_native_graph import row_normalize, symmetrize_dedup  # noqa: E402
from rebuttal_regimeB_extended import homophily, load_graph, propagate, ridge_acc  # noqa: E402
from run_real_experiments import _save_csv  # noqa: E402


def _canonical_edges(ei):
    u, v = ei[0], ei[1]
    mask = u < v
    return torch.stack([u[mask], v[mask]], dim=1)


def build_replacement_path(ei_sym, n, seed):
    """Return ordered original edges and unique disjoint replacement edges."""
    orig = _canonical_edges(ei_sym)
    e_und = len(orig)
    if e_und == 0:
        raise ValueError("graph has no undirected edges")

    rng = np.random.RandomState(seed)
    order = rng.permutation(e_und)
    orig_ordered = orig[torch.tensor(order, dtype=torch.long)]
    orig_set = {tuple(x) for x in orig.tolist()}
    repl_set = set()
    repl = []

    # Randomly keep either endpoint; never privilege the smaller node ID.
    keep_first = rng.randint(0, 2, size=e_und).astype(bool)
    max_attempts = max(1000, 100 * e_und)
    attempts = 0
    for i, (u, v) in enumerate(orig_ordered.tolist()):
        anchor = u if keep_first[i] else v
        while True:
            attempts += 1
            if attempts > max_attempts:
                raise RuntimeError(
                    "could not construct a unique disjoint replacement path; "
                    "the graph may be too dense for endpoint redirection"
                )
            other = int(rng.randint(0, n))
            if other == anchor:
                continue
            edge = (min(anchor, other), max(anchor, other))
            if edge in orig_set or edge in repl_set:
                continue
            repl_set.add(edge)
            repl.append(edge)
            break

    return orig_ordered, torch.tensor(repl, dtype=torch.long)


def dosed_graph(orig_ordered, repl_ordered, n, p):
    """Replace ceil(p*E) ordered original edges, preserving exact density."""
    if not 0.0 <= p <= 1.0:
        raise ValueError(f"dose p must lie in [0,1], got {p}")
    e_und = len(orig_ordered)
    k = int(np.ceil(p * e_und))
    canon = torch.cat([repl_ordered[:k], orig_ordered[k:]], dim=0)
    if len(canon) != e_und:
        raise AssertionError("edge count changed")
    ei = torch.cat([canon.T, canon[:, [1, 0]].T], dim=1)
    keys = ei[0] * n + ei[1]
    if torch.unique(keys).numel() != ei.shape[1]:
        raise AssertionError("duplicate directed edges in dose graph")
    return ei, k / e_und, k


def edge_overlap_fraction(ei, original):
    a = {tuple(x) for x in _canonical_edges(ei).tolist()}
    b = {tuple(x) for x in _canonical_edges(original).tolist()}
    return len(a & b) / max(len(b), 1)


def _parse_list(value):
    return [x.strip() for x in value.split(",") if x.strip()]


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--datasets", default="cora,citeseer,pubmed")
    p.add_argument("--seeds", default="0,1,2")
    p.add_argument("--levels", default="0,0.1,0.25,0.5,0.75,1")
    p.add_argument("--out", default="outputs/rebuttal")
    a = p.parse_args()

    datasets = _parse_list(a.datasets)
    seeds = [int(s) for s in _parse_list(a.seeds)]
    levels = [float(x) for x in _parse_list(a.levels)]
    if not levels or any(x < 0 or x > 1 for x in levels):
        p.error("all --levels must lie in [0,1]")
    if levels != sorted(levels) or len(levels) != len(set(levels)):
        p.error("--levels must be unique and sorted")

    from scipy.stats import spearmanr

    rows = []
    out_path = Path(a.out) / "rebuttal_alpha_native.csv"
    for ds in datasets:
        for seed in seeds:
            torch.manual_seed(seed)
            x, y, ei_raw, trm, vam, tem, _tr_missing = load_graph(ds, seed)
            del vam
            x = row_normalize(x)
            n, nc = x.shape[0], int(y.max()) + 1
            ei = symmetrize_dedup(ei_raw)
            # Reduce to a simple graph: strip self-loops uniformly.
            # The operator P = D^-1(A+I) supplies every node's
            # self-connection itself, so raw loops (present in WebKB)
            # are redundant with +I and are not part of the
            # connectivity being intervened on.
            ei = ei[:, ei[0] != ei[1]]
            orig_ordered, repl_ordered = build_replacement_path(ei, n, seed)

            accs, actual_levels = [], []
            for requested in levels:
                eid, actual, k = dosed_graph(orig_ordered, repl_ordered, n, requested)
                overlap = edge_overlap_fraction(eid, ei)
                expected_overlap = 1.0 - actual
                if abs(overlap - expected_overlap) > 1e-12:
                    raise AssertionError(
                        f"overlap mismatch: observed={overlap}, expected={expected_overlap}"
                    )
                h = propagate(x, eid, n)
                acc = ridge_acc(h, y, trm, tem, nc)
                htr, n_htr = homophily(eid, y, trm)
                accs.append(acc)
                actual_levels.append(actual)
                rows.append({
                    "dataset": ds,
                    "seed": seed,
                    "p_requested": requested,
                    "p_actual": actual,
                    "edges_replaced": k,
                    "E_und": len(orig_ordered),
                    "edge_overlap": overlap,
                    "acc": acc,
                    "hom_train": htr,
                    "hom_train_edges": n_htr,
                })

            rho = spearmanr(actual_levels, accs).correlation
            _save_csv(rows, out_path)
            print(
                f"  {ds} s{seed}: "
                + " ".join(
                    f"p{req:g}/{act:.4f}={acc:.3f}"
                    for req, act, acc in zip(levels, actual_levels, accs)
                )
                + f"  rho={rho:+.3f}",
                flush=True,
            )


if __name__ == "__main__":
    main()
