#!/usr/bin/env python3
"""Geometric Machine Training CLI.

Tests the hypothesis: geometry IS computation.
Fixed propagation operators + weak readout head.
All variation comes from graph construction.

Usage:
    # Single run (transductive, default)
    python scripts/train_gm.py --dataset sk_moons --graph_type knn --operator random_walk

    # Inductive anchor mode
    python scripts/train_gm.py --dataset mnist --gm_mode inductive_anchor_graph --anchor_k 8

    # With config
    python scripts/train_gm.py --config experiments/configs/gm_moons.yaml

    # Override config
    python scripts/train_gm.py --config experiments/configs/gm_moons.yaml --graph_type mutual_knn --k 8
"""
import argparse
import sys
import os
import yaml

os.environ.setdefault("OMP_NUM_THREADS", "1")
os.environ.setdefault("MKL_NUM_THREADS", "1")

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from vghl.utils.seed import set_seed
from vghl.utils.logging import get_logger
from vghl.data.loaders import build_datasets, build_dataloaders
from vghl.utils.config import ExperimentConfig
from vghl.models.graph_builder import GraphBuilderConfig
from vghl.models.propagation import PropagationConfig
from vghl.models.pruning import PruningConfig
from vghl.models.primitives import PrimitiveConfig
from vghl.models.anchor_graph import AnchorGraphConfig
from vghl.models.recursion import RecursionConfig
from vghl.models.geometric_machine import GeometricMachine
from vghl.train.gm_trainer import GMTrainer

import torch
from pathlib import Path

logger = get_logger("vghl.gm")


def parse_args():
    p = argparse.ArgumentParser(description="Geometric Machine Experiments")

    # Meta
    p.add_argument("--config", type=str, default=None, help="YAML config file")
    p.add_argument("--name", type=str, default=None, help="Run name")
    p.add_argument("--seed", type=int, default=0)
    p.add_argument("--out", type=str, default="outputs/gm")
    p.add_argument("--device", type=str, default="auto")

    # Data
    p.add_argument("--dataset", type=str, default="sk_moons",
                    help="Dataset: sk_moons|sk_circles|sk_swiss_roll|sk_s_curve|sk_blobs_noisy|"
                         "mnist|mnist_embed|fashion_mnist|wine|breast_cancer|digits|iris|"
                         "cifar10_pca|cifar10_resnet18|"
                         "ionosphere|sonar|hepatitis|vehicle|spambase|eeg_eye_state|"
                         "phoneme|hill_valley|haberman|saheart|bupa|spectf|"
                         "piecewise2d|spirals|blobs")
    p.add_argument("--n_train", type=int, default=5000)
    p.add_argument("--n_val", type=int, default=1000)
    p.add_argument("--n_test", type=int, default=1000)
    p.add_argument("--noise_sigma", type=float, default=0.1)

    # GM Mode (anchor graph)
    p.add_argument("--gm_mode", type=str, default="transductive_full_graph",
                    choices=["transductive_full_graph", "inductive_anchor_graph"],
                    help="Graph construction mode")
    p.add_argument("--anchor_k", type=int, default=8, help="k nearest anchors for query attachment")
    p.add_argument("--bipartite_steps", type=int, default=1, help="Propagation steps on bipartite edges")
    p.add_argument("--rebuild_graph_every", type=int, default=0,
                    help="Rebuild graph every N epochs (0=never, useful with learned embeddings)")

    # Graph Builder
    p.add_argument("--graph_type", type=str, default="knn",
                    choices=["knn", "mutual_knn", "epsilon", "adaptive_radius",
                             "mst_shortcuts", "gabriel", "hybrid"])
    p.add_argument("--k", type=int, default=16, help="kNN neighbors")
    p.add_argument("--epsilon", type=float, default=0.5, help="Epsilon for radius graph")
    p.add_argument("--adaptive_percentile", type=float, default=0.9)
    p.add_argument("--mst_shortcuts", type=int, default=4)
    p.add_argument("--hybrid_long_k", type=int, default=1)
    p.add_argument("--weight_mode", type=str, default="gaussian",
                    choices=["gaussian", "binary", "inverse_dist"])
    p.add_argument("--graph_sigma", type=float, default=1.0, help="Gaussian bandwidth")
    p.add_argument("--control", type=str, default="none",
                    choices=["none", "random_destination", "degree_preserving_rewire"],
                    help="Causal control: destroy geometry while preserving degree structure")
    p.add_argument("--symmetrize", action="store_true", default=True,
                    help="Symmetrize graph (default: True)")
    p.add_argument("--no_symmetrize", dest="symmetrize", action="store_false",
                    help="Disable graph symmetrization")

    # Propagation Operator
    p.add_argument("--operator", type=str, default="random_walk",
                    choices=["identity", "random_walk", "ppr", "heat", "laplacian", "gated"])
    p.add_argument("--prop_steps", type=int, default=5, help="Diffusion steps")
    p.add_argument("--ppr_alpha", type=float, default=0.15, help="PPR teleport probability")
    p.add_argument("--heat_t", type=float, default=1.0, help="Heat kernel time")

    # Pruning
    p.add_argument("--prune", action="store_true", help="Enable pruning")
    p.add_argument("--prune_methods", type=str, default="geometric",
                    help="Comma-separated: geometric,stability,label_consistency")
    p.add_argument("--prune_density_lo", type=float, default=0.05)
    p.add_argument("--prune_density_hi", type=float, default=0.95)
    p.add_argument("--prune_edge_pct", type=float, default=0.95)
    p.add_argument("--prune_n_bootstrap", type=int, default=5)
    p.add_argument("--prune_perturb_sigma", type=float, default=0.01)
    p.add_argument("--prune_node_jaccard_min", type=float, default=0.5)
    p.add_argument("--prune_label_agreement_min", type=float, default=0.3)

    # Primitives
    p.add_argument("--primitives", type=str, default="",
                    help="Comma-separated primitive types: triangle,star,clique_4,path_3,cycle_4")
    p.add_argument("--max_primitives", type=int, default=200)
    p.add_argument("--primitive_min_quality", type=float, default=0.0)
    p.add_argument("--primitives_in_propagation", action="store_true",
                    help="Phase 2: use primitives in forward computation path")

    # Recursion (Phase 2)
    p.add_argument("--recursion", action="store_true", help="Enable multilevel recursion")
    p.add_argument("--recursion_depth", type=int, default=1)
    p.add_argument("--port_rule", type=str, default="boundary_top2",
                    choices=["boundary_top2", "boundary_topk", "medoid", "farthest_pair",
                             "all_vertices", "endpoints"])
    p.add_argument("--wiring_rule", type=str, default="shared_boundary",
                    choices=["shared_boundary", "port_knn"])
    p.add_argument("--wiring_k", type=int, default=4)
    p.add_argument("--pool_mode", type=str, default="mean", choices=["mean", "max"])

    # Multilevel compute
    p.add_argument("--multilevel_scheme", type=str, default="bottom_up_top_down",
                    choices=["bottom_up_top_down", "bottom_up_only"])
    p.add_argument("--steps_per_level", type=int, default=3)
    p.add_argument("--fusion_mode", type=str, default="sum", choices=["sum", "replace"])
    p.add_argument("--top_down_scale", type=float, default=0.5)
    p.add_argument("--query_assignment", type=str, default="nearest_anchor",
                    choices=["nearest_anchor", "nearest_port"])

    # Merge (Phase 2)
    p.add_argument("--merge", action="store_true", help="Enable behavioral equivalence merging")
    p.add_argument("--merge_tau", type=float, default=0.95)
    p.add_argument("--merge_max", type=int, default=50)

    # Edit loop (Phase 2 structural search)
    p.add_argument("--edit_loop", action="store_true")
    p.add_argument("--edit_loop_iters", type=int, default=3)
    p.add_argument("--edit_alpha", type=float, default=0.01)
    p.add_argument("--edit_beta", type=float, default=0.01)
    p.add_argument("--edit_gamma", type=float, default=0.1)
    p.add_argument("--edit_max_proposals", type=int, default=50,
                    help="Max total proposals before forced stop in edit loop")
    p.add_argument("--edit_max_no_improve", type=int, default=2,
                    help="Consecutive no-improve iterations before stopping")

    # Head
    p.add_argument("--head", type=str, default="linear", choices=["linear", "mlp"])
    p.add_argument("--head_hidden", type=int, default=64)
    p.add_argument("--head_dropout", type=float, default=0.1)

    # Embedding (for high-dim data like MNIST)
    p.add_argument("--embed_dim", type=int, default=None,
                    help="If set, add learned embedding projection")
    p.add_argument("--train_embed", action="store_true",
                    help="Train embedding alongside head (requires --rebuild_graph_every>=1)")

    # Training
    p.add_argument("--epochs", type=int, default=100)
    p.add_argument("--batch_size", type=int, default=256)
    p.add_argument("--lr", type=float, default=1e-3)
    p.add_argument("--weight_decay", type=float, default=1e-4)
    p.add_argument("--early_stop", type=int, default=30)
    p.add_argument("--log_machine_every", type=int, default=5)
    p.add_argument("--compression_fractions", type=str, default="",
                    help="Comma-separated retention fractions for compression curve, "
                         "e.g. 1.0,0.8,0.6,0.4,0.2")

    # Quiet
    p.add_argument("--quiet", action="store_true")

    return p, p.parse_args()


def main():
    p, args = parse_args()

    # Load YAML config if provided
    yaml_cfg = {}
    if args.config is not None:
        with open(args.config) as f:
            yaml_cfg = yaml.safe_load(f) or {}

    # Build configs from CLI + YAML (CLI overrides YAML)
    # CLI wins if user explicitly set it (differs from argparse default), else YAML, else default.
    _defaults = {}
    for a in p._actions:
        if a.dest != 'help':
            _defaults[a.dest] = a.default

    def _resolve(dest, yaml_sect, yaml_key):
        """Return CLI value if explicitly set, else YAML value, else argparse default."""
        cli_val = getattr(args, dest)
        yaml_val = yaml_sect.get(yaml_key) if isinstance(yaml_sect, dict) else None
        if cli_val != _defaults.get(dest):
            return cli_val
        if yaml_val is not None:
            return yaml_val
        return cli_val

    seed = _resolve("seed", yaml_cfg, "seed")
    set_seed(seed)

    device = _resolve("device", yaml_cfg, "device")
    if device == "auto":
        device = "cuda" if torch.cuda.is_available() else "cpu"

    # Data config
    data_cfg = yaml_cfg.get("data", {})
    dataset = _resolve("dataset", data_cfg, "dataset")
    n_train = _resolve("n_train", data_cfg, "n_train")
    n_val = _resolve("n_val", data_cfg, "n_val")
    n_test = _resolve("n_test", data_cfg, "n_test")
    noise_sigma = _resolve("noise_sigma", data_cfg, "noise_sigma")

    # Build ExperimentConfig for data loading
    exp_cfg = ExperimentConfig()
    exp_cfg.data.dataset = dataset
    exp_cfg.data.n_train = n_train
    exp_cfg.data.n_val = n_val
    exp_cfg.data.n_test = n_test
    exp_cfg.data.noise_sigma = noise_sigma
    exp_cfg.seed = seed
    exp_cfg.train.batch_size = args.batch_size

    # Load data
    train_ds, val_ds, test_ds, meta = build_datasets(exp_cfg)
    train_loader, val_loader, test_loader = build_dataloaders(train_ds, val_ds, test_ds, exp_cfg)
    input_dim = meta.get("d", meta.get("input_dim", train_ds.X.shape[1]))
    n_classes = meta.get("n_classes", exp_cfg.data.n_classes)

    logger.info(f"Data: {dataset} | train={len(train_ds)}, dim={input_dim}, classes={n_classes}")

    # Graph Builder Config
    gb_yaml = yaml_cfg.get("graph_builder", {})
    graph_cfg = GraphBuilderConfig(
        type=gb_yaml.get("type", args.graph_type),
        k=gb_yaml.get("k", args.k),
        epsilon=gb_yaml.get("epsilon", args.epsilon),
        adaptive_percentile=gb_yaml.get("adaptive_percentile", args.adaptive_percentile),
        mst_shortcuts=gb_yaml.get("mst_shortcuts", args.mst_shortcuts),
        hybrid_long_k=gb_yaml.get("hybrid_long_k", args.hybrid_long_k),
        weight_mode=gb_yaml.get("weight_mode", args.weight_mode),
        sigma=gb_yaml.get("sigma", args.graph_sigma),
        symmetrize=gb_yaml.get("symmetrize", args.symmetrize),
        control=gb_yaml.get("control", args.control),
    )

    # Propagation Config
    prop_yaml = yaml_cfg.get("operator", {})
    prop_cfg = PropagationConfig(
        type=prop_yaml.get("type", args.operator),
        steps=prop_yaml.get("steps", args.prop_steps),
        alpha=prop_yaml.get("alpha", args.ppr_alpha),
        t=prop_yaml.get("t", args.heat_t),
    )

    # Anchor Graph Config
    anchor_yaml = yaml_cfg.get("anchor", {})
    anchor_cfg = AnchorGraphConfig(
        mode=anchor_yaml.get("mode", args.gm_mode),
        anchor_k=anchor_yaml.get("anchor_k", args.anchor_k),
        bipartite_steps=anchor_yaml.get("bipartite_steps", args.bipartite_steps),
    )

    # Pruning Config
    prune_yaml = yaml_cfg.get("pruning", {})
    pruning_cfg = None
    if args.prune or prune_yaml.get("enabled", False):
        methods_str = args.prune_methods if args.prune else prune_yaml.get("methods", "geometric")
        methods = [m.strip() for m in methods_str.split(",")]
        pruning_cfg = PruningConfig(
            enabled=True,
            methods=methods,
            density_percentile_low=prune_yaml.get("density_percentile_low", args.prune_density_lo),
            density_percentile_high=prune_yaml.get("density_percentile_high", args.prune_density_hi),
            edge_length_percentile=prune_yaml.get("edge_length_percentile", args.prune_edge_pct),
            n_bootstrap=prune_yaml.get("n_bootstrap", args.prune_n_bootstrap),
            perturb_sigma=prune_yaml.get("perturb_sigma", args.prune_perturb_sigma),
            node_jaccard_min=prune_yaml.get("node_jaccard_min", args.prune_node_jaccard_min),
            label_agreement_min=prune_yaml.get("label_agreement_min", args.prune_label_agreement_min),
        )

    # Primitives Config
    prim_yaml = yaml_cfg.get("primitives", {})
    prim_cfg = None
    prim_types_str = args.primitives or prim_yaml.get("types", "")
    if prim_types_str:
        prim_types = [t.strip() for t in prim_types_str.split(",") if t.strip()]
        prim_cfg = PrimitiveConfig(
            types=prim_types,
            max_primitives_per_type=prim_yaml.get("max_per_type", args.max_primitives),
            min_quality=prim_yaml.get("min_quality", args.primitive_min_quality),
            use_in_propagation=args.primitives_in_propagation or prim_yaml.get("use_in_propagation", False),
        )

    # Recursion Config
    rec_yaml = yaml_cfg.get("recursion", {})
    recursion_cfg = RecursionConfig(
        enabled=args.recursion or rec_yaml.get("enabled", False),
        depth=rec_yaml.get("depth", args.recursion_depth),
        port_rule=rec_yaml.get("port_rule", args.port_rule),
        wiring_rule=rec_yaml.get("wiring_rule", args.wiring_rule),
        wiring_k=rec_yaml.get("wiring_k", args.wiring_k),
        pool_mode=rec_yaml.get("pool_mode", args.pool_mode),
    )

    # Multilevel Compute Config
    from vghl.models.multilevel_compute import MultilevelComputeConfig
    ml_yaml = yaml_cfg.get("multilevel", {})
    multilevel_cfg = MultilevelComputeConfig(
        scheme=ml_yaml.get("scheme", args.multilevel_scheme),
        steps_per_level=ml_yaml.get("steps_per_level", args.steps_per_level),
        pool_mode=ml_yaml.get("pool_mode", args.pool_mode),
        fusion_mode=ml_yaml.get("fusion_mode", args.fusion_mode),
        top_down_scale=ml_yaml.get("top_down_scale", args.top_down_scale),
        query_assignment=ml_yaml.get("query_assignment", args.query_assignment),
    )

    # Merge Config
    from vghl.models.merge import MergeConfig
    merge_yaml = yaml_cfg.get("merge", {})
    merge_cfg = MergeConfig(
        enabled=args.merge or merge_yaml.get("enabled", False),
        tau=merge_yaml.get("tau", args.merge_tau),
        max_merges_per_level=merge_yaml.get("max_merges", args.merge_max),
    )

    # Edit Loop Config
    from vghl.models.edit_loop import EditLoopConfig
    el_yaml = yaml_cfg.get("edit_loop", {})
    edit_loop_cfg = EditLoopConfig(
        enabled=args.edit_loop or el_yaml.get("enabled", False),
        max_iterations=el_yaml.get("max_iterations", args.edit_loop_iters),
        alpha_nodes=el_yaml.get("alpha", args.edit_alpha),
        beta_edges=el_yaml.get("beta", args.edit_beta),
        gamma_instability=el_yaml.get("gamma", args.edit_gamma),
        try_merge=args.merge or el_yaml.get("try_merge", True),
        max_proposals=el_yaml.get("max_proposals", args.edit_max_proposals),
        max_no_improve=el_yaml.get("max_no_improve", args.edit_max_no_improve),
    )

    # Head config
    head_yaml = yaml_cfg.get("head", {})
    head_type = head_yaml.get("type", args.head)
    head_hidden = head_yaml.get("hidden", args.head_hidden)
    head_dropout = head_yaml.get("dropout", args.head_dropout)

    # Embedding
    embed_dim = yaml_cfg.get("embed_dim", args.embed_dim)

    # Build model
    model = GeometricMachine(
        input_dim=input_dim,
        n_classes=n_classes,
        graph_cfg=graph_cfg,
        prop_cfg=prop_cfg,
        anchor_cfg=anchor_cfg,
        pruning_cfg=pruning_cfg,
        primitive_cfg=prim_cfg,
        recursion_cfg=recursion_cfg,
        multilevel_cfg=multilevel_cfg,
        merge_cfg=merge_cfg,
        edit_loop_cfg=edit_loop_cfg,
        head_type=head_type,
        head_hidden=head_hidden,
        head_dropout=head_dropout,
        embed_dim=embed_dim,
    )

    n_params = sum(p.numel() for p in model.parameters())
    logger.info(
        f"Model: mode={anchor_cfg.mode}, graph={graph_cfg.type}, "
        f"op={prop_cfg.type}, head={head_type}, params={n_params:,}"
    )

    # Run name
    name = args.name
    if name is None:
        name = f"gm_{dataset}_{graph_cfg.type}_{prop_cfg.type}_{head_type}_k{graph_cfg.k}_s{seed}"
    run_dir = Path(args.out) / name

    # Save config
    run_dir.mkdir(parents=True, exist_ok=True)
    full_config = {
        "name": name, "seed": seed, "device": device,
        "data": {"dataset": dataset, "n_train": n_train, "n_val": n_val,
                 "n_test": n_test, "noise_sigma": noise_sigma, "input_dim": input_dim,
                 "n_classes": n_classes},
        "graph_builder": vars(graph_cfg),
        "operator": vars(prop_cfg),
        "anchor": vars(anchor_cfg),
        "pruning": vars(pruning_cfg) if pruning_cfg else {"enabled": False},
        "primitives": vars(prim_cfg) if prim_cfg else {"types": []},
        "recursion": vars(recursion_cfg),
        "head": {"type": head_type, "hidden": head_hidden, "dropout": head_dropout},
        "embed_dim": embed_dim,
        "training": {"epochs": args.epochs, "lr": args.lr, "weight_decay": args.weight_decay,
                      "batch_size": args.batch_size, "early_stop": args.early_stop},
    }
    with open(run_dir / "config.yaml", "w") as f:
        yaml.dump(full_config, f, default_flow_style=False, sort_keys=False)

    # Parse compression fractions
    comp_fracs = []
    comp_str = args.compression_fractions
    if comp_str:
        comp_fracs = [float(x.strip()) for x in comp_str.split(",") if x.strip()]

    # Train
    trainer = GMTrainer(
        model=model,
        train_loader=train_loader,
        val_loader=val_loader,
        test_loader=test_loader,
        n_classes=n_classes,
        device=device,
        run_dir=run_dir,
        lr=args.lr,
        weight_decay=args.weight_decay,
        epochs=args.epochs,
        early_stop_patience=args.early_stop,
        log_machine_every=args.log_machine_every,
        rebuild_graph_every=args.rebuild_graph_every,
        compression_fractions=comp_fracs,
        train_embed=args.train_embed,
    )

    results = trainer.train()

    # Inject CLI config into results.json for reproducibility
    import json as _json
    results_path = run_dir / "results.json"
    if results_path.exists():
        with open(results_path) as f:
            res_data = _json.load(f)
        res_data["config"] = {k: v for k, v in vars(args).items()
                              if not k.startswith("_")}
        with open(results_path, "w") as f:
            _json.dump(res_data, f, indent=2, default=str)

    logger.info(f"Outputs: {run_dir}")
    return results


if __name__ == "__main__":
    main()
